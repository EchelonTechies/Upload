﻿using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.DataAccess;
using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;

namespace IndRa.RiskModel.Helpers
{
    public class Email
    {
        IndRaDBcontext dbContext = new IndRaDBcontext();

        private string ServerName { get; set; }

        private int PortNumber { get; set; }

        private string Username { get; set; }

        private string Password { get; set; }

        private MailAddress FromAddress { get; set; }

        private string Subject { get; set; }

        private string MessageBody { get; set; }

        private List<MailAddress> Recipients { get; set; }

        private List<MailAddress> RecipientsAtCC { get; set; }

        private List<Attachment> Attachments { get; set; }

        public static bool SendPasswordResetLink(string firstName, string lastName, string toAddress, string activationCode)
        {
            try
            {
                using (IndRaDBcontext dbContext = new IndRaDBcontext())
                {
                    EmailTemplateDAL emailTemplateDAL = new EmailTemplateDAL(dbContext);
                    int templateID = (int)EmailTemplateEnum.PasswordResetTemplate;
                    EmailTemplate userPasswordResetTemplate = emailTemplateDAL.GetByID(templateID);

                    StringBuilder messageBody = new StringBuilder();
                    messageBody.Append(userPasswordResetTemplate.Template);
                    string activationLink = string.Format("{0}/Account/PasswordReset?emailAddress={1}&activationCode={2}", ConfigManager.GetRiskModelUrl(), toAddress, activationCode);
                    messageBody.Replace("{Username}", firstName + " " + lastName);
                    messageBody.Replace("{PasswordResetLink}", activationLink);

                    Email email = new Email
                    {
                        ServerName = ConfigManager.GetSMTPServerName(),
                        Username = ConfigManager.GetSMTPUsername(),
                        Password = ConfigManager.GetSMTPPassword(),
                        PortNumber = Convert.ToInt32(ConfigManager.GetSMTPPortNumber()),
                        FromAddress = new MailAddress(ConfigManager.GetSMTPFromAddress()),
                        Subject = userPasswordResetTemplate.EmailSubject,
                        MessageBody = messageBody.ToString(),
                        Recipients = new List<MailAddress> { new MailAddress(toAddress) }
                    };

                    return email.Send();
                }
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, new object());
                return false;
            }
        }

        public static bool SendMail(string toAddress, string companyName, int templateID)
        {
            try
            {
                using (IndRaDBcontext dbContext = new IndRaDBcontext())
                {
                    EmailTemplateDAL emailTemplateDAL = new EmailTemplateDAL(dbContext);
                    EmailTemplate userPasswordResetTemplate = emailTemplateDAL.GetByID(templateID);

                    StringBuilder messageBody = new StringBuilder();
                    messageBody.Append(userPasswordResetTemplate.Template);
                    messageBody.Replace("{CompanyName}", companyName);
                    //messageBody.Replace("{PasswordResetLink}", activationLink);

                    Email email = new Email
                    {
                        ServerName = ConfigManager.GetSMTPServerName(),
                        Username = ConfigManager.GetSMTPUsername(),
                        Password = ConfigManager.GetSMTPPassword(),
                        PortNumber = Convert.ToInt32(ConfigManager.GetSMTPPortNumber()),
                        FromAddress = new MailAddress(ConfigManager.GetSMTPFromAddress()),
                        Subject = userPasswordResetTemplate.EmailSubject,
                        MessageBody = messageBody.ToString(),
                        Recipients = new List<MailAddress> { new MailAddress(toAddress) }
                    };

                    return email.Send();
                }
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, new object());
                return false;
            }
        }
        private bool Send()
        {

            MailMessage mailMessage = new MailMessage();
            mailMessage.From = this.FromAddress;


            foreach (MailAddress recipient in this.Recipients)
            {
                if (this.Recipients.Count == 1)
                {
                    mailMessage.To.Add(this.Recipients[0]);
                }
                else
                {
                    mailMessage.To.Add(recipient);
                }
            }

            if (this.RecipientsAtCC != null)
            {
                foreach (MailAddress recipient in this.RecipientsAtCC)
                {
                    mailMessage.CC.Add(recipient);
                }
            }
            if (this.Attachments != null)
            {
                foreach (Attachment attachment in this.Attachments)
                {
                    if (attachment != null)
                    {
                        mailMessage.Attachments.Add(attachment);
                    }
                }
            }

            mailMessage.IsBodyHtml = true;
            mailMessage.Subject = this.Subject;
            mailMessage.Body = this.MessageBody;
            //newly added 04July
            mailMessage.SubjectEncoding = System.Text.Encoding.UTF8;
            mailMessage.BodyEncoding = System.Text.Encoding.UTF8;
            mailMessage.HeadersEncoding = Encoding.UTF8;

            SmtpClient smtpClient = new SmtpClient();
            smtpClient.Port = this.PortNumber;
            smtpClient.Host = this.ServerName;
            smtpClient.EnableSsl = true;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.Credentials = new System.Net.NetworkCredential(this.Username, this.Password);
            smtpClient.Send(mailMessage);
            return true;
        }
    }
}