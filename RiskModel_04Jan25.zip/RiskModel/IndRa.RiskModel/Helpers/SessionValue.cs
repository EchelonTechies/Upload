﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndRa.RiskModel.Helpers
{
    public class SessionValue
    {
        public static string RISKMODEL_FILE_PATH
        {
            get
            {
                return Convert.ToString(HttpContext.Current.Session["RISKMODEL_FILE_PATH"]);
            }
            set
            {
                HttpContext.Current.Session["RISKMODEL_FILE_PATH"] = value;
            }
        }
        public static void SetSuccessMessage(string message)
        {
            HttpContext.Current.Session["SUCCESS"] = message;
        }

        public static void SetErrorMessage(string message)
        {
            HttpContext.Current.Session["ERROR"] = message;
        }


        public static string UserName
        {
            get
            {
                return Convert.ToString(HttpContext.Current.Session["UserName"]);
            }
            set
            {
                HttpContext.Current.Session["UserName"] = value;
            }

        }
        public static int UserID
        {
            get
            {
                return Convert.ToInt32(HttpContext.Current.Session["UserID"]);
            }
            set
            {
                HttpContext.Current.Session["UserID"] = value;
            }

        }
        public static int RoleID
        {
            get
            {
                return Convert.ToInt32(HttpContext.Current.Session["RoleID"]);
            }
            set
            {
                HttpContext.Current.Session["RoleID"] = value;
            }

        }
    }
}