﻿using IndRa.BLL;
using IndRa.UI.Helpers;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Linq;
using System.Web;
using System.Web.Security;

namespace IndRa.Admin.Helpers
{
    public class HarrierRoleProvider : RoleProvider
    {
        private string _AppName;
        private string _DatabaseFileName;
        private int _ApplicationId = 0;
        private DateTime _ApplicationIDCacheDate;

        public override void Initialize(string name, NameValueCollection config)
        {

            if (config == null)
                throw new ArgumentNullException("config");

            if (String.IsNullOrEmpty(name))
                name = "AccessRoleProvider";

            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "$safeprojectname$ Role Provider");
            }

            base.Initialize(name, config);

            _DatabaseFileName = config["connectionStringName"];
            if (_DatabaseFileName == null || _DatabaseFileName.Length < 1)
                throw new ProviderException("Connection name not specified");

            _AppName = config["applicationName"];
            if (string.IsNullOrEmpty(_AppName))
                _AppName = SecUtility.GetDefaultAppName();

            if (_AppName.Length > 255)
            {
                throw new ProviderException("Provider application name too long, max is 255.");
            }

            config.Remove("connectionStringName");
            config.Remove("applicationName");
            config.Remove("description");
            if (config.Count > 0)
            {
                string attribUnrecognized = config.GetKey(0);
                if (!String.IsNullOrEmpty(attribUnrecognized))
                    throw new ProviderException("Provider unrecognized attribute: " + attribUnrecognized);
            }
        }

        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {

        }

        public override string ApplicationName
        {
            get { return _AppName; }
            set
            {
                if (_AppName != value)
                {
                    _ApplicationId = 0;
                    _AppName = value;
                }
            }
        }

        public override void CreateRole(string roleName)
        {
            SecUtility.CheckParameter(ref roleName, true, true, true, 255, "roleName");
            try
            {
                throw new ProviderException("Unknown provider failure");
            }
            catch
            {
                throw;
            }
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            return false;
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            return null;
        }

        public override string[] GetAllRoles()
        {
            try
            {
                UserBLL userBLL = new UserBLL();
                string[] roles = userBLL.GetAllRoles();
                if(roles != null && roles.Count() > 0)
                {
                    return roles;
                }
                else
                {
                    return new string[0];
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public override string[] GetRolesForUser(string username)
        {
            SecUtility.CheckParameter(ref username, true, false, true, 255, "username");
            if (username.Length < 1)
                return new string[0];
            try
            {
                UserBLL userBLL = new UserBLL();
                string[] roles = userBLL.GetUserRoles(username);
                if (roles != null && roles.Count() > 0)
                {
                    return roles;
                }
                else
                {
                    return new string[0];
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public override string[] GetUsersInRole(string roleName)
        {
            SecUtility.CheckParameter(ref roleName, true, true, true, 255, "roleName");
            StringCollection sc = new StringCollection();

            try
            {
                UserBLL userBLL = new UserBLL();
                string[] userList = userBLL.GetUsersInRole(roleName);
                if (userList != null && userList.Count() > 0)
                {
                    return userList;
                }
                else
                {
                    return new string[0];
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public override bool IsUserInRole(string username, string roleName)
        {
            SecUtility.CheckParameter(ref username, true, false, true, 255, "username");
            if (username.Length < 1)
                return false;
            SecUtility.CheckParameter(ref roleName, true, true, true, 255, "roleName");

            try
            {
                UserBLL userBLL = new UserBLL();
                return userBLL.IsUserInRole(username, roleName);
            }
            catch
            {
                throw;
            }
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {

        }

        public override bool RoleExists(string roleName)
        {
            try
            {
                SecUtility.CheckParameter(ref roleName, true, true, true, 255, "roleName");
            }
            catch
            {
                return false;
            }
            try
            {
                UserBLL userBLL = new UserBLL();
                int roleId = userBLL.GetRoleID(roleName);

                return (roleId > 0);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private bool CheckNull(string strValue)
        {
            if (string.IsNullOrEmpty(strValue) || strValue == "")
                return false;
            else
                return true;
        }

        private int GetApplicationId()
        {
            string appName = _AppName;
            if (!string.IsNullOrEmpty(appName))
            {
                if (appName.Length > 255)
                    appName = appName.Substring(0, 255);
            }
            _ApplicationId = 10011;
            _ApplicationIDCacheDate = DateTime.Now;
            if (_ApplicationId != 0)
                return _ApplicationId;
            throw new ProviderException("sorry exception in GetApplicationId");
        }       

    }
}