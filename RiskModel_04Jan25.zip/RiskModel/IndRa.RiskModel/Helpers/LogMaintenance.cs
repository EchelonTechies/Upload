﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndRa.RiskModel.Helpers
{
    public class LogMaintenance
    {
        public static void RegisterErrorLogger()
        {
            log4net.Config.XmlConfigurator.Configure();
        }

        /// <summary>
        ///     Log exception with type
        /// </summary>
        /// <param name="type"></param>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public static void Error(Type type, object message, Exception exception)
        {
            try
            {
                log4net.ILog log = log4net.LogManager.GetLogger(type);
                log.Error(message, exception);
            }
            catch (Exception)
            {
                //   TODO
            }
        }

        /// <summary>
        /// Log exception
        /// </summary>
        /// <param name="loggerName"></param>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public static void Error(string loggerName, object message, Exception exception)
        {
            try
            {
                log4net.ILog log = log4net.LogManager.GetLogger(loggerName);
                log.Error(message, exception);
            }
            catch (Exception)
            {
                //   TODO
            }
        }

        /// <summary>
        ///     Log info with type
        /// </summary>
        /// <param name="type"></param>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public static void Info(Type type, object message)
        {
            try
            {
                log4net.ILog log = log4net.LogManager.GetLogger(type);
                log.Info(message);
            }
            catch (Exception)
            {
                //   TODO
            }
        }

        /// <summary>
        /// Log info
        /// </summary>
        /// <param name="loggerName"></param>
        /// <param name="message"></param>
        public static void Info(string loggerName, object message)
        {
            try
            {
                log4net.ILog log = log4net.LogManager.GetLogger(loggerName);
                log.Info(message);
            }
            catch (Exception)
            {
                //   TODO
            }
        }
    }
}