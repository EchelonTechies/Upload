﻿using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndRa.RiskModel.Helpers
{
    public class DropDownValue
    {
        public static SelectList GetCompaniesList(int modelID, int roleID, int userID)
        {
            CompanyDAL companyDAL = new CompanyDAL();
            var companyLists = companyDAL.GetCompaniesList();
            List<SelectListItem> companyListItems = null;
            if (roleID == (int)RolesEnum.Admin || roleID == (int)RolesEnum.SuperAdmin)
            {
                companyListItems = (from companyList in companyLists
                                    where companyList.ModelId == modelID
                                    select new SelectListItem
                                    {
                                        Value = companyList.CompanyId.ToString(),
                                        Text = companyList.CompanyName,
                                    }).OrderBy(a => a.Text).ToList();
            }
            else
            {
                companyListItems = (from companyList in companyLists
                                    where companyList.ModelId == modelID && companyList.AssignedAnalystId == userID
                                    select new SelectListItem
                                    {
                                        Value = companyList.CompanyId.ToString(),
                                        Text = companyList.CompanyName,

                                    }).OrderBy(a => a.Text).ToList();
            }

            return new SelectList(companyListItems, "Value", "Text");
        }

        public static SelectList GetClientList()
        {
            CompanyDAL companyDAL = new CompanyDAL();
            var companyLists = companyDAL.GetCompaniesList();
            List<SelectListItem> companyListItems = (from companyList in companyLists
                                                     select new SelectListItem
                                                     {
                                                         Value = companyList.CompanyId.ToString(),
                                                         Text = companyList.CompanyName,
                                                     }).ToList();

            return new SelectList(companyListItems, "Value", "Text");
        }

        public static SelectList GetLocationsList()
        {
            CompanyDAL locationDAL = new CompanyDAL();
            var locationLists = locationDAL.GetLocationsList();
            List<SelectListItem> locationListItems = (from locationList in locationLists
                                                      select new SelectListItem
                                                      {
                                                          Value = locationList.LocationId.ToString(),
                                                          Text = locationList.LocationName,
                                                      }).ToList();

            return new SelectList(locationListItems, "Value", "Text");
        }

        public static SelectList GetSponsorBankList()
        {
            CompanyDAL locationDAL = new CompanyDAL();
            var sponsorBankLists = locationDAL.GetSponsorBankList();
            List<SelectListItem> listItems = (from list in sponsorBankLists
                                              select new SelectListItem
                                              {
                                                  Value = list.SponsorBankName,
                                                  Text = list.SponsorBankName,
                                              }).ToList();

            return new SelectList(listItems, "Value", "Text");
        }

        public static SelectList GetCurrencyList()
        {
            CompanyDAL locationDAL = new CompanyDAL();
            var lists = locationDAL.GetCurrencyList();
            List<SelectListItem> listItems = (from list in lists
                                              select new SelectListItem
                                              {
                                                  Value = list.CurrencyName,
                                                  Text = list.CurrencyName,
                                              }).ToList();

            return new SelectList(listItems, "Value", "Text");
        }

        public static SelectList GetModelList()
        {
            CompanyDAL dal = new CompanyDAL();
            var modelList = dal.GetModelList();
            List<SelectListItem> listItems = (from list in modelList
                                              select new SelectListItem
                                              {
                                                  Value = list.ModelId.ToString(),
                                                  Text = list.ModelName,
                                              }).ToList();
            return new SelectList(listItems, "Value", "Text");
        }

        public static SelectList GetAnalystList()
        {
            CompanyDAL dal = new CompanyDAL();
            var modelList = dal.GetUserList(3);
            List<SelectListItem> listItems = (from list in modelList
                                              select new SelectListItem
                                              {
                                                  Value = list.UserId.ToString(),
                                                  Text = list.UserName,
                                              }).ToList();
            return new SelectList(listItems, "Value", "Text");
        }

        public static SelectList GetAllAnalystList()
        {
            CompanyDAL dal = new CompanyDAL();
            var modelList = dal.GetAllAnalystList();
            List<SelectListItem> listItems = (from list in modelList
                                              select new SelectListItem
                                              {
                                                  Value = list.UserId.ToString(),
                                                  Text = list.UserName,
                                              }).ToList();
            return new SelectList(listItems, "Value", "Text");
        }

        public static SelectList GetYesorNoStatus()
        {
            CompanyDAL getStatusDAL = new CompanyDAL();
            return new SelectList(getStatusDAL.GetYesorNoStatus(), "");
        }

        public static SelectList GetYesNoStatus()
        {
            CompanyDAL getStatusDAL = new CompanyDAL();
            return new SelectList(getStatusDAL.GetYesNoStatus(), "");
        }

        public static SelectList GetParamterNoList()
        {
            CompanyDAL getStatusDAL = new CompanyDAL();
            return new SelectList(getStatusDAL.GetParamterNoList(), "");
        }


        public static SelectList GetRatingsList(int modelID)
        {
            CompanyDAL getRatingDAL = new CompanyDAL();
            var ratingList = getRatingDAL.GetRatingsList(modelID);
            List<SelectListItem> ratingListItems = (from rating in ratingList
                                                    select new SelectListItem
                                                    {
                                                        Value = rating.RatingName,
                                                        Text = rating.RatingName,
                                                    }).ToList();

            return new SelectList(ratingListItems, "Value", "Text");
        }

        public static SelectList GetRatingsListForReport(int modelID, int year)
        {
            CompanyDAL getRatingDAL = new CompanyDAL();
            var ratingList = getRatingDAL.GetRatingsListForReport(modelID, year);
            List<SelectListItem> ratingListItems = (from rating in ratingList
                                                    select new SelectListItem
                                                    {
                                                        Value = rating.RatingId.ToString(),
                                                        Text = rating.RatingName,
                                                    }).ToList();

            return new SelectList(ratingListItems, "Value", "Text");
        }
        public static SelectList GetFinYearList()
        {
            CompanyDAL getRatingDAL = new CompanyDAL();
            var ratingList = getRatingDAL.GetFinYearList();
            List<SelectListItem> ratingListItems = (from rating in ratingList
                                                    select new SelectListItem
                                                    {
                                                        Value = rating.RatingName,
                                                        Text = rating.RatingName,
                                                    }).ToList();

            return new SelectList(ratingListItems, "Value", "Text");
        }

        public static SelectList GetSubjectiveParameterList(int modelId, int headerId)
        {
            CommonDAL dal = new CommonDAL();
            var ratingList = dal.GetSubjectiveParameterDefinition(modelId, headerId);
            List<SelectListItem> ratingListItems = (from rating in ratingList
                                                    select new SelectListItem
                                                    {
                                                        Value = rating.Value,
                                                        Text = rating.Value,
                                                    }).ToList();

            return new SelectList(ratingListItems, "Value", "Text");
        }


        public static SelectList GetSegmentsList()
        {
            CompanyDAL getDAL = new CompanyDAL();
            var modelList = getDAL.GetSegmentsList();
            List<SelectListItem> modelListItems = (from models in modelList
                                                   select new SelectListItem
                                                   {
                                                       Value = models.ModelId.ToString(),
                                                       Text = models.ModelName,
                                                   }).ToList();

            return new SelectList(modelListItems, "Value", "Text");
        }

        public static SelectList GetYearType()
        {
            List<SelectListItem> items = new List<SelectListItem>();
            items.Add(new SelectListItem() { Text = "Historical Year", Value = "H" });
            items.Add(new SelectListItem() { Text = "New Year", Value = "N" });

            return new SelectList(items, "Value", "Text");
        }

        public static SelectList GetYearList()
        {
            CompanyDAL getDAL = new CompanyDAL();
            var yearList = getDAL.GetYearList();
            List<SelectListItem> yearListItems = (from years in yearList
                                                  select new SelectListItem
                                                  {
                                                      Value = years.year.ToString(),
                                                      Text = years.year.ToString(),
                                                  }).ToList();

            return new SelectList(yearListItems, "Value", "Text");
        }

        public static SelectList GetYearNewList()
        {
            CompanyDAL getDAL = new CompanyDAL();
            var yearList = getDAL.GetYearNewList();
            List<SelectListItem> yearListItems = (from years in yearList
                                                  select new SelectListItem
                                                  {
                                                      Value = years.year.ToString(),
                                                      Text = years.year.ToString(),
                                                  }).ToList();

            return new SelectList(yearListItems, "Value", "Text");
        }
        public static SelectList GetYearHistoricalList()
        {
            CompanyDAL getDAL = new CompanyDAL();
            var yearList = getDAL.GetYearHistoricalList();
            List<SelectListItem> yearListItems = (from years in yearList
                                                  select new SelectListItem
                                                  {
                                                      Value = years.year.ToString(),
                                                      Text = years.year.ToString(),
                                                  }).ToList();

            return new SelectList(yearListItems, "Value", "Text");
        }

        public static SelectList GetPFRMType()
        {
            List<SelectListItem> items = new List<SelectListItem>();
            items.Add(new SelectListItem() { Text = "PFRM - Public Agency", Value = "Public Agency" });
            items.Add(new SelectListItem() { Text = "PFRM - Private Agency", Value = "Private Agency" });
            items.Add(new SelectListItem() { Text = "PFRM - MFI", Value = "MFI" });
            items.Add(new SelectListItem() { Text = "PFRM - EWS", Value = "EWS" });

            return new SelectList(items, "Value", "Text");
        }


        public static SelectList GetLiabilitiesTypeList()
        {
            CompanyDAL getTypeDAL = new CompanyDAL();
            return new SelectList(getTypeDAL.GetLiabilitiesTypeList(), "");
        }

        public static SelectList GetFinancialPerformanceOfPlayers()
        {
            CompanyDAL getFinancialPerformanceOfPlayers = new CompanyDAL();
            return new SelectList(getFinancialPerformanceOfPlayers.GetFinancialPerformanceOfPlayers(), "");
        }

        public static SelectList GetExtentOfCompetition()
        {
            CompanyDAL getExtentOfCompetition = new CompanyDAL();
            return new SelectList(getExtentOfCompetition.GetExtentOfCompetition(), "");
        }

        public static SelectList GetProspectOfRealEstateMarket()
        {
            CompanyDAL getProspectOfRealEstateMarket = new CompanyDAL();
            return new SelectList(getProspectOfRealEstateMarket.GetProspectOfRealEstateMarket(), "");
        }

        public static SelectList GetRegulatoryImpactGovernmentPolicy()
        {
            CompanyDAL getRegulatoryImpactGovernmentPolicy = new CompanyDAL();
            return new SelectList(getRegulatoryImpactGovernmentPolicy.GetRegulatoryImpactGovernmentPolicy(), "");
        }

        public static SelectList GetRankOfMarketPosition()
        {
            CompanyDAL getRankOfMarketPosition = new CompanyDAL();
            return new SelectList(getRankOfMarketPosition.GetRankOfMarketPosition(), "");
        }

        public static SelectList GetGeographicalDiversification()
        {
            CompanyDAL getGeographicalDiversification = new CompanyDAL();
            return new SelectList(getGeographicalDiversification.GetGeographicalDiversification(), "");
        }

        public static SelectList GetProductMixHousingLoanvsLAP()
        {
            CompanyDAL getProductMixHousingLoanvsLAP = new CompanyDAL();
            return new SelectList(getProductMixHousingLoanvsLAP.GetProductMixHousingLoanvsLAP(), "");
        }

        public static SelectList GetCustomerMixSalariedPeopleVsOthers()
        {
            CompanyDAL getCustomerMixSalariedPeopleVsOthers = new CompanyDAL();
            return new SelectList(getCustomerMixSalariedPeopleVsOthers.GetCustomerMixSalariedPeopleVsOthers(), "");
        }

        public static SelectList GetCostOfResources()
        {
            CompanyDAL getCostOfResources = new CompanyDAL();
            return new SelectList(getCostOfResources.GetCostOfResources(), "");
        }

        public static SelectList GetTotalAssetGrowth()
        {
            CompanyDAL getTotalAssetGrowth = new CompanyDAL();
            return new SelectList(getTotalAssetGrowth.GetTotalAssetGrowth(), "");
        }

        public static SelectList GetDiversificationOfFundingProfile()
        {
            CompanyDAL getDiversificationOfFundingProfile = new CompanyDAL();
            return new SelectList(getDiversificationOfFundingProfile.GetDiversificationOfFundingProfile(), "");
        }

        public static SelectList GetAbilityOftheCompanytoRaisefundsandLiquidityManagement()
        {
            CompanyDAL getAbilityOftheCompanytoRaisefundsandLiquidityManagement = new CompanyDAL();
            return new SelectList(getAbilityOftheCompanytoRaisefundsandLiquidityManagement.GetAbilityOftheCompanytoRaisefundsandLiquidityManagement(), "");
        }

        public static SelectList GetAbilitytoMeetAchievementofRevenueProjections()
        {
            CompanyDAL getAbilitytoMeetAchievementofRevenueProjections = new CompanyDAL();
            return new SelectList(getAbilitytoMeetAchievementofRevenueProjections.GetAbilitytoMeetAchievementofRevenueProjections(), "");
        }

        public static SelectList GetAbilitytoMeetAchievementOfProfitProjections()
        {
            CompanyDAL getAbilitytoMeetAchievementOfProfitProjections = new CompanyDAL();
            return new SelectList(getAbilitytoMeetAchievementOfProfitProjections.GetAbilitytoMeetAchievementOfProfitProjections(), "");
        }

        public static SelectList GetPastPaymentRecordandTrackRecord()
        {
            CompanyDAL getPastPaymentRecordandTrackRecord = new CompanyDAL();
            return new SelectList(getPastPaymentRecordandTrackRecord.GetPastPaymentRecordandTrackRecord(), "");
        }

        public static SelectList GetRiskManagementSystem()
        {
            CompanyDAL getRiskManagementSystem = new CompanyDAL();
            return new SelectList(getRiskManagementSystem.GetRiskManagementSystem(), "");
        }

        public static SelectList GetManagementCredibility()
        {
            CompanyDAL getManagementCredibility = new CompanyDAL();
            return new SelectList(getManagementCredibility.GetManagementCredibility(), "");
        }

        public static SelectList GetManagementExperienceAndCompetence()
        {
            CompanyDAL getManagementExperienceAndCompetence = new CompanyDAL();
            return new SelectList(getManagementExperienceAndCompetence.GetManagementExperienceAndCompetence(), "");
        }

        public static SelectList GetRiskAppetite()
        {
            CompanyDAL getRiskAppetite = new CompanyDAL();
            return new SelectList(getRiskAppetite.GetRiskAppetite(), "");
        }

        public static SelectList GetNetMargin()
        {
            CompanyDAL getNetMargin = new CompanyDAL();
            return new SelectList(getNetMargin.GetNetMargin(), "");
        }

        public static SelectList GetPATAverageFundsDeployed()
        {
            CompanyDAL getPATAverageFundsDeployed = new CompanyDAL();
            return new SelectList(getPATAverageFundsDeployed.GetPATAverageFundsDeployed(), "");
        }

        public static SelectList GetPATAverageNetWorth()
        {
            CompanyDAL getPATAverageNetWorth = new CompanyDAL();
            return new SelectList(getPATAverageNetWorth.GetPATAverageNetWorth(), "");
        }

        public static SelectList GetOwnershipShareholdingStructure()
        {
            CompanyDAL getOwnershipShareholdingStructure = new CompanyDAL();
            return new SelectList(getOwnershipShareholdingStructure.GetOwnershipShareholdingStructure(), "");
        }

        public static SelectList GetManagementControl()
        {
            CompanyDAL getManagementControl = new CompanyDAL();
            return new SelectList(getManagementControl.GetManagementControl(), "");
        }

        public static SelectList GetStatedPostureOftheParent()
        {
            CompanyDAL getStatedPostureOftheParent = new CompanyDAL();
            return new SelectList(getStatedPostureOftheParent.GetStatedPostureOftheParent(), "");
        }

        public static SelectList GetPastTrackRecord()
        {
            CompanyDAL getPastTrackRecord = new CompanyDAL();
            return new SelectList(getPastTrackRecord.GetPastTrackRecord(), "");
        }

        public static SelectList GetBrandName()
        {
            CompanyDAL getBrandName = new CompanyDAL();
            return new SelectList(getBrandName.GetBrandName(), "");
        }

        public static SelectList GetProjectTypeList()
        {
            CompanyDAL locationDAL = new CompanyDAL();
            var projectTypeLists = locationDAL.GetProjectTypeList();

            List<SelectListItem> listItems = (from list in projectTypeLists
                                              select new SelectListItem
                                              {
                                                  Value = list.ProjectTypeId.ToString(),
                                                  Text = list.ProjectTypeName,
                                              }).ToList();

            return new SelectList(listItems, "Value", "Text");
        }

    }
}