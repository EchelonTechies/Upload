﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace IndRa.RiskModel.Helpers
{
    public class ConfigManager
    {
        public static string GetRiskModelUrl()
        {
            return ConfigurationManager.AppSettings["RiskModelUrl"].ToString();
        }

        public static string GetInputPath()
        {
            return ConfigurationManager.AppSettings["InputFolderPath"].ToString();
        }

        public static string GetOutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["OutputTemplateFilePath"].ToString();
        }

        public static string GetHFC_InputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["HFC_InputTemplateFilePath"].ToString();
        }

        public static string GetHFC_OutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["HFC_OutputTemplateFilePath"].ToString();
        }
        public static string GetHFCNew_InputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["HFCNew_InputTemplateFilePath"].ToString();
        }

        public static string GetHFCNew_OutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["HFCNew_OutputTemplateFilePath"].ToString();
        }

        public static string GetSCB_InputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["SCB_InputTemplateFilePath"].ToString();
        }

        public static string GetSCB_OutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["SCB_OutputTemplateFilePath"].ToString();
        }

        public static string GetSFB_InputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["SFB_InputTemplateFilePath"].ToString();
        }

        public static string GetSFB_OutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["SFB_OutputTemplateFilePath"].ToString();
        }

        public static string GetSTCOOP_InputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["STCOOP_InputTemplateFilePath"].ToString();
        }

        public static string GetSTCOOP_OutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["STCOOP_OutputTemplateFilePath"].ToString();
        }

        public static string GetRRB_InputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["RRB_InputTemplateFilePath"].ToString();
        }

        public static string GetRRB_OutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["RRB_OutputTemplateFilePath"].ToString();
        }

        public static string GetUCB_InputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["UCB_InputTemplateFilePath"].ToString();
        }

        public static string GetUCB_OutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["UCB_OutputTemplateFilePath"].ToString();
        }

        public static string GetACHFS_InputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["ACHFS_InputTemplateFilePath"].ToString();
        }

        public static string GetACHFS_OutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["ACHFS_OutputTemplateFilePath"].ToString();
        }

        public static string GetARDB_InputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["ARDB_InputTemplateFilePath"].ToString();
        }

        public static string GetARDB_OutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["ARDB_OutputTemplateFilePath"].ToString();
        }

        public static string GetPFRM_InputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["PFRM_InputTemplateFilePath"].ToString();
        }

        public static string GetPFRM_OutputTemplateFilePath()
        {
            return ConfigurationManager.AppSettings["PFRM_OutputTemplateFilePath"].ToString();
        }

        /*
        public static string GetHFC_OutputTemplateFilePath_DeleteFile()
        {
            return ConfigurationManager.AppSettings["HFC_OutputTemplateFilePath_DeleteFile"].ToString();
        }
        public static string GetSCB_OutputTemplateFilePath_DeleteFile()
        {
            return ConfigurationManager.AppSettings["SCB_OutputTemplateFilePath_DeleteFile"].ToString();
        }
        public static string GetSFB_OutputTemplateFilePath_DeleteFile()
        {
            return ConfigurationManager.AppSettings["SFB_OutputTemplateFilePath_DeleteFile"].ToString();
        }
        public static string GetRRB_OutputTemplateFilePath_DeleteFile()
        {
            return ConfigurationManager.AppSettings["RRB_OutputTemplateFilePath_DeleteFile"].ToString();
        }
        public static string GetSTCOOP_OutputTemplateFilePath_DeleteFile()
        {
            return ConfigurationManager.AppSettings["STCOOP_OutputTemplateFilePath_DeleteFile"].ToString();
        }
        public static string GetUCB_OutputTemplateFilePath_DeleteFile()
        {
            return ConfigurationManager.AppSettings["UCB_OutputTemplateFilePath_DeleteFile"].ToString();
        }
        public static string GetACHFS_OutputTemplateFilePath_DeleteFile()
        {
            return ConfigurationManager.AppSettings["ACHFS_OutputTemplateFilePath_DeleteFile"].ToString();
        }
        public static string GetARDB_OutputTemplateFilePath_DeleteFile()
        {
            return ConfigurationManager.AppSettings["ARDB_OutputTemplateFilePath_DeleteFile"].ToString();
        }
        public static string GetPFRM_OutputTemplateFilePath_DeleteFile()
        {
            return ConfigurationManager.AppSettings["PFRM_OutputTemplateFilePath_DeleteFile"].ToString();
        }
        public static string GetHFCNew_OutputTemplateFilePath_DeleteFile()
        {
            return ConfigurationManager.AppSettings["HFCNew_OutputTemplateFilePath_DeleteFile"].ToString();
        }
        */
        public static string GetOutputTemplateCopyFilePath()
        {
            return ConfigurationManager.AppSettings["OutputTemplateCopyFilePath"].ToString();
        }

        public static string GetExcelFilePaths()
        {
            return ConfigurationManager.AppSettings["ExcelFilePath"].ToString();
        }

        public static string GetExcelFilePath()
        {
            return ConfigurationManager.AppSettings["ExcelSheetFilePath"].ToString();
        }

        public static string GetExcelSheetFileCopyPath()
        {
            return ConfigurationManager.AppSettings["ExcelSheetFileCopyPath"].ToString();
        }

        public static string DateFormat()
        {
            return Convert.ToString(ConfigurationManager.AppSettings["DateFormat"]);
        }
        public static string GetReportWordDownloadFolder()
        {
            return Convert.ToString(ConfigurationManager.AppSettings["ReportWordDownload_Folder"]);
        }
        public static string GetReportWordDownloadFileName()
        {
            return Convert.ToString(ConfigurationManager.AppSettings["ReportWordDownload_FileName"]);
        }

        public static string GetReportWordDownloadLogoName()
        {
            return Convert.ToString(ConfigurationManager.AppSettings["ReportWordDownload_LogoName"]);
        }

        public static string GetLogFolder()
        {
            return Convert.ToString(ConfigurationManager.AppSettings["LogFolder"]);
        }


        #region SMTP Section

        public static string GetSMTPUsername()
        {
            return ConfigurationManager.AppSettings["SMTPUsername"].ToString();
        }

        public static string GetSMTPPassword()
        {
            return ConfigurationManager.AppSettings["SMTPPassword"].ToString();
        }

        public static string GetSMTPServerName()
        {
            return ConfigurationManager.AppSettings["SMTPServerName"].ToString();
        }

        public static string GetSMTPPortNumber()
        {
            return ConfigurationManager.AppSettings["SMTPPortNumber"].ToString();
        }

        public static string GetSMTPFromAddress()
        {
            return ConfigurationManager.AppSettings["SMTPFromAddress"].ToString();
        }

        public static string GetFromAddressforActivationPressreleaseRating()
        {
            return ConfigurationManager.AppSettings["FromAddressforActivationPressreleaseRating"].ToString();
        }

        public static string GetSupportEmailAddress()
        {
            return ConfigurationManager.AppSettings["SupportEmailAddress"].ToString();
        }

        public static string GetFromdonotreplyEmailAddress()
        {
            return ConfigurationManager.AppSettings["FromdonotreplyEmailAddress"].ToString();
        }

        #endregion

    }
}