﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Security.Cryptography;
using System.Configuration.Provider;
using System.Configuration;
using System.Web.Configuration;
using IndRa.RiskModel.DAL.DAL;
using System.IO;

namespace IndRa.RiskModel.Helpers
{
    public class CommonFunction
    {
        public static string REPORT_WORD_FONT = "Book Antiqua";    

        public string Encrypt_Password(string password)
        {
            string pswstr = string.Empty; byte[] psw_encode = new byte[password.Length];
            psw_encode = System.Text.Encoding.UTF8.GetBytes(password);
            pswstr = Convert.ToBase64String(psw_encode);
            return pswstr;
        }

        public System.Data.DataTable GenerateDataTableDoB()
        {
            System.Data.DataTable table = new System.Data.DataTable();
            table.Columns.Add("Sr.  No.", typeof(int));
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("designation", typeof(string));

            // Add DataRows to table

            for (int i = 1; i < 8; i++)
            {
                table.Rows.Add(i, "", "");
            }

            return table;
        }

        public System.Data.DataTable GenerateDataTableBaiscInformation()
        {
            System.Data.DataTable table = new System.Data.DataTable();

            table.Columns.Add("", typeof(string));
            table.Columns.Add("", typeof(string));
            table.Columns.Add("", typeof(string));

            string[] headerData = { "Year of Formation", "State of Operation", "Sponsor Bank", "Internal rating", "Refinance Outstanding", "Housing loan outstanding", "Housing Loan GNPA" };

            // Add DataRows to table
            for (int i = 0; i < headerData.Length; i++)
            {
                table.Rows.Add(headerData[i], "", "");
            }

            return table;
        }


        public void MoveFileToInputFolder(string filePath, int? issuerID, string finYear)
        {
            try
            {
                if (!string.IsNullOrEmpty(filePath))
                {
                    CompanyDAL companyDAL = new CompanyDAL();
                    string companyName = companyDAL.GetCompanyNameByID(issuerID);
                    string moveFilePath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}{1}\\{2}", ConfigManager.GetInputPath(), finYear, companyName));
                    string fileName = Path.GetFileName(filePath);

                    if (!Directory.Exists(moveFilePath))
                    {
                        System.IO.Directory.CreateDirectory(moveFilePath);
                    }
                    else
                    {
                        System.IO.DirectoryInfo di = new DirectoryInfo(moveFilePath);
                        foreach (FileInfo file in di.GetFiles())
                        {
                            file.Delete();
                        }
                    }
                    moveFilePath = moveFilePath + "\\" + fileName;

                    System.IO.File.Move(filePath, moveFilePath);
                }
            }
            catch { }
        }


    }
}