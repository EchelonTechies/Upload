﻿using IndRa.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndRa.Admin.Helpers
{
    public class Validations
    {
        /// <summary>
        ///     Check if Emai ID already Exist. 
        /// </summary>
        /// <param name="emailAddress"></param>
        /// <returns></returns>
        public bool IsExistEmailId(string emailAddress)
        {
            try
            {
                UserBLL userBLL = new UserBLL();
                bool status = userBLL.IsEmailAddressIsUnique(emailAddress);
                return status;
            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }

        /// <summary>
        ///     Check if User Name already Exist. 
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public bool IsExistUserName(string userName)
        {
            try
            {
                UserBLL userBLL = new UserBLL();
                bool status = userBLL.IsUserNameIsUnique(userName);
                return status;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
    }
}