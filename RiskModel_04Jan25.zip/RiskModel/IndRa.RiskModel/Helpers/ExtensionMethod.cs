﻿using System;

namespace IndRa.RiskModel.Helpers
{
    public class ExtensionMethod
    {
        public static string OutputFormattingsDouble(double Value)
        {
            string value = "";
            if (Value == Convert.ToDouble("-2146826246"))
            {
                value = Convert.ToString(Math.Round(Convert.ToDouble(Value) * 100, 2)) == "-2146826246" ? "#N/A" : Convert.ToString(Math.Round(Convert.ToDouble(Value) * 100, 2));
            }
            else if (Value == Convert.ToDouble("-2146826273"))
            {
                value = Convert.ToString(Math.Round(Convert.ToDouble(Value) * 100, 2)) == "-2146826273" ? "#VALUE!" : Convert.ToString(Math.Round(Convert.ToDouble(Value) * 100, 2));
            }
            else if (Value == Convert.ToDouble("-2146826281"))
            {
                value = Convert.ToString(Convert.ToDouble(Value)) == "-2146826281" ? "#DIV/0!" : Convert.ToString(Convert.ToInt32(Value));
            }
            else
            {
                value = Convert.ToString(Math.Round(Convert.ToDouble(Value) * 100, 2));
            }
            return value;
        }

        public static string OutputFormattingsDecimal(double Value)
        {
            string value = "";
            if (Value == Convert.ToDouble("-2146826246"))
            {
                value = Convert.ToString(Convert.ToDouble(Value)) == "-2146826246" ? "#N/A" : Convert.ToString(Convert.ToDouble(Value));
            }
            else if (Value == Convert.ToDouble("-2146826273"))
            {
                value = Convert.ToString(Convert.ToDouble(Value)) == "-2146826273" ? "#VALUE!" : Convert.ToString(Convert.ToDouble(Value));
            }
            else if (Value == Convert.ToDouble("-2146826281"))
            {
                value = Convert.ToString(Convert.ToDouble(Value)) == "-2146826281" ? "#DIV/0!" : Convert.ToString(Convert.ToInt32(Value));
            }
            else
            {
                value = Convert.ToString(Math.Round(Convert.ToDecimal(Value), 1, MidpointRounding.AwayFromZero));
            }
            return value;
        }

        public static string OutputFormattingsInt(double Value)
        {
            string value = "";
            if (Value == Convert.ToDouble("-2146826246"))
            {
                value = Convert.ToString(Convert.ToInt32(Value)) == "-2146826246" ? "#N/A" : Convert.ToString(Convert.ToInt32(Value));
            }
            else if (Value == Convert.ToDouble("-2146826273"))
            {
                value = Convert.ToString(Convert.ToInt32(Value)) == "-2146826273" ? "#VALUE!" : Convert.ToString(Convert.ToInt32(Value));
            }
            else if (Value == Convert.ToDouble("-2146826281"))
            {
                value = Convert.ToString(Convert.ToInt32(Value)) == "-2146826281" ? "#DIV/0!" : Convert.ToString(Convert.ToInt32(Value));
            }
            else
            {
                value = Convert.ToString(Convert.ToInt32(Value));
            }
            return value;
        }

        public static string GetValues(double? Value)
        {
            string value = "";
            if (Value == 0)
            {
                value = "0";
            }
            else
            {
                //value =Convert.ToString((Value));
               value = Convert.ToString(Math.Round(Value.Value));
            }
            return value;
        }

      
    }
}