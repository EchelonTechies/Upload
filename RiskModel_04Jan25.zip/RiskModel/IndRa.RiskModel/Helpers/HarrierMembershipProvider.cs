﻿using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.DataAccess;
using IndRa.RiskModel.DAL.Entities;
using IndRa.UI.Helpers;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Configuration.Provider;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Configuration;
using System.Web.Security;

namespace IndRa.Admin.Helpers
{
    public class HarrierMembershipProvider : MembershipProvider
    {

        private const int SALT_SIZE_IN_BYTES = 16;
        private bool _EnablePasswordRetrieval;
        private bool _EnablePasswordReset;
        private bool _RequiresQuestionAndAnswer;
        private string _AppName;
        private bool _RequiresUniqueEmail;
        private string _DatabaseFileName;
        private string _HashAlgorithmType;
        private int _ApplicationId = 0;
        private int _MaxInvalidPasswordAttempts;
        private int _PasswordAttemptWindow;
        private int _MinRequiredPasswordLength;
        private int _MinRequiredNonalphanumericCharacters;
        private string _PasswordStrengthRegularExpression;
        private DateTime _ApplicationIDCacheDate;
        private MembershipPasswordFormat _PasswordFormat;

        public override bool EnablePasswordRetrieval
        {
            get { return _EnablePasswordRetrieval; }
        }

        public override bool EnablePasswordReset
        {
            get { return _EnablePasswordReset; }
        }

        public override bool RequiresQuestionAndAnswer
        {
            get { return _RequiresQuestionAndAnswer; }
        }

        public override bool RequiresUniqueEmail
        {
            get { return _RequiresUniqueEmail; }
        }

        public override MembershipPasswordFormat PasswordFormat
        {
            get { return _PasswordFormat; }
        }

        public override int MaxInvalidPasswordAttempts
        {
            get { return _MaxInvalidPasswordAttempts; }
        }

        public override int PasswordAttemptWindow
        {
            get { return _PasswordAttemptWindow; }
        }

        public override int MinRequiredPasswordLength
        {
            get { return _MinRequiredPasswordLength; }
        }

        public override int MinRequiredNonAlphanumericCharacters
        {
            get { return _MinRequiredNonalphanumericCharacters; }
        }

        public override string PasswordStrengthRegularExpression
        {
            get { return _PasswordStrengthRegularExpression; }
        }

        public override string ApplicationName
        {
            get { return _AppName; }
            set
            {
                if (_AppName != value)
                {
                    _ApplicationId = 0;
                    _AppName = value;
                }
            }
        }

        public override void Initialize(string name, NameValueCollection config)
        {
            if (config == null)
                throw new ArgumentNullException("config");

            if (String.IsNullOrEmpty(name))
                name = "AccessMembershipProvider";

            if (string.IsNullOrEmpty(config["description"]))
            {
                config.Remove("description");
                config.Add("description", "Membership $safeprojectname$ Provider");
            }
            base.Initialize(name, config);

            _EnablePasswordRetrieval = SecUtility.GetBooleanValue(config, "enablePasswordRetrieval", false);
            _EnablePasswordReset = SecUtility.GetBooleanValue(config, "enablePasswordReset", true);
            _RequiresQuestionAndAnswer = SecUtility.GetBooleanValue(config, "requiresQuestionAndAnswer", false);
            _RequiresUniqueEmail = SecUtility.GetBooleanValue(config, "requiresUniqueEmail", false);
            _MaxInvalidPasswordAttempts = SecUtility.GetIntValue(config, "maxInvalidPasswordAttempts", 5, false, 0);
            _PasswordAttemptWindow = SecUtility.GetIntValue(config, "passwordAttemptWindow", 10, false, 0);
            _MinRequiredPasswordLength = SecUtility.GetIntValue(config, "minRequiredPasswordLength", 7, false, 128);
            _MinRequiredNonalphanumericCharacters = SecUtility.GetIntValue(config, "minRequiredNonalphanumericCharacters", 1, true, 128);

            _HashAlgorithmType = config["hashAlgorithmType"];
            if (String.IsNullOrEmpty(_HashAlgorithmType))
            {
                _HashAlgorithmType = "MD5";
            }

            _PasswordStrengthRegularExpression = config["passwordStrengthRegularExpression"];

            if (_PasswordStrengthRegularExpression != null)
            {
                _PasswordStrengthRegularExpression = _PasswordStrengthRegularExpression.Trim();
                if (_PasswordStrengthRegularExpression.Length != 0)
                {
                    try
                    {
                        Regex regex = new Regex(_PasswordStrengthRegularExpression);
                    }
                    catch (ArgumentException e)
                    {
                        throw new ProviderException(e.Message, e);
                    }
                }
            }
            else
            {
                _PasswordStrengthRegularExpression = string.Empty;
            }

            _AppName = config["applicationName"];
            if (string.IsNullOrEmpty(_AppName))
                _AppName = SecUtility.GetDefaultAppName();

            if (_AppName.Length > 255)
            {
                throw new ProviderException("Provider application name is too long, max length is 255.");
            }

            string strTemp = config["passwordFormat"];
            if (strTemp == null)
                strTemp = "Hashed";

            switch (strTemp)
            {
                case "Clear":
                    _PasswordFormat = MembershipPasswordFormat.Clear;
                    break;
                case "Encrypted":
                    _PasswordFormat = MembershipPasswordFormat.Encrypted;
                    break;
                case "Hashed":
                    _PasswordFormat = MembershipPasswordFormat.Hashed;
                    break;
                default:
                    throw new ProviderException("Bad password format");
            }

            if (_PasswordFormat == MembershipPasswordFormat.Hashed && _EnablePasswordRetrieval)
                throw new ProviderException("Provider cannot retrieve hashed password");

            _DatabaseFileName = config["connectionStringName"];
            if (_DatabaseFileName == null || _DatabaseFileName.Length < 1)
                throw new ProviderException("Connection name not specified");

            config.Remove("connectionStringName");
            config.Remove("enablePasswordRetrieval");
            config.Remove("enablePasswordReset");
            config.Remove("requiresQuestionAndAnswer");
            config.Remove("applicationName");
            config.Remove("requiresUniqueEmail");
            config.Remove("maxInvalidPasswordAttempts");
            config.Remove("passwordAttemptWindow");
            config.Remove("passwordFormat");
            config.Remove("name");
            config.Remove("description");
            config.Remove("minRequiredPasswordLength");
            config.Remove("minRequiredNonalphanumericCharacters");
            config.Remove("passwordStrengthRegularExpression");
            config.Remove("hashAlgorithmType");

            if (config.Count > 0)
            {
                string attribUnrecognized = config.GetKey(0);
                if (!String.IsNullOrEmpty(attribUnrecognized))
                    throw new ProviderException("Provider unrecognized attribute: " + attribUnrecognized);
            }

        }

        public override bool ChangePassword(string username, string oldPassword, string newPassword)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        //public bool ChangePassword(string username, string oldPassword, string newPassword, ref string responseMessage)
        //{
        //    try
        //    {
        //        string salt;
        //        int passwordFormat;
        //        int appId = GetAppplicationId();
        //        long userId = GetUserID(username);
        //        string hashUserPassword = GetPasswordWithFormat(userId, out passwordFormat, out salt);
        //        string hashUserProviedPassword = EncodePassword(oldPassword, passwordFormat, salt);
        //        if (hashUserPassword == hashUserProviedPassword)
        //        {
        //            string hashNewPassword = EncodePassword(newPassword, passwordFormat, salt);
        //            UserBLL userBLL = new UserBLL();
        //            bool result = userBLL.UpdatePassword(username, hashUserPassword, hashNewPassword, salt);
        //            responseMessage = userBLL.ResponseMessage;
        //            return result;
        //        }
        //        else
        //        {
        //            return false;
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}

        //public string GeneratePassword(string username, string oldPassword, string newPassword)
        //{
        //    try
        //    {
        //        string salt;
        //        int passwordFormat;
        //        int appId = GetAppplicationId();
        //        long userId = GetUserID(username);

        //        string hashUserPassword = GetPasswordWithFormat(userId, out passwordFormat, out salt);
        //        string hashUserNewPassword = EncodePassword(newPassword, passwordFormat, salt);

        //        UserBLL userBLL = new UserBLL();
        //        userBLL.UpdatePassword(username, hashUserPassword, hashUserNewPassword, salt);
        //        return userBLL.ResponseMessage;
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}

        public override bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override MembershipUser CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out MembershipCreateStatus status)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override bool DeleteUser(string username, bool deleteAllRelatedData)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override int GetNumberOfUsersOnline()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override string GetPassword(string username, string answer)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override MembershipUser GetUser(string username, bool userIsOnline)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override string GetUserNameByEmail(string email)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override string ResetPassword(string username, string answer)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override bool UnlockUser(string userName)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override void UpdateUser(MembershipUser user)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override bool ValidateUser(string username, string password)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public bool ValidateUser(string username, string password, ref string responseMessage)
        {
            try
            {
                bool result = false;
                long userId = GetUserID(username);
               
                if (userId > 0)
                {
                    if (CheckPassword(userId, password))
                    {
                        result = true;
                        responseMessage = "User login.";
                    }
                    else
                    {
                        result = false;
                        responseMessage = "Invalid password.";
                    }
                }
                else
                {
                    responseMessage = "Username does not exist.";
                }
                
                return result;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public string GenerateSalt()
        {
            byte[] buf = new byte[SALT_SIZE_IN_BYTES];
            (new RNGCryptoServiceProvider()).GetBytes(buf);
            return Convert.ToBase64String(buf);
        }

        public string EncodePassword(string pass, int passwordFormat, string salt)
        {
            if (passwordFormat == 0) // MembershipPasswordFormat.Clear
                return pass;

            byte[] bIn = Encoding.Unicode.GetBytes(pass);
            byte[] bSalt = Convert.FromBase64String(salt);
            byte[] bAll = new byte[bSalt.Length + bIn.Length];
            byte[] bRet = null;

            Buffer.BlockCopy(bSalt, 0, bAll, 0, bSalt.Length);
            Buffer.BlockCopy(bIn, 0, bAll, bSalt.Length, bIn.Length);
            if (passwordFormat == 1)    // MembershipPasswordFormat.Hashed
            {
                if (string.IsNullOrEmpty(_HashAlgorithmType))
                    _HashAlgorithmType = GetConfigData("hashAlgorithmType");

                HashAlgorithm s = HashAlgorithm.Create(_HashAlgorithmType);

                if (s == null)
                {
                    throw new ProviderException("Could not create a hash algorithm");
                }
                bRet = s.ComputeHash(bAll);
            }
            else
            {
                bRet = EncryptPassword(bAll);
            }

            return Convert.ToBase64String(bRet);
        }

        private string UnEncodePassword(string pass, int passwordFormat)
        {
            switch (passwordFormat)
            {
                case 0: // MembershipPasswordFormat.Clear:
                    return pass;
                case 1: // MembershipPasswordFormat.Hashed:
                    throw new ProviderException("Provider can not decode hashed password");
                default:
                    byte[] bIn = Convert.FromBase64String(pass);
                    byte[] bRet = DecryptPassword(bIn);
                    if (bRet == null)
                        return null;
                    return Encoding.Unicode.GetString(bRet, SALT_SIZE_IN_BYTES, bRet.Length - SALT_SIZE_IN_BYTES);
            }
        }

        private string GetPasswordWithFormat(long userId, out int passwordFormat, out string passwordSalt)
        {
            string pass = string.Empty;

            passwordFormat = 1;
            passwordSalt = String.Empty;
            if (userId == 0)
                return null;

            UserDAL userDAL = new UserDAL();
            User userEntity = userDAL.GetUserByID(userId);

            if (!string.IsNullOrEmpty(userEntity.UserName))
            {
                pass = userEntity.Password == null ? string.Empty : userEntity.Password;
                passwordSalt = userEntity.Salt == null ? string.Empty : userEntity.Salt;

                _PasswordFormat = MembershipPasswordFormat.Hashed;
                switch (_PasswordFormat)
                {
                    case MembershipPasswordFormat.Clear:
                        passwordFormat = 0;
                        break;
                    case MembershipPasswordFormat.Encrypted:
                        passwordFormat = 2;
                        break;
                    case MembershipPasswordFormat.Hashed:
                        passwordFormat = 1;
                        break;
                    default:
                        throw new ProviderException("Bad password format");
                }
            }

            return pass;
        }

        private int GetAppplicationId()
        {
            string appName = _AppName;
            if (!string.IsNullOrEmpty(appName))
            {
                if (appName.Length > 255)
                    appName = appName.Substring(0, 255);
            }
            _ApplicationId = 10011;
            _ApplicationIDCacheDate = DateTime.Now;
            if (_ApplicationId != 0)
                return _ApplicationId;
            throw new ProviderException("sorry exception in GetApplicationId");
        }

        private bool CheckPassword(long userId, string password)
        {
            string salt;
            int passwordFormat;
            string pass = GetPasswordWithFormat(userId, out passwordFormat, out salt);
            string pass2 = EncodePassword(password, passwordFormat, salt);
            return (pass == pass2);
        }

        private bool IsStatusDueToBadPassword(int status)
        {
            return (status >= 2 && status <= 6);
        }

        private const int PASSWORD_SIZE = 14;

        public virtual string GeneratePassword()
        {
            return Membership.GeneratePassword(
                      MinRequiredPasswordLength < PASSWORD_SIZE ? PASSWORD_SIZE : MinRequiredPasswordLength,
                      MinRequiredNonAlphanumericCharacters);
            string _allowedChars = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
            Random randNum = new Random();
            char[] chars = new char[8];
            int allowedCharCount = _allowedChars.Length;
            for (int i = 0; i < 8; i++)
            {
                chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
            }
            return new string(chars);
        }

        private string GetExceptionText(int status)
        {
            string key;
            switch (status)
            {
                case 0:
                    return String.Empty;
                case 1:
                    key = "User not found";
                    break;
                case 2:
                    key = "Wrong password";
                    break;
                case 3:
                    key = "Wrong answer";
                    break;
                case 4:
                    key = "Invalid password";
                    break;
                case 5:
                    key = "Invalid question";
                    break;
                case 6:
                    key = "Invalid answer";
                    break;
                case 7:
                    key = "Invalid email";
                    break;
                default:
                    key = "Unknown provider error";
                    break;
            }
            return key;
        }

        //public bool SaveUser(UserRegisterModel userRegisterModel, ref string responseMessage)
        //{
        //    string password = userRegisterModel.Password;
        //    string email = userRegisterModel.EmailAddress;

        //    string salt = GenerateSalt();
        //    string encodedPassword = EncodePassword(password, (int)MembershipPasswordFormat.Hashed, salt);

        //    userRegisterModel.Salt = salt;
        //    userRegisterModel.Password = encodedPassword;

        //    UserBLL userBLL = new UserBLL();
        //    bool status = userBLL.RegisterUser(userRegisterModel.FirstName, userRegisterModel.Lastname, userRegisterModel.UserName,
        //        userRegisterModel.EmailAddress, userRegisterModel.Password, userRegisterModel.Salt);
        //    responseMessage = userBLL.ResponseMessage;
        //    return status;
        //}

        public string ResetPassword(string newPassword, string salt, string opt = "")
        {
            string pass2 = EncodePassword(newPassword, (int)MembershipPasswordFormat.Hashed, salt);
            return pass2;
        }

        public string GetConfigData(string strKey)
        {
            string strValue = string.Empty;
            try
            {
                Configuration config = WebConfigurationManager.OpenWebConfiguration("/");
                SystemWebSectionGroup syswebSection = (SystemWebSectionGroup)config.GetSectionGroup("system.web");

                //  Get Key Value from Web.Config 
                if (syswebSection.Membership.Providers["MyMembershipProvider"] != null)
                    strValue = Convert.ToString(syswebSection.Membership.Providers["MyMembershipProvider"].Parameters[strKey]);

                if (string.IsNullOrWhiteSpace(strValue))
                {
                    switch (strKey)
                    {
                        case "hashAlgorithmType":
                            strValue = "MD5";
                            break;
                        case "minRequiredPasswordLength":
                            strValue = "8";
                            break;
                        case "minRequiredNonalphanumericCharacters":
                            strValue = "1";
                            break;
                        case "maxInvalidPasswordAttempts":
                            strValue = "5";
                            break;

                    }
                }

                return strValue;
            }
            catch
            {
                switch (strKey)
                {
                    case "hashAlgorithmType":
                        strValue = "MD5";
                        break;
                    case "minRequiredPasswordLength":
                        strValue = "8";
                        break;
                    case "minRequiredNonalphanumericCharacters":
                        strValue = "1";
                        break;
                    case "maxInvalidPasswordAttempts":
                        strValue = "5";
                        break;
                }
                return strValue;
            }
        }

        private static long GetUserID(string username)
        {
            UserDAL userDAL = new UserDAL();
            return userDAL.GetUserID(username);
        }

        private static int GetRoleID(string userId)
        {
            UserDAL userBLL = new UserDAL();
            return userBLL.GetRoleID(userId);
        }

        private string GetSalt()
        {
            return GenerateSalt();
        }


        ///// <summary>
        /////     Activate User.
        ///// </summary>
        ///// <param name="emailAddress"></param>
        ///// <param name="activationCode"></param>
        ///// <param name="responseMessage"></param>
        ///// <returns></returns>
        //public bool ActivateUser(string emailAddress, string activationCode, ref string responseMessage)
        //{
        //    bool result = false;
        //    UserDAL userDAL = new UserDAL();
        //    try
        //    {
        //        result = userDAL.ActivateUserAccount(emailAddress, activationCode);
        //    }
        //    catch (Exception ex)
        //    {
        //        responseMessage = userBLL.ResponseMessage;
        //    }

        //    responseMessage = userBLL.ResponseMessage;
        //    return result;

        //}

        //public static string GetCurrentUserRole
        //{
        //    get
        //    {
        //        UserDAL userDAL = new UserDAL();
        //        string username = HttpContext.Current.User.Identity.Name;
        //        long userId = userDAL.GetUserID(username);
        //        int roleId = userDAL.GetRoleID(userId);
        //        string userRoles = userDAL.GetRoleName(roleId);
        //        return userRoles;

        //    }
        //}

    }
}