﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndRa.RiskModel.Helpers
{
    public class CommonEntity
    {
        public string ResponseMessage { get; set; }
    }
}