﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace IndRa.RiskModel.Helpers
{
    public class ErrorLogger
    {

        private static readonly ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public static void LogError(Exception Exception, object objMessage = null)
        {
            if (Exception == null) return;
            if (Exception is HttpUnhandledException)
            {
                if (Exception.InnerException != null)
                {
                    if (logger.IsErrorEnabled)
                    {
                        logger.Error(Exception.StackTrace, Exception);
                        logger.Error(objMessage, Exception.InnerException);
                    }
                }
            }
            else
            {
                if (logger.IsErrorEnabled)
                {
                    logger.Error(Exception.StackTrace, Exception);
                    logger.Error(objMessage, Exception);
                }
            }
        }

        public static void LogInfo(string customeMessage)
        {
            try
            {
                string customMessage = customeMessage;
                if (!string.IsNullOrEmpty(customMessage))
                {
                    logger.Info(customMessage);
                    return;
                }
            }
            catch (Exception exception)
            {

            }
        }
    }
}