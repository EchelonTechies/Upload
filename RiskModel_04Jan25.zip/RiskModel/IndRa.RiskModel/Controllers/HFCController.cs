﻿using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using System.Text;
using System.ComponentModel;
using Xceed.Words.NET;
using Xceed.Document.NET;
using System.Globalization;
using ClosedXML.Excel;

namespace IndRa.RiskModel.Controllers
{
    public class HFCController : Controller
    {

        CommonDAL commonDAL = new CommonDAL();

        [Authorize]
        public ActionResult Index()
        {
            return RedirectToAction("ReadRiskModelExcelFile");
        }

        [Authorize]
        public ActionResult ReadRiskModelExcelFile(int? detailsId, short? logId)
        {
            RiskModelExcelEntity riskModelExcelEntity = new RiskModelExcelEntity();
            CompanyDAL companyDAL = new CompanyDAL();
            HFCDAL hfcDAL = new HFCDAL();
            HFC_BasicDetailsEntity hfc_BasicDetailsEntity = new HFC_BasicDetailsEntity();
            try
            {
                int roleID = SessionValue.RoleID;
                int userID = SessionValue.UserID;

                ViewBag.Companies = DropDownValue.GetCompaniesList((int)ModelsEnum.HFC, roleID, userID);
                ViewBag.YesorNoStatus = DropDownValue.GetYesorNoStatus();
                ViewBag.ParameterNo = DropDownValue.GetParamterNoList();
                ViewBag.CurrencyList = DropDownValue.GetCurrencyList();
                ViewBag.RatingList = DropDownValue.GetRatingsList((int)ModelsEnum.HFC);
                ViewBag.FinYearList = DropDownValue.GetFinYearList();

                if (detailsId.HasValue && detailsId != 0)
                {
                    // Get Log Data
                    if (logId.HasValue && logId.Value > 0)
                    {
                        hfc_BasicDetailsEntity = hfcDAL.GetBasicDetails_Archive(detailsId.Value, logId.Value);
                    }
                    else
                    {
                        hfc_BasicDetailsEntity = hfcDAL.GetBasicDetails(detailsId.Value);
                    }
                }
                else
                {
                    hfc_BasicDetailsEntity.DetailsId = 0;
                }
                if (hfc_BasicDetailsEntity.HFC_OutputDetailsEntity == null || hfc_BasicDetailsEntity.HFC_OutputDetailsEntity.Count == 0)
                {
                    hfc_BasicDetailsEntity.HFC_OutputDetailsEntity = hfcDAL.GetOutputTemplateEntity();
                }
                return View(hfc_BasicDetailsEntity);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
        }

        [Authorize]
        [HttpPost]
        public ActionResult ImporRiskModelData(HFC_BasicDetailsEntity riskModelExcelEntity)
        {
            bool success = false;
            string message = string.Empty;
            int userID = SessionValue.UserID;
            HFC_BasicDetailsEntity riskModelResult = new HFC_BasicDetailsEntity();
            try
            {
                HFCDAL hfcDAL = new HFCDAL();
                string fileName = Path.GetFileName(riskModelExcelEntity.ExcelFile.FileName);
                string copyFile = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}{1}", ConfigManager.GetExcelSheetFileCopyPath(), fileName));
                string copyFilePath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}", ConfigManager.GetExcelSheetFileCopyPath()));

                System.IO.Directory.CreateDirectory(copyFilePath);

                if (System.IO.Directory.Exists(copyFilePath))
                {
                    if (System.IO.File.Exists(copyFile))
                    {
                        System.IO.File.Delete(copyFile);
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }
                    else
                    {
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }

                    riskModelResult = hfcDAL.ImportCompanyDetailsFromExcel(copyFile, fileName, "Data Input Sheet$", userID);

                    if (riskModelResult != null)
                    {
                        riskModelResult.InputFilePath = copyFile;
                        success = true;
                        message = "Data Fetched From Excel Sheet";
                    }
                    else
                    {
                        success = false;
                        message = "Unable to fetch Excel Sheet Data";
                    }
                }

            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                success = false;
                message = exception.Message;

            }
            finally
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            return Json(new
            {
                Status = success,
                Message = message,
                Result = riskModelResult,
            }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SaveHFCDetails(HFC_BasicDetailsEntity riskModelExcelEntity)
        {
            int detailID = 0;
            short logID = 0;
            int detail_ArchiveID = 0;
            bool status = false;
            string message = string.Empty;

            try
            {
                //WriteFile("SaveHFCDetails :  " + riskModelExcelEntity.CompanyId);

                int userId = SessionValue.UserID;
                int roleId = SessionValue.RoleID;

                CompanyDAL companyDAL = new CompanyDAL();
                CommonFunction commonFunction = new CommonFunction();
                HFCDAL hcfDAL = new HFCDAL();
                UserDAL userDAL = new UserDAL();

                List<HFC_OutputDetailsEntity> outputDetailsEntity = new List<HFC_OutputDetailsEntity>();
                string outputFileName = "";

                #region Compute Output

                if (riskModelExcelEntity.ButtonValue == "ComputeOutput")
                {
                    status = true;
                    outputDetailsEntity = ComputeOutputDetails(riskModelExcelEntity, false, out outputFileName);
                    return Json(new
                    {
                        ButtonValue = riskModelExcelEntity.ButtonValue,
                        Status = status,
                        Message = message,
                        Result = outputDetailsEntity,
                    }, JsonRequestBehavior.AllowGet);
                }

                #endregion

                #region Download

                else if (riskModelExcelEntity.ButtonValue == "Download")
                {
                    status = true;
                    outputDetailsEntity = ComputeOutputDetails(riskModelExcelEntity, true, out outputFileName);
                    return Json(new
                    {
                        ButtonValue = riskModelExcelEntity.ButtonValue,
                        Status = status,
                        Message = message,
                        Result = outputDetailsEntity,
                        FileName = outputFileName,
                    }, JsonRequestBehavior.AllowGet);
                }

                #endregion

                #region Save

                else
                {

                    int? assignedUserID = companyDAL.GetAssignedAnalystID(riskModelExcelEntity.CompanyId);
                    string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
                    string toEmailAddress = userDAL.GetUserEmailAddress(assignedUserID.HasValue ? assignedUserID.Value : 0);

                    riskModelExcelEntity.HFC_KeyFinancialsEntity.CreatedBy = userId;
                    riskModelExcelEntity.HFC_KeyFinancialsEntity.UpdatedBy = userId;
                    riskModelExcelEntity.HFC_KeyFinancialsEntity.CreatedDateTime = DateTime.Now;
                    riskModelExcelEntity.HFC_KeyFinancialsEntity.UpdatedDateTime = DateTime.Now;

                    riskModelExcelEntity.HFC_SubjectiveParametersEntity.CreatedBy = userId;
                    riskModelExcelEntity.HFC_SubjectiveParametersEntity.UpdatedBy = userId;
                    riskModelExcelEntity.HFC_SubjectiveParametersEntity.CreatedDateTime = DateTime.Now;
                    riskModelExcelEntity.HFC_SubjectiveParametersEntity.UpdatedDateTime = DateTime.Now;

                    riskModelExcelEntity.CreatedDateTime = DateTime.Now;
                    if (Validation(riskModelExcelEntity, out message) == true)
                    {
                        if (userId != 0)
                        {
                            detailID = hcfDAL.SaveCompanyBasicDetailsAsDraft(userId, roleId, riskModelExcelEntity, out detail_ArchiveID, out logID);

                            if (detailID > 0)
                            {
                                commonFunction.MoveFileToInputFolder(riskModelExcelEntity.InputFilePath, riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);

                                // save Key Financials record
                                hcfDAL.SaveAsDraft_KeyFinancial(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.HFC_KeyFinancialsEntity);

                                // save Subjective Parameters record
                                hcfDAL.SaveAsDraft_SubjectiveParameters(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.HFC_SubjectiveParametersEntity);

                                // save Subjective Parameters record
                                hcfDAL.SaveAsDraft_OutputDetails(userId, roleId, detailID, logID, detail_ArchiveID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.HFC_OutputDetailsEntity);

                                if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                                {
                                    Email.SendMail(toEmailAddress, companyName, (int)EmailTemplateEnum.ApprovedEntityTemplate);
                                }
                                status = true;
                                message = "success";
                            }
                        }
                        else
                        {
                            message = "Session expired. Please relogin";
                        }
                        return Json(new
                        {
                            DetailID = detailID,
                            ButtonValue = riskModelExcelEntity.ButtonValue,
                            Status = status,
                            Message = message,
                            Result = riskModelExcelEntity,
                        }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new
                        {
                            ButtonValue = riskModelExcelEntity.ButtonValue,
                            Status = false,
                            Message = message,
                            Result = riskModelExcelEntity,
                        }, JsonRequestBehavior.AllowGet);
                    }
                }

                #endregion

            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }
            return Json(new
            {
                ButtonValue = riskModelExcelEntity.ButtonValue,
                Status = false,
                Message = message,
                Result = riskModelExcelEntity
            }, JsonRequestBehavior.AllowGet);
        }

        public bool Validation(HFC_BasicDetailsEntity riskModelExcelEntity, out string message)
        {
            StringBuilder sbQuery = new StringBuilder();
            message = "";

            object obj;

            if (riskModelExcelEntity.CompanyId == 0)
            {
                sbQuery.AppendLine("Basic Details: Entity Name is mandatory");
                message = sbQuery.ToString();
                return false;
            }
            else if (string.IsNullOrEmpty(riskModelExcelEntity.FinYear))
            {
                sbQuery.AppendLine("Basic Details: Financial Year is mandatory");
                message = sbQuery.ToString();
                return false;
            }
            if (riskModelExcelEntity.ButtonValue == ButtonValue.SaveAsDraft.ToString())
            {
                return true;
            }

            if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
            {
                if (string.IsNullOrEmpty(riskModelExcelEntity.Comments))
                {
                    sbQuery.AppendLine("Output: Admin comments is mandatory");
                }
                else if (string.IsNullOrEmpty(riskModelExcelEntity.FinalRating))
                {
                    sbQuery.AppendLine("Output: Final Rating is mandatory");
                }
            }
            HFC_KeyFinancialsEntity keyFinancialsEntity = riskModelExcelEntity.HFC_KeyFinancialsEntity;
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(keyFinancialsEntity);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null && property.DisplayName != string.Empty)
                    {
                        obj = keyFinancialsEntity.GetType().GetProperty(property.Name).GetValue(keyFinancialsEntity, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Key Financials: " + property.DisplayName + " is mandatory");
                        }
                        else
                        {
                            if (property.DisplayName == "Period of Year End" || property.DisplayName == "Period of Year End2")
                            {
                                string value = obj.ToString();
                                DateTime periodDate = Convert.ToDateTime(value);
                                DateTime curDate = DateTime.Now;
                                if (periodDate > curDate)
                                {
                                    sbQuery.AppendLine("Key Financials: " + property.DisplayName + " cannot be greater than current date");
                                }
                            }
                        }
                    }
                }
                catch { }
            }

            HFC_SubjectiveParametersEntity subjectiveParametersEntity = riskModelExcelEntity.HFC_SubjectiveParametersEntity;
            properties = TypeDescriptor.GetProperties(subjectiveParametersEntity);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = subjectiveParametersEntity.GetType().GetProperty(property.Name).GetValue(subjectiveParametersEntity, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Subjective Parameters: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            if (sbQuery.Length > 0)
            {
                message = sbQuery.ToString();
                return false;
            }
            return true;
        }

        [HttpPost]
        public List<HFC_OutputDetailsEntity> ComputeOutputDetails(HFC_BasicDetailsEntity riskModelExcelEntity, bool isDownload, out string outputfileName)
        {
            outputfileName = string.Empty;
            List<HFC_OutputDetailsEntity> outputDetailsEntity = new List<HFC_OutputDetailsEntity>();
            string message = string.Empty;

            try
            {
                WriteFile("Computing hfc output:  " + riskModelExcelEntity.CompanyId);

                int userId = SessionValue.UserID;
                int roleId = SessionValue.RoleID;
                CompanyDAL companyDAL = new CompanyDAL();
                HFCDAL hfcDAL = new HFCDAL();

                bool status = false;
                string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
                companyName = companyName.Replace("&", "");
                string fileName = string.Format("{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetHFC_InputTemplateFilePath()));
                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));

                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);

                status = hfcDAL.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath, out message);
                outputDetailsEntity = hfcDAL.GetOutputFromExcel(userTemplateFilePath, fileName, "Output NHB$", userId);
                if (userTemplateFilePath != null && isDownload == false)
                {
                    if (System.IO.File.Exists(userTemplateFilePath))
                    {
                        System.IO.File.Delete(userTemplateFilePath);
                    }
                }
                outputfileName = fileName;
            }
            catch (Exception ex)
            {
                WriteFile("Error Log :  " + ex.Message);
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }
            if (message != string.Empty)
            {
                WriteFile("Error Log :  " + message);
                ErrorLogger.LogInfo(message);
            }
            return outputDetailsEntity;
        }

        public JsonResult GetInputExcelFile(string detailsID)
        {
            string fileName = "";

            CompanyDAL company = new CompanyDAL();
            string inputFolder = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}", ConfigManager.GetInputPath()));
            string finYear = company.GetFinancialYearDetailsID(int.Parse(detailsID));
            string companyName = company.GetCompanyNameByDetailsID(int.Parse(detailsID));
            string filePath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}{1}\\{2}", ConfigManager.GetInputPath(), finYear, companyName));
            if (Directory.Exists(filePath))
            {
                string[] filePaths = Directory.GetFiles(filePath);
                for (int i = 0; i < filePaths.Length; i++)
                {
                    fileName = filePaths[i];
                }
            }
            return Json(new { aaData = fileName }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DownloadInputExcelFile(string filePath)
        {
            byte[] fileByteArray = System.IO.File.ReadAllBytes(filePath);
            string fileName = Path.GetFileName(filePath);
            return File(fileByteArray, "application/vnd.ms-excel", fileName);
        }

        public ActionResult DownloadOutputExcelFile(string fileName)
        {
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
            byte[] fileByteArray = System.IO.File.ReadAllBytes(userTemplateFilePath);
            return File(fileByteArray, "application/vnd.ms-excel", fileName);
        }

        [Authorize]
        [HttpGet]
        public ActionResult GetRatingPD(string ratingID)
        {
            CommonDAL commonDAL = new CommonDAL();
            string result = commonDAL.GetRatingPD(ratingID);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetFinancialYearEndDate(DateTime dateOfInput)
        {
            CommonDAL commonDAL = new CommonDAL();
            string result = commonDAL.GetFinancialYearEndDate(dateOfInput);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetPreviousKeyFinancialsData(string companyId, DateTime periodEndDate)
        {
            CommonDAL commonDAL = new CommonDAL();
            System.Data.DataTable dataTable = commonDAL.GetPreviousKeyFinancialsData(companyId, periodEndDate);
            List<HFC_KeyFinancialsEntity> obj = CommonDAL.ConvertDataTable<HFC_KeyFinancialsEntity>(dataTable);
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetSessionRoleId()
        {
            string result = SessionValue.RoleID.ToString();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetKeyFinancialsDefinition(int modelId)
        {
            List<ParameterDefinitionEntity> result = commonDAL.GetParameterDefinition(modelId);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetSubjectiveParameterDefinition(int modelId, string headerName)
        {
            // string a = Enum.GetName(typeof(SubjectiveParametersEnum), headerName);
            SubjectiveParametersEnum subjectiveParametersEnum = (SubjectiveParametersEnum)Enum.Parse(typeof(SubjectiveParametersEnum), headerName);
            int headerID = (int)subjectiveParametersEnum;

            List<ParameterDefinitionEntity> result = commonDAL.GetSubjectiveParameterDefinition(modelId, headerID);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        #region Report - Word document
        public ActionResult DownloadOutputWordFile(string fileName)
        {
            byte[] fileByteArray = System.IO.File.ReadAllBytes(fileName);
            string stringCutted = fileName.Split('/').Last();
            return File(fileByteArray, "application/vnd.ms-word", stringCutted);
        }

        [Authorize]
        [HttpPost]

        public ActionResult DownloadWord(string detailsId, string modelId, string logID)
        {
            bool status = false;
            string fileName = "";
            try
            {
                int sLogID = string.IsNullOrEmpty(logID) ? 0 : int.Parse(logID);
                System.Data.DataTable result = commonDAL.GetOutputDetailsReport(modelId, detailsId, sLogID);
                string companyName = result.Rows[0]["CompanyName"].ToString();
                companyName = companyName.Replace("&", "");
                CommonFunction _cmdFunction = new CommonFunction();

                string filePath = Server.MapPath("~//" + ConfigManager.GetReportWordDownloadFolder());

                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }

                fileName = ConfigManager.GetReportWordDownloadFileName() + "_" + companyName + "_" + DateTime.Now.Ticks.ToString() + ".docx";
                fileName = filePath + "//" + fileName;

                if (System.IO.File.Exists(filePath))
                {
                    System.IO.File.Delete(filePath);
                }

                int rSize = result.Rows.Count;
                int cSize = result.Columns.Count;

                //Formatting Text Title 
                Formatting titleFormat = new Formatting();
                titleFormat.FontFamily = new Xceed.Document.NET.Font("Calibri"); //new Xceed.Document.NET.Font(CommonFunction.REPORT_WORD_FONT);   //Specify font family 
                titleFormat.Size = 14;  //Specify font size
                titleFormat.Position = 40;
                titleFormat.FontColor = System.Drawing.Color.Black;
                //titleFormat.UnderlineColor = System.Drawing.Color.Gray;

                //Formatting Text Paragraph center 
                Formatting textParagraphFormatCenter = new Formatting();
                textParagraphFormatCenter.FontFamily = new Xceed.Document.NET.Font("Calibri");     //new Xceed.Document.NET.Font(CommonFunction.REPORT_WORD_FONT);    //font family  
                textParagraphFormatCenter.Size = 14;    //font size
                textParagraphFormatCenter.Position = 40;
                textParagraphFormatCenter.Bold = true;
                textParagraphFormatCenter.FontColor = System.Drawing.Color.Black;

                Formatting textFormat = new Formatting();
                textFormat.FontFamily = new Xceed.Document.NET.Font("Calibri");     //new Xceed.Document.NET.Font(CommonFunction.REPORT_WORD_FONT);    //font family  
                textFormat.Size = 14;    //font size
                textFormat.Position = 10;
                textFormat.FontColor = System.Drawing.Color.Black;


                DocX docX = DocX.Create(fileName, DocumentTypes.Document);

                var myImageFullPath = Server.MapPath(string.Format("~//images//{0}", ConfigManager.GetReportWordDownloadLogoName()));

                #region Logo
                // Add an image into the document.    
                Xceed.Document.NET.Image image = docX.AddImage(myImageFullPath);

                // Create a picture (A custom view of an Image).
                Xceed.Document.NET.Picture picture = image.CreatePicture();

                // Insert a new Paragraph into the document.
                Paragraph p1 = docX.InsertParagraph();

                // Append content to the Paragraph
                p1.AppendPicture(picture);
                p1.Alignment = Alignment.center;

                #endregion

                string riskManagementDeptTitle = "RISK MANAGEMENT DEPARTMENT";
                docX.InsertParagraph(riskManagementDeptTitle, false, textParagraphFormatCenter).Alignment = Alignment.center;

                string internalCreditRatingTitle = "INTERNAL CREDIT RATING";
                docX.InsertParagraph(internalCreditRatingTitle, false, textParagraphFormatCenter).Alignment = Alignment.center;

                string subjectiveParamtersTitle = "Scoring of Parameters: ";
                docX.InsertParagraph(subjectiveParamtersTitle, false, titleFormat);


                #region Output Details Table

                string finalRating = result.Rows[0]["FinalRating"].ToString();
                string pd = result.Rows[0]["PD"].ToString();
                string comments = result.Rows[0]["AdminComment"].ToString();

                result.Columns.RemoveAt(0);
                result.Columns.RemoveAt(0);
                result.Columns.RemoveAt(0);
                result.Columns.Remove("AdminComment");

                rSize = result.Rows.Count;
                cSize = result.Columns.Count;

                Table table = docX.AddTable(rSize + 1, cSize);    // incremented row by 1, to add header

                table.AutoFit = AutoFit.Contents;
                table.Design = TableDesign.TableNormal;
                table.SetTableCellMargin(TableCellMarginType.left, 20);

                for (int i = 0; i <= (int)TableBorderType.InsideV; i++)
                {
                    table.SetBorder((TableBorderType)i, new Xceed.Document.NET.Border());
                }

                // Add header to table
                for (int j = 0; j < cSize; j++)
                {
                    table.Rows[0].Cells[j].FillColor = System.Drawing.ColorTranslator.FromHtml("#FFD3D3D3");
                    table.Rows[0].Cells[j].Paragraphs[0].Bold().InsertText(result.Columns[j].ToString());
                }
                // Add rows to table
                for (int i = 0; i < rSize; i++)
                    for (int j = 0; j < cSize; j++)
                        table.Rows[i + 1].Cells[j].Paragraphs[0].FontSize(14).InsertText(result.Rows[i][j].ToString());

                docX.InsertParagraph().InsertTableBeforeSelf(table);
                #endregion

                string ratingTitle = "Rating as per committee: " + finalRating;
                docX.InsertParagraph(ratingTitle, false, titleFormat);

                string PD = "Probability of Default: " + pd + "%";
                docX.InsertParagraph(PD, false, titleFormat);

                string comment = "Committee comments: " + comments;
                docX.InsertParagraph(comment, false, textFormat);

                docX.Save();

                status = true;
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
            }
            // return result to View
            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);

        }

        [Authorize]
        [HttpGet]

        public ActionResult DownloadExcelAsPerTable(string detailsId, string modelId, string logID)
        {
            string fileName = detailsId + ".xlsx";
            try
            {
                int sLogID = string.IsNullOrEmpty(logID) ? 0 : int.Parse(logID);
                System.Data.DataTable result = commonDAL.GetOutputDetailsForExcelReport(modelId, detailsId, sLogID);
                using (XLWorkbook wb = new XLWorkbook())
                {
                    //Add DataTable in worksheet  
                    wb.Worksheets.Add(result);
                    using (MemoryStream stream = new MemoryStream())
                    {
                        wb.SaveAs(stream);
                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
                    }
                }
            }
            catch { }
            return View();
        }

        #endregion

        [HttpPost]
        public string GetFinalRatingDefinition(int modelId, int detailsId)
        {
            System.Data.DataTable result = commonDAL.GetFinalRatingDefinition(modelId, detailsId);
            return Newtonsoft.Json.JsonConvert.SerializeObject(new { result = result });
        }

        public void WriteFile(string text)
        {
            string path = ConfigManager.GetLogFolder();
            byte[] bytes = Encoding.ASCII.GetBytes(text);
            System.IO.FileStream file = System.IO.File.Create(path);
            file.Write(bytes, 0, bytes.Length);
            file.Close();
        }
    }
}

#region Extra Code

//private void SaveExcel(string existingFile, string newfilePath)
//{
//    Excel.Application xl = new Excel.Application();
//    Excel.Workbook wb = xl.Workbooks.Open(existingFile);
//    wb.SaveAs(newfilePath, Excel.XlFileFormat.xlWorkbookDefault,
//                         Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlNoChange,
//                         Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
//    wb.Saved = true;
//    wb.Close();
//    xl.Workbooks.Close();
//    xl.Quit();
//    //Excel.Application.
//    //Microsoft.Office.Interop.Excel.ExcelWorkBook.SaveAs("c:\\test.xls", Excel.XlFileFormat.xlWorkbookNormal,
//    //                     null, null, false, false, Excel.XlSaveAsAccessMode.xlShared,
//    //                     false, false, null, null, null);
//    //ExcelWorkBook.Close();
//}

//public ActionResult ReadOutputDetails()
//{
//    CompanyDAL companyDAL = new CompanyDAL();
//    HFCDAL hcfDAL = new HFCDAL();

//    try
//    {
//        string filePath = "";
//        string fileName = "";
//        filePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetOutputTemplateCopyFilePath()));
//        fileName = "2.xlsx";
//        filePath = filePath + fileName;
//        List<HFC_OutputDetailsEntity> hfc_OutputDetailsEntity = new List<HFC_OutputDetailsEntity>();
//        hfc_OutputDetailsEntity = hcfDAL.GetOutputFromExcel(filePath, fileName, "Output NHB$", 0);
//        return Json(new
//        {
//            Result = hfc_OutputDetailsEntity,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    catch (Exception ex)
//    {
//        ErrorLogger.LogError(ex, this);
//    }
//    return Json(new
//    {
//        Status = false,
//    }, JsonRequestBehavior.AllowGet);
//}
//public ActionResult ComputeOutputDetails_Old(int companyId)
//{
//    int userId = SessionValue.UserID;
//    int roleId = SessionValue.RoleID;
//    CompanyDAL companyDAL = new CompanyDAL();
//    HFCDAL hcfDAL = new HFCDAL();

//    bool status = false;
//    string message = string.Empty;
//    string companyName = companyDAL.GetCompanyNameByID(companyId);
//    int detailsID = companyDAL.GetCompanyBasicDetailsID(companyId);
//    if (detailsID == 0)
//    {
//        message = "Please save the entry as draft first";
//        return Json(new
//        {
//            Status = false,
//            Message = message,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetHFC_InputTemplateFilePath()));
//    string userTemplateFilePath = Server.MapPath(string.Format("~{0}//InputReport_{1}_{2}.xlsx", ConfigManager.GetOutputTemplateCopyFilePath(), companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss")));

//    System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
//    string fileName = string.Format("InputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));

//    try
//    {
//        List<HFC_OutputDetailsEntity> hfc_OutputDetailsEntity = new List<HFC_OutputDetailsEntity>();
//        status = hcfDAL.Get_OutputDetailsFromFrontEnd_InterOp(detailsID, userTemplateFilePath);
//        hfc_OutputDetailsEntity = hcfDAL.GetOutputFromExcel(userTemplateFilePath, fileName, "Output NHB$", userId);
//        if (userTemplateFilePath != null)
//        {
//            //if (System.IO.File.Exists(userTemplateFilePath))
//            //{
//            //    System.IO.File.Delete(userTemplateFilePath);
//            //}
//        }
//        return Json(new
//        {
//            Status = status,
//            Message = message,
//            Result = hfc_OutputDetailsEntity,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    catch (Exception ex)
//    {
//        ErrorLogger.LogError(ex, this);
//        message = ex.ToString();
//    }
//    return Json(new
//    {
//        Status = false,
//        Message = message,
//        //Result = riskModelExcelEntity,
//    }, JsonRequestBehavior.AllowGet);
//}

//[Authorize]
//[HttpPost]
//public ActionResult Download_HFCOutputDetails(int CompanyId, string CreatedDateTime)
//{
//    bool status = false;
//    string message = string.Empty;
//    string fileName = string.Empty;
//    int userID = SessionValue.UserID;
//    try
//    {
//        HFCDAL hfcDAL = new HFCDAL();
//        CompanyDAL companyDAL = new CompanyDAL();
//        string companyName = companyDAL.GetCompanyNameByID(CompanyId);
//        string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetHFC_OutputTemplateFilePath()));
//        string userTemplateFilePath = Server.MapPath(string.Format("~{0}//OutputReport_{1}_{2}.xlsx", ConfigManager.GetOutputTemplateCopyFilePath(), companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss")));
//        System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
//        fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
//        status = hfcDAL.Get_OutputDetails_OpenXML(CompanyId, Convert.ToDateTime(CreatedDateTime), userTemplateFilePath);
//    }
//    catch (Exception exception)
//    {
//        ErrorLogger.LogError(exception, this);
//        status = false;
//    }

//    return Json(new
//    {
//        fileName = fileName,
//        status = status,
//    }, JsonRequestBehavior.AllowGet);
//}


//[HttpPost]
//public ActionResult SaveOutput(List<HFC_OutputDetailsEntity> outputDetailsEntity)
//{
//    int userId = SessionValue.UserID;
//    int roleId = SessionValue.RoleID;
//    int detail_ArchiveID = 0;
//    bool status = false;
//    string message = string.Empty;
//    try
//    {
//        CompanyDAL companyDAL = new CompanyDAL();
//        HFCDAL hcfDAL = new HFCDAL();

//        DateTime dt = DateTime.Now;

//        //// save Output records
//        status = hcfDAL.SaveAsDraft_OutputDetails(userId, roleId, outputDetailsEntity[0].DetailsId, detail_ArchiveID, dt, outputDetailsEntity);

//        return Json(new
//        {
//            Status = status,
//            Message = message,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    catch (Exception ex)
//    {
//        ErrorLogger.LogError(ex, this);
//        message = ex.ToString();
//    }

//    return Json(new
//    {
//        Status = false,
//        Message = message,
//    }, JsonRequestBehavior.AllowGet); ;
//}

//[Authorize]
//[HttpPost]
//public ActionResult Download_OutputDetails_DetailsID(int detailsId)
//{
//    bool status = false;
//    string message = string.Empty;
//    string fileName = string.Empty;
//    int userID = SessionValue.UserID;
//    try
//    {
//        HFCDAL hfcDAL = new HFCDAL();
//        CompanyDAL companyDAL = new CompanyDAL();
//        string companyName = companyDAL.GetCompanyNameByDetailsID(detailsId);

//        string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetHFC_OutputTemplateFilePath()));
//        fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
//        string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
//        System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
//        status = hfcDAL.Get_OutputDetails_InterOp_DetailsId(detailsId, companyName, userTemplateFilePath);
//    }
//    catch (Exception exception)
//    {
//        ErrorLogger.LogError(exception, this);
//        status = false;
//    }

//    return Json(new
//    {
//        fileName = fileName,
//        status = status,
//    }, JsonRequestBehavior.AllowGet);
//}


#endregion