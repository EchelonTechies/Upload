﻿using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using Microsoft.Office.Interop.Excel;
using System;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using Extensionmethod=IndRa.RiskModel.DAL.Helpers;

namespace IndRa.RiskModel.Controllers
{
    public class NewOneController : Controller
    {
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

       
    }
}

