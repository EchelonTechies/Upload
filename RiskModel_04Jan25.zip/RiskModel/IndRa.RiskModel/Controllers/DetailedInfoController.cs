﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ClosedXML.Excel;
using ICSharpCode.SharpZipLib.Zip;
using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using Newtonsoft.Json;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

namespace IndRa.RiskModel.Controllers
{
    public class DetailedInfoController : Controller
    {
        ReportsDAL reportsDAL = new ReportsDAL();

        // GET: Reports
        public ActionResult Index()
        {
            ViewBag.RatingList = DropDownValue.GetRatingsList(0);
            ViewBag.SegmentList = DropDownValue.GetSegmentsList();
            ViewBag.YearList = DropDownValue.GetYearList();
            ViewBag.YearNewList = DropDownValue.GetYearNewList();
            ViewBag.YearHistoricalList = DropDownValue.GetYearHistoricalList();
            ViewBag.YearType = DropDownValue.GetYearType();
            //ViewBag.ClientList = DropDownValue.GetClientList();
            ViewBag.AnalystList = DropDownValue.GetAllAnalystList();
            @ViewBag.PFRMType = DropDownValue.GetProjectTypeList();
            return View();
        }

        [HttpGet]
        public string GetSegmentWiseNumber(string reportName, string fromYear, string toYear)
        {
            DataTable result = reportsDAL.GetSegmentWiseNumber(fromYear, toYear);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }
        [HttpGet]
        public string GetEntityWiseRatingMatrix(string reportName, string fromYear, string toYear)
        {
            DataTable result = reportsDAL.GetEntityWiseRatingMatrix(fromYear, toYear);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }

        [HttpGet]
        public string GetRatingSegmentWiseName(string rating, string modelId, string finYear, string reportName, string pfrmType)
        {
            DataTable result = reportsDAL.GetRatingSegmentWiseName(rating, modelId, finYear, pfrmType);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }

        [HttpGet]
        public string GetRatingwiseNumber(string modelId, string reportName, string fromYear, string toYear, string pfrmType)
        {
            DataTable result = reportsDAL.GetRatingwiseNumber(modelId, fromYear, toYear, pfrmType);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }
        [HttpGet]
        public string GetECL(string year, string reportName)
        {
            DataTable result = reportsDAL.GetECL(year);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { aaData = result });
        }

        [HttpGet]
        public string GetYearWiseParameter(string companyId, string reportName, string fromYear, string toYear)
        {
            DataTable result = reportsDAL.GetYearWiseParameter(companyId, fromYear, toYear);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }

        [HttpGet]
        public string GetClientWiseParameter(string financialYear, string modelId, string reportName)
        {
            DataTable result = reportsDAL.GetClientWiseParameter(financialYear, modelId);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }

        [HttpGet]
        public string GetCompanylog(string companyId, string finYear, string reportName)
        {
            DataTable result = reportsDAL.GetCompanylog(companyId, finYear);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }

        [HttpGet]
        public string GetUserlog(string analystId, string finYear, string reportName)
        {
            DataTable result = reportsDAL.GetUserlog(analystId, finYear);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }
        [HttpGet]
        public string GetRatingWiseTransition(string fromYear, string toYear, string modelId, string reportName, string pfrmType)
        {
            DataTable result = reportsDAL.GetRatingWiseTransition(fromYear, toYear, modelId, pfrmType);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }

        [HttpGet]
        public JsonResult GetHistoricalData(string finYear)
        {
            var data = reportsDAL.GetHistoricalData(finYear);
            List<DashboardEntity> result = data.ToList();
            return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetCompanyData(string modelId, string year)
        {
            var data = reportsDAL.GetCompanyData(modelId, year);
            List<DashboardAnalystEntity> result = data.ToList();
            return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
        }

        public string DownloadHistoricalDataFileExists(string folderPaths, string compressedFileName)
        {
            string message = "";
            try
            {
                folderPaths = Server.MapPath("~//HistoricalData//") + folderPaths;

                if (System.IO.Directory.Exists(folderPaths))
                {
                    string[] files = Directory.GetFiles(folderPaths, "*.*", SearchOption.AllDirectories);
                    if (files.Length > 0)
                    {
                        
                    }
                    else
                    {
                        message = "No file found.";
                    }
                }
                else
                {
                    message = "No file found.";
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            return message;
        }

        public void DownloadHistoricalData(string folderPaths, string compressedFileName)
        {
            try
            {
                folderPaths = Server.MapPath("~//HistoricalData//") + folderPaths;

                if (System.IO.Directory.Exists(folderPaths))
                {
                    string[] files = Directory.GetFiles(folderPaths, "*.*", SearchOption.AllDirectories);
                    if (files.Length > 0)
                    {
                        Response.AddHeader("Content-Disposition", "attachment; filename=" + compressedFileName + ".zip");
                        Response.ContentType = "application/zip";

                        using (var zipStream = new ZipOutputStream(Response.OutputStream))
                        {

                            foreach (string file in files)
                            {
                                byte[] fileBytes = System.IO.File.ReadAllBytes(file);

                                var fileEntry = new ZipEntry(Path.GetFileName(file))
                                {
                                    Size = fileBytes.Length
                                };

                                zipStream.PutNextEntry(fileEntry);
                                zipStream.Write(fileBytes, 0, fileBytes.Length);
                            }

                            zipStream.Flush();
                            zipStream.Close();
                        }
                    }
                    else
                    {
                        Response.Write("No file found.");
                    }
                }
                else
                {
                    Response.Write("No file found.");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }

        public void DownloadData(string reportName)
        {
            //reportName = "Report_SegmentWiseNumber";
            reportName = "Report_" + reportName;
            DataTable resultData = (DataTable)Session[reportName];

            string timeStamp = DateTime.Now.Ticks.ToString();
            string excelFileName = reportName + "_" + timeStamp + ".xlsx";
            string excelSheetName = reportName;
            if (excelSheetName.Length > 30)
            {
                excelSheetName = excelSheetName.Substring(0, 30);
            }

            if (resultData != null)
            {
                if (resultData.Rows.Count > 0)
                {
                    GenerateDownloadReport(resultData, excelFileName, excelSheetName);
                }
            }
            else
            {
                Response.Write("No Record Found !!!");
            }
        }

        [HttpGet]
        public JsonResult GetRatingList(int modelId, string year)
        {
            year = year.Replace("FY", "20");
            SelectList ratingListItems = DropDownValue.GetRatingsListForReport(modelId, Convert.ToInt32(year));
            return Json(new { aaData = ratingListItems }, JsonRequestBehavior.AllowGet);
        }

        public void GenerateDownloadReport(DataTable resultData, string excelFileName, string sheetName)
        {
            MemoryStream statusStream = new MemoryStream();
            try
            {
                XLWorkbook excelWorkbook = new XLWorkbook();
                resultData.TableName = sheetName;
                excelWorkbook.Worksheets.Add(resultData, sheetName);
                excelWorkbook.SaveAs(statusStream);

                Response.ClearContent();
                Response.AddHeader("content-disposition", "attachment;filename=" + excelFileName);
                Response.AddHeader("Content-Type", "application/vdnd.ms-excel");
                Response.BinaryWrite(statusStream.ToArray());
                Response.End();
            }
            catch (Exception ex)
            {
            }
        }

        // clear all reports session
        private void ClearReportSession()
        {
            if (Session["Report_SegmentWiseNumber"] != null)
            {
                Session.Remove("Report_SegmentWiseNumber");
            }

            if (Session["Report_EntityWiseRatingMatrix"] != null)
            {
                Session.Remove("Report_EntityWiseRatingMatrix");
            }

            if (Session["Report_RatingWiseSegmentWiseName"] != null)
            {
                Session.Remove("Report_RatingWiseSegmentWiseName");
            }

            if (Session["Report_RatingWiseNumber"] != null)
            {
                Session.Remove("Report_RatingWiseNumber");
            }

            if (Session["Report_RatingWiseTransition"] != null)
            {
                Session.Remove("Report_RatingWiseTransition");
            }

            if (Session["Report_ECL"] != null)
            {
                Session.Remove("Report_ECL");
            }

            if (Session["Report_ClientWiseParameters"] != null)
            {
                Session.Remove("Report_ClientWiseParameters");
            }

            if (Session["Report_YearWiseParameters"] != null)
            {
                Session.Remove("Report_YearWiseParameters");
            }

            if (Session["Report_CompanyLog"] != null)
            {
                Session.Remove("Report_CompanyLog");
            }

        }

        [Authorize]
        [HttpPost]
        public ActionResult GeneratePDF(string reportName)
        {
            bool status = false;
            reportName = "Report_" + reportName;
            DataTable resultData = (DataTable)Session[reportName];

            string timeStamp = DateTime.Now.Ticks.ToString();
            string filePath = Server.MapPath("~//" + ConfigManager.GetReportWordDownloadFolder());

            if (!Directory.Exists(filePath))
            {
                Directory.CreateDirectory(filePath);
            }

            string fileName = reportName + "_" + timeStamp + ".pdf";
            filePath = filePath + "//" + fileName;

            try
            {
                if (resultData != null)
                {
                    if (resultData.Rows.Count > 0)
                    {
                        createPDF(resultData, filePath);
                        status = true;
                    }
                }
                else
                {
                    Response.Write("No Record Found !!!");
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);

        }

        public ActionResult DownloadPDFFile(string fileName)
        {
            string filePath = Server.MapPath("~//" + ConfigManager.GetReportWordDownloadFolder());
            filePath = filePath + "//" + fileName;
            byte[] fileByteArray = System.IO.File.ReadAllBytes(filePath);
            return File(fileByteArray, "application/pdf", fileName);
        }

        public void createPDF(DataTable dataTable, string destinationPath)
        {
            Document document = new Document();
            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(destinationPath, FileMode.Create));
            document.Open();

            PdfPTable table = new PdfPTable(dataTable.Columns.Count);
            table.WidthPercentage = 100;

            Font font = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL);

            //Set columns names in the pdf file
            for (int k = 0; k < dataTable.Columns.Count; k++)
            {
                PdfPCell cell = new PdfPCell(new Phrase(dataTable.Columns[k].ColumnName, font));

                cell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                cell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
                cell.BackgroundColor = new BaseColor(System.Drawing.ColorTranslator.FromHtml("#C8C8C8"));

                table.AddCell(cell);
            }


            //Add values of DataTable in pdf file
            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                for (int j = 0; j < dataTable.Columns.Count; j++)
                {
                    PdfPCell cell = new PdfPCell(new Phrase(dataTable.Rows[i][j].ToString(), font));

                    //Align the cell in the center
                    cell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
                    cell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
                    cell.BackgroundColor = new BaseColor(System.Drawing.ColorTranslator.FromHtml("#FFFFFF"));

                    table.AddCell(cell);
                }
            }

            document.Add(table);
            document.Close();

        }

        public ActionResult GetCommpanyDetailsData(int detailsId, int modelId, string companyName)
        {
            string outputFileName = "";
            string message = string.Empty;

            try
            {
                ComputeOutputDetails(detailsId, modelId, companyName, true, out outputFileName);

                return Json(new
                {
                    Status = true,
                    FileName = outputFileName,
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }
            return Json(new
            {
                Status = false,
                FileName = outputFileName,
            }, JsonRequestBehavior.AllowGet);
        }

        private void ComputeOutputDetails(int detailsId, int modelId, string companyName, bool isDownload, out string outputfileName)
        {
            bool status = false;
            string message = string.Empty;
            outputfileName = string.Empty;
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;

            string fileName = string.Format("{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
            string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetHFC_InputTemplateFilePath()));
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));

            System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);

            try
            {
                if (modelId == (int)ModelsEnum.HFC)
                {
                    HFCDAL dal = new HFCDAL();
                    HFC_BasicDetailsEntity riskModelExcelEntity = new HFC_BasicDetailsEntity();
                    riskModelExcelEntity = dal.GetBasicDetails(detailsId);  // Get data from database
                    status = dal.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath,out message); // Generate Excel File
                }
                else if (modelId == (int)ModelsEnum.HFCNew)
                {
                    HFCNewDAL dal = new HFCNewDAL();
                    HFCNew_BasicDetailsEntity riskModelExcelEntity = new HFCNew_BasicDetailsEntity();
                    riskModelExcelEntity = dal.GetBasicDetails(detailsId);  // Get data from database
                    status = dal.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath); // Generate Excel File
                }
                else if (modelId == (int)ModelsEnum.SCB)
                {
                    SCBDAL dal = new SCBDAL();
                    SCB_BasicDetailsEntity riskModelExcelEntity = new SCB_BasicDetailsEntity();
                    riskModelExcelEntity = dal.GetBasicDetails(detailsId);  // Get data from database
                    status = dal.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath); // Generate Excel File
                }
                else if (modelId == (int)ModelsEnum.SFB)
                {
                    SFBDAL dal = new SFBDAL();
                    SFB_BasicDetailsEntity riskModelExcelEntity = new SFB_BasicDetailsEntity();
                    riskModelExcelEntity = dal.GetBasicDetails(detailsId);  // Get data from database
                    status = dal.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath); // Generate Excel File
                }
                else if (modelId == (int)ModelsEnum.ACHFS)
                {
                    ACHFSDAL dal = new ACHFSDAL();
                    ACHFS_BasicDetailsEntity riskModelExcelEntity = new ACHFS_BasicDetailsEntity();
                    riskModelExcelEntity = dal.GetBasicDetails(detailsId);  // Get data from database
                    status = dal.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath); // Generate Excel File
                }
                else if (modelId == (int)ModelsEnum.ARDB)
                {
                    ARDBDAL dal = new ARDBDAL();
                    ARDB_BasicDetailsEntity riskModelExcelEntity = new ARDB_BasicDetailsEntity();
                    riskModelExcelEntity = dal.GetBasicDetails(detailsId);  // Get data from database
                    status = dal.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath); // Generate Excel File
                }
                else if (modelId == (int)ModelsEnum.RRB)
                {
                    RRBDAL dal = new RRBDAL();
                    RRB_BasicDetailsEntity riskModelExcelEntity = new RRB_BasicDetailsEntity();
                    riskModelExcelEntity = dal.GetBasicDetails(detailsId);  // Get data from database
                    status = dal.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath); // Generate Excel File
                }
                else if (modelId == (int)ModelsEnum.StCoop)
                {
                    STCOOPDAL dal = new STCOOPDAL();
                    STCOOP_BasicDetailsEntity riskModelExcelEntity = new STCOOP_BasicDetailsEntity();
                    riskModelExcelEntity = dal.GetBasicDetails(detailsId);  // Get data from database
                    status = dal.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath); // Generate Excel File
                }
                else if (modelId == (int)ModelsEnum.UCB)
                {
                    UCBDAL dal = new UCBDAL();
                    UCB_BasicDetailsEntity riskModelExcelEntity = new UCB_BasicDetailsEntity();
                    riskModelExcelEntity = dal.GetBasicDetails(detailsId);  // Get data from database
                    status = dal.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath); // Generate Excel File
                }


                if (status)
                {
                    outputfileName = fileName;
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }
        }


        [HttpGet]
        public ActionResult GetEntityListByModel(int modelId)
        {
            CompanyDAL companyDAL = new CompanyDAL();
            List<CompanyEntity> result = companyDAL.GetCompaniesListByModel(modelId).ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public string GetOutputSheetData(string fromYear, string toYear, string modelId, string reportName)
        {
            DataTable result = reportsDAL.GetOutputSheetData(fromYear, toYear, modelId);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }

        [HttpGet]
        public string GetOutputSheetData_Html(string fromYear, string toYear, string modelId, string reportName)
        {
            var result = reportsDAL.GetOutputSheetData_Html(fromYear, toYear, modelId);
            ClearReportSession();
            Session["Report_" + reportName] = result;
            return JsonConvert.SerializeObject(new { result = result });
        }
    }
}

