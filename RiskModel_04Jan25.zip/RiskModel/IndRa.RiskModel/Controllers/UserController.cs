﻿using IndRa.Admin.Helpers;
using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using IndRa.RiskModel.Models.User;
using System;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;

namespace IndRa.RiskModel.Controllers
{
    public class UserController : Controller
    {

        public HarrierMembershipProvider MembershipService { get; set; }

        protected override void Initialize(RequestContext requestContext)
        {
            if (MembershipService == null)
                MembershipService = new HarrierMembershipProvider();
            base.Initialize(requestContext);
        }

        [HttpGet]
        [Authorize]
        public ActionResult UserList()
        {
            try
            {
                int roleID = SessionValue.RoleID;
                ViewBag.Error = "";
                ViewBag.UserRoleList = UserRoleList(roleID);
                ViewBag.IsActive = DropDownValue.GetYesNoStatus();
                return View();
               
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
        }

        [HttpGet]
        [Authorize]
        public ActionResult GetAllUsersList()
        {
            try
            {
                int roleID = SessionValue.RoleID;
                UserDAL userDAL = new UserDAL();
                var getAllUsersList = userDAL.GetAllUsersList(roleID).ToList();
                var userList = getAllUsersList.Select((users, index) => new
                {
                    SrNo = index + 1,
                    UserId = users.UserId,
                    FirstName = users.FirstName,
                    LastName = users.LastName,
                    UserName = users.UserName,
                    EmailAddress = users.Email,
                    UserCode = users.UserCode,
                    UserRole = userDAL.GetRoleName(users.RoleId),
                    IsActive = users.IsActive == false ? "No" : "Yes",
                    Edit = Url.Action("EditUser", "User", new { UserID = users.UserId }),
                    Disable = Url.Action("DeleteUser", "User", new { UserID = users.UserId }),
                }).ToList();

                return Json(new
                {
                    data = userList
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return null;
            }
        }


        [HttpGet]
        [Authorize]
        public ActionResult CreateUser()
        {
            try
            {
                int roleId = SessionValue.RoleID;
                ViewBag.Error = "";
                ViewBag.UserRoleList = UserRoleList(roleId);
                ViewBag.IsActive = DropDownValue.GetYesorNoStatus();
                return View();
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
        }

        [HttpPost]
        [Authorize]
        public JsonResult CreateUser(CreateUserModel createUserModel)
        {
            int userID = SessionValue.UserID;
            int roleId = SessionValue.RoleID;

            ViewBag.Error = "";
            string message = string.Empty;
            string responseMessage = string.Empty;
            UserDAL userDAL = new UserDAL();
            bool status = false;
            try
            {
                if (userDAL.CheckDuplicateUserName(createUserModel.UserName) == false && userDAL.CheckDuplicateEmail(createUserModel.Email) == false)
                {
                    if (ModelState.IsValid)
                    {
                        int userRoleID = userDAL.GetRoleID(createUserModel.UserRole);
                        var salt = MembershipService.GenerateSalt();
                        UserEntity userEntity = new UserEntity
                        {
                            RoleId = userRoleID,
                            FirstName = createUserModel.FirstName,
                            LastName = createUserModel.LastName,
                            UserCode = createUserModel.UserCode,
                            Email = createUserModel.Email,
                            UserName = createUserModel.UserName,
                            Password = MembershipService.EncodePassword(createUserModel.Password, 1, salt),
                            Salt = salt,
                            CreatedBy = userID,
                            CreatedDateTime = DateTime.Now,
                            UpdatedBy = userID,
                            UpdatedDateTime = DateTime.Now,
                            IsActive = true,
                        };
                        status = userDAL.CreateUser(userEntity);

                        if (status)
                        {
                            message = "User account created successfully, A link has been sent to your email address to set your password.";
                            ViewBag.Error = message;
                            SessionValue.SetSuccessMessage(message);
                            ViewBag.UserRoleList = UserRoleList(roleId);
                            string activationCode = Generate.EmailActivationCode();
                            userDAL.UpdateEmailActivationCodeByUserName(createUserModel.UserName, activationCode);
                            Email.SendPasswordResetLink(createUserModel.FirstName, createUserModel.LastName, createUserModel.Email, activationCode);


                        }
                        else
                        {
                            message = "Error occured while saving User Details.";
                            ViewBag.Error = message;
                            SessionValue.SetErrorMessage(message);
                            ViewBag.UserRoleList = UserRoleList(roleId);
                            return null;
                        }

                    }
                    else
                    {
                        message = "Error occured while saving User Details.";
                        ViewBag.Error = message;
                        SessionValue.SetErrorMessage(message);
                        return null;
                    }
                }
                else
                {
                    message = "Error occured while saving User Details.";
                    ViewBag.Error = message;
                    SessionValue.SetErrorMessage(message);
                    return null;
                }

                return Json(new
                {
                    Status = status,
                    Message = message,
                }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return null;
            }
        }

        [NonAction]
        [Authorize]
        public SelectList UserRoleList(int roleId)
        {
            UserDAL userDAL = new UserDAL();
            return new SelectList(userDAL.GetAllRoles(roleId));
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult EditUser(int UserID)
        {
            try
            {
                int roleID = SessionValue.RoleID;
                UserDAL userDAL = new UserDAL();
                var user = userDAL.GetUserByID(UserID);
                ViewBag.UserRoleList = UserRoleList(roleID);
                EditUserModel editUserModel = new EditUserModel
                {
                    UserID = user.UserId,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email,
                    UserRole = userDAL.GetRoleName(user.RoleId),
                    Password = user.Password,
                    UserCode = user.UserCode
                };

                return View(editUserModel);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
        }

        [HttpPost]
        [Authorize]
        public ActionResult EditUser(EditUserModel editUserModel)
        {
            int userID = SessionValue.UserID;
            int roleID = SessionValue.RoleID;

            bool success = false;
            ViewBag.Error = "";
            string message = string.Empty;
            UserDAL userDAL = new UserDAL();
            if (ModelState.IsValid)
            {
                int userRoleID = userDAL.GetRoleID(editUserModel.UserRole);
                try
                {
                    UserEntity userEntity = new UserEntity
                    {
                        UserId = editUserModel.UserID,
                        RoleId = userRoleID,
                        FirstName = editUserModel.FirstName,
                        LastName = editUserModel.LastName,
                        UserCode = editUserModel.UserCode,
                        Email = editUserModel.Email,
                        UserName = editUserModel.UserName,
                        UpdatedBy = userID,
                        UpdatedDateTime = DateTime.Now,
                        IsActive = editUserModel.IsActive,
                    };
                    success = userDAL.UpdateUserDetails(userEntity);

                    if (success)
                    {
                        message = "User Details updated successfully.";
                        ViewBag.Error = message;
                        SessionValue.SetSuccessMessage(message);
                        ViewBag.UserRoleList = UserRoleList(roleID);
                    }
                    else
                    {
                        message = "User Details not Updated successfully.";
                        ViewBag.Error = message;
                        SessionValue.SetErrorMessage(message);
                        ViewBag.UserRoleList = UserRoleList(roleID);
                        return View(editUserModel);
                    }

                    return Json(new
                    {
                        Status = success,
                        Message = message,
                    }, JsonRequestBehavior.AllowGet);
                }
                catch (Exception exception)
                {
                    ErrorLogger.LogError(exception, this);
                    return View("Error");
                }
            }
            else
            {
                message = string.Join("; ", ModelState.Values
                                        .SelectMany(x => x.Errors)
                                        .Select(x => x.ErrorMessage));

                return Json(new
                {
                    Status = false,
                    Message = message,
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult DeleteUser(int userId)
        {
            bool result = false;
            int updateUserID = SessionValue.UserID;

            try
            {
                UserDAL userDAL = new UserDAL();
                result = userDAL.DeleteUser(userId, updateUserID);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
            }

            return Json(new { result = result }, JsonRequestBehavior.AllowGet);
        }

    }
}