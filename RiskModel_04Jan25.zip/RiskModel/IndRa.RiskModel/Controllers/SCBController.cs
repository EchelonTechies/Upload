﻿using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Extensionmethod = IndRa.RiskModel.DAL.Helpers;

namespace IndRa.RiskModel.Controllers
{
    public class SCBController : Controller
    {

        SCBDAL scbDAL = new SCBDAL();

        [Authorize]
        public ActionResult Index()
        {
            return RedirectToAction("ReadRiskModelExcelFile");
        }

        [HttpPost]
        public ActionResult GetSubjectiveParametersList(int ModelId)
        {
            var data = scbDAL.GetSubjectiveParametersList(ModelId);
            List<SubjectiveParametersEntity> result = data.ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        public ActionResult ReadRiskModelExcelFile(int? detailsId, short? logId)
        {
            RiskModelExcelEntity riskModelExcelEntity = new RiskModelExcelEntity();
            CompanyDAL companyDAL = new CompanyDAL();
            SCB_BasicDetailsEntity scb_BasicDetailsEntity = new SCB_BasicDetailsEntity();

            try
            {
                int roleID = SessionValue.RoleID;
                int userID = SessionValue.UserID;

                ViewBag.Companies = DropDownValue.GetCompaniesList((int)ModelsEnum.SCB,roleID,userID);
                ViewBag.RatingList = DropDownValue.GetRatingsList((int)ModelsEnum.SCB);

                ViewBag.Locations = DropDownValue.GetLocationsList();
                ViewBag.GetYesNoStatus = DropDownValue.GetYesNoStatus();
                ViewBag.YesorNoStatus = DropDownValue.GetYesorNoStatus();
                ViewBag.ParameterNo = DropDownValue.GetParamterNoList();
                ViewBag.CurrencyList = DropDownValue.GetCurrencyList();
                ViewBag.FinYearList = DropDownValue.GetFinYearList();
                if (detailsId.HasValue && detailsId != 0)
                {
                    // Get Log Data
                    if (logId.HasValue && logId.Value > 0)
                    {
                        scb_BasicDetailsEntity = scbDAL.GetBasicDetails_Archive(detailsId.Value, logId.Value);
                    }
                    else
                    {
                        scb_BasicDetailsEntity = scbDAL.GetBasicDetails(detailsId.Value);
                    }
                }
                else
                {
                    scb_BasicDetailsEntity.DetailsId = 0;
                }
                if (scb_BasicDetailsEntity.SCB_OutputDetailsEntity == null || scb_BasicDetailsEntity.SCB_OutputDetailsEntity.Count == 0)
                {
                    scb_BasicDetailsEntity.SCB_OutputDetailsEntity = scbDAL.GetOutputTemplateEntity();
                }
                return View(scb_BasicDetailsEntity);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
        }

        public ActionResult SaveSCBDetails(SCB_BasicDetailsEntity riskModelExcelEntity)
        {
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            int detailID = 0;
            short logID = 0;
            int detail_ArchiveID = 0;

            bool status = false;
            string message = string.Empty;
            CompanyDAL companyDAL = new CompanyDAL();
            UserDAL userDAL = new UserDAL();
            CommonFunction commonFunction = new CommonFunction();
            SCBDAL scbDAL = new SCBDAL();
            string riskModelFilePath = SessionValue.RISKMODEL_FILE_PATH;
            List<SCB_OutputDetailsEntity> outputDetailsEntity = new List<SCB_OutputDetailsEntity>();
            string outputFileName = "";
            
            try
            {                 
                

                #region Compute Output

                if (riskModelExcelEntity.ButtonValue == "ComputeOutput")
                {
                    status = true;
                    outputDetailsEntity = ComputeOutputDetails(riskModelExcelEntity, false, out outputFileName);
                    return Json(new
                    {
                        ButtonValue = riskModelExcelEntity.ButtonValue,
                        Status = status,
                        Message = message,
                        Result = outputDetailsEntity,
                    }, JsonRequestBehavior.AllowGet);
                }

                #endregion

                #region Download

                else if (riskModelExcelEntity.ButtonValue == "Download")
                {
                    status = true;
                    outputDetailsEntity = ComputeOutputDetails(riskModelExcelEntity, true, out outputFileName);
                    return Json(new
                    {
                        ButtonValue = riskModelExcelEntity.ButtonValue,
                        Status = status,
                        Message = message,
                        Result = outputDetailsEntity,
                        FileName = outputFileName,
                    }, JsonRequestBehavior.AllowGet);
                }

                #endregion


                #region Save

                else
                {
                    int? assignedUserID = companyDAL.GetAssignedAnalystID(riskModelExcelEntity.CompanyId);
                    string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
                    string toEmailAddress = userDAL.GetUserEmailAddress(assignedUserID.HasValue ? assignedUserID.Value : 0);
 
                    riskModelExcelEntity.SCB_KeyFinancialsEntity.CreatedBy = userId;
                    riskModelExcelEntity.SCB_KeyFinancialsEntity.UpdatedBy = userId;
                    riskModelExcelEntity.SCB_KeyFinancialsEntity.CreatedDateTime = DateTime.Now;
                    riskModelExcelEntity.SCB_KeyFinancialsEntity.UpdatedDateTime = DateTime.Now;

                    riskModelExcelEntity.SCB_SubjectiveParametersEntity.CreatedBy = userId;
                    riskModelExcelEntity.SCB_SubjectiveParametersEntity.UpdatedBy = userId;
                    riskModelExcelEntity.SCB_SubjectiveParametersEntity.CreatedDateTime = DateTime.Now;
                    riskModelExcelEntity.SCB_SubjectiveParametersEntity.UpdatedDateTime = DateTime.Now;

                    riskModelExcelEntity.SCB_IndustryExpsoureEntity.CreatedBy = userId;
                    riskModelExcelEntity.SCB_IndustryExpsoureEntity.UpdatedBy = userId;
                    riskModelExcelEntity.SCB_IndustryExpsoureEntity.CreatedDateTime = DateTime.Now;
                    riskModelExcelEntity.SCB_IndustryExpsoureEntity.UpdatedDateTime = DateTime.Now;

                    if (Validation(riskModelExcelEntity, out message) == true)
                    {
                        detailID = scbDAL.SaveCompanyBasicDetailsAsDraft(userId, roleId, riskModelExcelEntity, out detail_ArchiveID,out logID);

                        if (detailID > 0)
                        {
                            commonFunction.MoveFileToInputFolder(riskModelExcelEntity.InputFilePath, riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);

                            // save Key Financials record
                            scbDAL.SaveAsDraft_SCBKeyFinancial(userId, roleId, detailID, logID,riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.SCB_KeyFinancialsEntity);

                            // save Subjective Parameters record
                            scbDAL.SaveAsDraft_SCBSubjectiveParameters(userId, roleId, detailID, logID,riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.SCB_SubjectiveParametersEntity);

                            // save Industry Exposure record
                            scbDAL.SaveAsDraft_SCBIndustryExposure(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.SCB_IndustryExpsoureEntity);

                            // save Output records
                            scbDAL.SaveAsDraft_OutputDetails(userId, roleId, detailID,logID,detail_ArchiveID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.SCB_OutputDetailsEntity);
                            if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                            {
                                Email.SendMail(toEmailAddress, companyName, (int)EmailTemplateEnum.ApprovedEntityTemplate);
                            }
                            status = true;
                            message = "success";
                        }
                        return Json(new
                        {
                            DetailID = detailID,
                            ButtonValue = riskModelExcelEntity.ButtonValue,
                            Status = status,
                            Message = message,
                            Result = riskModelExcelEntity,
                        }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new
                        {
                            ButtonValue = riskModelExcelEntity.ButtonValue,
                            Status = false,
                            Message = message,
                            Result = riskModelExcelEntity,
                        }, JsonRequestBehavior.AllowGet);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }

            return Json(new
            {
                ButtonValue = riskModelExcelEntity.ButtonValue,
                Status = false,
                Message = message,
                Result = riskModelExcelEntity,
            }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpPost]
        public ActionResult ImporRiskModelData(SCB_BasicDetailsEntity riskModelExcelEntity)
        {
            bool success = false;
            string message = string.Empty;
            int userID = SessionValue.UserID;
            SCB_BasicDetailsEntity riskModelResult = new SCB_BasicDetailsEntity();
            try
            {
                SCBDAL scbDAL = new SCBDAL();
                string fileName = Path.GetFileName(riskModelExcelEntity.ExcelFile.FileName);
                string copyFile = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}{1}", ConfigManager.GetExcelSheetFileCopyPath(), fileName));
                string copyFilePath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}", ConfigManager.GetExcelSheetFileCopyPath()));

                System.IO.Directory.CreateDirectory(copyFilePath);

                if (System.IO.Directory.Exists(copyFilePath))
                {
                    if (System.IO.File.Exists(copyFile))
                    {
                        System.IO.File.Delete(copyFile);
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }
                    else
                    {
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }

                    riskModelResult = scbDAL.ImportCompanyDetailsFromExcel(copyFile, fileName, "Data Input Sheet$", userID);
                    if (riskModelResult != null)
                    {
                        riskModelResult.InputFilePath = copyFile;
                        success = true;
                        message = "Data Fetched From Excel Sheet";
                    }
                    else
                    {
                        success = false;
                        message = "Unable to fetch Excel Sheet Data";
                    }
                }
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                success = false;
                message = exception.Message;
            }
            finally
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return Json(new
            {
                Status = success,
                Message = message,
                Result = riskModelResult,
            }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Download_SCBOutputDetails(int CompanyId, string CreatedDateTime)
        {
            bool status = false;
            string message = string.Empty;
            string fileName = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                SCBDAL scbDAL = new SCBDAL();
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByID(CompanyId);
                companyName = companyName.Replace("&", "");

                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetSCB_OutputTemplateFilePath()));
                fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));

                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
                status = scbDAL.Get_OutputDetails_OpenXML(CompanyId, Convert.ToDateTime(CreatedDateTime), userTemplateFilePath);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                status = false;
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DownloadOutputExcelFile(string fileName)
        {
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
            byte[] fileByteArray = System.IO.File.ReadAllBytes(userTemplateFilePath);
            return File(fileByteArray, "application/vnd.ms-excel", fileName);
        }

        public List<SCB_OutputDetailsEntity> ComputeOutputDetails(SCB_BasicDetailsEntity riskModelExcelEntity, bool isDownload, out string outputfileName)
        {
            outputfileName = string.Empty;
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            CompanyDAL companyDAL = new CompanyDAL();
            SCBDAL SCBDAL = new SCBDAL();
            List<SCB_OutputDetailsEntity> outputDetailsEntity = new List<SCB_OutputDetailsEntity>();

            bool status = false;
            string message = string.Empty;
            string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
            companyName = companyName.Replace("&", "");

            string fileName = string.Format("{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
            string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetSCB_InputTemplateFilePath()));
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));

            System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);

            try
            {
                status = SCBDAL.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath);
                outputDetailsEntity = SCBDAL.GetOutputFromExcel(userTemplateFilePath, fileName, "Output NHB$", userId);
                if (userTemplateFilePath != null && isDownload == false)
                {
                    if (System.IO.File.Exists(userTemplateFilePath))
                    {
                        System.IO.File.Delete(userTemplateFilePath);
                    }
                }
                outputfileName = fileName;
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }
            return outputDetailsEntity;
        }

        
        [HttpPost]
        public ActionResult SaveOutput(List<SCB_OutputDetailsEntity> outputDetailsEntity)
        {
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            int detailID = outputDetailsEntity[0].DetailsId;
            int detail_ArchiveID = 0;
            bool status = false;
            string message = string.Empty;
            try
            {
                CompanyDAL companyDAL = new CompanyDAL();
                SCBDAL scbDAL = new SCBDAL();

                DateTime dt = DateTime.Now;

                //// save Output records
                //status = scbDAL.SaveAsDraft_OutputDetails(userId, roleId, detailID, detail_ArchiveID, dt, outputDetailsEntity);

                return Json(new
                {
                    Status = status,
                    Message = message,
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }

            return Json(new
            {
                Status = false,
                Message = message,
            }, JsonRequestBehavior.AllowGet); ;
        }

        [Authorize]
        [HttpPost]
        public ActionResult Download_SCBOutputDetails_DetailsID(int detailsId)
        {
            bool status = false;
            string message = string.Empty;
            string fileName = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                SCBDAL scbDAL = new SCBDAL();
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByDetailsID(detailsId);

                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetSCB_OutputTemplateFilePath()));
                fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
                status = scbDAL.Get_OutputDetails_InterOp_DetailsId(detailsId, companyName, userTemplateFilePath);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                status = false;
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);
        }

        public bool Validation(SCB_BasicDetailsEntity riskModelExcelEntity, out string message)
        {
            StringBuilder sbQuery = new StringBuilder();
            message = "";
            object obj;

            if (riskModelExcelEntity.CompanyId == 0)
            {
                sbQuery.AppendLine("Basic Details: Entity Name is mandatory");
                message = sbQuery.ToString();
                return false;
            }
            else if (string.IsNullOrEmpty(riskModelExcelEntity.FinYear))
            {
                sbQuery.AppendLine("Basic Details: Financial Year is mandatory");
                message = sbQuery.ToString();
                return false;
            }
            if (riskModelExcelEntity.ButtonValue == ButtonValue.SaveAsDraft.ToString())
            {
                return true;
            }

            if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
            {
                if (string.IsNullOrEmpty(riskModelExcelEntity.Comments))
                {
                    sbQuery.AppendLine("Output: Admin comments is mandatory");
                }
                else if (string.IsNullOrEmpty(riskModelExcelEntity.FinalRating))
                {
                    sbQuery.AppendLine("Output: Final Rating is mandatory");
                }
            }

            SCB_KeyFinancialsEntity keyFinancialsEntity = riskModelExcelEntity.SCB_KeyFinancialsEntity;
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(keyFinancialsEntity);

            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null && property.DisplayName != string.Empty)
                    {
                        obj = keyFinancialsEntity.GetType().GetProperty(property.Name).GetValue(keyFinancialsEntity, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Key Financials: " + property.DisplayName + " is mandatory");
                        }
                        else
                        {
                            if (property.DisplayName == "Period of Year End" || property.DisplayName == "Period of Year End2")
                            {
                                string value = obj.ToString();
                                DateTime periodDate = Convert.ToDateTime(value);
                                DateTime curDate = DateTime.Now;
                                if (periodDate > curDate)
                                {
                                    sbQuery.AppendLine("Key Financials: " + property.DisplayName + " cannot be greater than current date");
                                }
                            }
                        }
                    }
                }
                catch { }
            }

            SCB_SubjectiveParametersEntity subjectiveParametersEntity = riskModelExcelEntity.SCB_SubjectiveParametersEntity;
            properties = TypeDescriptor.GetProperties(subjectiveParametersEntity);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = subjectiveParametersEntity.GetType().GetProperty(property.Name).GetValue(subjectiveParametersEntity, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Subjective Parameters: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            SCB_IndustryExpsoureEntity industryExpsoureEntity = riskModelExcelEntity.SCB_IndustryExpsoureEntity;
            properties = TypeDescriptor.GetProperties(subjectiveParametersEntity);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = industryExpsoureEntity.GetType().GetProperty(property.Name).GetValue(industryExpsoureEntity, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Industry Exposure: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            if (sbQuery.Length > 0)
            {
                message = sbQuery.ToString();
                return false;
            }
            return true;
        }


    }
}

//[HttpPost]
//public ActionResult ComputeOutputDetails(int companyId)
//{
//    int userId = SessionValue.UserID;
//    int roleId = SessionValue.RoleID;
//    CompanyDAL companyDAL = new CompanyDAL();
//    SCBDAL scbDAL = new SCBDAL();

//    bool status = false;
//    string message = string.Empty;
//    string companyName = companyDAL.GetCompanyNameByID(companyId);
//    int detailsID = companyDAL.GetCompanyBasicDetailsID(companyId);
//    if (detailsID == 0)
//    {
//        message = "Please save the entry as draft first";
//        return Json(new
//        {
//            Status = false,
//            Message = message,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetSCB_InputTemplateFilePath()));
//    string userTemplateFilePath = Server.MapPath(string.Format("~{0}//OutputReport_{1}_{2}.xlsx", ConfigManager.GetOutputTemplateCopyFilePath(), companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss")));

//    System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
//    string fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));

//    try
//    {
//        List<SCB_OutputDetailsEntity> scb_OutputDetailsEntity = new List<SCB_OutputDetailsEntity>();
//        status = scbDAL.Get_OutputDetailsFromFrontEnd_InterOp(detailsID, userTemplateFilePath);
//        // SaveExcel(userTemplateFilePath, newuserTemplateFilePath);
//        scb_OutputDetailsEntity = scbDAL.GetOutputFromExcel(userTemplateFilePath, fileName, "Output NHB$", userId);
//        if (userTemplateFilePath != null)
//        {
//            //if (System.IO.File.Exists(userTemplateFilePath))
//            //{
//            //    System.IO.File.Delete(userTemplateFilePath);
//            //}
//        }
//        return Json(new
//        {
//            Status = status,
//            Message = message,
//            Result = scb_OutputDetailsEntity,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    catch (Exception ex)
//    {
//        ErrorLogger.LogError(ex, this);
//        message = ex.ToString();
//    }
//    return Json(new
//    {
//        Status = false,
//        Message = message,
//        //Result = riskModelExcelEntity,
//    }, JsonRequestBehavior.AllowGet);
//}
