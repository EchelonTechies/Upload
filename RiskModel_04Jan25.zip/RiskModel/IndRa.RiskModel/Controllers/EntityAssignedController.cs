﻿using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndRa.RiskModel.Controllers
{
    public class EntityAssignedController : Controller
    {
        CommonDAL commonDAL = new CommonDAL();
        ReportsDAL reportsDAL = new ReportsDAL();

        // GET: Dashboard
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetEntityAssignedAnalystList(string searchText)
        {
            int roleID = SessionValue.RoleID;
            List<AnalystEntity> result = commonDAL.GetEntityAnalystList(searchText);
            return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
        }

    }
}