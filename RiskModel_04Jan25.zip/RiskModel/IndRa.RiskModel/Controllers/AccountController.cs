﻿
using DocumentFormat.OpenXml.Spreadsheet;
using IndRa.Admin.Helpers;
using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.DataAccess;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using IndRa.RiskModel.Models.User;
using System;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;
namespace IndRa.RiskModel
{
    [Authorize]
    public class AccountController : Controller
    {
        public HarrierMembershipProvider MembershipService { get; set; }

        protected override void Initialize(RequestContext requestContext)
        {
            if (MembershipService == null)
                MembershipService = new HarrierMembershipProvider();

            base.Initialize(requestContext);
        }


        [SessionExpire]
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Login()
        {
            //ViewBag.ReturnUrl = returnUrl;
            //if (User.Identity.IsAuthenticated)
            //{
            //    if (!string.IsNullOrEmpty(returnUrl))
            //    {
            //        return Redirect(returnUrl);
            //    }
            //    else
            //    {
            //        return RedirectToAction("Index", "Home");
            //    }
            //}
            //else
            //{
            //    return View();
            //}
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
        public ActionResult Login(LoginEnity loginModel, string returnUrl)
        {
            UserDAL userDAL = new UserDAL();
            string responseMessage = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(loginModel.UserName) || string.IsNullOrEmpty(loginModel.Password))
                {
                    ViewBag.Error = true;
                    ViewBag.Message = "Username or password cannot be blank!";
                    return View();

                }
                if (ModelState.IsValid && MembershipService.ValidateUser(loginModel.UserName, loginModel.Password, ref responseMessage))
                {
                    User userDetails = userDAL.GetUserDetailsByUserName(loginModel.UserName);
                    bool isUserActive = userDAL.GetUserStatus(loginModel.UserName); // check user is active or not
                    FormsAuthentication.SetAuthCookie(loginModel.UserName, true);
                    if (userDetails != null && isUserActive)
                    {
                        SessionValue.UserName = userDetails.FirstName;
                        SessionValue.UserID = userDetails.UserId;
                        SessionValue.RoleID = userDetails.RoleId;
                        if (userDetails.RoleId == (int)RolesEnum.Admin || userDetails.RoleId == (int)RolesEnum.SuperAdmin)
                        {
                            return RedirectToAction("Index", "DashboardAdmin");
                        }
                        else
                        {
                            return RedirectToAction("Index", "Dashboard");
                        }
                    }
                    else
                    {
                        ViewBag.Error = true;
                        ViewBag.Message = "User does not exist";
                        return View();
                    }
                }
                else
                {
                    ViewBag.Error = true;
                    ViewBag.Message = "Error in Login user: " + responseMessage;
                    return View();
                }
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult ResetForgotPassword()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult ResetForgotPassword(ForgotPasswordModel forgotPasswordModel)
        {
            ViewBag.Error = false;
            ViewBag.Message = string.Empty;
            bool success = false;
            string responseMessage = string.Empty;
            UserDAL userDAL = new UserDAL();
            try
            {
                if (string.IsNullOrEmpty(forgotPasswordModel.Email))
                {
                    ViewBag.Error = true;
                    ViewBag.Message = "Email field cannot be blank!";
                    return View();

                }
                if (forgotPasswordModel != null)
                {
                    var userEmail = userDAL.GetUserByEmailAddress(forgotPasswordModel.Email);
                    if (userEmail != null)
                    {
                        string activationCode = Generate.EmailActivationCode();
                        userDAL.UpdateEmailActivationCodeByEmail(forgotPasswordModel.Email, activationCode);
                        bool isMailSent = Email.SendPasswordResetLink(userEmail.FirstName, userEmail.LastName, forgotPasswordModel.Email, activationCode);
                        if (isMailSent == true)
                        {
                            responseMessage = "Your reset password link sent to your email address.";
                            success = true;
                        }
                        else
                        {
                            responseMessage = "Mail sending problem. Please check log";
                            success = false;
                        }
                        ViewBag.Message = responseMessage;
                    }
                    else
                    {
                        responseMessage = "This Email Address is not Register.";
                        ViewBag.Message = responseMessage;
                    }
                }
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                responseMessage = "An error occured. Please try again.";
                ViewBag.Message = responseMessage;
            }

            if (HttpContext.Request.IsAjaxRequest())
            {
                return Json(new
                {
                    success = success,
                    responseMessage = responseMessage,
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                if (success)
                {
                    ViewBag.Success = true;
                    ViewBag.Message = responseMessage;
                    ModelState.Clear();
                    return View();
                }
                else
                {
                    ViewBag.Error = true;
                    ViewBag.Message = responseMessage;
                    return View();
                }
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult PasswordReset(string emailAddress, string activationCode)
        {
            string responseMessage = string.Empty;
            ViewBag.Message = string.Empty;
            ViewBag.Error = false;
            UserDAL userDAL = new UserDAL();
            try
            {
                if (userDAL.CheckEmailActivationCode(emailAddress, activationCode))
                {
                    ViewBag.Success = true;
                    ViewBag.Message = "Hi! Please enter your new Password";
                    ViewBag.EmailId = emailAddress;
                    return View("ResetPassword");
                }
                else
                {
                    ViewBag.Message = "Unable to set password";
                    ViewBag.Error = true;
                    return View("Error");
                }

            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                responseMessage = "An error occured. Please try again.";
            }
            return View("ResetPassword");


        }

        [Authorize]
        public ActionResult ResetPassword()
        {
            ResetPasswordModel resetPasswordModel = new ResetPasswordModel();
            int userID = SessionValue.UserID;
            resetPasswordModel.UserID = userID.ToString();
            return View(resetPasswordModel);
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult ResetPassword(ResetPasswordModel resetPasswordModel)
        {
            string responseMessage = string.Empty;
            ViewBag.Error = false;
            ViewBag.Message = string.Empty;
            UserDAL userDAL = new UserDAL();

            try
            {
                if (string.IsNullOrEmpty(resetPasswordModel.NewPassword) || string.IsNullOrEmpty(resetPasswordModel.Confirmpassword))
                {
                    ViewBag.Error = true;
                    ViewBag.Message = "Password fields cannot be blank!";
                    return View();

                }
                else if (resetPasswordModel.NewPassword != resetPasswordModel.Confirmpassword)
                {

                    ViewBag.Error = true;
                    ViewBag.Message = "Password does not match";
                    return View();
                }
                else
                {
                    //string emailAddress = resetPasswordModel.EmailAddress == null ? "" : resetPasswordModel.EmailAddress;
                    //long userID = userDAL.GetUserIdByEmailAddress(resetPasswordModel.EmailAddress);
                    long userID = long.Parse(resetPasswordModel.UserID);
                    User userEntity = userDAL.GetUserByID(userID);
                    if (userEntity.Salt == null)
                    {
                        userEntity.Salt = MembershipService.GenerateSalt();
                    }
                    string encodedPassword = MembershipService.EncodePassword(resetPasswordModel.NewPassword, 1, userEntity.Salt);

                    if (userDAL.ResetPassword(userEntity.Email, encodedPassword, userEntity.Salt))
                    {
                        ViewBag.Message = "Password has been set successfully";
                        ViewBag.Success = true;
                        return RedirectToAction("Login");
                    }
                    else
                    {
                        ViewBag.Message = "Failed to set Password";
                        ViewBag.Error = true;
                        return View(resetPasswordModel);
                    }
                }
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                responseMessage = "An error occured. Please try again.";
            }
            return View();
        }


        [HttpPost]
        [AllowAnonymous]
        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Account");
        }
    }
}