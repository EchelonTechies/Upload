﻿using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using Extensionmethod = IndRa.RiskModel.DAL.Helpers;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text;
using System.ComponentModel;
namespace IndRa.RiskModel.Controllers
{
    public class HFCNewController : Controller
    {
        [Authorize]
        public ActionResult Index()
        {
            return RedirectToAction("ReadRiskModelExcelFile");
        }

        [Authorize]
        public ActionResult ReadRiskModelExcelFile(int? detailsId, short? logId)
        {
            RiskModelExcelEntity riskModelExcelEntity = new RiskModelExcelEntity();
            CompanyDAL companyDAL = new CompanyDAL();
            HFCNewDAL hfcNewDAL = new HFCNewDAL();
            HFCNew_BasicDetailsEntity hfcNew_BasicDetailsEntity = new HFCNew_BasicDetailsEntity();
            try
            {
                int roleID = SessionValue.RoleID;
                int userID = SessionValue.UserID;

                ViewBag.Companies = DropDownValue.GetCompaniesList((int)ModelsEnum.HFCNew,roleID,userID);
                ViewBag.RatingList = DropDownValue.GetRatingsList((int)ModelsEnum.HFCNew);

                ViewBag.YesorNoStatus = DropDownValue.GetYesorNoStatus();
                ViewBag.ParameterNo = DropDownValue.GetParamterNoList();
                ViewBag.CurrencyList = DropDownValue.GetCurrencyList();
                ViewBag.FinYearList = DropDownValue.GetFinYearList();
                if (detailsId.HasValue && detailsId != 0)
                {
                    // Get Log Data
                    if (logId.HasValue && logId.Value > 0)
                    {
                        hfcNew_BasicDetailsEntity = hfcNewDAL.GetBasicDetails_Archive(detailsId.Value, logId.Value);
                    }
                    else
                    {
                        hfcNew_BasicDetailsEntity = hfcNewDAL.GetBasicDetails(detailsId.Value);
                    }
                }
                else
                {
                    hfcNew_BasicDetailsEntity.DetailsId = 0;
                }
                if (hfcNew_BasicDetailsEntity.HFCNew_OutputDetailsEntity == null || hfcNew_BasicDetailsEntity.HFCNew_OutputDetailsEntity.Count == 0)
                {
                    hfcNew_BasicDetailsEntity.HFCNew_OutputDetailsEntity = hfcNewDAL.GetOutputTemplateEntity();
                }
                return View(hfcNew_BasicDetailsEntity);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
            return View();
        }
         
        [Authorize]
        [HttpPost]
        public ActionResult ImporRiskModelData(HFCNew_BasicDetailsEntity riskModelExcelEntity)
        {
            bool success = false;
            string message = string.Empty;
            int userID = SessionValue.UserID;
            HFCNew_BasicDetailsEntity riskModelResult = new HFCNew_BasicDetailsEntity();
            try
            {
                HFCNewDAL hfcNewDAL = new HFCNewDAL();
                string fileName = Path.GetFileName(riskModelExcelEntity.ExcelFile.FileName);
                string copyFile = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}{1}", ConfigManager.GetExcelSheetFileCopyPath(), fileName));
                string copyFilePath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}", ConfigManager.GetExcelSheetFileCopyPath()));

                System.IO.Directory.CreateDirectory(copyFilePath);

                if (System.IO.Directory.Exists(copyFilePath))
                {
                    if (System.IO.File.Exists(copyFile))
                    {
                        System.IO.File.Delete(copyFile);
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }
                    else
                    {
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }

                    riskModelResult = hfcNewDAL.ImportCompanyDetailsFromExcel(copyFile, fileName, "Data Input Sheet$", userID);
                    
                    if (riskModelResult != null)
                    {
                        riskModelResult.InputFilePath = copyFile;
                        success = true;
                        message = "Data Fetched From Excel Sheet";
                    }
                    else
                    {
                        success = false;
                        message = "Unable to fetch Excel Sheet Data";
                    }
                }

            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                success = false;
                message = exception.Message;

            }
            finally
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            return Json(new
            {
                Status = success,
                Message = message,
                Result = riskModelResult,
            }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SaveHFCNewDetails(HFCNew_BasicDetailsEntity riskModelExcelEntity)
        {
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            int detailID = 0;
            short logID = 0;
            int detail_ArchiveID = 0;
            bool status = false;
            string message = string.Empty;

            try
            {
                CompanyDAL companyDAL = new CompanyDAL();
                HFCNewDAL hcfDAL = new HFCNewDAL();
                UserDAL userDAL = new UserDAL();

                CommonFunction commonFunction = new CommonFunction();
                string riskModelFilePath = SessionValue.RISKMODEL_FILE_PATH;
                List<HFCNew_OutputDetailsEntity> outputDetailsEntity = new List<HFCNew_OutputDetailsEntity>();
                string outputFileName = "";
                
                #region Compute Output

                if (riskModelExcelEntity.ButtonValue == "ComputeOutput")
                {
                    status = true;
                    outputDetailsEntity = ComputeOutputDetails(riskModelExcelEntity, false, out outputFileName);
                    return Json(new
                    {
                        ButtonValue = riskModelExcelEntity.ButtonValue,
                        Status = status,
                        Message = message,
                        Result = outputDetailsEntity,
                    }, JsonRequestBehavior.AllowGet);
                }

                #endregion

                #region Download

                else if (riskModelExcelEntity.ButtonValue == "Download")
                {
                    status = true;
                    outputDetailsEntity = ComputeOutputDetails(riskModelExcelEntity, true, out outputFileName);
                    return Json(new
                    {
                        ButtonValue = riskModelExcelEntity.ButtonValue,
                        Status = status,
                        Message = message,
                        Result = outputDetailsEntity,
                        FileName = outputFileName,
                    }, JsonRequestBehavior.AllowGet);
                }

                #endregion

                #region Save

                else
                {
                    int? assignedUserID = companyDAL.GetAssignedAnalystID(riskModelExcelEntity.CompanyId);
                    string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
                    string toEmailAddress = userDAL.GetUserEmailAddress(assignedUserID.HasValue ? assignedUserID.Value : 0);
                     
                    riskModelExcelEntity.HFCNew_KeyFinancialsEntity.CreatedBy = userId;
                    riskModelExcelEntity.HFCNew_KeyFinancialsEntity.UpdatedBy = userId;
                    riskModelExcelEntity.HFCNew_KeyFinancialsEntity.CreatedDateTime = DateTime.Now;
                    riskModelExcelEntity.HFCNew_KeyFinancialsEntity.UpdatedDateTime = DateTime.Now;

                    riskModelExcelEntity.HFCNew_SubjectiveParametersEntity.CreatedBy = userId;
                    riskModelExcelEntity.HFCNew_SubjectiveParametersEntity.UpdatedBy = userId;
                    riskModelExcelEntity.HFCNew_SubjectiveParametersEntity.CreatedDateTime = DateTime.Now;
                    riskModelExcelEntity.HFCNew_SubjectiveParametersEntity.UpdatedDateTime = DateTime.Now;

                    riskModelExcelEntity.CreatedDateTime = DateTime.Now;
                    if (Validation(riskModelExcelEntity, out message) == true)
                    {
                        detailID = hcfDAL.SaveCompanyBasicDetailsAsDraft(userId, roleId, riskModelExcelEntity, out detail_ArchiveID,out logID);

                        if (detailID > 0)
                        {
                            commonFunction.MoveFileToInputFolder(riskModelExcelEntity.InputFilePath, riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);

                            // save Key Financials record
                            hcfDAL.SaveAsDraft_KeyFinancial(userId, roleId, detailID, logID,riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.HFCNew_KeyFinancialsEntity);

                            // save Subjective Parameters record
                            hcfDAL.SaveAsDraft_SubjectiveParameters(userId, roleId, detailID, logID,riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.HFCNew_SubjectiveParametersEntity);

                            //// save Output records
                            hcfDAL.SaveAsDraft_OutputDetails(userId, roleId, detailID,logID ,detail_ArchiveID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.HFCNew_OutputDetailsEntity);
                            if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                            {
                                Email.SendMail(toEmailAddress, companyName, (int)EmailTemplateEnum.ApprovedEntityTemplate);
                            }
                            status = true;
                            message = "success";                  
                        }
                        return Json(new
                        {
                            DetailID = detailID,
                            ButtonValue = riskModelExcelEntity.ButtonValue,
                            Status = status,
                            Message = message,
                            Result = riskModelExcelEntity,
                        }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new
                        {
                            ButtonValue = riskModelExcelEntity.ButtonValue,
                            Status = false,
                            Message = message,
                            Result = riskModelExcelEntity,
                        }, JsonRequestBehavior.AllowGet);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }

            return Json(new
            {
                ButtonValue = riskModelExcelEntity.ButtonValue,
                Status = false,
                Message = message,
                Result = riskModelExcelEntity,
            }, JsonRequestBehavior.AllowGet);
        }

        public bool Validation(HFCNew_BasicDetailsEntity riskModelExcelEntity, out string message)
        {
            StringBuilder sbQuery = new StringBuilder();
            message = "";
            object obj;

            if (riskModelExcelEntity.CompanyId == 0)
            {
                sbQuery.AppendLine("Basic Details: Entity Name is mandatory");
                message = sbQuery.ToString();
                return false;
            }
            else if (string.IsNullOrEmpty(riskModelExcelEntity.FinYear))
            {
                sbQuery.AppendLine("Basic Details: Financial Year is mandatory");
                message = sbQuery.ToString();
                return false;
            }
            if (riskModelExcelEntity.ButtonValue == ButtonValue.SaveAsDraft.ToString())
            {
                return true;
            }

            if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
            {
                if (string.IsNullOrEmpty(riskModelExcelEntity.Comments))
                {
                    sbQuery.AppendLine("Output: Admin comments is mandatory");
                }
                else if (string.IsNullOrEmpty(riskModelExcelEntity.FinalRating))
                {
                    sbQuery.AppendLine("Output: Final Rating is mandatory");
                }
            }

            HFCNew_KeyFinancialsEntity keyFinancialsEntity = riskModelExcelEntity.HFCNew_KeyFinancialsEntity;
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(keyFinancialsEntity);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null && property.DisplayName != string.Empty)
                    {
                        obj = keyFinancialsEntity.GetType().GetProperty(property.Name).GetValue(keyFinancialsEntity, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Key Financials: " + property.DisplayName + " is mandatory");
                        }
                        else
                        {
                            if (property.DisplayName == "Period of Year End" || property.DisplayName == "Period of Year End2")
                            {
                                string value = obj.ToString();
                                DateTime periodDate = Convert.ToDateTime(value);
                                DateTime curDate = DateTime.Now;
                                if (periodDate > curDate)
                                {
                                    sbQuery.AppendLine("Key Financials: " + property.DisplayName + " cannot be greater than current date");
                                }
                            }
                        }
                    }
                }
                catch { }
            }

            HFCNew_SubjectiveParametersEntity subjectiveParametersEntity = riskModelExcelEntity.HFCNew_SubjectiveParametersEntity;
            properties = TypeDescriptor.GetProperties(subjectiveParametersEntity);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = subjectiveParametersEntity.GetType().GetProperty(property.Name).GetValue(subjectiveParametersEntity, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Subjective Parameters: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            if (sbQuery.Length > 0)
            {
                message = sbQuery.ToString();
                return false;
            }
            return true;
        }

        public List<HFCNew_OutputDetailsEntity> ComputeOutputDetails(HFCNew_BasicDetailsEntity riskModelExcelEntity, bool isDownload, out string outputfileName)
        {
            outputfileName = string.Empty;
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            CompanyDAL companyDAL = new CompanyDAL();
            HFCNewDAL HFCNewDAL = new HFCNewDAL();
            List<HFCNew_OutputDetailsEntity> outputDetailsEntity = new List<HFCNew_OutputDetailsEntity>();

            bool status = false;
            string message = string.Empty;
            string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
            companyName = companyName.Replace("&", "");

            string fileName = string.Format("{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
            string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetHFCNew_InputTemplateFilePath()));
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));

            System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);

            try
            {
                status = HFCNewDAL.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath);
                outputDetailsEntity = HFCNewDAL.GetOutputFromExcel(userTemplateFilePath, fileName, "Output NHB$", userId);
                if (userTemplateFilePath != null && isDownload == false)
                {
                    if (System.IO.File.Exists(userTemplateFilePath))
                    {
                        System.IO.File.Delete(userTemplateFilePath);
                    }
                }
                outputfileName = fileName;
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }
            return outputDetailsEntity;
        }


        
        [HttpPost]
        public ActionResult SaveOutput(List<HFCNew_OutputDetailsEntity> outputDetailsEntity)
        {
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            int detail_ArchiveID = 0;
            bool status = false;
            string message = string.Empty;
            try
            {
                CompanyDAL companyDAL = new CompanyDAL();
                HFCNewDAL hcfDAL = new HFCNewDAL();

                DateTime dt = DateTime.Now;

                //// save Output records
                //status = hcfDAL.SaveAsDraft_OutputDetails(userId, roleId, outputDetailsEntity[0].DetailsId, detail_ArchiveID, dt, outputDetailsEntity);

                return Json(new
                {
                    Status = status,
                    Message = message,
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }

            return Json(new
            {
                Status = false,
                Message = message,
            }, JsonRequestBehavior.AllowGet); ;
        }

        [Authorize]
        [HttpPost]
        public ActionResult Download_OutputDetails_DetailsID(int detailsId)
        {
            bool status = false;
            string message = string.Empty;
            string fileName = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                HFCNewDAL hfcNewDAL = new HFCNewDAL();
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByDetailsID(detailsId);

                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetHFCNew_OutputTemplateFilePath()));
                fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
                status = hfcNewDAL.Get_OutputDetails_InterOp_DetailsId(detailsId, companyName ,userTemplateFilePath);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                status = false;
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Download_HFCNewOutputDetails(int CompanyId, string CreatedDateTime)
        {
            bool status = false;
            string message = string.Empty;
            string fileName = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                HFCNewDAL hfcNewDAL = new HFCNewDAL();
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByID(CompanyId);
                companyName = companyName.Replace("&", "");

                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetHFCNew_OutputTemplateFilePath()));
                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//OutputReport_{1}_{2}.xlsx", ConfigManager.GetOutputTemplateCopyFilePath(), companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss")));
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
                fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                status = hfcNewDAL.Get_OutputDetails_OpenXML(CompanyId, Convert.ToDateTime(CreatedDateTime), userTemplateFilePath);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                status = false;
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DownloadOutputExcelFile(string fileName)
        {
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
            byte[] fileByteArray = System.IO.File.ReadAllBytes(userTemplateFilePath);
            return File(fileByteArray, "application/vnd.ms-excel", fileName);
        }

    }


}

//private void SaveExcel(string existingFile, string newfilePath)
//{
//    Excel.Application xl = new Excel.Application();
//    Excel.Workbook wb = xl.Workbooks.Open(existingFile);
//    wb.SaveAs(newfilePath, Excel.XlFileFormat.xlWorkbookDefault,
//                         Type.Missing, Type.Missing, false, false, Excel.XlSaveAsAccessMode.xlNoChange,
//                         Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
//    wb.Saved = true;
//    wb.Close();
//    xl.Workbooks.Close();
//    xl.Quit();
//    //Excel.Application.
//    //Microsoft.Office.Interop.Excel.ExcelWorkBook.SaveAs("c:\\test.xls", Excel.XlFileFormat.xlWorkbookNormal,
//    //                     null, null, false, false, Excel.XlSaveAsAccessMode.xlShared,
//    //                     false, false, null, null, null);
//    //ExcelWorkBook.Close();
//}

//public ActionResult ReadOutputDetails()
//{
//    CompanyDAL companyDAL = new CompanyDAL();
//    HFCNewDAL hcfDAL = new HFCNewDAL();

//    try
//    {
//        string filePath = "";
//        string fileName = "";
//        filePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetOutputTemplateCopyFilePath()));
//        fileName = "2.xlsx";
//        filePath = filePath + fileName;
//        List<HFCNew_OutputDetailsEntity> hfcNew_OutputDetailsEntity = new List<HFCNew_OutputDetailsEntity>();
//        hfcNew_OutputDetailsEntity = hcfDAL.GetOutputFromExcel(filePath, fileName, "Output NHB$", 0);
//        return Json(new
//        {
//            Result = hfcNew_OutputDetailsEntity,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    catch (Exception ex)
//    {
//        ErrorLogger.LogError(ex, this);
//    }
//    return Json(new
//    {
//        Status = false,
//    }, JsonRequestBehavior.AllowGet);
//}


//public ActionResult ComputeOutputDetails(int companyId)
//{
//    int userId = SessionValue.UserID;
//    int roleId = SessionValue.RoleID;
//    CompanyDAL companyDAL = new CompanyDAL();
//    HFCNewDAL hcfDAL = new HFCNewDAL();

//    bool status = false;
//    string message = string.Empty;
//    string companyName = companyDAL.GetCompanyNameByID(companyId);
//    int detailsID = companyDAL.GetCompanyBasicDetailsID(companyId);
//    if (detailsID == 0)
//    {
//        message = "Please save the entry as draft first";
//        return Json(new
//        {
//            Status = false,
//            Message = message,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetHFCNew_InputTemplateFilePath()));
//    string userTemplateFilePath = Server.MapPath(string.Format("~{0}//InputReport_{1}_{2}.xlsx", ConfigManager.GetOutputTemplateCopyFilePath(), companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss")));

//    System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
//    string fileName = string.Format("InputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));

//    try
//    {
//        List<HFCNew_OutputDetailsEntity> hfcNew_OutputDetailsEntity = new List<HFCNew_OutputDetailsEntity>();
//        status = hcfDAL.Get_OutputDetailsFromFrontEnd_InterOp(detailsID, userTemplateFilePath);
//        hfcNew_OutputDetailsEntity = hcfDAL.GetOutputFromExcel(userTemplateFilePath, fileName, "Output NHB$", userId);
//        if (userTemplateFilePath != null)
//        {
//            //if (System.IO.File.Exists(userTemplateFilePath))
//            //{
//            //    System.IO.File.Delete(userTemplateFilePath);
//            //}
//        }
//        return Json(new
//        {
//            Status = status,
//            Message = message,
//            Result = hfcNew_OutputDetailsEntity,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    catch (Exception ex)
//    {
//        ErrorLogger.LogError(ex, this);
//        message = ex.ToString();
//    }
//    return Json(new
//    {
//        Status = false,
//        Message = message,
//        //Result = riskModelExcelEntity,
//    }, JsonRequestBehavior.AllowGet);
//}
