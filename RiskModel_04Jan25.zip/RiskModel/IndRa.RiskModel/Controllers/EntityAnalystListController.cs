﻿using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndRa.RiskModel.Controllers
{
    public class EntityAnalystListController : Controller
    {
        CommonDAL commonDAL = new CommonDAL();

        // GET: Dashboard
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetEntityAnalystList(string searchText)
        {
            int roleID = SessionValue.RoleID;
            List<AnalystEntity> result = commonDAL.GetEntityAnalystList(searchText);
            return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult SelectModel(int id, int modelId)
        {
            string controllerMethod = "ReadRiskModelExcelFile";
            var enumDisplayStatus = (ModelsEnum)modelId;
            string modelName = enumDisplayStatus.ToString();
            try
            {
                return RedirectToAction(controllerMethod, modelName, new
                {
                    detailsId = id,
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            return View();
        }

    }
}