﻿using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Extensionmethod = IndRa.RiskModel.DAL.Helpers;

namespace IndRa.RiskModel.Controllers
{
    public class PFRMController : Controller
    {
        [Authorize]
        public ActionResult Index()
        {
            return RedirectToAction("ReadRiskModelExcelFile");
        }


        [HttpPost]
        public ActionResult GetHeaderParametersList(int ModelId)
        {
            PFRMDAL pfrmDAL = new PFRMDAL();
            var data = pfrmDAL.GetHeaderParametersList();
            List<SubjectiveParametersEntity> result = data.ToList();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        public ActionResult ReadRiskModelExcelFile(int? detailsId, short? logId)
        {
            //HttpContext.Current.Session["RoleID"]
            //System.Web.HttpContext context = System.Web.HttpContext.Current;
            //if (context.Session == null)
            //{
            //   return RedirectToAction("Login", "Account");
            //}
            RiskModelExcelEntity riskModelExcelEntity = new RiskModelExcelEntity();
            CompanyDAL companyDAL = new CompanyDAL();
            PFRMDAL pfrmDAL = new PFRMDAL();
            PFRM_BasicDetailsEntity pfrm_BasicDetailsEntity = new PFRM_BasicDetailsEntity();
            try
            {
                int roleID = SessionValue.RoleID;
                int userID = SessionValue.UserID;

                ViewBag.Companies = DropDownValue.GetCompaniesList((int)ModelsEnum.PFRM, roleID, userID);
                ViewBag.RatingList = DropDownValue.GetRatingsList((int)ModelsEnum.PFRM);
                ViewBag.Locations = DropDownValue.GetLocationsList();
                ViewBag.YesorNoStatus = DropDownValue.GetYesorNoStatus();
                ViewBag.ParameterNo = DropDownValue.GetParamterNoList();
                ViewBag.ProjectTypeList = DropDownValue.GetProjectTypeList();
                ViewBag.FinYearList = DropDownValue.GetFinYearList();

                if (detailsId.HasValue && detailsId != 0)
                {
                    // Get Log Data
                    if (logId.HasValue && logId.Value > 0)
                    {
                        pfrm_BasicDetailsEntity = pfrmDAL.GetBasicDetails_Archive(detailsId.Value, logId.Value);
                    }
                    else
                    {
                        pfrm_BasicDetailsEntity = pfrmDAL.GetBasicDetails(detailsId.Value);
                    }
                }
                else
                {
                    pfrm_BasicDetailsEntity.DetailsId = 0;
                }
                return View(pfrm_BasicDetailsEntity);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
        }

        [Authorize]
        [HttpPost]
        public ActionResult ImporRiskModelData(PFRM_BasicDetailsEntity riskModelExcelEntity)
        {
            bool success = false;
            string message = string.Empty;
            int userID = SessionValue.UserID;
            PFRM_BasicDetailsEntity riskModelResult = new PFRM_BasicDetailsEntity();
            try
            {
                PFRMDAL pfrm_DAL = new PFRMDAL();
                string fileName = Path.GetFileName(riskModelExcelEntity.ExcelFile.FileName);
                string copyFile = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}{1}", ConfigManager.GetExcelSheetFileCopyPath(), fileName));
                string copyFilePath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}", ConfigManager.GetExcelSheetFileCopyPath()));

                System.IO.Directory.CreateDirectory(copyFilePath);

                if (System.IO.Directory.Exists(copyFilePath))
                {
                    if (System.IO.File.Exists(copyFile))
                    {
                        System.IO.File.Delete(copyFile);
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }
                    else
                    {
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }

                    riskModelResult = pfrm_DAL.ImportCompanyDetailsFromExcel(copyFile, fileName, "Data Template$", userID);


                    if (riskModelResult != null)
                    {
                        riskModelResult.InputFilePath = copyFile;
                        success = true;
                        message = "Data Fetched From Excel Sheet";
                    }
                    else
                    {
                        success = false;
                        message = "Unable to fetch Excel Sheet Data";
                    }
                }

            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                success = false;
                message = exception.Message;

            }
            finally
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            return Json(new
            {
                Status = success,
                Message = message,
                Result = riskModelResult,
            }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SavePFRMDetails(PFRM_BasicDetailsEntity riskModelExcelEntity)
        {
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            int detailID = 0;
            short logID = 0;

            int detail_ArchiveID = 0;

            bool status = false;
            string message = string.Empty;
            CompanyDAL companyDAL = new CompanyDAL();
            UserDAL userDAL = new UserDAL();

            CommonFunction commonFunction = new CommonFunction();
            PFRMDAL pfrmDAL = new PFRMDAL();
            string riskModelFilePath = SessionValue.RISKMODEL_FILE_PATH;
            List<PFRM_OutputDetailsEntity> pfrm_OutputDetailsEntity = new List<PFRM_OutputDetailsEntity>();

            List<PFRM_OutputDetailsEntity> outputDetailsEntity = new List<PFRM_OutputDetailsEntity>();
            string outputFileName = "";

            #region Compute Output

            if (riskModelExcelEntity.ButtonValue == "ComputeOutput")
            {
                status = true;
                outputDetailsEntity = ComputeOutputDetails(riskModelExcelEntity, false, out outputFileName);
                return Json(new
                {
                    ButtonValue = riskModelExcelEntity.ButtonValue,
                    Status = status,
                    Message = message,
                    Result = outputDetailsEntity,
                }, JsonRequestBehavior.AllowGet);
            }
            #endregion


            #region Download

            else if (riskModelExcelEntity.ButtonValue == "Download")
            {
                status = true;
                outputDetailsEntity = ComputeOutputDetails(riskModelExcelEntity, true, out outputFileName);
                return Json(new
                {
                    ButtonValue = riskModelExcelEntity.ButtonValue,
                    Status = status,
                    Message = message,
                    Result = outputDetailsEntity,
                    FileName = outputFileName,
                }, JsonRequestBehavior.AllowGet);
            }

            #endregion

            #region Save

            else
            {
                int? assignedUserID = companyDAL.GetAssignedAnalystID(riskModelExcelEntity.CompanyId);
                string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
                string toEmailAddress = userDAL.GetUserEmailAddress(assignedUserID.HasValue ? assignedUserID.Value : 0);

                riskModelExcelEntity.PFRM_SponsorRiskAssessmentEntity.CreatedBy = userId;
                riskModelExcelEntity.PFRM_SponsorRiskAssessmentEntity.UpdatedBy = userId;
                riskModelExcelEntity.PFRM_SponsorRiskAssessmentEntity.CreatedDateTime = DateTime.Now;
                riskModelExcelEntity.PFRM_SponsorRiskAssessmentEntity.UpdatedDateTime = DateTime.Now;

                riskModelExcelEntity.PFRM_ConstructionRiskAssessmentEntity.CreatedBy = userId;
                riskModelExcelEntity.PFRM_ConstructionRiskAssessmentEntity.UpdatedBy = userId;
                riskModelExcelEntity.PFRM_ConstructionRiskAssessmentEntity.CreatedDateTime = DateTime.Now;
                riskModelExcelEntity.PFRM_ConstructionRiskAssessmentEntity.UpdatedDateTime = DateTime.Now;

                riskModelExcelEntity.PFRM_MarketRiskAssessmentEntity.CreatedBy = userId;
                riskModelExcelEntity.PFRM_MarketRiskAssessmentEntity.UpdatedBy = userId;
                riskModelExcelEntity.PFRM_MarketRiskAssessmentEntity.CreatedDateTime = DateTime.Now;
                riskModelExcelEntity.PFRM_MarketRiskAssessmentEntity.UpdatedDateTime = DateTime.Now;

                riskModelExcelEntity.PFRM_ProjectCostViablityEntity.CreatedBy = userId;
                riskModelExcelEntity.PFRM_ProjectCostViablityEntity.UpdatedBy = userId;
                riskModelExcelEntity.PFRM_ProjectCostViablityEntity.CreatedDateTime = DateTime.Now;
                riskModelExcelEntity.PFRM_ProjectCostViablityEntity.UpdatedDateTime = DateTime.Now;

                riskModelExcelEntity.PFRM_ProjectStatusEntity.CreatedBy = userId;
                riskModelExcelEntity.PFRM_ProjectStatusEntity.UpdatedBy = userId;
                riskModelExcelEntity.PFRM_ProjectStatusEntity.CreatedDateTime = DateTime.Now;
                riskModelExcelEntity.PFRM_ProjectStatusEntity.UpdatedDateTime = DateTime.Now;

                riskModelExcelEntity.PFRM_ConductProjectAccountEntity.CreatedBy = userId;
                riskModelExcelEntity.PFRM_ConductProjectAccountEntity.UpdatedBy = userId;
                riskModelExcelEntity.PFRM_ConductProjectAccountEntity.CreatedDateTime = DateTime.Now;
                riskModelExcelEntity.PFRM_ConductProjectAccountEntity.UpdatedDateTime = DateTime.Now;

                riskModelExcelEntity.PFRM_PublicSectorAgencyFinancialInputEntity.CreatedBy = userId;
                riskModelExcelEntity.PFRM_PublicSectorAgencyFinancialInputEntity.UpdatedBy = userId;
                riskModelExcelEntity.PFRM_PublicSectorAgencyFinancialInputEntity.CreatedDateTime = DateTime.Now;
                riskModelExcelEntity.PFRM_PublicSectorAgencyFinancialInputEntity.UpdatedDateTime = DateTime.Now;

                riskModelExcelEntity.PFRM_PrivateSectorAgencyFinancialInputEntity.CreatedBy = userId;
                riskModelExcelEntity.PFRM_PrivateSectorAgencyFinancialInputEntity.UpdatedBy = userId;
                riskModelExcelEntity.PFRM_PrivateSectorAgencyFinancialInputEntity.CreatedDateTime = DateTime.Now;
                riskModelExcelEntity.PFRM_PrivateSectorAgencyFinancialInputEntity.UpdatedDateTime = DateTime.Now;

                riskModelExcelEntity.PFRM_MicroFinanceInstitutionEntity.CreatedBy = userId;
                riskModelExcelEntity.PFRM_MicroFinanceInstitutionEntity.UpdatedBy = userId;
                riskModelExcelEntity.PFRM_MicroFinanceInstitutionEntity.CreatedDateTime = DateTime.Now;
                riskModelExcelEntity.PFRM_MicroFinanceInstitutionEntity.UpdatedDateTime = DateTime.Now;

                if (Validation(riskModelExcelEntity, out message) == true)
                {
                    detailID = pfrmDAL.SaveCompanyBasicDetailsAsDraft(userId, roleId, riskModelExcelEntity, out detail_ArchiveID, out logID);

                    if (detailID > 0)
                    {
                        commonFunction.MoveFileToInputFolder(riskModelExcelEntity.InputFilePath, riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);

                        // save Sponsor Risk Assessment
                        pfrmDAL.SaveAsDraft_SponsorRiskAssessment(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.PFRM_SponsorRiskAssessmentEntity);

                        // save ConductProjectAccount
                        pfrmDAL.SaveAsDraft_ConductProjectAccount(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.PFRM_ConductProjectAccountEntity);

                        // save Construction Risk Assessment
                        pfrmDAL.SaveAsDraft_ConstructionRiskAssessment(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.PFRM_ConstructionRiskAssessmentEntity);

                        // save Market Risk Assessment
                        pfrmDAL.SaveAsDraft_MarketRiskAssessment(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.PFRM_MarketRiskAssessmentEntity);

                        // save Micro Finance Institution
                        pfrmDAL.SaveAsDraft_MicroFinanceInstitution(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.PFRM_MicroFinanceInstitutionEntity);

                        // save Private Sector Agency Financial Input
                        pfrmDAL.SaveAsDraft_PrivateSectorAgencyFinancialInput(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.PFRM_PrivateSectorAgencyFinancialInputEntity);

                        // save Public Sector Agency Financial Input
                        pfrmDAL.SaveAsDraft_PublicSectorAgencyFinancialInput(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.PFRM_PublicSectorAgencyFinancialInputEntity);

                        // save Project Status
                        pfrmDAL.SaveAsDraft_ProjectStatus(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.PFRM_ProjectStatusEntity);

                        // save Project Cost Viablity
                        pfrmDAL.SaveAsDraft_ProjectCostViablity(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.PFRM_ProjectCostViablityEntity);

                        // save Output records
                        //pfrmDAL.SaveAsDraft_OutputDetails(userId, roleId, detailID, detail_ArchiveID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.PFRM_OutputDetailsEntity);
                        if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                        {
                            Email.SendMail(toEmailAddress, companyName, (int)EmailTemplateEnum.ApprovedEntityTemplate);
                        }
                        status = true;
                        message = "success";
                    }
                    return Json(new
                    {
                        DetailID = detailID,
                        ButtonValue = riskModelExcelEntity.ButtonValue,
                        Status = true,
                        Message = message,
                        Result = riskModelExcelEntity,
                    }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new
                    {
                        ButtonValue = riskModelExcelEntity.ButtonValue,
                        Status = false,
                        Message = message,
                        Result = riskModelExcelEntity,
                    }, JsonRequestBehavior.AllowGet);
                }
            }

            #endregion

        }

        [Authorize]
        [HttpPost]
        public ActionResult DownloadOutputExcelFileDetails(int CompanyId, string CreatedDateTime)
        {
            bool status = false;
            string message = string.Empty;
            string fileName = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                PFRMDAL pfrmDAL = new PFRMDAL();
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByID(CompanyId);
                companyName = companyName.Replace("&", "");

                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetPFRM_OutputTemplateFilePath()));
                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//OutputReport_{1}_{2}.xlsx", ConfigManager.GetOutputTemplateCopyFilePath(), companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss")));
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
                fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                status = pfrmDAL.Get_OutputDetails_OpenXML(CompanyId, Convert.ToDateTime(CreatedDateTime), userTemplateFilePath);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                status = false;
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DownloadOutputExcelFile(string fileName)
        {
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
            byte[] fileByteArray = System.IO.File.ReadAllBytes(userTemplateFilePath);
            return File(fileByteArray, "application/vnd.ms-excel", fileName);
        }

        public List<PFRM_OutputDetailsEntity> ComputeOutputDetails(PFRM_BasicDetailsEntity riskModelExcelEntity, bool isDownload, out string outputfileName)
        {
            outputfileName = string.Empty;

            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            CompanyDAL companyDAL = new CompanyDAL();
            PFRMDAL PFRMDAL = new PFRMDAL();
            List<PFRM_OutputDetailsEntity> outputDetailsEntity = new List<PFRM_OutputDetailsEntity>();

            bool status = false;
            string message = string.Empty;
            string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
            companyName = companyName.Replace("&", "");

            string fileName = string.Format("{0}_{1}.xlsm", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
            string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetPFRM_InputTemplateFilePath()));
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
            try
            {
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
            }
            catch (Exception ex)
            {
                ErrorLogger.LogInfo("System.IO.File.Copy Error: " + ex.Message);
                ErrorLogger.LogError(ex, this);
            }
            try
            {
                status = PFRMDAL.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath);
            }
            catch (Exception ex)
            {
                ErrorLogger.LogInfo("ComputeOutputDetails Error: " + ex.Message);
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }
            try
            {
                outputDetailsEntity = PFRMDAL.GetOutputFromExcel(userTemplateFilePath, fileName, "Working$", userId);
                if (userTemplateFilePath != null && isDownload == false)
                {
                    if (System.IO.File.Exists(userTemplateFilePath))
                    {
                        //Commented Temp
                        //System.IO.File.Delete(userTemplateFilePath);
                    }
                }
                outputfileName = fileName;
            }
            catch (Exception ex)
            {
                ErrorLogger.LogInfo("GetOutputFromExcel Error: " + ex.Message);
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }
            return outputDetailsEntity;
        }


        [HttpPost]
        public ActionResult SaveOutput(List<PFRM_OutputDetailsEntity> outputDetailsEntity)
        {
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            int detailID = 0;
            int detail_ArchiveID = 0;
            bool status = false;
            string message = string.Empty;
            try
            {
                CompanyDAL companyDAL = new CompanyDAL();
                PFRMDAL pfrmDAL = new PFRMDAL();

                DateTime dt = DateTime.Now;
                short logID = companyDAL.GetNHBLatestLogId(outputDetailsEntity[0].DetailsId);
                //// save Output records
                status = pfrmDAL.SaveAsDraft_OutputDetails(userId, roleId, outputDetailsEntity[0].DetailsId, logID, detail_ArchiveID, dt, outputDetailsEntity);

                return Json(new
                {
                    Status = status,
                    Message = message,
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }

            return Json(new
            {
                Status = false,
                Message = message,
            }, JsonRequestBehavior.AllowGet); ;
        }

        public bool Validation(PFRM_BasicDetailsEntity riskModelExcelEntity, out string message)
        {
            StringBuilder sbQuery = new StringBuilder();
            message = "";
            object obj;

            if (riskModelExcelEntity.CompanyId == 0)
            {
                sbQuery.AppendLine("Basic Details: Entity Name is mandatory");
                message = sbQuery.ToString();
                return false;
            }
            else if (string.IsNullOrEmpty(riskModelExcelEntity.FinYear))
            {
                sbQuery.AppendLine("Basic Details: Financial Year is mandatory");
                message = sbQuery.ToString();
                return false;
            }
            if (riskModelExcelEntity.ButtonValue == ButtonValue.SaveAsDraft.ToString())
            {
                return true;
            }

            if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
            {
                if (string.IsNullOrEmpty(riskModelExcelEntity.Comments))
                {
                    sbQuery.AppendLine("Output: Admin comments is mandatory");
                }
                else if (string.IsNullOrEmpty(riskModelExcelEntity.FinalRating))
                {
                    sbQuery.AppendLine("Output: Final Rating is mandatory");
                }
            }

            PFRM_SponsorRiskAssessmentEntity sponsorRiskAssessment = riskModelExcelEntity.PFRM_SponsorRiskAssessmentEntity;
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(sponsorRiskAssessment);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null && property.DisplayName != string.Empty)
                    {
                        obj = sponsorRiskAssessment.GetType().GetProperty(property.Name).GetValue(sponsorRiskAssessment, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Sponsor Risk Assessment: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            PFRM_ConstructionRiskAssessmentEntity constructionRisk = riskModelExcelEntity.PFRM_ConstructionRiskAssessmentEntity;
            properties = TypeDescriptor.GetProperties(constructionRisk);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = constructionRisk.GetType().GetProperty(property.Name).GetValue(constructionRisk, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Construction Risk Assessment: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            PFRM_ConductProjectAccountEntity conductProject = riskModelExcelEntity.PFRM_ConductProjectAccountEntity;
            properties = TypeDescriptor.GetProperties(conductProject);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = conductProject.GetType().GetProperty(property.Name).GetValue(conductProject, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Conduct Project: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            PFRM_ProjectCostViablityEntity projectCostVialbility = riskModelExcelEntity.PFRM_ProjectCostViablityEntity;
            properties = TypeDescriptor.GetProperties(projectCostVialbility);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = projectCostVialbility.GetType().GetProperty(property.Name).GetValue(projectCostVialbility, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Project Cost Viability: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            PFRM_ProjectStatusEntity projectStatus = riskModelExcelEntity.PFRM_ProjectStatusEntity;
            properties = TypeDescriptor.GetProperties(projectStatus);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = projectStatus.GetType().GetProperty(property.Name).GetValue(projectStatus, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Project Status: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            PFRM_MarketRiskAssessmentEntity marketRisk = riskModelExcelEntity.PFRM_MarketRiskAssessmentEntity;
            properties = TypeDescriptor.GetProperties(projectStatus);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = marketRisk.GetType().GetProperty(property.Name).GetValue(marketRisk, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Market Risk: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }


            PFRM_MicroFinanceInstitutionEntity microFinanceInstitute = riskModelExcelEntity.PFRM_MicroFinanceInstitutionEntity;
            properties = TypeDescriptor.GetProperties(microFinanceInstitute);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = microFinanceInstitute.GetType().GetProperty(property.Name).GetValue(microFinanceInstitute, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Micro Finance Institute: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            PFRM_PrivateSectorAgencyFinancialInputEntity privateSectorAgency = riskModelExcelEntity.PFRM_PrivateSectorAgencyFinancialInputEntity;
            properties = TypeDescriptor.GetProperties(privateSectorAgency);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = privateSectorAgency.GetType().GetProperty(property.Name).GetValue(privateSectorAgency, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Private Sector Agency: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            PFRM_PublicSectorAgencyFinancialInputEntity publicSectorAgency = riskModelExcelEntity.PFRM_PublicSectorAgencyFinancialInputEntity;
            properties = TypeDescriptor.GetProperties(publicSectorAgency);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = publicSectorAgency.GetType().GetProperty(property.Name).GetValue(publicSectorAgency, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Public Sector Agency: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }
            if (sbQuery.Length > 0)
            {
                message = sbQuery.ToString();
                return false;
            }
            return true;
        }

        [Authorize]
        [HttpPost]
        public ActionResult Download_PFRMOutputDetails(int CompanyId, string CreatedDateTime)
        {
            bool status = false;
            string message = string.Empty;
            string fileName = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                PFRMDAL PFRMDAL = new PFRMDAL();
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByID(CompanyId);
                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetPFRM_OutputTemplateFilePath()));
                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//OutputReport_{1}_{2}.xlsx", ConfigManager.GetOutputTemplateCopyFilePath(), companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss")));
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
                fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                status = PFRMDAL.Get_OutputDetails_OpenXML(CompanyId, Convert.ToDateTime(CreatedDateTime), userTemplateFilePath);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                status = false;
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Download_PFRMOutputDetails_DetailsID(int detailsId)
        {
            bool status = false;
            string message = string.Empty;
            string fileName = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                PFRMDAL pfrmDAL = new PFRMDAL();
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByDetailsID(detailsId);

                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetPFRM_OutputTemplateFilePath()));
                fileName = string.Format("OutputReport_{0}_{1}.xlsm", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
                status = pfrmDAL.Get_OutputDetails_InterOp_DetailsId(detailsId, companyName, userTemplateFilePath);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                status = false;
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);
        }

    }


}

//public ActionResult ComputeOutputDetails(int companyId)
//{
//    int userId = SessionValue.UserID;
//    int roleId = SessionValue.RoleID;
//    CompanyDAL companyDAL = new CompanyDAL();
//    PFRMDAL pfrmDAL = new PFRMDAL();

//    bool status = false;
//    string message = string.Empty;
//    string companyName = companyDAL.GetCompanyNameByID(companyId);
//    int detailsID = companyDAL.GetCompanyBasicDetailsID(companyId);
//    if (detailsID == 0)
//    {
//        message = "Please save the entry as draft first";
//        return Json(new
//        {
//            Status = false,
//            Message = message,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetPFRM_InputTemplateFilePath()));
//    string userTemplateFilePath = Server.MapPath(string.Format("~{0}//InputReport_{1}_{2}.xlsm", ConfigManager.GetOutputTemplateCopyFilePath(), companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss")));

//    System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
//    string fileName = string.Format("InputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));

//    try
//    {
//        List<PFRM_OutputDetailsEntity> outputDetailsEntity = new List<PFRM_OutputDetailsEntity>();
//        status = pfrmDAL.Get_OutputDetailsFromFrontEnd_InterOp(detailsID, userTemplateFilePath);
//        outputDetailsEntity = pfrmDAL.GetOutputFromExcel(userTemplateFilePath, fileName, "Working$", userId);
//        if (userTemplateFilePath != null)
//        {
//            if (System.IO.File.Exists(userTemplateFilePath))
//            {
//                System.IO.File.Delete(userTemplateFilePath);
//            }
//        }
//        return Json(new
//        {
//            Status = status,
//            Message = message,
//            Result = outputDetailsEntity,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    catch (Exception ex)
//    {
//        ErrorLogger.LogError(ex, this);
//        message = ex.ToString();
//    }
//    return Json(new
//    {
//        Status = false,
//        Message = message,
//        //Result = riskModelExcelEntity,
//    }, JsonRequestBehavior.AllowGet);
//}
