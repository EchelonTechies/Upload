﻿using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Extensionmethod = IndRa.RiskModel.DAL.Helpers;

namespace IndRa.RiskModel.Controllers
{
    public class SFBController : Controller
    {
        SFBDAL sfbDAL = new SFBDAL();
        [Authorize]
        public ActionResult Index()
        {
            return RedirectToAction("ReadRiskModelExcelFile");
        }

        [Authorize]
        public ActionResult ReadRiskModelExcelFile(int? detailsId, short? logId)
        {
            RiskModelExcelEntity riskModelExcelEntity = new RiskModelExcelEntity();
            CompanyDAL companyDAL = new CompanyDAL();
            SFB_BasicDetailsEntity sfb_BasicDetailsEntity = new SFB_BasicDetailsEntity();

            try
            {
                int roleID = SessionValue.RoleID;
                int userID = SessionValue.UserID;

                ViewBag.Companies = DropDownValue.GetCompaniesList((int)ModelsEnum.SFB, roleID, userID);
                ViewBag.RatingList = DropDownValue.GetRatingsList((int)ModelsEnum.SFB);

                ViewBag.Locations = DropDownValue.GetLocationsList();
                ViewBag.GetYesNoStatus = DropDownValue.GetYesNoStatus();
                ViewBag.YesorNoStatus = DropDownValue.GetYesorNoStatus();
                ViewBag.CurrencyList = DropDownValue.GetCurrencyList();
                ViewBag.FinYearList = DropDownValue.GetFinYearList();
                if (detailsId.HasValue && detailsId != 0)
                {
                    // Get Log Data
                    if (logId.HasValue && logId.Value > 0)
                    {
                        sfb_BasicDetailsEntity = sfbDAL.GetBasicDetails_Archive(detailsId.Value, logId.Value);
                    }
                    else
                    {
                        sfb_BasicDetailsEntity = sfbDAL.GetBasicDetails(detailsId.Value);
                    }
                }
                else
                {
                    sfb_BasicDetailsEntity.DetailsId = 0;
                }
                if (sfb_BasicDetailsEntity.SFB_OutputDetailsEntity == null || sfb_BasicDetailsEntity.SFB_OutputDetailsEntity.Count == 0)
                {
                    sfb_BasicDetailsEntity.SFB_OutputDetailsEntity = sfbDAL.GetOutputTemplateEntity();
                }
                return View(sfb_BasicDetailsEntity);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
        }

        public ActionResult SaveSFBDetails(SFB_BasicDetailsEntity riskModelExcelEntity)
        {
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            int detailID = 0;
            short logID = 0;
            int detail_ArchiveID = 0;

            bool status = false;
            string message = string.Empty;
            CompanyDAL companyDAL = new CompanyDAL();
            UserDAL userDAL = new UserDAL();
            CommonFunction commonFunction = new CommonFunction();
            SFBDAL SFBDAL = new SFBDAL();
            string riskModelFilePath = SessionValue.RISKMODEL_FILE_PATH;
            List<SFB_OutputDetailsEntity> outputDetailsEntity = new List<SFB_OutputDetailsEntity>();
            string outputFileName = "";

            try
            {
                #region Compute Output

                if (riskModelExcelEntity.ButtonValue == "ComputeOutput")
                {
                    status = true;
                    outputDetailsEntity = ComputeOutputDetails(riskModelExcelEntity, false, out outputFileName);
                    return Json(new
                    {
                        ButtonValue = riskModelExcelEntity.ButtonValue,
                        Status = status,
                        Message = message,
                        Result = outputDetailsEntity,
                    }, JsonRequestBehavior.AllowGet);
                }

                #endregion

                #region Download

                else if (riskModelExcelEntity.ButtonValue == "Download")
                {
                    status = true;
                    outputDetailsEntity = ComputeOutputDetails(riskModelExcelEntity, true, out outputFileName);
                    return Json(new
                    {
                        ButtonValue = riskModelExcelEntity.ButtonValue,
                        Status = status,
                        Message = message,
                        Result = outputDetailsEntity,
                        FileName = outputFileName,
                    }, JsonRequestBehavior.AllowGet);
                }

                #endregion

                #region Save

                else
                {
                    int? assignedUserID = companyDAL.GetAssignedAnalystID(riskModelExcelEntity.CompanyId);
                    string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
                    string toEmailAddress = userDAL.GetUserEmailAddress(assignedUserID.HasValue ? assignedUserID.Value : 0);

                    riskModelExcelEntity.SFB_KeyFinancialsEntity.CreatedBy = userId;
                    riskModelExcelEntity.SFB_KeyFinancialsEntity.UpdatedBy = userId;
                    riskModelExcelEntity.SFB_KeyFinancialsEntity.CreatedDateTime = DateTime.Now;
                    riskModelExcelEntity.SFB_KeyFinancialsEntity.UpdatedDateTime = DateTime.Now;

                    riskModelExcelEntity.SFB_SubjectiveParametersEntity.CreatedBy = userId;
                    riskModelExcelEntity.SFB_SubjectiveParametersEntity.UpdatedBy = userId;
                    riskModelExcelEntity.SFB_SubjectiveParametersEntity.CreatedDateTime = DateTime.Now;
                    riskModelExcelEntity.SFB_SubjectiveParametersEntity.UpdatedDateTime = DateTime.Now;

                    riskModelExcelEntity.SFB_IndustryExpsoureEntity.CreatedBy = userId;
                    riskModelExcelEntity.SFB_IndustryExpsoureEntity.UpdatedBy = userId;
                    riskModelExcelEntity.SFB_IndustryExpsoureEntity.CreatedDateTime = DateTime.Now;
                    riskModelExcelEntity.SFB_IndustryExpsoureEntity.UpdatedDateTime = DateTime.Now;

                    if (Validation(riskModelExcelEntity, out message) == true)
                    {
                        detailID = SFBDAL.SaveCompanyBasicDetailsAsDraft(userId, roleId, riskModelExcelEntity, out detail_ArchiveID, out logID);

                        if (detailID > 0)
                        {
                            commonFunction.MoveFileToInputFolder(riskModelExcelEntity.InputFilePath, riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);

                            // save Key Financials record
                            SFBDAL.SaveAsDraft_SFBKeyFinancial(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.SFB_KeyFinancialsEntity);

                            // save Subjective Parameters record
                            SFBDAL.SaveAsDraft_SFBSubjectiveParameters(userId, roleId,  detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.SFB_SubjectiveParametersEntity);

                            // save Industry Exposure record
                            SFBDAL.SaveAsDraft_SFBIndustryExposure(userId, roleId, detailID, logID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.SFB_IndustryExpsoureEntity);

                            // save Output records
                            SFBDAL.SaveAsDraft_OutputDetails(userId, roleId, detailID,logID, detail_ArchiveID, riskModelExcelEntity.CreatedDateTime, riskModelExcelEntity.SFB_OutputDetailsEntity);
                            if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                            {
                                Email.SendMail(toEmailAddress, companyName, (int)EmailTemplateEnum.ApprovedEntityTemplate);
                            }
                            status = true;
                            message = "success";
                        }
                        return Json(new
                        {
                            DetailID = detailID,
                            ButtonValue = riskModelExcelEntity.ButtonValue,
                            Status = status,
                            Message = message,
                            Result = riskModelExcelEntity
                        }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new
                        {
                            ButtonValue = riskModelExcelEntity.ButtonValue,
                            Status = false,
                            Message = message,
                            Result = riskModelExcelEntity
                        }, JsonRequestBehavior.AllowGet);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }

            return Json(new
            {
                ButtonValue = riskModelExcelEntity.ButtonValue,
                Status = false,
                Message = message,
                Result = riskModelExcelEntity
            }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpPost]
        public ActionResult ImporRiskModelData(SFB_BasicDetailsEntity riskModelExcelEntity)
        {
            bool success = false;
            string message = string.Empty;
            int userID = SessionValue.UserID;
            SFB_BasicDetailsEntity riskModelResult = new SFB_BasicDetailsEntity();
            try
            {
                SFBDAL SFBDAL = new SFBDAL();
                string fileName = Path.GetFileName(riskModelExcelEntity.ExcelFile.FileName);
                string copyFile = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}{1}", ConfigManager.GetExcelSheetFileCopyPath(), fileName));
                string copyFilePath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}", ConfigManager.GetExcelSheetFileCopyPath()));

                System.IO.Directory.CreateDirectory(copyFilePath);

                if (System.IO.Directory.Exists(copyFilePath))
                {
                    if (System.IO.File.Exists(copyFile))
                    {
                        System.IO.File.Delete(copyFile);
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }
                    else
                    {
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }

                    riskModelResult = SFBDAL.ImportCompanyDetailsFromExcel(copyFile, fileName, "Data Input Sheet$", userID);
                    if (riskModelResult != null)
                    {
                        riskModelResult.InputFilePath = copyFile;
                        success = true;
                        message = "Data Fetched From Excel Sheet";
                    }
                    else
                    {
                        success = false;
                        message = "Unable to fetch Excel Sheet Data";
                    }
                }

            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                success = false;
                message = exception.Message;

            }
            finally
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            return Json(new
            {
                Status = success,
                Message = message,
                Result = riskModelResult,
            }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Download_SFBOutputDetails(int CompanyId, string CreatedDateTime)
        {
            bool status = false;
            string message = string.Empty;
            string fileName = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                SFBDAL SFBDAL = new SFBDAL();
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByID(CompanyId);
                companyName = companyName.Replace("&", "");

                fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetSFB_OutputTemplateFilePath()));
                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//OutputReport_{1}_{2}.xlsx", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
                status = SFBDAL.Get_OutputDetails_OpenXML(CompanyId, Convert.ToDateTime(CreatedDateTime), userTemplateFilePath);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                status = false;
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DownloadOutputExcelFile(string fileName)
        {
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
            byte[] fileByteArray = System.IO.File.ReadAllBytes(userTemplateFilePath);
            return File(fileByteArray, "application/vnd.ms-excel", fileName);
        }

        public List<SFB_OutputDetailsEntity> ComputeOutputDetails(SFB_BasicDetailsEntity riskModelExcelEntity, bool isDownload, out string outputfileName)
        {
            outputfileName = string.Empty;
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            CompanyDAL companyDAL = new CompanyDAL();
            SFBDAL SFBDAL = new SFBDAL();
            List<SFB_OutputDetailsEntity> outputDetailsEntity = new List<SFB_OutputDetailsEntity>();

            bool status = false;
            string message = string.Empty;
            string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
            companyName = companyName.Replace("&", "");

            string fileName = string.Format("{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
            string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetSFB_InputTemplateFilePath()));
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));

            System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);

            try
            {
                status = SFBDAL.ComputeOutputDetails(riskModelExcelEntity, userTemplateFilePath);
                outputDetailsEntity = SFBDAL.GetOutputFromExcel(userTemplateFilePath, fileName, "Output NHB$", userId);
                if (userTemplateFilePath != null && isDownload == false)
                {
                    if (System.IO.File.Exists(userTemplateFilePath))
                    {
                        System.IO.File.Delete(userTemplateFilePath);
                    }
                }
                outputfileName = fileName;
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }
            return outputDetailsEntity;
        }




        public ActionResult SaveOutput(List<SFB_OutputDetailsEntity> outputDetailsEntity)
        {
            int userId = SessionValue.UserID;
            int roleId = SessionValue.RoleID;
            int detailID = outputDetailsEntity[0].DetailsId;
            int detail_ArchiveID = 0;
            bool status = false;
            string message = string.Empty;
            try
            {
                CompanyDAL companyDAL = new CompanyDAL();
                SFBDAL sfbDAL = new SFBDAL();

                DateTime dt = DateTime.Now;

                //// save Output records
                //status = sfbDAL.SaveAsDraft_OutputDetails(userId, roleId, detailID, detail_ArchiveID, dt, outputDetailsEntity);

                return Json(new
                {
                    Status = status,
                    Message = message,
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                ErrorLogger.LogError(ex, this);
                message = ex.ToString();
            }

            return Json(new
            {
                Status = false,
                Message = message,
            }, JsonRequestBehavior.AllowGet); ;
        }


        [Authorize]
        [HttpPost]
        public ActionResult Download_SFBOutputDetails_DetailsID(int detailsId)
        {
            bool status = false;
            string message = string.Empty;
            string fileName = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                SFBDAL sfbDAL = new SFBDAL();
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByDetailsID(detailsId);

                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetSFB_OutputTemplateFilePath()));
                fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
                status = sfbDAL.Get_OutputDetails_InterOp_DetailsId(detailsId, companyName, userTemplateFilePath);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                status = false;
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);
        }

        public bool Validation(SFB_BasicDetailsEntity riskModelExcelEntity, out string message)
        {
            StringBuilder sbQuery = new StringBuilder();
            message = "";
            object obj;

            if (riskModelExcelEntity.CompanyId == 0)
            {
                sbQuery.AppendLine("Basic Details: Entity Name is mandatory");
                message = sbQuery.ToString();
                return false;
            }
            else if (string.IsNullOrEmpty(riskModelExcelEntity.FinYear))
            {
                sbQuery.AppendLine("Basic Details: Financial Year is mandatory");
                message = sbQuery.ToString();
                return false;
            }
            if (riskModelExcelEntity.ButtonValue == ButtonValue.SaveAsDraft.ToString())
            {
                return true;
            }

            if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
            {
                if (string.IsNullOrEmpty(riskModelExcelEntity.Comments))
                {
                    sbQuery.AppendLine("Output: Admin comments is mandatory");
                }
                else if (string.IsNullOrEmpty(riskModelExcelEntity.FinalRating))
                {
                    sbQuery.AppendLine("Output: Final Rating is mandatory");
                }
            }

            SFB_KeyFinancialsEntity keyFinancialsEntity = riskModelExcelEntity.SFB_KeyFinancialsEntity;
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(keyFinancialsEntity);

            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null && property.DisplayName != string.Empty)
                    {
                        obj = keyFinancialsEntity.GetType().GetProperty(property.Name).GetValue(keyFinancialsEntity, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Key Financials: " + property.DisplayName + " is mandatory");
                        }
                        else
                        {
                            if (property.DisplayName == "Period of Year End" || property.DisplayName == "Period of Year End2")
                            {
                                string value = obj.ToString();
                                DateTime periodDate = Convert.ToDateTime(value);
                                DateTime curDate = DateTime.Now;
                                if (periodDate > curDate)
                                {
                                    sbQuery.AppendLine("Key Financials: " + property.DisplayName + " cannot be greater than current date");
                                }
                            }
                        }
                    }
                }
                catch { }
            }

            SFB_SubjectiveParametersEntity subjectiveParametersEntity = riskModelExcelEntity.SFB_SubjectiveParametersEntity;
            properties = TypeDescriptor.GetProperties(subjectiveParametersEntity);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = subjectiveParametersEntity.GetType().GetProperty(property.Name).GetValue(subjectiveParametersEntity, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Subjective Parameters: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            SFB_IndustryExpsoureEntity industryExpsoureEntity = riskModelExcelEntity.SFB_IndustryExpsoureEntity;
            properties = TypeDescriptor.GetProperties(industryExpsoureEntity);
            foreach (PropertyDescriptor property in properties)
            {
                try
                {
                    if (property != null)
                    {
                        obj = industryExpsoureEntity.GetType().GetProperty(property.Name).GetValue(industryExpsoureEntity, null);
                        if (obj == null || obj.ToString() == string.Empty)
                        {
                            sbQuery.AppendLine("Industry Exposure: " + property.DisplayName + " is mandatory");
                        }
                    }
                }
                catch { }
            }

            if (sbQuery.Length > 0)
            {
                message = sbQuery.ToString();
                return false;
            }
            return true;
        }


    }
}

//public ActionResult ComputeOutputDetails(int companyId)
//{
//    int userId = SessionValue.UserID;
//    int roleId = SessionValue.RoleID;
//    CompanyDAL companyDAL = new CompanyDAL();
//    SFBDAL sfbDAL = new SFBDAL();

//    bool status = false;
//    string message = string.Empty;
//    string companyName = companyDAL.GetCompanyNameByID(companyId);
//    int detailsID = companyDAL.GetCompanyBasicDetailsID(companyId);
//    if (detailsID == 0)
//    {
//        message = "Please save the entry as draft first";
//        return Json(new
//        {
//            Status = false,
//            Message = message,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetSFB_InputTemplateFilePath()));
//    string userTemplateFilePath = Server.MapPath(string.Format("~{0}//OutputReport_{1}_{2}.xlsx", ConfigManager.GetOutputTemplateCopyFilePath(), companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss")));

//    System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
//    string fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));

//    try
//    {
//        List<SFB_OutputDetailsEntity> sfb_OutputDetailsEntity = new List<SFB_OutputDetailsEntity>();
//        status = sfbDAL.Get_OutputDetailsFromFrontEnd_InterOp(detailsID, userTemplateFilePath);
//        // SaveExcel(userTemplateFilePath, newuserTemplateFilePath);
//        sfb_OutputDetailsEntity = sfbDAL.GetOutputFromExcel(userTemplateFilePath, fileName, "Output NHB$", userId);
//        if (userTemplateFilePath != null)
//        {
//            if (System.IO.File.Exists(userTemplateFilePath))
//            {
//                System.IO.File.Delete(userTemplateFilePath);
//            }
//        }
//        return Json(new
//        {
//            Status = status,
//            Message = message,
//            Result = sfb_OutputDetailsEntity,
//        }, JsonRequestBehavior.AllowGet);
//    }
//    catch (Exception ex)
//    {
//        ErrorLogger.LogError(ex, this);
//        message = ex.ToString();
//    }
//    return Json(new
//    {
//        Status = false,
//        Message = message,
//        //Result = riskModelExcelEntity,
//    }, JsonRequestBehavior.AllowGet);
//}
