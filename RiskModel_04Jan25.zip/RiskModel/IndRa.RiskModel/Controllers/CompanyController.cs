﻿using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.DataAccess;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using IndRa.RiskModel.Models.Company;
using System;
using System.IO;
using System.Linq;
using System.Web.Mvc;

namespace IndRa.RiskModel.Controllers
{
    public class CompanyController : Controller
    {
        [HttpGet]
        [Authorize]
        public ActionResult CompanyList()
        {
            ViewBag.ModelList = DropDownValue.GetModelList();
            ViewBag.AnalystList = DropDownValue.GetAnalystList();

            return View();
        }

        [Authorize]
        [HttpGet]
        public ActionResult GetAllCompanyList()
        {
            try
            {
                CompanyDAL companyDAL = new CompanyDAL();
                var getAllCompaniesList = companyDAL.GetCompaniesList().ToList();
                var companyList = getAllCompaniesList.Select((company, index) => new
                {
                    SrNo = index + 1,
                    CompanyId = company.CompanyId,
                    CompanyName = company.CompanyName,
                    ModelId = company.ModelId,
                    ModelName = company.ModelName,
                    AssignedAnalystId = company.AssignedAnalystId,
                    AssignedAnalystName = company.AssignedAnalystName,
                    PanCard = company.PanCard,

                    //CategoryName = company.mod.ToString(),
                    Edit = Url.Action("EditCompany", "Company", new { CompanyId = company.CompanyId }),
                    Delete = Url.Action("DeleteCompany", "Company", new { CompanyId = company.CompanyId })
                }).ToList();

                return Json(new
                {
                    data = companyList
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return null;
            }
        }

        [HttpGet]
        [Authorize]
        public ActionResult CreateCompany()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        public JsonResult CreateCompany(CreateCompanyModel createCompanyModel)
        {
            int userID = SessionValue.UserID;
            string message = string.Empty;
            string responseMessage = string.Empty;
            bool status = false;
            DateTime? nullableDate = null;
            bool sendMail = false;

            CompanyDAL companyDAL = new CompanyDAL();
            try
            {
                if (ModelState.IsValid)
                {
                    CompanyEntity companyEntity = new CompanyEntity
                    {
                        CompanyName = createCompanyModel.CompanyName,
                        CreatedBy = userID,
                        ModelId = createCompanyModel.ModelId,
                        AssignedAnalystId = createCompanyModel.AssignedAnalystId,
                        AssignedDate = createCompanyModel.AssignedAnalystId.HasValue ? DateTime.Now : nullableDate,
                        PanCard = createCompanyModel.PanCard,
                        InActive = true,
                        CreatedDateTime = DateTime.Now,
                        UpdatedBy = userID,
                        UpdatedDateTime = DateTime.Now
                    };
                    status = companyDAL.CheckDuplicatePANCard(companyEntity);
                    if (status == true)
                    {
                        message = "Duplicate PAN Card No.";
                        status = false;
                    }
                    else
                    {
                        status = companyDAL.CreateCompany(companyEntity);
                    }
                }
                if (status == true)
                {
                    UserDAL userDAL = new UserDAL();
                    Email.SendMail(userDAL.GetUserEmailAddress(createCompanyModel.AssignedAnalystId.Value), createCompanyModel.CompanyName, (int)EmailTemplateEnum.AssignedEntityTemplate);
                    message = "Company Added Successfully.";
                }
                else
                {
                    if (message == string.Empty)
                    {
                        message = "Error occurred in adding Company.";
                    }
                }
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception);
                ViewBag.Error = exception.Message;
            }

            return Json(new
            {
                Status = status,
                Message = message,
            }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpGet]
        public ActionResult EditCompany(int CompanyId)
        {
            try
            {
                CompanyDAL companyDAL = new CompanyDAL();
                var company = companyDAL.GetCompanyByID(CompanyId);
                EditCompanyModel editCompanyModel = new EditCompanyModel
                {
                    CompanyId = company.CompanyId,
                    CompanyName = company.CompanyName,
                };

                return Json(new
                {
                    data = editCompanyModel
                }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
        }

        [Authorize]
        [HttpPost]
        public JsonResult EditCompany(EditCompanyModel editCompanyModel)
        {
            bool status = false;
            string message = string.Empty;
            int userID = SessionValue.UserID;
            DateTime? asssignedDate = null;
            bool sendMail = false;
            CompanyDAL companyDAL = new CompanyDAL();
            int? previousAssignedAnalystID;
            try
            {
                if (editCompanyModel.AssignedAnalystId.HasValue)
                {
                    previousAssignedAnalystID = companyDAL.GetAssignedAnalystID(editCompanyModel.CompanyId);
                    if (previousAssignedAnalystID.HasValue)
                    {
                        if (editCompanyModel.AssignedAnalystId.Value != previousAssignedAnalystID.Value)
                        {
                            asssignedDate = DateTime.Now;
                            sendMail = true;
                        }
                        if (editCompanyModel.AssignedAnalystId.Value == previousAssignedAnalystID.Value)
                        {
                            asssignedDate = companyDAL.GetAssignedAnalystDate(editCompanyModel.CompanyId);
                        }
                    }
                    else
                    {
                        asssignedDate = DateTime.Now;
                        sendMail = true;
                    }
                }

                CompanyEntity companyEntity = new CompanyEntity
                {
                    CompanyId = editCompanyModel.CompanyId,
                    CompanyName = editCompanyModel.CompanyName,
                    ModelId = editCompanyModel.ModelId,
                    AssignedAnalystId = editCompanyModel.AssignedAnalystId,
                    PanCard = editCompanyModel.PanCard,
                    AssignedDate = asssignedDate,
                    UpdatedBy = userID,
                    UpdatedDateTime = DateTime.Now
                };
                status = companyDAL.CheckDuplicatePANCard(companyEntity);
                if (status == true)
                {
                    message = "Duplicate Company Name.";
                    status = false;
                }
                else
                {
                    status = companyDAL.UpdateCompanyDetails(companyEntity);
                }


                if (status == true)
                {
                    message = "Company Updated Successfully.";
                    if (sendMail == true)
                    {
                        UserDAL userDAL = new UserDAL();
                        bool success = Email.SendMail(userDAL.GetUserEmailAddress(companyEntity.AssignedAnalystId.Value), companyEntity.CompanyName, (int)EmailTemplateEnum.AssignedEntityTemplate);
                        if (success == true)
                        {
                            //Success
                            companyDAL.UpdateAnalystMailSent(companyEntity.CompanyId, "Y");
                        }
                        else 
                        {
                            //Failed
                            companyDAL.UpdateAnalystMailSent(companyEntity.CompanyId, "F");
                        }
                    }
                }
                else
                {
                    if (message == string.Empty)
                    {
                        message = "Error occurred in updating Company.";
                    }
                }
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception);
                ViewBag.Error = exception.Message;
                message = exception.Message;
            }
            return Json(new
            {
                Status = status,
                Message = message,
            }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult DeleteCompany(int companyId)
        {
            bool result = false;
            string message = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                CompanyDAL companyDAL = new CompanyDAL();
                result = companyDAL.DeleteCompany(companyId, userID);
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception);
                ViewBag.Error = exception.Message;
            }

            return Json(new { result = result }, JsonRequestBehavior.AllowGet);
        }

        //[HttpGet]
        //public JsonResult CheckIfCompanyExistAndGetDetails(int CompanyId)
        //{
        //    int userId = SessionValue.UserID;
        //    bool status = false;
        //    string message = string.Empty;
        //    CompanyDAL companyDAL = new CompanyDAL();
        //    RiskModelExcelEntity riskModelExcelEntity = new RiskModelExcelEntity();
        //    NHB_BalanceSheet_Liabilities nHB_BalanceSheet_Liabilities;
        //    NHB_BalanceSheet_Liabilities_Final nHB_BalanceSheet_Liabilities_Final;
        //    NHB_BalanceSheet_Assets nHB_BalanceSheet_Assets;
        //    NHB_BalanceSheet_Assets_Final nHB_BalanceSheet_Assets_Final;
        //    NHB_ContingentLiabilities nHB_ContingentLiabilities;
        //    NHB_ContingentLiabilities_Final nHB_ContingentLiabilities_Final;
        //    NHB_OtherBalanceSheet_Disclosures nHB_OtherBalanceSheet_Disclosures;
        //    NHB_OtherBalanceSheet_Disclosures_Final nHB_OtherBalanceSheet_Disclosures_Final;
        //    NHB_ProfitAndLossStatement nHB_ProfitAndLossStatement;
        //    NHB_ProfitAndLossStatement_Final nHB_ProfitAndLossStatement_Final;
        //    NHB_ALMStatementLatest nHB_ALMStatementLatest;
        //    NHB_ALMStatementLatest_Final nHB_ALMStatementLatest_Final;
        //    NHB_KeyRatio nHB_KeyRatio;
        //    NHB_KeyRatio_Final nHB_KeyRatio_Final;
        //    NHB_IndustryRiskInputs nHB_IndustryRiskInputs;
        //    NHB_IndustryRiskInputs_Final nHB_IndustryRiskInputs_Final;
        //    NHB_BusinessRiskInputs nHB_BusinessRiskInputs;
        //    NHB_BusinessRiskInputs_Final nHB_BusinessRiskInputs_Final;
        //    NHB_FinancialRiskInputs nHB_FinancialRiskInputs;
        //    NHB_FinancialRiskInputs_Final nHB_FinancialRiskInputs_Final;
        //    NHB_ManagementRiskInputs nHB_ManagementRiskInputs;
        //    NHB_ManagementRiskInputs_Final nHB_ManagementRiskInputs_Final;
        //    NHB_NotchUpCriteriaInput nHB_NotchUpCriteriaInput;
        //    NHB_NotchUpCriteriaInput_Final nHB_NotchUpCriteriaInput_Final;
        //    try
        //    {
        //        NHB_Details nHB_Details = companyDAL.GetCompanyBasicDetails(CompanyId);
        //        if (nHB_Details != null)
        //        {
        //            if (nHB_Details.DetailsId != 0)
        //            {
        //                if (!nHB_Details.IsFinal.Value)
        //                {
        //                    nHB_BalanceSheet_Liabilities = companyDAL.GetBalanceSheetLiabilitiesDetails(nHB_Details.DetailsId);
        //                    nHB_BalanceSheet_Assets = companyDAL.GetBalanceSheetAssetsDetails(nHB_Details.DetailsId);
        //                    nHB_ContingentLiabilities = companyDAL.GetContingentLiabilitiesDetails(nHB_Details.DetailsId);
        //                    nHB_OtherBalanceSheet_Disclosures = companyDAL.GetOtherBalanceSheet_DisclosuresDetails(nHB_Details.DetailsId);
        //                    nHB_ProfitAndLossStatement = companyDAL.GetProfitAndLossStatementDetails(nHB_Details.DetailsId);
        //                    nHB_ALMStatementLatest = companyDAL.GetALMStatmentLatestDetails(nHB_Details.DetailsId);
        //                    nHB_KeyRatio = companyDAL.GetKeyRatioDetails(nHB_Details.DetailsId);
        //                    nHB_IndustryRiskInputs = companyDAL.GetIndustryRiskInputsDetails(nHB_Details.DetailsId);
        //                    nHB_BusinessRiskInputs = companyDAL.GetBusinessRiskInputsDetails(nHB_Details.DetailsId);
        //                    nHB_FinancialRiskInputs = companyDAL.GetFinancialRiskInputsDetails(nHB_Details.DetailsId);
        //                    nHB_ManagementRiskInputs = companyDAL.GetManagementRiskInputsDetails(nHB_Details.DetailsId);
        //                    nHB_NotchUpCriteriaInput = companyDAL.GetNotchUpCriteriaInputsDetails(nHB_Details.DetailsId);

        //                    if (nHB_BalanceSheet_Liabilities != null && nHB_BalanceSheet_Assets != null && nHB_ContingentLiabilities != null && nHB_OtherBalanceSheet_Disclosures != null && nHB_ProfitAndLossStatement != null && nHB_ALMStatementLatest != null
        //                        && nHB_KeyRatio != null && nHB_IndustryRiskInputs != null && nHB_BusinessRiskInputs != null && nHB_FinancialRiskInputs != null && nHB_ManagementRiskInputs != null && nHB_NotchUpCriteriaInput != null)
        //                    {
        //                        riskModelExcelEntity = new RiskModelExcelEntity()
        //                        {
        //                            CompanyId = nHB_Details.CompanyId,
        //                            CurrencyUnits = nHB_Details.CurrencyUnits,
        //                            DateOfInput = nHB_Details.DateOfInput,
        //                            DetailsId = nHB_Details.DetailsId,
        //                            FinancialYearEndingDate = nHB_Details.FinancialYearEndingDate.Value.ToString(),
        //                            LocationId = nHB_Details.LocationId,
        //                            ParentCompanyIsExist = (nHB_Details.ParentCompanyIsExist == true) ? "Yes" : "No",
        //                            ParentCompanyId = companyDAL.GetCompanyIDByCompanyName(nHB_Details.ParentCompanyName, userId),
        //                            ParentRating = nHB_Details.ParentRating,
        //                            #region NHB_BalanceSheets_Liabilitiess
        //                            NHB_BalanceSheets_Liabilities = new NHB_BalanceSheets_Liabilitiess()
        //                            {
        //                                PeriodEndingDate1_Liabilities = nHB_BalanceSheet_Liabilities.PeriodEndingDate1,
        //                                PeriodEndingDate2_Liabilities = nHB_BalanceSheet_Liabilities.PeriodEndingDate2,
        //                                PeriodEndingDate3_Liabilities = nHB_BalanceSheet_Liabilities.PeriodEndingDate3,
        //                                PeriodEndingDate4_Liabilities = nHB_BalanceSheet_Liabilities.PeriodEndingDate4,
        //                                LiabilitiesType1 = nHB_BalanceSheet_Liabilities.LiabilitiesType1,
        //                                LiabilitiesType2 = nHB_BalanceSheet_Liabilities.LiabilitiesType2,
        //                                LiabilitiesType3 = nHB_BalanceSheet_Liabilities.LiabilitiesType3,
        //                                LiabilitiesType4 = nHB_BalanceSheet_Liabilities.LiabilitiesType4,
        //                                CapitalPEOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CapitalPEOutput1)),
        //                                CapitalPEOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CapitalPEOutput2)),
        //                                CapitalPEOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CapitalPEOutput3)),
        //                                CapitalPEOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CapitalPEOutput4)),
        //                                CalledAndPaid_Up1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CalledAndPaid_Up1)),
        //                                CalledAndPaid_Up2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CalledAndPaid_Up2)),
        //                                CalledAndPaid_Up3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CalledAndPaid_Up3)),
        //                                CalledAndPaid_Up4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CalledAndPaid_Up4)),
        //                                EquityShareWarrant1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.EquityShareWarrant1)),
        //                                EquityShareWarrant2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.EquityShareWarrant2)),
        //                                EquityShareWarrant3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.EquityShareWarrant3)),
        //                                EquityShareWarrant4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.EquityShareWarrant4)),
        //                                ReservesAndSurplusOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.ReservesAndSurplusOutput1)),
        //                                ReservesAndSurplusOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.ReservesAndSurplusOutput2)),
        //                                ReservesAndSurplusOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.ReservesAndSurplusOutput3)),
        //                                ReservesAndSurplusOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.ReservesAndSurplusOutput4)),
        //                                CapitalReserves1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CapitalReserves1)),
        //                                CapitalReserves2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CapitalReserves2)),
        //                                CapitalReserves3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CapitalReserves3)),
        //                                CapitalReserves4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CapitalReserves4)),
        //                                GeneralReserves1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.GeneralReserves1)),
        //                                GeneralReserves2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.GeneralReserves2)),
        //                                GeneralReserves3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.GeneralReserves3)),
        //                                GeneralReserves4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.GeneralReserves4)),
        //                                SharePremium1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.SharePremium1)),
        //                                SharePremium2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.SharePremium2)),
        //                                SharePremium3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.SharePremium3)),
        //                                SharePremium4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.SharePremium4)),
        //                                SpecialPurposeReserves1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.SpecialPurposeReserves1)),
        //                                SpecialPurposeReserves2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.SpecialPurposeReserves2)),
        //                                SpecialPurposeReserves3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.SpecialPurposeReserves3)),
        //                                SpecialPurposeReserves4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.SpecialPurposeReserves4)),
        //                                OtherReserves1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.OtherReserves1)),
        //                                OtherReserves2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.OtherReserves2)),
        //                                OtherReserves3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.OtherReserves3)),
        //                                OtherReserves4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.OtherReserves4)),
        //                                RevenueReserves1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.RevenueReserves1)),
        //                                RevenueReserves2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.RevenueReserves2)),
        //                                RevenueReserves3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.RevenueReserves3)),
        //                                RevenueReserves4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.RevenueReserves4)),
        //                                IntangibleAssets1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.IntangibleAssets1)),
        //                                IntangibleAssets2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.IntangibleAssets2)),
        //                                IntangibleAssets3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.IntangibleAssets3)),
        //                                IntangibleAssets4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.IntangibleAssets4)),
        //                                BorrowingsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.BorrowingsOutput1)),
        //                                BorrowingsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.BorrowingsOutput2)),
        //                                BorrowingsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.BorrowingsOutput3)),
        //                                BorrowingsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.BorrowingsOutput4)),
        //                                CommercialPaper1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CommercialPaper1)),
        //                                CommercialPaper2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CommercialPaper2)),
        //                                CommercialPaper3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CommercialPaper3)),
        //                                CommercialPaper4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CommercialPaper4)),
        //                                InterCorporateDeposits1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.InterCorporateDeposits1)),
        //                                InterCorporateDeposits2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.InterCorporateDeposits2)),
        //                                InterCorporateDeposits3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.InterCorporateDeposits3)),
        //                                InterCorporateDeposits4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.InterCorporateDeposits4)),
        //                                CallAndNoticeMoney1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CallAndNoticeMoney1)),
        //                                CallAndNoticeMoney2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CallAndNoticeMoney2)),
        //                                CallAndNoticeMoney3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CallAndNoticeMoney3)),
        //                                CallAndNoticeMoney4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.CallAndNoticeMoney4)),
        //                                OtherBorrowings1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.OtherBorrowings1)),
        //                                OtherBorrowings2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.OtherBorrowings2)),
        //                                OtherBorrowings3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.OtherBorrowings3)),
        //                                OtherBorrowings4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.OtherBorrowings4)),
        //                                LongTermBorrowingsWithinYear1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsWithinYear1)),
        //                                LongTermBorrowingsWithinYear2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsWithinYear2)),
        //                                LongTermBorrowingsWithinYear3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsWithinYear3)),
        //                                LongTermBorrowingsWithinYear4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsWithinYear4)),
        //                                PublicDeposits1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.PublicDeposits1)),
        //                                PublicDeposits2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.PublicDeposits2)),
        //                                PublicDeposits3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.PublicDeposits3)),
        //                                PublicDeposits4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.PublicDeposits4)),
        //                                ShortTermBorrowings1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.ShortTermBorrowings1)),
        //                                ShortTermBorrowings2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.ShortTermBorrowings2)),
        //                                ShortTermBorrowings3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.ShortTermBorrowings3)),
        //                                ShortTermBorrowings4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.ShortTermBorrowings4)),
        //                                LongTermBorrowingsFloatingNHB1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFloatingNHB1)),
        //                                LongTermBorrowingsFloatingNHB2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFloatingNHB2)),
        //                                LongTermBorrowingsFloatingNHB3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFloatingNHB3)),
        //                                LongTermBorrowingsFloatingNHB4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFloatingNHB4)),
        //                                LongTermBorrowingsFloatingOthers1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFloatingOthers1)),
        //                                LongTermBorrowingsFloatingOthers2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFloatingOthers2)),
        //                                LongTermBorrowingsFloatingOthers3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFloatingOthers3)),
        //                                LongTermBorrowingsFloatingOthers4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFloatingOthers4)),
        //                                LongTermBorrowingsFixedNHB1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFixedNHB1)),
        //                                LongTermBorrowingsFixedNHB2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFixedNHB2)),
        //                                LongTermBorrowingsFixedNHB3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFixedNHB3)),
        //                                LongTermBorrowingsFixedNHB4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFixedNHB4)),
        //                                LongTermBorrowingsFixedOthers1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFixedOthers1)),
        //                                LongTermBorrowingsFixedOthers2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFixedOthers2)),
        //                                LongTermBorrowingsFixedOthers3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFixedOthers3)),
        //                                LongTermBorrowingsFixedOthers4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermBorrowingsFixedOthers4)),
        //                                UnsecuredLongTermBorrowings1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.UnsecuredLongTermBorrowings1)),
        //                                UnsecuredLongTermBorrowings2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.UnsecuredLongTermBorrowings2)),
        //                                UnsecuredLongTermBorrowings3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.UnsecuredLongTermBorrowings3)),
        //                                UnsecuredLongTermBorrowings4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.UnsecuredLongTermBorrowings4)),
        //                                LongTermForeignCurrency1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermForeignCurrency1)),
        //                                LongTermForeignCurrency2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermForeignCurrency2)),
        //                                LongTermForeignCurrency3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermForeignCurrency3)),
        //                                LongTermForeignCurrency4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LongTermForeignCurrency4)),
        //                                BorrowingsFromRelatedParties1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.BorrowingsFromRelatedParties1)),
        //                                BorrowingsFromRelatedParties2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.BorrowingsFromRelatedParties2)),
        //                                BorrowingsFromRelatedParties3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.BorrowingsFromRelatedParties3)),
        //                                BorrowingsFromRelatedParties4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.BorrowingsFromRelatedParties4)),
        //                                HybridInstruments1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.HybridInstruments1)),
        //                                HybridInstruments2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.HybridInstruments2)),
        //                                HybridInstruments3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.HybridInstruments3)),
        //                                HybridInstruments4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities.HybridInstruments4)),
        //                                LiabilitiesAndCapitalTotalOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LiabilitiesAndCapitalTotalOutput1)),
        //                                LiabilitiesAndCapitalTotalOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LiabilitiesAndCapitalTotalOutput2)),
        //                                LiabilitiesAndCapitalTotalOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LiabilitiesAndCapitalTotalOutput3)),
        //                                LiabilitiesAndCapitalTotalOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities.LiabilitiesAndCapitalTotalOutput4)),

        //                            },
        //                            #endregion
        //                            #region NHB_BalanceSheet_Assetss
        //                            NHB_BalanceSheet_Assets = new NHB_BalanceSheet_Assetss()
        //                            {
        //                                PeriodEndingDate1_Assets = nHB_BalanceSheet_Assets.PeriodEndingDate1,
        //                                PeriodEndingDate2_Assets = nHB_BalanceSheet_Assets.PeriodEndingDate2,
        //                                PeriodEndingDate3_Assets = nHB_BalanceSheet_Assets.PeriodEndingDate3,
        //                                PeriodEndingDate4_Assets = nHB_BalanceSheet_Assets.PeriodEndingDate4,
        //                                FixedAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.FixedAssetsOutput1)),
        //                                FixedAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.FixedAssetsOutput2)),
        //                                FixedAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.FixedAssetsOutput3)),
        //                                FixedAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.FixedAssetsOutput4)),
        //                                OwnedNetBlock1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OwnedNetBlock1)),
        //                                OwnedNetBlock2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OwnedNetBlock2)),
        //                                OwnedNetBlock3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OwnedNetBlock3)),
        //                                OwnedNetBlock4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OwnedNetBlock4)),
        //                                LeasedNetBlock1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.LeasedNetBlock1)),
        //                                LeasedNetBlock2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.LeasedNetBlock2)),
        //                                LeasedNetBlock3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.LeasedNetBlock3)),
        //                                LeasedNetBlock4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.LeasedNetBlock4)),
        //                                CapitalWorkInProgress1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CapitalWorkInProgress1)),
        //                                CapitalWorkInProgress2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CapitalWorkInProgress2)),
        //                                CapitalWorkInProgress3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CapitalWorkInProgress3)),
        //                                CapitalWorkInProgress4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CapitalWorkInProgress4)),
        //                                InvestmentsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsOutput1)),
        //                                InvestmentsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsOutput2)),
        //                                InvestmentsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsOutput3)),
        //                                InvestmentsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsOutput4)),
        //                                CentralGovernmentSecuritiesQuoted1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted1)),
        //                                CentralGovernmentSecuritiesQuoted2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted2)),
        //                                CentralGovernmentSecuritiesQuoted3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted3)),
        //                                CentralGovernmentSecuritiesQuoted4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted4)),
        //                                CentralGovernmentDebtUnquoted1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted1)),
        //                                CentralGovernmentDebtUnquoted2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted2)),
        //                                CentralGovernmentDebtUnquoted3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted3)),
        //                                CentralGovernmentDebtUnquoted4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted4)),
        //                                StateGovernmentSecurities1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.StateGovernmentSecurities1)),
        //                                StateGovernmentSecurities2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.StateGovernmentSecurities2)),
        //                                StateGovernmentSecurities3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.StateGovernmentSecurities3)),
        //                                StateGovernmentSecurities4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.StateGovernmentSecurities4)),
        //                                GuaranteedPublicSectorBonds1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds1)),
        //                                GuaranteedPublicSectorBonds2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds2)),
        //                                GuaranteedPublicSectorBonds3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds3)),
        //                                GuaranteedPublicSectorBonds4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds4)),
        //                                OtherPublicSectorBonds1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherPublicSectorBonds1)),
        //                                OtherPublicSectorBonds2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherPublicSectorBonds2)),
        //                                OtherPublicSectorBonds3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherPublicSectorBonds3)),
        //                                OtherPublicSectorBonds4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherPublicSectorBonds4)),
        //                                PrivateSectorBondsInvestmentGrade1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade1)),
        //                                PrivateSectorBondsInvestmentGrade2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade2)),
        //                                PrivateSectorBondsInvestmentGrade3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade3)),
        //                                PrivateSectorBondsInvestmentGrade4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade4)),
        //                                OtherPrivateSectorBonds1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherPrivateSectorBonds1)),
        //                                OtherPrivateSectorBonds2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherPrivateSectorBonds2)),
        //                                OtherPrivateSectorBonds3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherPrivateSectorBonds3)),
        //                                OtherPrivateSectorBonds4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherPrivateSectorBonds4)),
        //                                MutualFunds1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.MutualFunds1)),
        //                                MutualFunds2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.MutualFunds2)),
        //                                MutualFunds3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.MutualFunds3)),
        //                                MutualFunds4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.MutualFunds4)),
        //                                ListedEquity1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ListedEquity1)),
        //                                ListedEquity2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ListedEquity2)),
        //                                ListedEquity3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ListedEquity3)),
        //                                ListedEquity4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ListedEquity4)),
        //                                UnlistedEquity1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.UnlistedEquity1)),
        //                                UnlistedEquity2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.UnlistedEquity2)),
        //                                UnlistedEquity3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.UnlistedEquity3)),
        //                                UnlistedEquity4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.UnlistedEquity4)),
        //                                InvestmentsInParentAndSubsidiariesAndAssociates1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates1)),
        //                                InvestmentsInParentAndSubsidiariesAndAssociates2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates2)),
        //                                InvestmentsInParentAndSubsidiariesAndAssociates3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates3)),
        //                                InvestmentsInParentAndSubsidiariesAndAssociates4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates4)),
        //                                CurrentAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.CurrentAssetsOutput1)),
        //                                CurrentAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.CurrentAssetsOutput2)),
        //                                CurrentAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.CurrentAssetsOutput3)),
        //                                CurrentAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.CurrentAssetsOutput4)),
        //                                HirePurchaseReceivables1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.HirePurchaseReceivables1)),
        //                                HirePurchaseReceivables2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.HirePurchaseReceivables2)),
        //                                HirePurchaseReceivables3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.HirePurchaseReceivables3)),
        //                                HirePurchaseReceivables4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.HirePurchaseReceivables4)),
        //                                FinanceLeases1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.FinanceLeases1)),
        //                                FinanceLeases2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.FinanceLeases2)),
        //                                FinanceLeases3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.FinanceLeases3)),
        //                                FinanceLeases4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.FinanceLeases4)),
        //                                SecuredLoans1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.SecuredLoans1)),
        //                                SecuredLoans2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.SecuredLoans2)),
        //                                SecuredLoans3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.SecuredLoans3)),
        //                                SecuredLoans4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.SecuredLoans4)),
        //                                UnsecuredLoans1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.UnsecuredLoans1)),
        //                                UnsecuredLoans2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.UnsecuredLoans2)),
        //                                UnsecuredLoans3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.UnsecuredLoans3)),
        //                                UnsecuredLoans4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.UnsecuredLoans4)),
        //                                Debtors1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.Debtors1)),
        //                                Debtors2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.Debtors2)),
        //                                Debtors3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.Debtors3)),
        //                                Debtors4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.Debtors4)),
        //                                BillsDiscounted1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.BillsDiscounted1)),
        //                                BillsDiscounted2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.BillsDiscounted2)),
        //                                BillsDiscounted3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.BillsDiscounted3)),
        //                                BillsDiscounted4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.BillsDiscounted4)),
        //                                OtherInterestBearingLoans1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherInterestBearingLoans1)),
        //                                OtherInterestBearingLoans2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherInterestBearingLoans2)),
        //                                OtherInterestBearingLoans3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherInterestBearingLoans3)),
        //                                OtherInterestBearingLoans4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherInterestBearingLoans4)),
        //                                LoansToRelatedParties1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.LoansToRelatedParties1)),
        //                                LoansToRelatedParties2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.LoansToRelatedParties2)),
        //                                LoansToRelatedParties3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.LoansToRelatedParties3)),
        //                                LoansToRelatedParties4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.LoansToRelatedParties4)),
        //                                CashAndBank1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CashAndBank1)),
        //                                CashAndBank2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CashAndBank2)),
        //                                CashAndBank3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CashAndBank3)),
        //                                CashAndBank4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.CashAndBank4)),
        //                                AdvancesPaid1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.AdvancesPaid1)),
        //                                AdvancesPaid2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.AdvancesPaid2)),
        //                                AdvancesPaid3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.AdvancesPaid3)),
        //                                AdvancesPaid4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.AdvancesPaid4)),
        //                                OtherCurrentAssets1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherCurrentAssets1)),
        //                                OtherCurrentAssets2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherCurrentAssets2)),
        //                                OtherCurrentAssets3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherCurrentAssets3)),
        //                                OtherCurrentAssets4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherCurrentAssets4)),
        //                                InvestmentsInSecuritisedAssets1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets1)),
        //                                InvestmentsInSecuritisedAssets2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets2)),
        //                                InvestmentsInSecuritisedAssets3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets3)),
        //                                InvestmentsInSecuritisedAssets4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets4)),
        //                                CurrentLiabilitiesOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.CurrentLiabilitiesOutput1)),
        //                                CurrentLiabilitiesOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.CurrentLiabilitiesOutput2)),
        //                                CurrentLiabilitiesOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.CurrentLiabilitiesOutput3)),
        //                                CurrentLiabilitiesOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.CurrentLiabilitiesOutput4)),
        //                                InterestAccruedButNotDue1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InterestAccruedButNotDue1)),
        //                                InterestAccruedButNotDue2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InterestAccruedButNotDue2)),
        //                                InterestAccruedButNotDue3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InterestAccruedButNotDue3)),
        //                                InterestAccruedButNotDue4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.InterestAccruedButNotDue4)),
        //                                DepositsReceived1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.DepositsReceived1)),
        //                                DepositsReceived2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.DepositsReceived2)),
        //                                DepositsReceived3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.DepositsReceived3)),
        //                                DepositsReceived4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.DepositsReceived4)),
        //                                AdvancesReceived1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.AdvancesReceived1)),
        //                                AdvancesReceived2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.AdvancesReceived2)),
        //                                AdvancesReceived3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.AdvancesReceived3)),
        //                                AdvancesReceived4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.AdvancesReceived4)),
        //                                OtherCurrentLiabilities1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherCurrentLiabilities1)),
        //                                OtherCurrentLiabilities2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherCurrentLiabilities2)),
        //                                OtherCurrentLiabilities3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherCurrentLiabilities3)),
        //                                OtherCurrentLiabilities4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherCurrentLiabilities4)),
        //                                DeferredtaxLiability1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.DeferredtaxLiability1)),
        //                                DeferredtaxLiability2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.DeferredtaxLiability2)),
        //                                DeferredtaxLiability3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.DeferredtaxLiability3)),
        //                                DeferredtaxLiability4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.DeferredtaxLiability4)),
        //                                ReceivablesSecuritised1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ReceivablesSecuritised1)),
        //                                ReceivablesSecuritised2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ReceivablesSecuritised2)),
        //                                ReceivablesSecuritised3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ReceivablesSecuritised3)),
        //                                ReceivablesSecuritised4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ReceivablesSecuritised4)),
        //                                ProvisionsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionsOutput1)),
        //                                ProvisionsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionsOutput2)),
        //                                ProvisionsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionsOutput3)),
        //                                ProvisionsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionsOutput4)),
        //                                ProvisionForLoanLosses1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForLoanLosses1)),
        //                                ProvisionForLoanLosses2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForLoanLosses2)),
        //                                ProvisionForLoanLosses3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForLoanLosses3)),
        //                                ProvisionForLoanLosses4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForLoanLosses4)),
        //                                ProvisionForDoubtfulDebtors1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors1)),
        //                                ProvisionForDoubtfulDebtors2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors2)),
        //                                ProvisionForDoubtfulDebtors3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors3)),
        //                                ProvisionForDoubtfulDebtors4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors4)),
        //                                ProvisionForDepreciation1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDepreciation1)),
        //                                ProvisionForDepreciation2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDepreciation2)),
        //                                ProvisionForDepreciation3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDepreciation3)),
        //                                ProvisionForDepreciation4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDepreciation4)),
        //                                ProvisionForImpairmentofAssets1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets1)),
        //                                ProvisionForImpairmentofAssets2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets2)),
        //                                ProvisionForImpairmentofAssets3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets3)),
        //                                ProvisionForImpairmentofAssets4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets4)),
        //                                ProvisionForDividend1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDividend1)),
        //                                ProvisionForDividend2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDividend2)),
        //                                ProvisionForDividend3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDividend3)),
        //                                ProvisionForDividend4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDividend4)),
        //                                ProvisionForTaxes1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForTaxes1)),
        //                                ProvisionForTaxes2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForTaxes2)),
        //                                ProvisionForTaxes3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForTaxes3)),
        //                                ProvisionForTaxes4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForTaxes4)),
        //                                ProvisionForDeferredTaxes1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDeferredTaxes1)),
        //                                ProvisionForDeferredTaxes2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDeferredTaxes2)),
        //                                ProvisionForDeferredTaxes3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDeferredTaxes3)),
        //                                ProvisionForDeferredTaxes4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForDeferredTaxes4)),
        //                                ProvisionForExpenses1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForExpenses1)),
        //                                ProvisionForExpenses2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForExpenses2)),
        //                                ProvisionForExpenses3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForExpenses3)),
        //                                ProvisionForExpenses4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.ProvisionForExpenses4)),
        //                                OtherProvisions1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherProvisions1)),
        //                                OtherProvisions2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherProvisions2)),
        //                                OtherProvisions3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherProvisions3)),
        //                                OtherProvisions4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets.OtherProvisions4)),
        //                                NetCurrentAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.NetCurrentAssetsOutput1)),
        //                                NetCurrentAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.NetCurrentAssetsOutput2)),
        //                                NetCurrentAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.NetCurrentAssetsOutput3)),
        //                                NetCurrentAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.NetCurrentAssetsOutput4)),
        //                                TotalAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.TotalAssetsOutput1)),
        //                                TotalAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.TotalAssetsOutput2)),
        //                                TotalAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.TotalAssetsOutput3)),
        //                                TotalAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets.TotalAssetsOutput4)),
        //                                ErrorCheck1 = nHB_BalanceSheet_Assets.ErrorCheck1,
        //                                ErrorCheck2 = nHB_BalanceSheet_Assets.ErrorCheck2,
        //                                ErrorCheck3 = nHB_BalanceSheet_Assets.ErrorCheck3,
        //                                ErrorCheck4 = nHB_BalanceSheet_Assets.ErrorCheck4
        //                            },
        //                            #endregion
        //                            #region NHB_Contingent_Liabilitiess
        //                            NHB_Contingent_Liabilities = new NHB_Contingent_Liabilitiess()
        //                            {
        //                                LiabilityOnSecuritisationContracts1 = nHB_ContingentLiabilities.LiabilityOnSecuritisationContracts1,
        //                                LiabilityOnSecuritisationContracts2 = nHB_ContingentLiabilities.LiabilityOnSecuritisationContracts2,
        //                                LiabilityOnSecuritisationContracts3 = nHB_ContingentLiabilities.LiabilityOnSecuritisationContracts3,
        //                                LiabilityOnSecuritisationContracts4 = nHB_ContingentLiabilities.LiabilityOnSecuritisationContracts4,
        //                                GuaranteesGiven1 = nHB_ContingentLiabilities.GuaranteesGiven1,
        //                                GuaranteesGiven2 = nHB_ContingentLiabilities.GuaranteesGiven2,
        //                                GuaranteesGiven3 = nHB_ContingentLiabilities.GuaranteesGiven3,
        //                                GuaranteesGiven4 = nHB_ContingentLiabilities.GuaranteesGiven4,
        //                                LiabilityOnPartlyPaidInvestments1 = nHB_ContingentLiabilities.LiabilityOnPartlyPaidInvestments1,
        //                                LiabilityOnPartlyPaidInvestments2 = nHB_ContingentLiabilities.LiabilityOnPartlyPaidInvestments2,
        //                                LiabilityOnPartlyPaidInvestments3 = nHB_ContingentLiabilities.LiabilityOnPartlyPaidInvestments3,
        //                                LiabilityOnPartlyPaidInvestments4 = nHB_ContingentLiabilities.LiabilityOnPartlyPaidInvestments4,
        //                                LiabilityOnForeignExchangContracts1 = nHB_ContingentLiabilities.LiabilityOnForeignExchangContracts1,
        //                                LiabilityOnForeignExchangContracts2 = nHB_ContingentLiabilities.LiabilityOnForeignExchangContracts2,
        //                                LiabilityOnForeignExchangContracts3 = nHB_ContingentLiabilities.LiabilityOnForeignExchangContracts3,
        //                                LiabilityOnForeignExchangContracts4 = nHB_ContingentLiabilities.LiabilityOnForeignExchangContracts4,
        //                                LiabilityOnDerivativeContracts1 = nHB_ContingentLiabilities.LiabilityOnDerivativeContracts1,
        //                                LiabilityOnDerivativeContracts2 = nHB_ContingentLiabilities.LiabilityOnDerivativeContracts2,
        //                                LiabilityOnDerivativeContracts3 = nHB_ContingentLiabilities.LiabilityOnDerivativeContracts3,
        //                                LiabilityOnDerivativeContracts4 = nHB_ContingentLiabilities.LiabilityOnDerivativeContracts4,
        //                                EndorsementsAndAcceptancesAndOtherObligations1 = nHB_ContingentLiabilities.EndorsementsAndAcceptancesAndOtherObligations1,
        //                                EndorsementsAndAcceptancesAndOtherObligations2 = nHB_ContingentLiabilities.EndorsementsAndAcceptancesAndOtherObligations2,
        //                                EndorsementsAndAcceptancesAndOtherObligations3 = nHB_ContingentLiabilities.EndorsementsAndAcceptancesAndOtherObligations3,
        //                                EndorsementsAndAcceptancesAndOtherObligations4 = nHB_ContingentLiabilities.EndorsementsAndAcceptancesAndOtherObligations4,
        //                                ClaimsNotAcknowledgedAsDebts1 = nHB_ContingentLiabilities.ClaimsNotAcknowledgedAsDebts1,
        //                                ClaimsNotAcknowledgedAsDebts2 = nHB_ContingentLiabilities.ClaimsNotAcknowledgedAsDebts2,
        //                                ClaimsNotAcknowledgedAsDebts3 = nHB_ContingentLiabilities.ClaimsNotAcknowledgedAsDebts3,
        //                                ClaimsNotAcknowledgedAsDebts4 = nHB_ContingentLiabilities.ClaimsNotAcknowledgedAsDebts4,
        //                                OtherItems1 = nHB_ContingentLiabilities.OtherItems1,
        //                                OtherItems2 = nHB_ContingentLiabilities.OtherItems2,
        //                                OtherItems3 = nHB_ContingentLiabilities.OtherItems3,
        //                                OtherItems4 = nHB_ContingentLiabilities.OtherItems4
        //                            },
        //                            #endregion
        //                            #region NHB_OtherBalanceSheet_Disclosuress
        //                            NHB_OtherBalanceSheet_Disclosures = new NHB_OtherBalanceSheet_Disclosuress()
        //                            {
        //                                TierICapitalRatioPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage1),
        //                                TierICapitalRatioPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage2),
        //                                TierICapitalRatioPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage3),
        //                                TierICapitalRatioPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage4),
        //                                TierIICapitalRatioPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage1),
        //                                TierIICapitalRatioPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage2),
        //                                TierIICapitalRatioPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage3),
        //                                TierIICapitalRatioPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage4),
        //                                TotalCapitalRatioPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage1),
        //                                TotalCapitalRatioPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage2),
        //                                TotalCapitalRatioPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage3),
        //                                TotalCapitalRatioPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage4),
        //                                ThirdPartyOriginationsAndServicingPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage1),
        //                                ThirdPartyOriginationsAndServicingPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage2),
        //                                ThirdPartyOriginationsAndServicingPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage3),
        //                                ThirdPartyOriginationsAndServicingPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage4),
        //                                SecuritisedPortfolioOutstandingPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage1),
        //                                SecuritisedPortfolioOutstandingPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage2),
        //                                SecuritisedPortfolioOutstandingPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage3),
        //                                SecuritisedPortfolioOutstandingPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage4),
        //                                TotalManagedAssetsPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage1),
        //                                TotalManagedAssetsPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage2),
        //                                TotalManagedAssetsPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage3),
        //                                TotalManagedAssetsPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage4),
        //                                GrossNPAs1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.GrossNPAs1),
        //                                GrossNPAs2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.GrossNPAs2),
        //                                GrossNPAs3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.GrossNPAs3),
        //                                GrossNPAs4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.GrossNPAs4),
        //                                SpecificLossProvisionsHeld1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld1),
        //                                SpecificLossProvisionsHeld2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld2),
        //                                SpecificLossProvisionsHeld3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld3),
        //                                SpecificLossProvisionsHeld4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld4),
        //                                NetNPAs1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.NetNPAs1),
        //                                NetNPAs2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.NetNPAs2),
        //                                NetNPAs3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.NetNPAs3),
        //                                NetNPAs4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures.NetNPAs4),
        //                            },
        //                            #endregion
        //                            #region  NHB_ProfitAndLossStatement
        //                            NHB_ProfitAndLossStatements = new NHB_ProfitAndLossStatementss()
        //                            {
        //                                PeriodEndingDate1_ProfitAndLoss = nHB_ProfitAndLossStatement.PeriodEndingDate1,
        //                                PeriodEndingDate2_ProfitAndLoss = nHB_ProfitAndLossStatement.PeriodEndingDate2,
        //                                PeriodEndingDate3_ProfitAndLoss = nHB_ProfitAndLossStatement.PeriodEndingDate3,
        //                                PeriodEndingDate4_ProfitAndLoss = nHB_ProfitAndLossStatement.PeriodEndingDate4,
        //                                IncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeOutput1)),
        //                                IncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeOutput1)),
        //                                IncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeOutput1)),
        //                                IncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeOutput1)),
        //                                InterestIncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeOutput1)),
        //                                InterestIncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeOutput2)),
        //                                InterestIncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeOutput3)),
        //                                InterestIncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeOutput4)),
        //                                InterestonHousingLoansIndividuals1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestonHousingLoansIndividuals1)),
        //                                InterestonHousingLoansIndividuals2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestonHousingLoansIndividuals2)),
        //                                InterestonHousingLoansIndividuals3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestonHousingLoansIndividuals3)),
        //                                InterestonHousingLoansIndividuals4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestonHousingLoansIndividuals4)),
        //                                InterestonHousingLoansCorporateBodies1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestonHousingLoansCorporateBodies1)),
        //                                InterestonHousingLoansCorporateBodies2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestonHousingLoansCorporateBodies2)),
        //                                InterestonHousingLoansCorporateBodies3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestonHousingLoansCorporateBodies3)),
        //                                InterestonHousingLoansCorporateBodies4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestonHousingLoansCorporateBodies4)),
        //                                OtherInterestIncome1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherInterestIncome1)),
        //                                OtherInterestIncome2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherInterestIncome2)),
        //                                OtherInterestIncome3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherInterestIncome3)),
        //                                OtherInterestIncome4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherInterestIncome4)),
        //                                IncomeFromInvestmentsShortTerm1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeFromInvestmentsShortTerm1)),
        //                                IncomeFromInvestmentsShortTerm2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeFromInvestmentsShortTerm2)),
        //                                IncomeFromInvestmentsShortTerm3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeFromInvestmentsShortTerm3)),
        //                                IncomeFromInvestmentsShortTerm4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeFromInvestmentsShortTerm4)),
        //                                IncomeFromInvestmentsLongTerm1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeFromInvestmentsLongTerm1)),
        //                                IncomeFromInvestmentsLongTerm2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeFromInvestmentsLongTerm2)),
        //                                IncomeFromInvestmentsLongTerm3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeFromInvestmentsLongTerm3)),
        //                                IncomeFromInvestmentsLongTerm4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.IncomeFromInvestmentsLongTerm4)),
        //                                OtherOperatingIncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherOperatingIncomeOutput1)),
        //                                OtherOperatingIncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherOperatingIncomeOutput2)),
        //                                OtherOperatingIncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherOperatingIncomeOutput3)),
        //                                OtherOperatingIncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherOperatingIncomeOutput4)),
        //                                FeesReceived1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.FeesReceived1)),
        //                                FeesReceived2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.FeesReceived2)),
        //                                FeesReceived3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.FeesReceived3)),
        //                                FeesReceived4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.FeesReceived4)),
        //                                CommisionsAndExchangeAndBrokerage1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.CommisionsAndExchangeAndBrokerage1)),
        //                                CommisionsAndExchangeAndBrokerage2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.CommisionsAndExchangeAndBrokerage2)),
        //                                CommisionsAndExchangeAndBrokerage3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.CommisionsAndExchangeAndBrokerage3)),
        //                                CommisionsAndExchangeAndBrokerage4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.CommisionsAndExchangeAndBrokerage4)),
        //                                ProfitLossSaleInvestments1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossSaleInvestments1)),
        //                                ProfitLossSaleInvestments2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossSaleInvestments2)),
        //                                ProfitLossSaleInvestments3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossSaleInvestments3)),
        //                                ProfitLossSaleInvestments4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossSaleInvestments4)),
        //                                ProfitLossSaleAssets1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossSaleAssets1)),
        //                                ProfitLossSaleAssets2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossSaleAssets2)),
        //                                ProfitLossSaleAssets3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossSaleAssets3)),
        //                                ProfitLossSaleAssets4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossSaleAssets4)),
        //                                ProfitLossExchangeTransactions1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossExchangeTransactions1)),
        //                                ProfitLossExchangeTransactions2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossExchangeTransactions2)),
        //                                ProfitLossExchangeTransactions3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossExchangeTransactions3)),
        //                                ProfitLossExchangeTransactions4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitLossExchangeTransactions4)),
        //                                OtherServiceIncome1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherServiceIncome1)),
        //                                OtherServiceIncome2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherServiceIncome2)),
        //                                OtherServiceIncome3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherServiceIncome3)),
        //                                OtherServiceIncome4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherServiceIncome4)),
        //                                GainOnSaleOfSecuritisedAssets1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.GainOnSaleOfSecuritisedAssets1)),
        //                                GainOnSaleOfSecuritisedAssets2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.GainOnSaleOfSecuritisedAssets2)),
        //                                GainOnSaleOfSecuritisedAssets3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.GainOnSaleOfSecuritisedAssets3)),
        //                                GainOnSaleOfSecuritisedAssets4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.GainOnSaleOfSecuritisedAssets4)),
        //                                OtherNonOperatingIncome1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherNonOperatingIncome1)),
        //                                OtherNonOperatingIncome2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherNonOperatingIncome2)),
        //                                OtherNonOperatingIncome3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherNonOperatingIncome3)),
        //                                OtherNonOperatingIncome4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherNonOperatingIncome4)),
        //                                ExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ExpenseOutput1)),
        //                                ExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ExpenseOutput2)),
        //                                ExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ExpenseOutput3)),
        //                                ExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ExpenseOutput4)),
        //                                InterestExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestExpenseOutput1)),
        //                                InterestExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestExpenseOutput2)),
        //                                InterestExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestExpenseOutput3)),
        //                                InterestExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestExpenseOutput4)),
        //                                InterestOnDeposits1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestOnDeposits1)),
        //                                InterestOnDeposits2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestOnDeposits2)),
        //                                InterestOnDeposits3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestOnDeposits3)),
        //                                InterestOnDeposits4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestOnDeposits4)),
        //                                InterestOnBorrowings1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestOnBorrowings1)),
        //                                InterestOnBorrowings2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestOnBorrowings2)),
        //                                InterestOnBorrowings3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestOnBorrowings3)),
        //                                InterestOnBorrowings4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestOnBorrowings4)),
        //                                InterestPaidOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestPaidOutput1)),
        //                                InterestPaidOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestPaidOutput2)),
        //                                InterestPaidOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestPaidOutput3)),
        //                                InterestPaidOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.InterestPaidOutput4)),
        //                                OtherFinancialCharges1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherFinancialCharges1)),
        //                                OtherFinancialCharges2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherFinancialCharges2)),
        //                                OtherFinancialCharges3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherFinancialCharges3)),
        //                                OtherFinancialCharges4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherFinancialCharges4)),
        //                                PersonnelExpenses1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.PersonnelExpenses1)),
        //                                PersonnelExpenses2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.PersonnelExpenses2)),
        //                                PersonnelExpenses3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.PersonnelExpenses3)),
        //                                PersonnelExpenses4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.PersonnelExpenses4)),
        //                                OperatingExpensesOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.OperatingExpensesOutput1)),
        //                                OperatingExpensesOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.OperatingExpensesOutput2)),
        //                                OperatingExpensesOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.OperatingExpensesOutput3)),
        //                                OperatingExpensesOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.OperatingExpensesOutput4)),
        //                                OperatingExpenses1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OperatingExpenses1)),
        //                                OperatingExpenses2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OperatingExpenses2)),
        //                                OperatingExpenses3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OperatingExpenses3)),
        //                                OperatingExpenses4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OperatingExpenses4)),
        //                                MiscellaneousExpensesWrittenOff1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.MiscellaneousExpensesWrittenOff1)),
        //                                MiscellaneousExpensesWrittenOff2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.MiscellaneousExpensesWrittenOff2)),
        //                                MiscellaneousExpensesWrittenOff3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.MiscellaneousExpensesWrittenOff3)),
        //                                MiscellaneousExpensesWrittenOff4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.MiscellaneousExpensesWrittenOff4)),
        //                                ProvisionForImpairmentInValueOfAssets1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForImpairmentInValueOfAssets1)),
        //                                ProvisionForImpairmentInValueOfAssets2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForImpairmentInValueOfAssets2)),
        //                                ProvisionForImpairmentInValueOfAssets3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForImpairmentInValueOfAssets3)),
        //                                ProvisionForImpairmentInValueOfAssets4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForImpairmentInValueOfAssets4)),
        //                                Depreciation1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.Depreciation1)),
        //                                Depreciation2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.Depreciation2)),
        //                                Depreciation3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.Depreciation3)),
        //                                Depreciation4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.Depreciation4)),
        //                                LoanLosses1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.LoanLosses1)),
        //                                LoanLosses2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.LoanLosses2)),
        //                                LoanLosses3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.LoanLosses3)),
        //                                LoanLosses4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.LoanLosses4)),
        //                                ProvisionForLoanLosses1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForLoanLosses1)),
        //                                ProvisionForLoanLosses2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForLoanLosses2)),
        //                                ProvisionForLoanLosses3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForLoanLosses3)),
        //                                ProvisionForLoanLosses4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForLoanLosses4)),
        //                                ProvisionForInterestOnIncomeTaxRefund1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForInterestOnIncomeTaxRefund1)),
        //                                ProvisionForInterestOnIncomeTaxRefund2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForInterestOnIncomeTaxRefund2)),
        //                                ProvisionForInterestOnIncomeTaxRefund3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForInterestOnIncomeTaxRefund3)),
        //                                ProvisionForInterestOnIncomeTaxRefund4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForInterestOnIncomeTaxRefund4)),
        //                                ProvisionForBadDebtsWrittenBack1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForBadDebtsWrittenBack1)),
        //                                ProvisionForBadDebtsWrittenBack2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForBadDebtsWrittenBack2)),
        //                                ProvisionForBadDebtsWrittenBack3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForBadDebtsWrittenBack3)),
        //                                ProvisionForBadDebtsWrittenBack4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.ProvisionForBadDebtsWrittenBack4)),
        //                                OtherCreditAssetsWrittenOff1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherCreditAssetsWrittenOff1)),
        //                                OtherCreditAssetsWrittenOff2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherCreditAssetsWrittenOff2)),
        //                                OtherCreditAssetsWrittenOff3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherCreditAssetsWrittenOff3)),
        //                                OtherCreditAssetsWrittenOff4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherCreditAssetsWrittenOff4)),
        //                                OtherAdjustments1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherAdjustments1)),
        //                                OtherAdjustments2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherAdjustments2)),
        //                                OtherAdjustments3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherAdjustments3)),
        //                                OtherAdjustments4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.OtherAdjustments4)),
        //                                ProfitBeforeTaxOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitBeforeTaxOutput1)),
        //                                ProfitBeforeTaxOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitBeforeTaxOutput2)),
        //                                ProfitBeforeTaxOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitBeforeTaxOutput3)),
        //                                ProfitBeforeTaxOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitBeforeTaxOutput4)),
        //                                TaxExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.TaxExpenseOutput1)),
        //                                TaxExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.TaxExpenseOutput2)),
        //                                TaxExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.TaxExpenseOutput3)),
        //                                TaxExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.TaxExpenseOutput4)),
        //                                CurrentTax1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.CurrentTax1)),
        //                                CurrentTax2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.CurrentTax2)),
        //                                CurrentTax3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.CurrentTax3)),
        //                                CurrentTax4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.CurrentTax4)),
        //                                DeferredTax1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.DeferredTax1)),
        //                                DeferredTax2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.DeferredTax2)),
        //                                DeferredTax3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.DeferredTax3)),
        //                                DeferredTax4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.DeferredTax4)),
        //                                ProfitAfterTaxOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitAfterTaxOutput1)),
        //                                ProfitAfterTaxOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitAfterTaxOutput2)),
        //                                ProfitAfterTaxOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitAfterTaxOutput3)),
        //                                ProfitAfterTaxOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement.ProfitAfterTaxOutput4)),
        //                                PreferenceDividend_Tax1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.PreferenceDividend_Tax1)),
        //                                PreferenceDividend_Tax2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.PreferenceDividend_Tax2)),
        //                                PreferenceDividend_Tax3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.PreferenceDividend_Tax3)),
        //                                PreferenceDividend_Tax4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.PreferenceDividend_Tax4)),
        //                                EquityDividend_Tax1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.EquityDividend_Tax1)),
        //                                EquityDividend_Tax2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.EquityDividend_Tax2)),
        //                                EquityDividend_Tax3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.EquityDividend_Tax3)),
        //                                EquityDividend_Tax4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement.EquityDividend_Tax4)),
        //                            },
        //                            #endregion
        //                            #region  NHB_ALMStatementLatest
        //                            NHB_ALM_Statement_Latests = new NHB_ALM_Statement_Latests()
        //                            {
        //                                Statement_Date = nHB_ALMStatementLatest.StatementDate,
        //                                Day1to14DaysInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Day1to14DaysInflow)),
        //                                Day1to14DaysOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Day1to14DaysOurflow)),
        //                                Day1to14DaysMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Day1to14DaysMismatch)),
        //                                Day14DaysTo1MonthInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Day14DaysTo1MonthInflow)),
        //                                Day14DaysTo1MonthOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Day14DaysTo1MonthOurflow)),
        //                                Day14DaysTo1MonthMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Day14DaysTo1MonthMismatch)),
        //                                Month1To2MonthsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Month1To2MonthsInflow)),
        //                                Month1To2MonthsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Month1To2MonthsOurflow)),
        //                                Month1To2MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Month1To2MonthsMismatch)),
        //                                Month2To3MonthsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Month2To3MonthsInflow)),
        //                                Month2To3MonthsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Month2To3MonthsOurflow)),
        //                                Month2To3MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Month2To3MonthsMismatch)),
        //                                Month3To6MonthsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Month3To6MonthsInflow)),
        //                                Month3To6MonthsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Month3To6MonthsOurflow)),
        //                                Month3To6MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Month3To6MonthsMismatch)),
        //                                Month6MonthsTo1YearInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Month6MonthsTo1YearInflow)),
        //                                Month6MonthsTo1YearOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Month6MonthsTo1YearOurflow)),
        //                                Month6MonthsTo1YearMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Month6MonthsTo1YearMismatch)),
        //                                Year1To3YearsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Year1To3YearsInflow)),
        //                                Year1To3YearsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Year1To3YearsOurflow)),
        //                                Year1To3YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Year1To3YearsMismatch)),
        //                                Year3To5YearsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Year3To5YearsInflow)),
        //                                Year3To5YearsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Year3To5YearsOurflow)),
        //                                Year3To5YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Year3To5YearsMismatch)),
        //                                Year5To7YearsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Year5To7YearsInflow)),
        //                                Year5To7YearsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Year5To7YearsOurflow)),
        //                                Year5To7YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Year5To7YearsMismatch)),
        //                                Year7To10YearsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Year7To10YearsInflow)),
        //                                Year7To10YearsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Year7To10YearsOurflow)),
        //                                Year7To10YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Year7To10YearsMismatch)),
        //                                Over10YearsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Over10YearsInflow)),
        //                                Over10YearsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest.Over10YearsOurflow)),
        //                                Over10YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest.Over10YearsMismatch)),

        //                            },
        //                            #endregion
        //                            #region NHB_KeyRatio
        //                            NHB_KeyRatios = new NHB_KeyRatioss()
        //                            {
        //                                TotalAssets1 = nHB_KeyRatio.TotalAssets1,
        //                                TotalAssets2 = nHB_KeyRatio.TotalAssets2,
        //                                TotalAssets3 = nHB_KeyRatio.TotalAssets3,
        //                                TotalAssets4 = nHB_KeyRatio.TotalAssets4,
        //                                GrossNPAPercentage1 = nHB_KeyRatio.GrossNPAPercentage1,
        //                                GrossNPAPercentage2 = nHB_KeyRatio.GrossNPAPercentage2,
        //                                GrossNPAPercentage3 = nHB_KeyRatio.GrossNPAPercentage3,
        //                                GrossNPAPercentage4 = nHB_KeyRatio.GrossNPAPercentage4,
        //                                ALMMismatchPercentage1 = nHB_KeyRatio.ALMMismatchPercentage1,
        //                                ALMMismatchPercentage2 = nHB_KeyRatio.ALMMismatchPercentage2,
        //                                ALMMismatchPercentage3 = nHB_KeyRatio.ALMMismatchPercentage3,
        //                                ALMMismatchPercentage4 = nHB_KeyRatio.ALMMismatchPercentage4,
        //                                NetWorth1 = nHB_KeyRatio.NetWorth1,
        //                                NetWorth2 = nHB_KeyRatio.NetWorth2,
        //                                NetWorth3 = nHB_KeyRatio.NetWorth3,
        //                                NetWorth4 = nHB_KeyRatio.NetWorth4,
        //                                CRARPercentage1 = nHB_KeyRatio.CRARPercentage1,
        //                                CRARPercentage2 = nHB_KeyRatio.CRARPercentage2,
        //                                CRARPercentage3 = nHB_KeyRatio.CRARPercentage3,
        //                                CRARPercentage4 = nHB_KeyRatio.CRARPercentage4,
        //                                GearingPercentage1 = nHB_KeyRatio.GearingPercentage1,
        //                                GearingPercentage2 = nHB_KeyRatio.GearingPercentage2,
        //                                GearingPercentage3 = nHB_KeyRatio.GearingPercentage3,
        //                                GearingPercentage4 = nHB_KeyRatio.GearingPercentage4,
        //                                TangibleNWNetNPA1 = nHB_KeyRatio.TangibleNWNetNPA1,
        //                                TangibleNWNetNPA2 = nHB_KeyRatio.TangibleNWNetNPA2,
        //                                TangibleNWNetNPA3 = nHB_KeyRatio.TangibleNWNetNPA3,
        //                                TangibleNWNetNPA4 = nHB_KeyRatio.TangibleNWNetNPA4,
        //                                NetMarginPercentage1 = nHB_KeyRatio.NetMarginPercentage1,
        //                                NetMarginPercentage2 = nHB_KeyRatio.NetMarginPercentage2,
        //                                NetMarginPercentage3 = nHB_KeyRatio.NetMarginPercentage3,
        //                                NetMarginPercentage4 = nHB_KeyRatio.NetMarginPercentage4,
        //                                PATAverageFundsDeployedPercentage1 = nHB_KeyRatio.PATAverageFundsDeployedPercentage1,
        //                                PATAverageFundsDeployedPercentage2 = nHB_KeyRatio.PATAverageFundsDeployedPercentage2,
        //                                PATAverageFundsDeployedPercentage3 = nHB_KeyRatio.PATAverageFundsDeployedPercentage3,
        //                                PATAverageFundsDeployedPercentage4 = nHB_KeyRatio.PATAverageFundsDeployedPercentage4,
        //                                PATAverageNetWorthPercentage1 = nHB_KeyRatio.PATAverageNetWorthPercentage1,
        //                                PATAverageNetWorthPercentage2 = nHB_KeyRatio.PATAverageNetWorthPercentage2,
        //                                PATAverageNetWorthPercentage3 = nHB_KeyRatio.PATAverageNetWorthPercentage3,
        //                                PATAverageNetWorthPercentage4 = nHB_KeyRatio.PATAverageNetWorthPercentage4,
        //                            },
        //                            #endregion
        //                            #region NHB_Industry_RiskInputs
        //                            NHB_Industry_RiskInputs = new NHB_Industry_RiskInputss()
        //                            {
        //                                FinancialPerformanceofPlayer = nHB_IndustryRiskInputs.FinancialPerformanceofPlayer.Trim(),
        //                                ExtentOfCompetition = nHB_IndustryRiskInputs.ExtentOfCompetition.Trim(),
        //                                ProspectOfRealEstateMarket = nHB_IndustryRiskInputs.ProspectOfRealEstateMarket.Trim(),
        //                                RegulatoryImpact = nHB_IndustryRiskInputs.RegulatoryImpact.Trim()
        //                            },
        //                            #endregion
        //                            #region NHB_Business_RiskInputs
        //                            NHB_Business_RiskInputs = new NHB_Business_RiskInputss()
        //                            {
        //                                RankOfMarketPosition = nHB_BusinessRiskInputs.RankOfMarketPosition.Trim(),
        //                                GeographicalDiversification = nHB_BusinessRiskInputs.GeographicalDiversification.Trim(),
        //                                ProductMix = nHB_BusinessRiskInputs.ProductMix.Trim(),
        //                                CustomerMix = nHB_BusinessRiskInputs.CustomerMix.Trim(),
        //                                CostOfResources = nHB_BusinessRiskInputs.CostOfResources.Trim(),
        //                                TotalAssetGrowth = nHB_BusinessRiskInputs.TotalAssetGrowth.Trim(),
        //                                DiversificationOfFundingProfile = nHB_BusinessRiskInputs.DiversificationOfFundingProfile.Trim()
        //                            },
        //                            #endregion
        //                            #region NHB_Financial_RiskInputs
        //                            NHB_Financial_RiskInputs = new NHB_Financial_RiskInputss()
        //                            {
        //                                CompanysAbility = nHB_FinancialRiskInputs.CompanysAbility.Trim()
        //                            },
        //                            #endregion
        //                            #region NHB_Management_RiskInputs
        //                            NHB_Management_RiskInputs = new NHB_Management_RiskInputss()
        //                            {
        //                                AbilityToMeetRevenueProjection = nHB_ManagementRiskInputs.AbilityToMeetRevenueProjection.Trim(),
        //                                AbilityToMeetProfitProjection = nHB_ManagementRiskInputs.AbilityToMeetProfitProjection.Trim(),
        //                                PastPaymentRecord = nHB_ManagementRiskInputs.PastPaymentRecord.Trim(),
        //                                RiskManagementSystem = nHB_ManagementRiskInputs.RiskManagementSystem.Trim(),
        //                                ManagementCredibility = nHB_ManagementRiskInputs.ManagementCredibility.Trim(),
        //                                ManagementExperienceAndCompetence = nHB_ManagementRiskInputs.ManagementExperienceAndCompetence.Trim(),
        //                                RiskAppetite = nHB_ManagementRiskInputs.RiskAppetite.Trim(),
        //                            },
        //                            #endregion
        //                            #region NHB_NotchUp_CriteriaInputs
        //                            NHB_NotchUp_CriteriaInputs = new NHB_NotchUp_CriteriaInputss()
        //                            {
        //                                ShareholdingStructure = nHB_NotchUpCriteriaInput.ShareholdingStructure.Trim(),
        //                                ManagementControl = nHB_NotchUpCriteriaInput.ManagementControl.Trim(),
        //                                StatedPostureOfTheParent = nHB_NotchUpCriteriaInput.StatedPostureOfTheParent.Trim(),
        //                                PastTrackRecord = nHB_NotchUpCriteriaInput.PastTrackRecord.Trim(),
        //                                BrandName = nHB_NotchUpCriteriaInput.BrandName.Trim()
        //                            },
        //                            #endregion
        //                        };
        //                    }
        //                }
        //                else
        //                {
        //                    nHB_BalanceSheet_Liabilities_Final = companyDAL.GetBalanceSheetLiabilitiesDetails_Final(nHB_Details.DetailsId);
        //                    nHB_BalanceSheet_Assets_Final = companyDAL.GetBalanceSheetAssetsDetails_Final(nHB_Details.DetailsId);
        //                    nHB_ContingentLiabilities_Final = companyDAL.GetContingentLiabilitiesDetails_Final(nHB_Details.DetailsId);
        //                    nHB_OtherBalanceSheet_Disclosures_Final = companyDAL.GetOtherBalanceSheet_DisclosuresDetails_Final(nHB_Details.DetailsId);
        //                    nHB_ProfitAndLossStatement_Final = companyDAL.GetProfitAndLossStatementDetails_Final(nHB_Details.DetailsId);
        //                    nHB_ALMStatementLatest_Final = companyDAL.GetALMStatmentLatestDetails_Final(nHB_Details.DetailsId);
        //                    nHB_KeyRatio_Final = companyDAL.GetKeyRatioDetails_Final(nHB_Details.DetailsId);
        //                    nHB_IndustryRiskInputs_Final = companyDAL.GetIndustryRiskInputsDetails_Final(nHB_Details.DetailsId);
        //                    nHB_BusinessRiskInputs_Final = companyDAL.GetBusinessRiskInputsDetails_Final(nHB_Details.DetailsId);
        //                    nHB_FinancialRiskInputs_Final = companyDAL.GetFinancialRiskInputsDetails_Final(nHB_Details.DetailsId);
        //                    nHB_ManagementRiskInputs_Final = companyDAL.GetManagementRiskInputsDetails_Final(nHB_Details.DetailsId);
        //                    nHB_NotchUpCriteriaInput_Final = companyDAL.GetNotchUpCriteriaInputsDetails_Final(nHB_Details.DetailsId);


        //                    if (nHB_BalanceSheet_Liabilities_Final != null && nHB_BalanceSheet_Assets_Final != null && nHB_ContingentLiabilities_Final != null && nHB_OtherBalanceSheet_Disclosures_Final != null && nHB_ProfitAndLossStatement_Final != null && nHB_ALMStatementLatest_Final != null
        //                        && nHB_KeyRatio_Final != null && nHB_IndustryRiskInputs_Final != null && nHB_BusinessRiskInputs_Final != null && nHB_FinancialRiskInputs_Final != null && nHB_ManagementRiskInputs_Final != null && nHB_NotchUpCriteriaInput_Final != null)
        //                    {
        //                        riskModelExcelEntity = new RiskModelExcelEntity()
        //                        {
        //                            CompanyId = nHB_Details.CompanyId,
        //                            CurrencyUnits = nHB_Details.CurrencyUnits,
        //                            DateOfInput = nHB_Details.DateOfInput,
        //                            DetailsId = nHB_Details.DetailsId,
        //                            FinancialYearEndingDate = nHB_Details.FinancialYearEndingDate.Value.ToString(),
        //                            LocationId = nHB_Details.LocationId,
        //                            ParentCompanyIsExist = (nHB_Details.ParentCompanyIsExist == true) ? "Yes" : "No",
        //                            ParentCompanyName = nHB_Details.ParentCompanyName,
        //                            ParentRating = nHB_Details.ParentRating,
        //                            #region NHB_BalanceSheets_Liabilitiess
        //                            NHB_BalanceSheets_Liabilities = new NHB_BalanceSheets_Liabilitiess()
        //                            {
        //                                PeriodEndingDate1_Liabilities = nHB_BalanceSheet_Liabilities_Final.PeriodEndingDate1,
        //                                PeriodEndingDate2_Liabilities = nHB_BalanceSheet_Liabilities_Final.PeriodEndingDate2,
        //                                PeriodEndingDate3_Liabilities = nHB_BalanceSheet_Liabilities_Final.PeriodEndingDate3,
        //                                PeriodEndingDate4_Liabilities = nHB_BalanceSheet_Liabilities_Final.PeriodEndingDate4,
        //                                LiabilitiesType1 = nHB_BalanceSheet_Liabilities_Final.LiabilitiesType1,
        //                                LiabilitiesType2 = nHB_BalanceSheet_Liabilities_Final.LiabilitiesType2,
        //                                LiabilitiesType3 = nHB_BalanceSheet_Liabilities_Final.LiabilitiesType3,
        //                                LiabilitiesType4 = nHB_BalanceSheet_Liabilities_Final.LiabilitiesType4,
        //                                CapitalPEOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CapitalPEOutput1)),
        //                                CapitalPEOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CapitalPEOutput2)),
        //                                CapitalPEOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CapitalPEOutput3)),
        //                                CapitalPEOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CapitalPEOutput4)),
        //                                CalledAndPaid_Up1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CalledAndPaid_Up1)),
        //                                CalledAndPaid_Up2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CalledAndPaid_Up2)),
        //                                CalledAndPaid_Up3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CalledAndPaid_Up3)),
        //                                CalledAndPaid_Up4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CalledAndPaid_Up4)),
        //                                EquityShareWarrant1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.EquityShareWarrant1)),
        //                                EquityShareWarrant2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.EquityShareWarrant2)),
        //                                EquityShareWarrant3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.EquityShareWarrant3)),
        //                                EquityShareWarrant4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.EquityShareWarrant4)),
        //                                ReservesAndSurplusOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.ReservesAndSurplusOutput1)),
        //                                ReservesAndSurplusOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.ReservesAndSurplusOutput2)),
        //                                ReservesAndSurplusOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.ReservesAndSurplusOutput3)),
        //                                ReservesAndSurplusOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.ReservesAndSurplusOutput4)),
        //                                CapitalReserves1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CapitalReserves1)),
        //                                CapitalReserves2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CapitalReserves2)),
        //                                CapitalReserves3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CapitalReserves3)),
        //                                CapitalReserves4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CapitalReserves4)),
        //                                GeneralReserves1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.GeneralReserves1)),
        //                                GeneralReserves2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.GeneralReserves2)),
        //                                GeneralReserves3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.GeneralReserves3)),
        //                                GeneralReserves4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.GeneralReserves4)),
        //                                SharePremium1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.SharePremium1)),
        //                                SharePremium2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.SharePremium2)),
        //                                SharePremium3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.SharePremium3)),
        //                                SharePremium4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.SharePremium4)),
        //                                SpecialPurposeReserves1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.SpecialPurposeReserves1)),
        //                                SpecialPurposeReserves2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.SpecialPurposeReserves2)),
        //                                SpecialPurposeReserves3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.SpecialPurposeReserves3)),
        //                                SpecialPurposeReserves4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.SpecialPurposeReserves4)),
        //                                OtherReserves1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.OtherReserves1)),
        //                                OtherReserves2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.OtherReserves2)),
        //                                OtherReserves3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.OtherReserves3)),
        //                                OtherReserves4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.OtherReserves4)),
        //                                RevenueReserves1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.RevenueReserves1)),
        //                                RevenueReserves2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.RevenueReserves2)),
        //                                RevenueReserves3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.RevenueReserves3)),
        //                                RevenueReserves4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.RevenueReserves4)),
        //                                IntangibleAssets1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.IntangibleAssets1)),
        //                                IntangibleAssets2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.IntangibleAssets2)),
        //                                IntangibleAssets3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.IntangibleAssets3)),
        //                                IntangibleAssets4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.IntangibleAssets4)),
        //                                BorrowingsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.BorrowingsOutput1)),
        //                                BorrowingsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.BorrowingsOutput2)),
        //                                BorrowingsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.BorrowingsOutput3)),
        //                                BorrowingsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.BorrowingsOutput4)),
        //                                CommercialPaper1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CommercialPaper1)),
        //                                CommercialPaper2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CommercialPaper2)),
        //                                CommercialPaper3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CommercialPaper3)),
        //                                CommercialPaper4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CommercialPaper4)),
        //                                InterCorporateDeposits1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.InterCorporateDeposits1)),
        //                                InterCorporateDeposits2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.InterCorporateDeposits2)),
        //                                InterCorporateDeposits3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.InterCorporateDeposits3)),
        //                                InterCorporateDeposits4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.InterCorporateDeposits4)),
        //                                CallAndNoticeMoney1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CallAndNoticeMoney1)),
        //                                CallAndNoticeMoney2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CallAndNoticeMoney2)),
        //                                CallAndNoticeMoney3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CallAndNoticeMoney3)),
        //                                CallAndNoticeMoney4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.CallAndNoticeMoney4)),
        //                                OtherBorrowings1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.OtherBorrowings1)),
        //                                OtherBorrowings2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.OtherBorrowings2)),
        //                                OtherBorrowings3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.OtherBorrowings3)),
        //                                OtherBorrowings4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.OtherBorrowings4)),
        //                                LongTermBorrowingsWithinYear1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsWithinYear1)),
        //                                LongTermBorrowingsWithinYear2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsWithinYear2)),
        //                                LongTermBorrowingsWithinYear3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsWithinYear3)),
        //                                LongTermBorrowingsWithinYear4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsWithinYear4)),
        //                                PublicDeposits1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.PublicDeposits1)),
        //                                PublicDeposits2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.PublicDeposits2)),
        //                                PublicDeposits3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.PublicDeposits3)),
        //                                PublicDeposits4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.PublicDeposits4)),
        //                                ShortTermBorrowings1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.ShortTermBorrowings1)),
        //                                ShortTermBorrowings2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.ShortTermBorrowings2)),
        //                                ShortTermBorrowings3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.ShortTermBorrowings3)),
        //                                ShortTermBorrowings4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.ShortTermBorrowings4)),
        //                                LongTermBorrowingsFloatingNHB1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFloatingNHB1)),
        //                                LongTermBorrowingsFloatingNHB2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFloatingNHB2)),
        //                                LongTermBorrowingsFloatingNHB3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFloatingNHB3)),
        //                                LongTermBorrowingsFloatingNHB4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFloatingNHB4)),
        //                                LongTermBorrowingsFloatingOthers1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFloatingOthers1)),
        //                                LongTermBorrowingsFloatingOthers2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFloatingOthers2)),
        //                                LongTermBorrowingsFloatingOthers3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFloatingOthers3)),
        //                                LongTermBorrowingsFloatingOthers4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFloatingOthers4)),
        //                                LongTermBorrowingsFixedNHB1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFixedNHB1)),
        //                                LongTermBorrowingsFixedNHB2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFixedNHB2)),
        //                                LongTermBorrowingsFixedNHB3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFixedNHB3)),
        //                                LongTermBorrowingsFixedNHB4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFixedNHB4)),
        //                                LongTermBorrowingsFixedOthers1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFixedOthers1)),
        //                                LongTermBorrowingsFixedOthers2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFixedOthers2)),
        //                                LongTermBorrowingsFixedOthers3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFixedOthers3)),
        //                                LongTermBorrowingsFixedOthers4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermBorrowingsFixedOthers4)),
        //                                UnsecuredLongTermBorrowings1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.UnsecuredLongTermBorrowings1)),
        //                                UnsecuredLongTermBorrowings2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.UnsecuredLongTermBorrowings2)),
        //                                UnsecuredLongTermBorrowings3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.UnsecuredLongTermBorrowings3)),
        //                                UnsecuredLongTermBorrowings4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.UnsecuredLongTermBorrowings4)),
        //                                LongTermForeignCurrency1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermForeignCurrency1)),
        //                                LongTermForeignCurrency2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermForeignCurrency2)),
        //                                LongTermForeignCurrency3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermForeignCurrency3)),
        //                                LongTermForeignCurrency4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LongTermForeignCurrency4)),
        //                                BorrowingsFromRelatedParties1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.BorrowingsFromRelatedParties1)),
        //                                BorrowingsFromRelatedParties2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.BorrowingsFromRelatedParties2)),
        //                                BorrowingsFromRelatedParties3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.BorrowingsFromRelatedParties3)),
        //                                BorrowingsFromRelatedParties4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.BorrowingsFromRelatedParties4)),
        //                                HybridInstruments1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.HybridInstruments1)),
        //                                HybridInstruments2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.HybridInstruments2)),
        //                                HybridInstruments3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.HybridInstruments3)),
        //                                HybridInstruments4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.HybridInstruments4)),
        //                                LiabilitiesAndCapitalTotalOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LiabilitiesAndCapitalTotalOutput1)),
        //                                LiabilitiesAndCapitalTotalOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LiabilitiesAndCapitalTotalOutput2)),
        //                                LiabilitiesAndCapitalTotalOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LiabilitiesAndCapitalTotalOutput3)),
        //                                LiabilitiesAndCapitalTotalOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Liabilities_Final.LiabilitiesAndCapitalTotalOutput4)),

        //                            },
        //                            #endregion
        //                            #region NHB_BalanceSheet_Assetss
        //                            NHB_BalanceSheet_Assets = new NHB_BalanceSheet_Assetss()
        //                            {
        //                                PeriodEndingDate1_Assets = nHB_BalanceSheet_Assets_Final.PeriodEndingDate1,
        //                                PeriodEndingDate2_Assets = nHB_BalanceSheet_Assets_Final.PeriodEndingDate2,
        //                                PeriodEndingDate3_Assets = nHB_BalanceSheet_Assets_Final.PeriodEndingDate3,
        //                                PeriodEndingDate4_Assets = nHB_BalanceSheet_Assets_Final.PeriodEndingDate4,
        //                                FixedAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.FixedAssetsOutput1)),
        //                                FixedAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.FixedAssetsOutput2)),
        //                                FixedAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.FixedAssetsOutput3)),
        //                                FixedAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.FixedAssetsOutput4)),
        //                                OwnedNetBlock1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OwnedNetBlock1)),
        //                                OwnedNetBlock2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OwnedNetBlock2)),
        //                                OwnedNetBlock3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OwnedNetBlock3)),
        //                                OwnedNetBlock4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OwnedNetBlock4)),
        //                                LeasedNetBlock1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.LeasedNetBlock1)),
        //                                LeasedNetBlock2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.LeasedNetBlock2)),
        //                                LeasedNetBlock3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.LeasedNetBlock3)),
        //                                LeasedNetBlock4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.LeasedNetBlock4)),
        //                                CapitalWorkInProgress1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CapitalWorkInProgress1)),
        //                                CapitalWorkInProgress2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CapitalWorkInProgress2)),
        //                                CapitalWorkInProgress3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CapitalWorkInProgress3)),
        //                                CapitalWorkInProgress4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CapitalWorkInProgress4)),
        //                                InvestmentsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsOutput1)),
        //                                InvestmentsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsOutput2)),
        //                                InvestmentsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsOutput3)),
        //                                InvestmentsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsOutput4)),
        //                                CentralGovernmentSecuritiesQuoted1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CentralGovernmentSecuritiesQuoted1)),
        //                                CentralGovernmentSecuritiesQuoted2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CentralGovernmentSecuritiesQuoted2)),
        //                                CentralGovernmentSecuritiesQuoted3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CentralGovernmentSecuritiesQuoted3)),
        //                                CentralGovernmentSecuritiesQuoted4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CentralGovernmentSecuritiesQuoted4)),
        //                                CentralGovernmentDebtUnquoted1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CentralGovernmentDebtUnquoted1)),
        //                                CentralGovernmentDebtUnquoted2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CentralGovernmentDebtUnquoted2)),
        //                                CentralGovernmentDebtUnquoted3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CentralGovernmentDebtUnquoted3)),
        //                                CentralGovernmentDebtUnquoted4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CentralGovernmentDebtUnquoted4)),
        //                                StateGovernmentSecurities1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.StateGovernmentSecurities1)),
        //                                StateGovernmentSecurities2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.StateGovernmentSecurities2)),
        //                                StateGovernmentSecurities3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.StateGovernmentSecurities3)),
        //                                StateGovernmentSecurities4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.StateGovernmentSecurities4)),
        //                                GuaranteedPublicSectorBonds1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.GuaranteedPublicSectorBonds1)),
        //                                GuaranteedPublicSectorBonds2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.GuaranteedPublicSectorBonds2)),
        //                                GuaranteedPublicSectorBonds3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.GuaranteedPublicSectorBonds3)),
        //                                GuaranteedPublicSectorBonds4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.GuaranteedPublicSectorBonds4)),
        //                                OtherPublicSectorBonds1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherPublicSectorBonds1)),
        //                                OtherPublicSectorBonds2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherPublicSectorBonds2)),
        //                                OtherPublicSectorBonds3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherPublicSectorBonds3)),
        //                                OtherPublicSectorBonds4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherPublicSectorBonds4)),
        //                                PrivateSectorBondsInvestmentGrade1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.PrivateSectorBondsInvestmentGrade1)),
        //                                PrivateSectorBondsInvestmentGrade2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.PrivateSectorBondsInvestmentGrade2)),
        //                                PrivateSectorBondsInvestmentGrade3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.PrivateSectorBondsInvestmentGrade3)),
        //                                PrivateSectorBondsInvestmentGrade4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.PrivateSectorBondsInvestmentGrade4)),
        //                                OtherPrivateSectorBonds1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherPrivateSectorBonds1)),
        //                                OtherPrivateSectorBonds2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherPrivateSectorBonds2)),
        //                                OtherPrivateSectorBonds3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherPrivateSectorBonds3)),
        //                                OtherPrivateSectorBonds4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherPrivateSectorBonds4)),
        //                                MutualFunds1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.MutualFunds1)),
        //                                MutualFunds2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.MutualFunds2)),
        //                                MutualFunds3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.MutualFunds3)),
        //                                MutualFunds4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.MutualFunds4)),
        //                                ListedEquity1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ListedEquity1)),
        //                                ListedEquity2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ListedEquity2)),
        //                                ListedEquity3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ListedEquity3)),
        //                                ListedEquity4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ListedEquity4)),
        //                                UnlistedEquity1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.UnlistedEquity1)),
        //                                UnlistedEquity2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.UnlistedEquity2)),
        //                                UnlistedEquity3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.UnlistedEquity3)),
        //                                UnlistedEquity4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.UnlistedEquity4)),
        //                                InvestmentsInParentAndSubsidiariesAndAssociates1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsInParentAndSubsidiariesAndAssociates1)),
        //                                InvestmentsInParentAndSubsidiariesAndAssociates2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsInParentAndSubsidiariesAndAssociates2)),
        //                                InvestmentsInParentAndSubsidiariesAndAssociates3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsInParentAndSubsidiariesAndAssociates3)),
        //                                InvestmentsInParentAndSubsidiariesAndAssociates4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsInParentAndSubsidiariesAndAssociates4)),
        //                                CurrentAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CurrentAssetsOutput1)),
        //                                CurrentAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CurrentAssetsOutput2)),
        //                                CurrentAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CurrentAssetsOutput3)),
        //                                CurrentAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CurrentAssetsOutput4)),
        //                                HirePurchaseReceivables1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.HirePurchaseReceivables1)),
        //                                HirePurchaseReceivables2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.HirePurchaseReceivables2)),
        //                                HirePurchaseReceivables3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.HirePurchaseReceivables3)),
        //                                HirePurchaseReceivables4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.HirePurchaseReceivables4)),
        //                                FinanceLeases1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.FinanceLeases1)),
        //                                FinanceLeases2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.FinanceLeases2)),
        //                                FinanceLeases3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.FinanceLeases3)),
        //                                FinanceLeases4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.FinanceLeases4)),
        //                                SecuredLoans1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.SecuredLoans1)),
        //                                SecuredLoans2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.SecuredLoans2)),
        //                                SecuredLoans3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.SecuredLoans3)),
        //                                SecuredLoans4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.SecuredLoans4)),
        //                                UnsecuredLoans1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.UnsecuredLoans1)),
        //                                UnsecuredLoans2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.UnsecuredLoans2)),
        //                                UnsecuredLoans3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.UnsecuredLoans3)),
        //                                UnsecuredLoans4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.UnsecuredLoans4)),
        //                                Debtors1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.Debtors1)),
        //                                Debtors2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.Debtors2)),
        //                                Debtors3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.Debtors3)),
        //                                Debtors4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.Debtors4)),
        //                                BillsDiscounted1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.BillsDiscounted1)),
        //                                BillsDiscounted2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.BillsDiscounted2)),
        //                                BillsDiscounted3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.BillsDiscounted3)),
        //                                BillsDiscounted4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.BillsDiscounted4)),
        //                                OtherInterestBearingLoans1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherInterestBearingLoans1)),
        //                                OtherInterestBearingLoans2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherInterestBearingLoans2)),
        //                                OtherInterestBearingLoans3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherInterestBearingLoans3)),
        //                                OtherInterestBearingLoans4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherInterestBearingLoans4)),
        //                                LoansToRelatedParties1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.LoansToRelatedParties1)),
        //                                LoansToRelatedParties2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.LoansToRelatedParties2)),
        //                                LoansToRelatedParties3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.LoansToRelatedParties3)),
        //                                LoansToRelatedParties4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.LoansToRelatedParties4)),
        //                                CashAndBank1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CashAndBank1)),
        //                                CashAndBank2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CashAndBank2)),
        //                                CashAndBank3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CashAndBank3)),
        //                                CashAndBank4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CashAndBank4)),
        //                                AdvancesPaid1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.AdvancesPaid1)),
        //                                AdvancesPaid2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.AdvancesPaid2)),
        //                                AdvancesPaid3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.AdvancesPaid3)),
        //                                AdvancesPaid4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.AdvancesPaid4)),
        //                                OtherCurrentAssets1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherCurrentAssets1)),
        //                                OtherCurrentAssets2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherCurrentAssets2)),
        //                                OtherCurrentAssets3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherCurrentAssets3)),
        //                                OtherCurrentAssets4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherCurrentAssets4)),
        //                                InvestmentsInSecuritisedAssets1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsInSecuritisedAssets1)),
        //                                InvestmentsInSecuritisedAssets2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsInSecuritisedAssets2)),
        //                                InvestmentsInSecuritisedAssets3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsInSecuritisedAssets3)),
        //                                InvestmentsInSecuritisedAssets4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InvestmentsInSecuritisedAssets4)),
        //                                CurrentLiabilitiesOutput1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CurrentLiabilitiesOutput1)),
        //                                CurrentLiabilitiesOutput2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CurrentLiabilitiesOutput2)),
        //                                CurrentLiabilitiesOutput3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CurrentLiabilitiesOutput3)),
        //                                CurrentLiabilitiesOutput4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.CurrentLiabilitiesOutput4)),
        //                                InterestAccruedButNotDue1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InterestAccruedButNotDue1)),
        //                                InterestAccruedButNotDue2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InterestAccruedButNotDue2)),
        //                                InterestAccruedButNotDue3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InterestAccruedButNotDue3)),
        //                                InterestAccruedButNotDue4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.InterestAccruedButNotDue4)),
        //                                DepositsReceived1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.DepositsReceived1)),
        //                                DepositsReceived2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.DepositsReceived2)),
        //                                DepositsReceived3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.DepositsReceived3)),
        //                                DepositsReceived4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.DepositsReceived4)),
        //                                AdvancesReceived1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.AdvancesReceived1)),
        //                                AdvancesReceived2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.AdvancesReceived2)),
        //                                AdvancesReceived3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.AdvancesReceived3)),
        //                                AdvancesReceived4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.AdvancesReceived4)),
        //                                OtherCurrentLiabilities1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherCurrentLiabilities1)),
        //                                OtherCurrentLiabilities2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherCurrentLiabilities2)),
        //                                OtherCurrentLiabilities3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherCurrentLiabilities3)),
        //                                OtherCurrentLiabilities4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherCurrentLiabilities4)),
        //                                DeferredtaxLiability1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.DeferredtaxLiability1)),
        //                                DeferredtaxLiability2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.DeferredtaxLiability2)),
        //                                DeferredtaxLiability3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.DeferredtaxLiability3)),
        //                                DeferredtaxLiability4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.DeferredtaxLiability4)),
        //                                ReceivablesSecuritised1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ReceivablesSecuritised1)),
        //                                ReceivablesSecuritised2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ReceivablesSecuritised2)),
        //                                ReceivablesSecuritised3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ReceivablesSecuritised3)),
        //                                ReceivablesSecuritised4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ReceivablesSecuritised4)),
        //                                ProvisionsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionsOutput1)),
        //                                ProvisionsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionsOutput2)),
        //                                ProvisionsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionsOutput3)),
        //                                ProvisionsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionsOutput4)),
        //                                ProvisionForLoanLosses1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForLoanLosses1)),
        //                                ProvisionForLoanLosses2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForLoanLosses2)),
        //                                ProvisionForLoanLosses3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForLoanLosses3)),
        //                                ProvisionForLoanLosses4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForLoanLosses4)),
        //                                ProvisionForDoubtfulDebtors1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDoubtfulDebtors1)),
        //                                ProvisionForDoubtfulDebtors2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDoubtfulDebtors2)),
        //                                ProvisionForDoubtfulDebtors3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDoubtfulDebtors3)),
        //                                ProvisionForDoubtfulDebtors4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDoubtfulDebtors4)),
        //                                ProvisionForDepreciation1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDepreciation1)),
        //                                ProvisionForDepreciation2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDepreciation2)),
        //                                ProvisionForDepreciation3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDepreciation3)),
        //                                ProvisionForDepreciation4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDepreciation4)),
        //                                ProvisionForImpairmentofAssets1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForImpairmentofAssets1)),
        //                                ProvisionForImpairmentofAssets2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForImpairmentofAssets2)),
        //                                ProvisionForImpairmentofAssets3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForImpairmentofAssets3)),
        //                                ProvisionForImpairmentofAssets4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForImpairmentofAssets4)),
        //                                ProvisionForDividend1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDividend1)),
        //                                ProvisionForDividend2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDividend2)),
        //                                ProvisionForDividend3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDividend3)),
        //                                ProvisionForDividend4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDividend4)),
        //                                ProvisionForTaxes1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForTaxes1)),
        //                                ProvisionForTaxes2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForTaxes2)),
        //                                ProvisionForTaxes3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForTaxes3)),
        //                                ProvisionForTaxes4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForTaxes4)),
        //                                ProvisionForDeferredTaxes1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDeferredTaxes1)),
        //                                ProvisionForDeferredTaxes2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDeferredTaxes2)),
        //                                ProvisionForDeferredTaxes3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDeferredTaxes3)),
        //                                ProvisionForDeferredTaxes4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForDeferredTaxes4)),
        //                                ProvisionForExpenses1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForExpenses1)),
        //                                ProvisionForExpenses2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForExpenses2)),
        //                                ProvisionForExpenses3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForExpenses3)),
        //                                ProvisionForExpenses4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.ProvisionForExpenses4)),
        //                                OtherProvisions1 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherProvisions1)),
        //                                OtherProvisions2 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherProvisions2)),
        //                                OtherProvisions3 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherProvisions3)),
        //                                OtherProvisions4 = Convert.ToString(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.OtherProvisions4)),
        //                                NetCurrentAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.NetCurrentAssetsOutput1)),
        //                                NetCurrentAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.NetCurrentAssetsOutput2)),
        //                                NetCurrentAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.NetCurrentAssetsOutput3)),
        //                                NetCurrentAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.NetCurrentAssetsOutput4)),
        //                                TotalAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.TotalAssetsOutput1)),
        //                                TotalAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.TotalAssetsOutput2)),
        //                                TotalAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.TotalAssetsOutput3)),
        //                                TotalAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_BalanceSheet_Assets_Final.TotalAssetsOutput4)),
        //                                ErrorCheck1 = nHB_BalanceSheet_Assets_Final.ErrorCheck1,
        //                                ErrorCheck2 = nHB_BalanceSheet_Assets_Final.ErrorCheck2,
        //                                ErrorCheck3 = nHB_BalanceSheet_Assets_Final.ErrorCheck3,
        //                                ErrorCheck4 = nHB_BalanceSheet_Assets_Final.ErrorCheck4
        //                            },
        //                            #endregion
        //                            #region NHB_Contingent_Liabilitiess
        //                            NHB_Contingent_Liabilities = new NHB_Contingent_Liabilitiess()
        //                            {
        //                                LiabilityOnSecuritisationContracts1 = nHB_ContingentLiabilities_Final.LiabilityOnSecuritisationContracts1,
        //                                LiabilityOnSecuritisationContracts2 = nHB_ContingentLiabilities_Final.LiabilityOnSecuritisationContracts2,
        //                                LiabilityOnSecuritisationContracts3 = nHB_ContingentLiabilities_Final.LiabilityOnSecuritisationContracts3,
        //                                LiabilityOnSecuritisationContracts4 = nHB_ContingentLiabilities_Final.LiabilityOnSecuritisationContracts4,
        //                                GuaranteesGiven1 = nHB_ContingentLiabilities_Final.GuaranteesGiven1,
        //                                GuaranteesGiven2 = nHB_ContingentLiabilities_Final.GuaranteesGiven2,
        //                                GuaranteesGiven3 = nHB_ContingentLiabilities_Final.GuaranteesGiven3,
        //                                GuaranteesGiven4 = nHB_ContingentLiabilities_Final.GuaranteesGiven4,
        //                                LiabilityOnPartlyPaidInvestments1 = nHB_ContingentLiabilities_Final.LiabilityOnPartlyPaidInvestments1,
        //                                LiabilityOnPartlyPaidInvestments2 = nHB_ContingentLiabilities_Final.LiabilityOnPartlyPaidInvestments2,
        //                                LiabilityOnPartlyPaidInvestments3 = nHB_ContingentLiabilities_Final.LiabilityOnPartlyPaidInvestments3,
        //                                LiabilityOnPartlyPaidInvestments4 = nHB_ContingentLiabilities_Final.LiabilityOnPartlyPaidInvestments4,
        //                                LiabilityOnForeignExchangContracts1 = nHB_ContingentLiabilities_Final.LiabilityOnForeignExchangContracts1,
        //                                LiabilityOnForeignExchangContracts2 = nHB_ContingentLiabilities_Final.LiabilityOnForeignExchangContracts2,
        //                                LiabilityOnForeignExchangContracts3 = nHB_ContingentLiabilities_Final.LiabilityOnForeignExchangContracts3,
        //                                LiabilityOnForeignExchangContracts4 = nHB_ContingentLiabilities_Final.LiabilityOnForeignExchangContracts4,
        //                                LiabilityOnDerivativeContracts1 = nHB_ContingentLiabilities_Final.LiabilityOnDerivativeContracts1,
        //                                LiabilityOnDerivativeContracts2 = nHB_ContingentLiabilities_Final.LiabilityOnDerivativeContracts2,
        //                                LiabilityOnDerivativeContracts3 = nHB_ContingentLiabilities_Final.LiabilityOnDerivativeContracts3,
        //                                LiabilityOnDerivativeContracts4 = nHB_ContingentLiabilities_Final.LiabilityOnDerivativeContracts4,
        //                                EndorsementsAndAcceptancesAndOtherObligations1 = nHB_ContingentLiabilities_Final.EndorsementsAndAcceptancesAndOtherObligations1,
        //                                EndorsementsAndAcceptancesAndOtherObligations2 = nHB_ContingentLiabilities_Final.EndorsementsAndAcceptancesAndOtherObligations2,
        //                                EndorsementsAndAcceptancesAndOtherObligations3 = nHB_ContingentLiabilities_Final.EndorsementsAndAcceptancesAndOtherObligations3,
        //                                EndorsementsAndAcceptancesAndOtherObligations4 = nHB_ContingentLiabilities_Final.EndorsementsAndAcceptancesAndOtherObligations4,
        //                                ClaimsNotAcknowledgedAsDebts1 = nHB_ContingentLiabilities_Final.ClaimsNotAcknowledgedAsDebts1,
        //                                ClaimsNotAcknowledgedAsDebts2 = nHB_ContingentLiabilities_Final.ClaimsNotAcknowledgedAsDebts2,
        //                                ClaimsNotAcknowledgedAsDebts3 = nHB_ContingentLiabilities_Final.ClaimsNotAcknowledgedAsDebts3,
        //                                ClaimsNotAcknowledgedAsDebts4 = nHB_ContingentLiabilities_Final.ClaimsNotAcknowledgedAsDebts4,
        //                                OtherItems1 = nHB_ContingentLiabilities_Final.OtherItems1,
        //                                OtherItems2 = nHB_ContingentLiabilities_Final.OtherItems2,
        //                                OtherItems3 = nHB_ContingentLiabilities_Final.OtherItems3,
        //                                OtherItems4 = nHB_ContingentLiabilities_Final.OtherItems4
        //                            },
        //                            #endregion
        //                            #region NHB_OtherBalanceSheet_Disclosuress
        //                            NHB_OtherBalanceSheet_Disclosures = new NHB_OtherBalanceSheet_Disclosuress()
        //                            {
        //                                TierICapitalRatioPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TierICapitalRatioPercentage1),
        //                                TierICapitalRatioPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TierICapitalRatioPercentage2),
        //                                TierICapitalRatioPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TierICapitalRatioPercentage3),
        //                                TierICapitalRatioPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TierICapitalRatioPercentage4),
        //                                TierIICapitalRatioPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TierIICapitalRatioPercentage1),
        //                                TierIICapitalRatioPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TierIICapitalRatioPercentage2),
        //                                TierIICapitalRatioPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TierIICapitalRatioPercentage3),
        //                                TierIICapitalRatioPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TierIICapitalRatioPercentage4),
        //                                TotalCapitalRatioPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TotalCapitalRatioPercentage1),
        //                                TotalCapitalRatioPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TotalCapitalRatioPercentage2),
        //                                TotalCapitalRatioPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TotalCapitalRatioPercentage3),
        //                                TotalCapitalRatioPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TotalCapitalRatioPercentage4),
        //                                ThirdPartyOriginationsAndServicingPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.ThirdPartyOriginationsAndServicingPercentage1),
        //                                ThirdPartyOriginationsAndServicingPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.ThirdPartyOriginationsAndServicingPercentage2),
        //                                ThirdPartyOriginationsAndServicingPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.ThirdPartyOriginationsAndServicingPercentage3),
        //                                ThirdPartyOriginationsAndServicingPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.ThirdPartyOriginationsAndServicingPercentage4),
        //                                SecuritisedPortfolioOutstandingPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.SecuritisedPortfolioOutstandingPercentage1),
        //                                SecuritisedPortfolioOutstandingPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.SecuritisedPortfolioOutstandingPercentage2),
        //                                SecuritisedPortfolioOutstandingPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.SecuritisedPortfolioOutstandingPercentage3),
        //                                SecuritisedPortfolioOutstandingPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.SecuritisedPortfolioOutstandingPercentage4),
        //                                TotalManagedAssetsPercentage1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TotalManagedAssetsPercentage1),
        //                                TotalManagedAssetsPercentage2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TotalManagedAssetsPercentage2),
        //                                TotalManagedAssetsPercentage3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TotalManagedAssetsPercentage3),
        //                                TotalManagedAssetsPercentage4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.TotalManagedAssetsPercentage4),
        //                                GrossNPAs1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.GrossNPAs1),
        //                                GrossNPAs2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.GrossNPAs2),
        //                                GrossNPAs3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.GrossNPAs3),
        //                                GrossNPAs4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.GrossNPAs4),
        //                                SpecificLossProvisionsHeld1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.SpecificLossProvisionsHeld1),
        //                                SpecificLossProvisionsHeld2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.SpecificLossProvisionsHeld2),
        //                                SpecificLossProvisionsHeld3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.SpecificLossProvisionsHeld3),
        //                                SpecificLossProvisionsHeld4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.SpecificLossProvisionsHeld4),
        //                                NetNPAs1 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.NetNPAs1),
        //                                NetNPAs2 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.NetNPAs2),
        //                                NetNPAs3 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.NetNPAs3),
        //                                NetNPAs4 = Convert.ToString(nHB_OtherBalanceSheet_Disclosures_Final.NetNPAs4),
        //                            },
        //                            #endregion
        //                            #region  NHB_ProfitAndLossStatement
        //                            NHB_ProfitAndLossStatements = new NHB_ProfitAndLossStatementss()
        //                            {
        //                                PeriodEndingDate1_ProfitAndLoss = nHB_ProfitAndLossStatement_Final.PeriodEndingDate1,
        //                                PeriodEndingDate2_ProfitAndLoss = nHB_ProfitAndLossStatement_Final.PeriodEndingDate2,
        //                                PeriodEndingDate3_ProfitAndLoss = nHB_ProfitAndLossStatement_Final.PeriodEndingDate3,
        //                                PeriodEndingDate4_ProfitAndLoss = nHB_ProfitAndLossStatement_Final.PeriodEndingDate4,
        //                                IncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeOutput1)),
        //                                IncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeOutput2)),
        //                                IncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeOutput3)),
        //                                IncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeOutput4)),
        //                                InterestIncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeOutput1)),
        //                                InterestIncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeOutput2)),
        //                                InterestIncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeOutput3)),
        //                                InterestIncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeOutput4)),
        //                                InterestonHousingLoansIndividuals1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestonHousingLoansIndividuals1)),
        //                                InterestonHousingLoansIndividuals2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestonHousingLoansIndividuals2)),
        //                                InterestonHousingLoansIndividuals3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestonHousingLoansIndividuals3)),
        //                                InterestonHousingLoansIndividuals4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestonHousingLoansIndividuals4)),
        //                                InterestonHousingLoansCorporateBodies1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestonHousingLoansCorporateBodies1)),
        //                                InterestonHousingLoansCorporateBodies2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestonHousingLoansCorporateBodies2)),
        //                                InterestonHousingLoansCorporateBodies3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestonHousingLoansCorporateBodies3)),
        //                                InterestonHousingLoansCorporateBodies4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestonHousingLoansCorporateBodies4)),
        //                                OtherInterestIncome1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherInterestIncome1)),
        //                                OtherInterestIncome2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherInterestIncome2)),
        //                                OtherInterestIncome3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherInterestIncome3)),
        //                                OtherInterestIncome4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherInterestIncome4)),
        //                                IncomeFromInvestmentsShortTerm1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeFromInvestmentsShortTerm1)),
        //                                IncomeFromInvestmentsShortTerm2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeFromInvestmentsShortTerm2)),
        //                                IncomeFromInvestmentsShortTerm3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeFromInvestmentsShortTerm3)),
        //                                IncomeFromInvestmentsShortTerm4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeFromInvestmentsShortTerm4)),
        //                                IncomeFromInvestmentsLongTerm1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeFromInvestmentsLongTerm1)),
        //                                IncomeFromInvestmentsLongTerm2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeFromInvestmentsLongTerm2)),
        //                                IncomeFromInvestmentsLongTerm3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeFromInvestmentsLongTerm3)),
        //                                IncomeFromInvestmentsLongTerm4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.IncomeFromInvestmentsLongTerm4)),
        //                                OtherOperatingIncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherOperatingIncomeOutput1)),
        //                                OtherOperatingIncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherOperatingIncomeOutput2)),
        //                                OtherOperatingIncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherOperatingIncomeOutput3)),
        //                                OtherOperatingIncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherOperatingIncomeOutput4)),
        //                                FeesReceived1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.FeesReceived1)),
        //                                FeesReceived2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.FeesReceived2)),
        //                                FeesReceived3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.FeesReceived3)),
        //                                FeesReceived4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.FeesReceived4)),
        //                                CommisionsAndExchangeAndBrokerage1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.CommisionsAndExchangeAndBrokerage1)),
        //                                CommisionsAndExchangeAndBrokerage2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.CommisionsAndExchangeAndBrokerage2)),
        //                                CommisionsAndExchangeAndBrokerage3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.CommisionsAndExchangeAndBrokerage3)),
        //                                CommisionsAndExchangeAndBrokerage4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.CommisionsAndExchangeAndBrokerage4)),
        //                                ProfitLossSaleInvestments1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossSaleInvestments1)),
        //                                ProfitLossSaleInvestments2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossSaleInvestments2)),
        //                                ProfitLossSaleInvestments3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossSaleInvestments3)),
        //                                ProfitLossSaleInvestments4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossSaleInvestments4)),
        //                                ProfitLossSaleAssets1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossSaleAssets1)),
        //                                ProfitLossSaleAssets2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossSaleAssets2)),
        //                                ProfitLossSaleAssets3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossSaleAssets3)),
        //                                ProfitLossSaleAssets4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossSaleAssets4)),
        //                                ProfitLossExchangeTransactions1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossExchangeTransactions1)),
        //                                ProfitLossExchangeTransactions2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossExchangeTransactions2)),
        //                                ProfitLossExchangeTransactions3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossExchangeTransactions3)),
        //                                ProfitLossExchangeTransactions4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitLossExchangeTransactions4)),
        //                                OtherServiceIncome1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherServiceIncome1)),
        //                                OtherServiceIncome2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherServiceIncome2)),
        //                                OtherServiceIncome3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherServiceIncome3)),
        //                                OtherServiceIncome4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherServiceIncome4)),
        //                                GainOnSaleOfSecuritisedAssets1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.GainOnSaleOfSecuritisedAssets1)),
        //                                GainOnSaleOfSecuritisedAssets2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.GainOnSaleOfSecuritisedAssets2)),
        //                                GainOnSaleOfSecuritisedAssets3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.GainOnSaleOfSecuritisedAssets3)),
        //                                GainOnSaleOfSecuritisedAssets4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.GainOnSaleOfSecuritisedAssets4)),
        //                                OtherNonOperatingIncome1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherNonOperatingIncome1)),
        //                                OtherNonOperatingIncome2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherNonOperatingIncome2)),
        //                                OtherNonOperatingIncome3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherNonOperatingIncome3)),
        //                                OtherNonOperatingIncome4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherNonOperatingIncome4)),
        //                                ExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ExpenseOutput1)),
        //                                ExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ExpenseOutput2)),
        //                                ExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ExpenseOutput3)),
        //                                ExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ExpenseOutput4)),
        //                                InterestExpenseOutput1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestExpenseOutput1)),
        //                                InterestExpenseOutput2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestExpenseOutput2)),
        //                                InterestExpenseOutput3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestExpenseOutput3)),
        //                                InterestExpenseOutput4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestExpenseOutput4)),
        //                                InterestOnDeposits1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestOnDeposits1)),
        //                                InterestOnDeposits2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestOnDeposits2)),
        //                                InterestOnDeposits3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestOnDeposits3)),
        //                                InterestOnDeposits4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestOnDeposits4)),
        //                                InterestOnBorrowings1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestOnBorrowings1)),
        //                                InterestOnBorrowings2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestOnBorrowings2)),
        //                                InterestOnBorrowings3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestOnBorrowings3)),
        //                                InterestOnBorrowings4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestOnBorrowings4)),
        //                                InterestPaidOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestPaidOutput1)),
        //                                InterestPaidOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestPaidOutput2)),
        //                                InterestPaidOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestPaidOutput3)),
        //                                InterestPaidOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.InterestPaidOutput4)),
        //                                OtherFinancialCharges1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherFinancialCharges1)),
        //                                OtherFinancialCharges2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherFinancialCharges2)),
        //                                OtherFinancialCharges3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherFinancialCharges3)),
        //                                OtherFinancialCharges4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherFinancialCharges4)),
        //                                PersonnelExpenses1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.PersonnelExpenses1)),
        //                                PersonnelExpenses2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.PersonnelExpenses2)),
        //                                PersonnelExpenses3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.PersonnelExpenses3)),
        //                                PersonnelExpenses4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.PersonnelExpenses4)),
        //                                OperatingExpensesOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OperatingExpensesOutput1)),
        //                                OperatingExpensesOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OperatingExpensesOutput2)),
        //                                OperatingExpensesOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OperatingExpensesOutput3)),
        //                                OperatingExpensesOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OperatingExpensesOutput4)),
        //                                OperatingExpenses1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OperatingExpenses1)),
        //                                OperatingExpenses2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OperatingExpenses2)),
        //                                OperatingExpenses3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OperatingExpenses3)),
        //                                OperatingExpenses4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OperatingExpenses4)),
        //                                MiscellaneousExpensesWrittenOff1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.MiscellaneousExpensesWrittenOff1)),
        //                                MiscellaneousExpensesWrittenOff2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.MiscellaneousExpensesWrittenOff2)),
        //                                MiscellaneousExpensesWrittenOff3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.MiscellaneousExpensesWrittenOff3)),
        //                                MiscellaneousExpensesWrittenOff4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.MiscellaneousExpensesWrittenOff4)),
        //                                ProvisionForImpairmentInValueOfAssets1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForImpairmentInValueOfAssets1)),
        //                                ProvisionForImpairmentInValueOfAssets2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForImpairmentInValueOfAssets2)),
        //                                ProvisionForImpairmentInValueOfAssets3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForImpairmentInValueOfAssets3)),
        //                                ProvisionForImpairmentInValueOfAssets4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForImpairmentInValueOfAssets4)),
        //                                Depreciation1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.Depreciation1)),
        //                                Depreciation2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.Depreciation2)),
        //                                Depreciation3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.Depreciation3)),
        //                                Depreciation4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.Depreciation4)),
        //                                LoanLosses1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.LoanLosses1)),
        //                                LoanLosses2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.LoanLosses2)),
        //                                LoanLosses3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.LoanLosses3)),
        //                                LoanLosses4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.LoanLosses4)),
        //                                ProvisionForLoanLosses1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForLoanLosses1)),
        //                                ProvisionForLoanLosses2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForLoanLosses2)),
        //                                ProvisionForLoanLosses3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForLoanLosses3)),
        //                                ProvisionForLoanLosses4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForLoanLosses4)),
        //                                ProvisionForInterestOnIncomeTaxRefund1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForInterestOnIncomeTaxRefund1)),
        //                                ProvisionForInterestOnIncomeTaxRefund2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForInterestOnIncomeTaxRefund2)),
        //                                ProvisionForInterestOnIncomeTaxRefund3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForInterestOnIncomeTaxRefund3)),
        //                                ProvisionForInterestOnIncomeTaxRefund4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForInterestOnIncomeTaxRefund4)),
        //                                ProvisionForBadDebtsWrittenBack1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForBadDebtsWrittenBack1)),
        //                                ProvisionForBadDebtsWrittenBack2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForBadDebtsWrittenBack2)),
        //                                ProvisionForBadDebtsWrittenBack3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForBadDebtsWrittenBack3)),
        //                                ProvisionForBadDebtsWrittenBack4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProvisionForBadDebtsWrittenBack4)),
        //                                OtherCreditAssetsWrittenOff1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherCreditAssetsWrittenOff1)),
        //                                OtherCreditAssetsWrittenOff2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherCreditAssetsWrittenOff2)),
        //                                OtherCreditAssetsWrittenOff3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherCreditAssetsWrittenOff3)),
        //                                OtherCreditAssetsWrittenOff4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherCreditAssetsWrittenOff4)),
        //                                OtherAdjustments1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherAdjustments1)),
        //                                OtherAdjustments2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherAdjustments2)),
        //                                OtherAdjustments3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherAdjustments3)),
        //                                OtherAdjustments4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.OtherAdjustments4)),
        //                                ProfitBeforeTaxOutput1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitBeforeTaxOutput1)),
        //                                ProfitBeforeTaxOutput2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitBeforeTaxOutput2)),
        //                                ProfitBeforeTaxOutput3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitBeforeTaxOutput3)),
        //                                ProfitBeforeTaxOutput4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitBeforeTaxOutput4)),
        //                                TaxExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.TaxExpenseOutput1)),
        //                                TaxExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.TaxExpenseOutput2)),
        //                                TaxExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.TaxExpenseOutput3)),
        //                                TaxExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.TaxExpenseOutput4)),
        //                                CurrentTax1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.CurrentTax1)),
        //                                CurrentTax2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.CurrentTax2)),
        //                                CurrentTax3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.CurrentTax3)),
        //                                CurrentTax4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.CurrentTax4)),
        //                                DeferredTax1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.DeferredTax1)),
        //                                DeferredTax2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.DeferredTax2)),
        //                                DeferredTax3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.DeferredTax3)),
        //                                DeferredTax4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.DeferredTax4)),
        //                                ProfitAfterTaxOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitAfterTaxOutput1)),
        //                                ProfitAfterTaxOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitAfterTaxOutput2)),
        //                                ProfitAfterTaxOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitAfterTaxOutput3)),
        //                                ProfitAfterTaxOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.ProfitAfterTaxOutput4)),
        //                                PreferenceDividend_Tax1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.PreferenceDividend_Tax1)),
        //                                PreferenceDividend_Tax2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.PreferenceDividend_Tax2)),
        //                                PreferenceDividend_Tax3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.PreferenceDividend_Tax3)),
        //                                PreferenceDividend_Tax4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.PreferenceDividend_Tax4)),
        //                                EquityDividend_Tax1 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.EquityDividend_Tax1)),
        //                                EquityDividend_Tax2 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.EquityDividend_Tax2)),
        //                                EquityDividend_Tax3 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.EquityDividend_Tax3)),
        //                                EquityDividend_Tax4 = Convert.ToString(Convert.ToDouble(nHB_ProfitAndLossStatement_Final.EquityDividend_Tax4)),
        //                            },
        //                            #endregion
        //                            #region  NHB_ALMStatementLatest
        //                            NHB_ALM_Statement_Latests = new NHB_ALM_Statement_Latests()
        //                            {
        //                                Statement_Date = nHB_ALMStatementLatest_Final.StatementDate,
        //                                Day1to14DaysInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Day1to14DaysInflow)),
        //                                Day1to14DaysOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Day1to14DaysOurflow)),
        //                                Day1to14DaysMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Day1to14DaysMismatch)),
        //                                Day14DaysTo1MonthInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Day14DaysTo1MonthInflow)),
        //                                Day14DaysTo1MonthOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Day14DaysTo1MonthOurflow)),
        //                                Day14DaysTo1MonthMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Day14DaysTo1MonthMismatch)),
        //                                Month1To2MonthsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month1To2MonthsInflow)),
        //                                Month1To2MonthsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month1To2MonthsOurflow)),
        //                                Month1To2MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month1To2MonthsMismatch)),
        //                                Month2To3MonthsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month2To3MonthsInflow)),
        //                                Month2To3MonthsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month2To3MonthsOurflow)),
        //                                Month2To3MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month2To3MonthsMismatch)),
        //                                Month3To6MonthsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month3To6MonthsInflow)),
        //                                Month3To6MonthsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month3To6MonthsOurflow)),
        //                                Month3To6MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month3To6MonthsMismatch)),
        //                                Month6MonthsTo1YearInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month6MonthsTo1YearInflow)),
        //                                Month6MonthsTo1YearOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month6MonthsTo1YearOurflow)),
        //                                Month6MonthsTo1YearMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Month6MonthsTo1YearMismatch)),
        //                                Year1To3YearsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year1To3YearsInflow)),
        //                                Year1To3YearsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year1To3YearsOurflow)),
        //                                Year1To3YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year1To3YearsMismatch)),
        //                                Year3To5YearsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year3To5YearsInflow)),
        //                                Year3To5YearsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year3To5YearsOurflow)),
        //                                Year3To5YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year3To5YearsMismatch)),
        //                                Year5To7YearsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year5To7YearsInflow)),
        //                                Year5To7YearsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year5To7YearsOurflow)),
        //                                Year5To7YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year5To7YearsMismatch)),
        //                                Year7To10YearsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year7To10YearsInflow)),
        //                                Year7To10YearsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year7To10YearsOurflow)),
        //                                Year7To10YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Year7To10YearsMismatch)),
        //                                Over10YearsInflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Over10YearsInflow)),
        //                                Over10YearsOurflow = Convert.ToString(Convert.ToDouble(nHB_ALMStatementLatest_Final.Over10YearsOurflow)),
        //                                Over10YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(nHB_ALMStatementLatest_Final.Over10YearsMismatch)),

        //                            },
        //                            #endregion
        //                            #region NHB_KeyRatio
        //                            NHB_KeyRatios = new NHB_KeyRatioss()
        //                            {
        //                                TotalAssets1 = nHB_KeyRatio_Final.TotalAssets1,
        //                                TotalAssets2 = nHB_KeyRatio_Final.TotalAssets2,
        //                                TotalAssets3 = nHB_KeyRatio_Final.TotalAssets3,
        //                                TotalAssets4 = nHB_KeyRatio_Final.TotalAssets4,
        //                                GrossNPAPercentage1 = nHB_KeyRatio_Final.GrossNPAPercentage1,
        //                                GrossNPAPercentage2 = nHB_KeyRatio_Final.GrossNPAPercentage2,
        //                                GrossNPAPercentage3 = nHB_KeyRatio_Final.GrossNPAPercentage3,
        //                                GrossNPAPercentage4 = nHB_KeyRatio_Final.GrossNPAPercentage4,
        //                                ALMMismatchPercentage1 = nHB_KeyRatio_Final.ALMMismatchPercentage1,
        //                                ALMMismatchPercentage2 = nHB_KeyRatio_Final.ALMMismatchPercentage2,
        //                                ALMMismatchPercentage3 = nHB_KeyRatio_Final.ALMMismatchPercentage3,
        //                                ALMMismatchPercentage4 = nHB_KeyRatio_Final.ALMMismatchPercentage4,
        //                                NetWorth1 = nHB_KeyRatio_Final.NetWorth1,
        //                                NetWorth2 = nHB_KeyRatio_Final.NetWorth2,
        //                                NetWorth3 = nHB_KeyRatio_Final.NetWorth3,
        //                                NetWorth4 = nHB_KeyRatio_Final.NetWorth4,
        //                                CRARPercentage1 = nHB_KeyRatio_Final.CRARPercentage1,
        //                                CRARPercentage2 = nHB_KeyRatio_Final.CRARPercentage2,
        //                                CRARPercentage3 = nHB_KeyRatio_Final.CRARPercentage3,
        //                                CRARPercentage4 = nHB_KeyRatio_Final.CRARPercentage4,
        //                                GearingPercentage1 = nHB_KeyRatio_Final.GearingPercentage1,
        //                                GearingPercentage2 = nHB_KeyRatio_Final.GearingPercentage2,
        //                                GearingPercentage3 = nHB_KeyRatio_Final.GearingPercentage3,
        //                                GearingPercentage4 = nHB_KeyRatio_Final.GearingPercentage4,
        //                                TangibleNWNetNPA1 = nHB_KeyRatio_Final.TangibleNWNetNPA1,
        //                                TangibleNWNetNPA2 = nHB_KeyRatio_Final.TangibleNWNetNPA2,
        //                                TangibleNWNetNPA3 = nHB_KeyRatio_Final.TangibleNWNetNPA3,
        //                                TangibleNWNetNPA4 = nHB_KeyRatio_Final.TangibleNWNetNPA4,
        //                                NetMarginPercentage1 = nHB_KeyRatio_Final.NetMarginPercentage1,
        //                                NetMarginPercentage2 = nHB_KeyRatio_Final.NetMarginPercentage2,
        //                                NetMarginPercentage3 = nHB_KeyRatio_Final.NetMarginPercentage3,
        //                                NetMarginPercentage4 = nHB_KeyRatio_Final.NetMarginPercentage4,
        //                                PATAverageFundsDeployedPercentage1 = nHB_KeyRatio_Final.PATAverageFundsDeployedPercentage1,
        //                                PATAverageFundsDeployedPercentage2 = nHB_KeyRatio_Final.PATAverageFundsDeployedPercentage2,
        //                                PATAverageFundsDeployedPercentage3 = nHB_KeyRatio_Final.PATAverageFundsDeployedPercentage3,
        //                                PATAverageFundsDeployedPercentage4 = nHB_KeyRatio_Final.PATAverageFundsDeployedPercentage4,
        //                                PATAverageNetWorthPercentage1 = nHB_KeyRatio_Final.PATAverageNetWorthPercentage1,
        //                                PATAverageNetWorthPercentage2 = nHB_KeyRatio_Final.PATAverageNetWorthPercentage2,
        //                                PATAverageNetWorthPercentage3 = nHB_KeyRatio_Final.PATAverageNetWorthPercentage3,
        //                                PATAverageNetWorthPercentage4 = nHB_KeyRatio_Final.PATAverageNetWorthPercentage4,
        //                            },
        //                            #endregion
        //                            #region NHB_Industry_RiskInputs
        //                            NHB_Industry_RiskInputs = new NHB_Industry_RiskInputss()
        //                            {
        //                                FinancialPerformanceofPlayer = nHB_IndustryRiskInputs_Final.FinancialPerformanceofPlayer.Trim(),
        //                                ExtentOfCompetition = nHB_IndustryRiskInputs_Final.ExtentOfCompetition.Trim(),
        //                                ProspectOfRealEstateMarket = nHB_IndustryRiskInputs_Final.ProspectOfRealEstateMarket.Trim(),
        //                                RegulatoryImpact = nHB_IndustryRiskInputs_Final.RegulatoryImpact.Trim()
        //                            },
        //                            #endregion
        //                            #region NHB_Business_RiskInputs
        //                            NHB_Business_RiskInputs = new NHB_Business_RiskInputss()
        //                            {
        //                                RankOfMarketPosition = nHB_BusinessRiskInputs_Final.RankOfMarketPosition.Trim(),
        //                                GeographicalDiversification = nHB_BusinessRiskInputs_Final.GeographicalDiversification.Trim(),
        //                                ProductMix = nHB_BusinessRiskInputs_Final.ProductMix.Trim(),
        //                                CustomerMix = nHB_BusinessRiskInputs_Final.CustomerMix.Trim(),
        //                                CostOfResources = nHB_BusinessRiskInputs_Final.CostOfResources.Trim(),
        //                                TotalAssetGrowth = nHB_BusinessRiskInputs_Final.TotalAssetGrowth.Trim(),
        //                                DiversificationOfFundingProfile = nHB_BusinessRiskInputs_Final.DiversificationOfFundingProfile.Trim()
        //                            },
        //                            #endregion
        //                            #region NHB_Financial_RiskInputs
        //                            NHB_Financial_RiskInputs = new NHB_Financial_RiskInputss()
        //                            {
        //                                CompanysAbility = nHB_FinancialRiskInputs_Final.CompanysAbility.Trim()
        //                            },
        //                            #endregion
        //                            #region NHB_Management_RiskInputs
        //                            NHB_Management_RiskInputs = new NHB_Management_RiskInputss()
        //                            {
        //                                AbilityToMeetRevenueProjection = nHB_ManagementRiskInputs_Final.AbilityToMeetRevenueProjection.Trim(),
        //                                AbilityToMeetProfitProjection = nHB_ManagementRiskInputs_Final.AbilityToMeetProfitProjection.Trim(),
        //                                PastPaymentRecord = nHB_ManagementRiskInputs_Final.PastPaymentRecord.Trim(),
        //                                RiskManagementSystem = nHB_ManagementRiskInputs_Final.RiskManagementSystem.Trim(),
        //                                ManagementCredibility = nHB_ManagementRiskInputs_Final.ManagementCredibility.Trim(),
        //                                ManagementExperienceAndCompetence = nHB_ManagementRiskInputs_Final.ManagementExperienceAndCompetence.Trim(),
        //                                RiskAppetite = nHB_ManagementRiskInputs_Final.RiskAppetite.Trim(),
        //                            },
        //                            #endregion
        //                            #region NHB_NotchUp_CriteriaInputs
        //                            NHB_NotchUp_CriteriaInputs = new NHB_NotchUp_CriteriaInputss()
        //                            {
        //                                ShareholdingStructure = nHB_NotchUpCriteriaInput_Final.ShareholdingStructure.Trim(),
        //                                ManagementControl = nHB_NotchUpCriteriaInput_Final.ManagementControl.Trim(),
        //                                StatedPostureOfTheParent = nHB_NotchUpCriteriaInput_Final.StatedPostureOfTheParent.Trim(),
        //                                PastTrackRecord = nHB_NotchUpCriteriaInput_Final.PastTrackRecord.Trim(),
        //                                BrandName = nHB_NotchUpCriteriaInput_Final.BrandName.Trim()
        //                            },
        //                            #endregion

        //                        };
        //                    }

        //                }

        //            }
        //            else
        //            {
        //                ViewBag.Error = true;
        //                ViewBag.Message = "Company Details not found";
        //            }
        //        }
        //        else
        //        {
        //            ViewBag.Error = true;
        //            ViewBag.Message = "Details Not Registered with the selected company";
        //        }
        //    }
        //    catch (Exception exception)
        //    {
        //        ErrorLogger.LogError(exception);
        //        message = exception.Message;
        //    }

        //    return Json(new
        //    {
        //        Status = status,
        //        Result = riskModelExcelEntity,
        //    }, JsonRequestBehavior.AllowGet);
        //}

        /// <summary>
        /// Import Risk Model Excel Data 
        /// </summary>
        /// <param name="companyExcelFile"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPost]
        public ActionResult ImporRiskModelData(RiskModelExcelEntity riskModelExcelEntity)
        {
            bool success = false;
            string message = string.Empty;
            int userID = SessionValue.UserID;
            RiskModelExcelEntity riskModelResult = new RiskModelExcelEntity();
            try
            {
                CompanyDAL companyDAL = new CompanyDAL();
                string fileName = Path.GetFileName(riskModelExcelEntity.ExcelFile.FileName);
                string copyFile = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}{1}", ConfigManager.GetExcelSheetFileCopyPath(), fileName));
                string copyFilePath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("{0}", ConfigManager.GetExcelSheetFileCopyPath()));

                System.IO.Directory.CreateDirectory(copyFilePath);
                if (System.IO.Directory.Exists(copyFilePath))
                {
                    if (System.IO.File.Exists(copyFile))
                    {
                        System.IO.File.Delete(copyFile);
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }
                    else
                    {
                        riskModelExcelEntity.ExcelFile.SaveAs(copyFile);
                        SessionValue.RISKMODEL_FILE_PATH = copyFile;
                    }

                    riskModelResult = companyDAL.ImportCompanyDetailsFromExcel(fileName, copyFile, userID);
                    if (riskModelResult != null)
                    {
                        success = true;
                        message = "Data Fetched From Excel Sheet";
                    }
                    else
                    {
                        success = false;
                        message = "Unable to fetch Excel Sheet Data";
                    }
                }

            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                success = false;
                message = exception.Message;

            }
            finally
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            return Json(new
            {
                Status = success,
                Message = message,
                Result = riskModelResult,
            }, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpPost]
        public ActionResult DownloadCompanyOutputDetails(int CompanyId, string CreatedDateTime)
        {
            bool status = false;
            string message = string.Empty;
            string fileName = string.Empty;
            int userID = SessionValue.UserID;
            try
            {
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByID(CompanyId);
                string orignalTemplateFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetOutputTemplateFilePath()));
                string userTemplateFilePath = Server.MapPath(string.Format("~{0}//OutputReport_{1}_{2}.xlsx", ConfigManager.GetOutputTemplateCopyFilePath(), companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss")));
                System.IO.File.Copy(orignalTemplateFilePath, userTemplateFilePath, true);
                fileName = string.Format("OutputReport_{0}_{1}.xlsx", companyName, DateTime.Now.ToString("ddMMyyyy_HHmmss"));
                //status = companyDAL.GetOutputDetails(CompanyId, Convert.ToDateTime(CreatedDateTime), userTemplateFilePath);

            }
            catch (Exception exception)
            {
                throw exception;
            }

            return Json(new
            {
                fileName = fileName,
                status = status,
            }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DownloadOutputExcelFile(string fileName)
        {
            string userTemplateFilePath = Server.MapPath(string.Format("~{0}//{1}", ConfigManager.GetOutputTemplateCopyFilePath(), fileName));
            byte[] fileByteArray = System.IO.File.ReadAllBytes(userTemplateFilePath);
            return File(fileByteArray, "application/vnd.ms-excel", fileName);
        }
    }

}
