﻿using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndRa.RiskModel.Controllers
{
    public class DashboardController : Controller
    {
        CommonDAL commonDAL = new CommonDAL();

        // GET: Dashboard
        public ActionResult Index()
        {
            if (Session["Username"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        [HttpGet]
        public JsonResult GetNHBDetailList()
        {
            int roleID = SessionValue.RoleID;
            int userID = SessionValue.UserID;

            var data = commonDAL.GetNHBDetailList(roleID,userID);
            List<DashboardAnalystEntity> result = data.ToList();
            return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult SelectModel(int id, int modelId)
        {
            string controllerMethod = "ReadRiskModelExcelFile";
            var enumDisplayStatus = (ModelsEnum)modelId;
            string modelName= enumDisplayStatus.ToString();
            try
            {
                return RedirectToAction(controllerMethod, modelName, new
                {
                    detailsId = id,
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            return View();
        }

    }
}