﻿using IndRa.RiskModel.DAL;
using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndRa.RiskModel.Controllers
{
    public class DashboardAdminController : Controller
    {
        CommonDAL commonDAL = new CommonDAL();
        ReportsDAL reportsDAL = new ReportsDAL();

        // GET: Dashboard
        public ActionResult Index()
        {
            if (Session["Username"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            return View();
        }

        [HttpGet]
        public JsonResult GetPendingApprovalList()
        {
            int roleID = SessionValue.RoleID;
            int userID = SessionValue.UserID;
            userID = -1;

            var data = commonDAL.GetPendingApprovalList(roleID, userID);
            List<DashboardAnalystEntity> result = data.ToList();
            return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetApprovalListByDetailsId(int detailsId)
        {
            int roleID = SessionValue.RoleID;
            int userID = SessionValue.UserID;
            userID = -1;

            var data = commonDAL.GetApprovalListByDetailsId(userID, detailsId);
            List<DashboardAnalystEntity> result = data.ToList();
            return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetEntityAssignedAnalystList(string searchText)
        {
            int roleID = SessionValue.RoleID;
            List<AnalystEntity> result = commonDAL.GetEntityAnalystList(searchText);
            return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
        }

        //[HttpGet]
        //public string GetRecentActivityList()
        //{
        //    string fromDate = DateTime.Now.AddDays(-7).ToShortDateString();
        //    string toDate = DateTime.Now.ToShortDateString();

        //    DataTable dataTable = reportsDAL.GetCompanylog(fromDate, toDate);
        //    List<CompanyEntity> result = CommonDAL.ConvertDataTable<CompanyEntity>(dataTable);

        //    return JsonConvert.SerializeObject(new { aaData = result });
        //}

        [HttpGet]
        public JsonResult GetRecentCompanyList()
        {
            string fromDate = DateTime.Now.AddDays(-120).ToShortDateString();
            string toDate = DateTime.Now.ToShortDateString();

            List<CompanyEntity> result = commonDAL.GetRecentCompanyList(fromDate, toDate);
            return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult SelectModel(int id, int modelId,short? logId)
        {
            string controllerMethod = "ReadRiskModelExcelFile";
            var enumDisplayStatus = (ModelsEnum)modelId;
            string modelName = enumDisplayStatus.ToString();
            try
            {
                return RedirectToAction(controllerMethod, modelName, new
                {
                    detailsId = id,
                    logId = logId,
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            return View();
        }

        [HttpGet]
        public JsonResult GetEntityAnalystList(string searchText)
        {
            int roleID = SessionValue.RoleID;
            List<AnalystEntity> result = commonDAL.GetEntityAnalystList(searchText);
            return Json(new { aaData = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult SelectEntityModel(int id, int modelId)
        {
            string controllerMethod = "ReadRiskModelExcelFile";
            var enumDisplayStatus = (ModelsEnum)modelId;
            string modelName = enumDisplayStatus.ToString();
            try
            {
                return RedirectToAction(controllerMethod, modelName, new
                {
                    detailsId = id,
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            return View();
        }

    }
}