﻿using IndRa.RiskModel.DAL.DAL;
using IndRa.RiskModel.DAL.Entities;
using IndRa.RiskModel.Helpers;
using Microsoft.Office.Interop.Excel;
using System;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using Extensionmethod=IndRa.RiskModel.DAL.Helpers;

namespace IndRa.RiskModel.Controllers
{
    public class HomeController : Controller
    {
        [Authorize]
        public ActionResult Index()
        {
            return RedirectToAction("ReadRiskModelExcelFile");
        }

        [Authorize]
        public ActionResult ReadRiskModelExcelFile()
        {
            RiskModelExcelEntity riskModelExcelEntity = new RiskModelExcelEntity();
            CompanyDAL companyDAL = new CompanyDAL();
            try
            {
                int roleID = SessionValue.RoleID;
                int userID = SessionValue.UserID;

                ViewBag.Companies = DropDownValue.GetCompaniesList((int)ModelsEnum.HFC,roleID,userID);
                ViewBag.Locations = DropDownValue.GetLocationsList();
                ViewBag.YesorNoStatus = DropDownValue.GetYesorNoStatus();
                ViewBag.LiablitiliesType = DropDownValue.GetLiabilitiesTypeList();
                ViewBag.FinancialPerformanceOfPlayers = DropDownValue.GetFinancialPerformanceOfPlayers();
                ViewBag.ExtentOfCompetition = DropDownValue.GetExtentOfCompetition();
                ViewBag.ProspectOfRealEstateMarket = DropDownValue.GetProspectOfRealEstateMarket();
                ViewBag.RegulatoryImpact = DropDownValue.GetRegulatoryImpactGovernmentPolicy();
                ViewBag.RankOfMarketPosition = DropDownValue.GetRankOfMarketPosition();
                ViewBag.GeographicalDiversification = DropDownValue.GetGeographicalDiversification();
                ViewBag.ProductMix = DropDownValue.GetProductMixHousingLoanvsLAP();
                ViewBag.CustomerMix = DropDownValue.GetCustomerMixSalariedPeopleVsOthers();
                ViewBag.CostOfResources = DropDownValue.GetCostOfResources();
                ViewBag.TotalAssetGrowth = DropDownValue.GetTotalAssetGrowth();
                ViewBag.DiversificationOfFundingProfile = DropDownValue.GetDiversificationOfFundingProfile();
                ViewBag.CompanysAbility = DropDownValue.GetAbilityOftheCompanytoRaisefundsandLiquidityManagement();
                ViewBag.AbilitytoMeetAchievementofRevenueProjections = DropDownValue.GetAbilitytoMeetAchievementofRevenueProjections();
                ViewBag.AbilitytoMeetAchievementOfProfitProjections = DropDownValue.GetAbilitytoMeetAchievementOfProfitProjections();
                ViewBag.PastPaymentRecordandTrackRecord = DropDownValue.GetPastPaymentRecordandTrackRecord();
                ViewBag.RiskManagementSystem = DropDownValue.GetRiskManagementSystem();
                ViewBag.ManagementCredibility = DropDownValue.GetManagementCredibility();
                ViewBag.ManagementExperienceAndCompetence = DropDownValue.GetManagementExperienceAndCompetence();
                ViewBag.RiskAppetite = DropDownValue.GetRiskAppetite();
                ViewBag.NetMargin = DropDownValue.GetNetMargin();
                ViewBag.PATAverageFundsDeployed = DropDownValue.GetPATAverageFundsDeployed();
                ViewBag.PATAverageNetWorth = DropDownValue.GetPATAverageNetWorth();
                ViewBag.OwnershipShareholdingStructure = DropDownValue.GetOwnershipShareholdingStructure();
                ViewBag.ManagementControl = DropDownValue.GetManagementControl();
                ViewBag.StatedPostureOftheParent = DropDownValue.GetStatedPostureOftheParent();
                ViewBag.PastTrackRecord = DropDownValue.GetPastTrackRecord();
                ViewBag.BrandName = DropDownValue.GetBrandName();

                // Check file path in session object
                string indRaRiskModelFilePath = SessionValue.RISKMODEL_FILE_PATH;
                if (!string.IsNullOrWhiteSpace(indRaRiskModelFilePath) && System.IO.File.Exists(indRaRiskModelFilePath))
                {
                    //mWorkBook = xlApp.Workbooks.Open(indRaRiskModelFilePath, 0, false, 5, "", "", true, XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                    SessionValue.RISKMODEL_FILE_PATH = indRaRiskModelFilePath;
                }
                else
                {
                    var orignalFilePath = Server.MapPath(string.Format("~{0}", ConfigManager.GetExcelFilePath()));
                    FileInfo file = new FileInfo(orignalFilePath);
                    string path = file.Directory.ToString();

                    string userTempFilePath = string.Format("{0}\\NHB_HFC_Model_{1}.xlsx", path, Guid.NewGuid());
                    System.IO.File.Copy(orignalFilePath, userTempFilePath, true);
                    SessionValue.RISKMODEL_FILE_PATH = userTempFilePath;

                    //mWorkBook = xlApp.Workbooks.Open(userTempFilePath, 0, false, 5, "", "", true, XlPlatform.xlWindows, "", true, false, 0, true, false, false);

                }
            }
            catch (Exception exception)
            {
                ErrorLogger.LogError(exception, this);
                return View("Error");
            }
            return View();
        }

        //public ActionResult SaveCompanyDetails(RiskModelExcelEntity riskModelExcelEntity)
        //{
        //    int userId = SessionValue.UserID;
        //    int roleId = SessionValue.RoleID;
        //    int detailID = 0;
        //    ViewBag.Error = "";
        //    CompanyDAL companyDAL = new CompanyDAL();
        //    bool status = false;
        //    string message = string.Empty;
        //    Workbook mWorkBook = null;
        //    Sheets mWorkSheets = null;
        //    Worksheet mWSheet = null;
        //    Microsoft.Office.Interop.Excel.Application xlApp = null;
        //    try
        //    {
        //        xlApp = new Microsoft.Office.Interop.Excel.Application();
        //        object misValue = System.Reflection.Missing.Value;
        //        xlApp.DisplayAlerts = false;
        //        xlApp.EditDirectlyInCell = true;
        //        xlApp.EnableEvents = true;
        //        string riskModelFilePath = SessionValue.RISKMODEL_FILE_PATH;

        //        if (riskModelExcelEntity.ButtonValue == "SaveAsDraft")
        //        {
        //            if (!string.IsNullOrWhiteSpace(riskModelFilePath))
        //            {
        //                mWorkBook = xlApp.Workbooks.Open(riskModelFilePath, 0, false, 5, "", "", true, XlPlatform.xlWindows, "", true, false, 0, true, false, false);
        //                mWorkSheets = mWorkBook.Worksheets;
        //                //Get the already exists sheet
        //                mWSheet = (Worksheet)mWorkSheets.get_Item(1);

        //                if (riskModelExcelEntity != null)
        //                {
        //                    #region NHB_Details

        //                    mWSheet.Cells[1, 2] = riskModelExcelEntity.DateOfInput;
        //                    mWSheet.Cells[2, 2] = riskModelExcelEntity.CompanyId;
        //                    string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
        //                    mWSheet.Cells[3, 2] = companyName;
        //                    string location = companyDAL.GetLocationByID(riskModelExcelEntity.LocationId);
        //                    mWSheet.Cells[4, 2] = location;
        //                    mWSheet.Cells[5, 2] = riskModelExcelEntity.FinancialYearEndingDate;
        //                    mWSheet.Cells[6, 2] = riskModelExcelEntity.CurrencyUnits;
        //                    mWSheet.Cells[7, 2] = riskModelExcelEntity.ParentCompanyIsExist;
        //                    string parentCompanyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.ParentCompanyId);
        //                    mWSheet.Cells[8, 2] = parentCompanyName;
        //                    mWSheet.Cells[9, 2] = riskModelExcelEntity.ParentRating;

        //                    #endregion

        //                    #region NHB_BalanceSheets_Liabilities

        //                    mWSheet.Cells[11, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate1_Liabilities;
        //                    mWSheet.Cells[11, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate2_Liabilities;
        //                    mWSheet.Cells[11, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate3_Liabilities;
        //                    mWSheet.Cells[11, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate4_Liabilities;

        //                    mWSheet.Cells[12, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesType1;
        //                    mWSheet.Cells[12, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesType2;
        //                    mWSheet.Cells[12, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesType3;
        //                    mWSheet.Cells[12, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesType4;

        //                    mWSheet.Cells[14, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up1;
        //                    mWSheet.Cells[14, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up2;
        //                    mWSheet.Cells[14, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up3;
        //                    mWSheet.Cells[14, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up4;

        //                    mWSheet.Cells[15, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.EquityShareWarrant1;
        //                    mWSheet.Cells[15, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.EquityShareWarrant2;
        //                    mWSheet.Cells[15, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.EquityShareWarrant3;
        //                    mWSheet.Cells[15, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.EquityShareWarrant4;

        //                    mWSheet.Cells[17, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalReserves1;
        //                    mWSheet.Cells[17, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalReserves2;
        //                    mWSheet.Cells[17, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalReserves3;
        //                    mWSheet.Cells[17, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalReserves4;

        //                    mWSheet.Cells[18, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.GeneralReserves1;
        //                    mWSheet.Cells[18, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.GeneralReserves2;
        //                    mWSheet.Cells[18, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.GeneralReserves3;
        //                    mWSheet.Cells[18, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.GeneralReserves4;

        //                    mWSheet.Cells[19, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SharePremium1;
        //                    mWSheet.Cells[19, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SharePremium2;
        //                    mWSheet.Cells[19, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SharePremium3;
        //                    mWSheet.Cells[19, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SharePremium4;

        //                    mWSheet.Cells[20, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves1;
        //                    mWSheet.Cells[20, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves2;
        //                    mWSheet.Cells[20, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves3;
        //                    mWSheet.Cells[20, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves4;

        //                    mWSheet.Cells[21, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherReserves1;
        //                    mWSheet.Cells[21, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherReserves2;
        //                    mWSheet.Cells[21, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherReserves3;
        //                    mWSheet.Cells[21, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherReserves4;

        //                    mWSheet.Cells[22, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.RevenueReserves1;
        //                    mWSheet.Cells[22, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.RevenueReserves2;
        //                    mWSheet.Cells[22, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.RevenueReserves3;
        //                    mWSheet.Cells[22, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.RevenueReserves4;

        //                    mWSheet.Cells[23, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.IntangibleAssets1;
        //                    mWSheet.Cells[23, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.IntangibleAssets2;
        //                    mWSheet.Cells[23, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.IntangibleAssets3;
        //                    mWSheet.Cells[23, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.IntangibleAssets4;

        //                    mWSheet.Cells[25, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CommercialPaper1;
        //                    mWSheet.Cells[25, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CommercialPaper2;
        //                    mWSheet.Cells[25, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CommercialPaper3;
        //                    mWSheet.Cells[25, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CommercialPaper4;

        //                    mWSheet.Cells[26, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.InterCorporateDeposits1;
        //                    mWSheet.Cells[26, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.InterCorporateDeposits2;
        //                    mWSheet.Cells[26, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.InterCorporateDeposits3;
        //                    mWSheet.Cells[26, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.InterCorporateDeposits4;

        //                    mWSheet.Cells[27, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney1;
        //                    mWSheet.Cells[27, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney2;
        //                    mWSheet.Cells[27, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney3;
        //                    mWSheet.Cells[27, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney4;

        //                    mWSheet.Cells[28, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherBorrowings1;
        //                    mWSheet.Cells[28, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherBorrowings2;
        //                    mWSheet.Cells[28, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherBorrowings3;
        //                    mWSheet.Cells[28, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherBorrowings4;

        //                    mWSheet.Cells[29, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear1;
        //                    mWSheet.Cells[29, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear2;
        //                    mWSheet.Cells[29, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear3;
        //                    mWSheet.Cells[29, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear4;

        //                    mWSheet.Cells[30, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PublicDeposits1;
        //                    mWSheet.Cells[30, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PublicDeposits2;
        //                    mWSheet.Cells[30, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PublicDeposits3;
        //                    mWSheet.Cells[30, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PublicDeposits4;

        //                    mWSheet.Cells[31, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ShortTermBorrowings1;
        //                    mWSheet.Cells[31, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ShortTermBorrowings2;
        //                    mWSheet.Cells[31, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ShortTermBorrowings3;
        //                    mWSheet.Cells[31, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ShortTermBorrowings4;

        //                    mWSheet.Cells[32, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB1;
        //                    mWSheet.Cells[32, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB2;
        //                    mWSheet.Cells[32, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB3;
        //                    mWSheet.Cells[32, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB4;

        //                    mWSheet.Cells[33, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers1;
        //                    mWSheet.Cells[33, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers2;
        //                    mWSheet.Cells[33, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers3;
        //                    mWSheet.Cells[33, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers4;

        //                    mWSheet.Cells[34, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB1;
        //                    mWSheet.Cells[34, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB2;
        //                    mWSheet.Cells[34, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB3;
        //                    mWSheet.Cells[34, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB4;

        //                    mWSheet.Cells[35, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers1;
        //                    mWSheet.Cells[35, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers2;
        //                    mWSheet.Cells[35, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers3;
        //                    mWSheet.Cells[35, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers4;

        //                    mWSheet.Cells[36, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings1;
        //                    mWSheet.Cells[36, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings2;
        //                    mWSheet.Cells[36, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings3;
        //                    mWSheet.Cells[36, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings4;

        //                    mWSheet.Cells[37, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency1;
        //                    mWSheet.Cells[37, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency2;
        //                    mWSheet.Cells[37, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency3;
        //                    mWSheet.Cells[37, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency4;

        //                    mWSheet.Cells[38, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties1;
        //                    mWSheet.Cells[38, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties2;
        //                    mWSheet.Cells[38, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties3;
        //                    mWSheet.Cells[38, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties4;

        //                    mWSheet.Cells[39, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.HybridInstruments1;
        //                    mWSheet.Cells[39, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.HybridInstruments2;
        //                    mWSheet.Cells[39, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.HybridInstruments3;
        //                    mWSheet.Cells[39, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.HybridInstruments4;

        //                    #region NBH_BalanceSheets_Liabilities_Outputs

        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalPEOutput1 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[13, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalPEOutput2 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[13, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalPEOutput3 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[13, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalPEOutput4 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[13, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput1 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[16, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput2 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[16, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput3 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[16, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput4 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[16, 5].Value2));
                          

        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsOutput1 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[24, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsOutput2 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[24, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsOutput3 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[24, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsOutput4 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[24, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput1 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[40, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput2 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[40, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput3 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[40, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput4 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[40, 5].Value2));

        //                    #endregion

        //                    #endregion

        //                    #region NBH_BalanceSheet_Assets

        //                    mWSheet.Cells[42, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PeriodEndingDate1_Assets;
        //                    mWSheet.Cells[42, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PeriodEndingDate2_Assets;
        //                    mWSheet.Cells[42, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PeriodEndingDate3_Assets;
        //                    mWSheet.Cells[42, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PeriodEndingDate4_Assets;

        //                    mWSheet.Cells[44, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OwnedNetBlock1;
        //                    mWSheet.Cells[44, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OwnedNetBlock2;
        //                    mWSheet.Cells[44, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OwnedNetBlock3;
        //                    mWSheet.Cells[44, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OwnedNetBlock4;

        //                    mWSheet.Cells[45, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LeasedNetBlock1;
        //                    mWSheet.Cells[45, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LeasedNetBlock2;
        //                    mWSheet.Cells[45, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LeasedNetBlock3;
        //                    mWSheet.Cells[45, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LeasedNetBlock4;

        //                    mWSheet.Cells[46, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CapitalWorkInProgress1;
        //                    mWSheet.Cells[46, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CapitalWorkInProgress2;
        //                    mWSheet.Cells[46, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CapitalWorkInProgress3;
        //                    mWSheet.Cells[46, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CapitalWorkInProgress4;

        //                    mWSheet.Cells[48, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted1;
        //                    mWSheet.Cells[48, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted2;
        //                    mWSheet.Cells[48, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted3;
        //                    mWSheet.Cells[48, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted4;

        //                    mWSheet.Cells[49, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted1;
        //                    mWSheet.Cells[49, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted2;
        //                    mWSheet.Cells[49, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted3;
        //                    mWSheet.Cells[49, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted4;

        //                    mWSheet.Cells[50, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.StateGovernmentSecurities1;
        //                    mWSheet.Cells[50, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.StateGovernmentSecurities2;
        //                    mWSheet.Cells[50, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.StateGovernmentSecurities3;
        //                    mWSheet.Cells[50, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.StateGovernmentSecurities4;

        //                    mWSheet.Cells[51, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds1;
        //                    mWSheet.Cells[51, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds2;
        //                    mWSheet.Cells[51, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds3;
        //                    mWSheet.Cells[51, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds4;

        //                    mWSheet.Cells[52, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPublicSectorBonds1;
        //                    mWSheet.Cells[52, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPublicSectorBonds2;
        //                    mWSheet.Cells[52, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPublicSectorBonds3;
        //                    mWSheet.Cells[52, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPublicSectorBonds4;

        //                    mWSheet.Cells[53, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade1;
        //                    mWSheet.Cells[53, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade2;
        //                    mWSheet.Cells[53, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade3;
        //                    mWSheet.Cells[53, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade4;

        //                    mWSheet.Cells[54, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds1;
        //                    mWSheet.Cells[54, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds2;
        //                    mWSheet.Cells[54, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds3;
        //                    mWSheet.Cells[54, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds4;

        //                    mWSheet.Cells[55, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.MutualFunds1;
        //                    mWSheet.Cells[55, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.MutualFunds2;
        //                    mWSheet.Cells[55, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.MutualFunds3;
        //                    mWSheet.Cells[55, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.MutualFunds4;

        //                    mWSheet.Cells[56, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ListedEquity1;
        //                    mWSheet.Cells[56, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ListedEquity2;
        //                    mWSheet.Cells[56, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ListedEquity3;
        //                    mWSheet.Cells[56, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ListedEquity4;

        //                    mWSheet.Cells[57, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnlistedEquity1;
        //                    mWSheet.Cells[57, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnlistedEquity2;
        //                    mWSheet.Cells[57, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnlistedEquity3;
        //                    mWSheet.Cells[57, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnlistedEquity4;

        //                    mWSheet.Cells[58, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates1;
        //                    mWSheet.Cells[58, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates2;
        //                    mWSheet.Cells[58, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates3;
        //                    mWSheet.Cells[58, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates4;

        //                    mWSheet.Cells[60, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.HirePurchaseReceivables1;
        //                    mWSheet.Cells[60, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.HirePurchaseReceivables2;
        //                    mWSheet.Cells[60, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.HirePurchaseReceivables3;
        //                    mWSheet.Cells[60, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.HirePurchaseReceivables4;

        //                    mWSheet.Cells[61, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.FinanceLeases1;
        //                    mWSheet.Cells[61, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.FinanceLeases2;
        //                    mWSheet.Cells[61, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.FinanceLeases3;
        //                    mWSheet.Cells[61, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.FinanceLeases4;

        //                    mWSheet.Cells[62, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.SecuredLoans1;
        //                    mWSheet.Cells[62, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.SecuredLoans2;
        //                    mWSheet.Cells[62, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.SecuredLoans3;
        //                    mWSheet.Cells[62, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.SecuredLoans4;

        //                    mWSheet.Cells[63, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnsecuredLoans1;
        //                    mWSheet.Cells[63, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnsecuredLoans2;
        //                    mWSheet.Cells[63, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnsecuredLoans3;
        //                    mWSheet.Cells[63, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnsecuredLoans4;

        //                    mWSheet.Cells[64, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.Debtors1;
        //                    mWSheet.Cells[64, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.Debtors2;
        //                    mWSheet.Cells[64, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.Debtors3;
        //                    mWSheet.Cells[64, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.Debtors4;

        //                    mWSheet.Cells[65, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.BillsDiscounted1;
        //                    mWSheet.Cells[65, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.BillsDiscounted2;
        //                    mWSheet.Cells[65, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.BillsDiscounted3;
        //                    mWSheet.Cells[65, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.BillsDiscounted4;

        //                    mWSheet.Cells[66, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherInterestBearingLoans1;
        //                    mWSheet.Cells[66, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherInterestBearingLoans2;
        //                    mWSheet.Cells[66, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherInterestBearingLoans3;
        //                    mWSheet.Cells[66, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherInterestBearingLoans4;

        //                    mWSheet.Cells[67, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LoansToRelatedParties1;
        //                    mWSheet.Cells[67, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LoansToRelatedParties2;
        //                    mWSheet.Cells[67, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LoansToRelatedParties3;
        //                    mWSheet.Cells[67, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LoansToRelatedParties4;

        //                    mWSheet.Cells[68, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CashAndBank1;
        //                    mWSheet.Cells[68, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CashAndBank2;
        //                    mWSheet.Cells[68, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CashAndBank3;
        //                    mWSheet.Cells[68, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CashAndBank4;

        //                    mWSheet.Cells[69, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesPaid1;
        //                    mWSheet.Cells[69, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesPaid2;
        //                    mWSheet.Cells[69, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesPaid3;
        //                    mWSheet.Cells[69, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesPaid4;

        //                    mWSheet.Cells[70, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentAssets1;
        //                    mWSheet.Cells[70, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentAssets2;
        //                    mWSheet.Cells[70, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentAssets3;
        //                    mWSheet.Cells[70, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentAssets4;

        //                    mWSheet.Cells[71, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets1;
        //                    mWSheet.Cells[71, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets2;
        //                    mWSheet.Cells[71, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets3;
        //                    mWSheet.Cells[71, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets4;

        //                    mWSheet.Cells[73, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InterestAccruedButNotDue1;
        //                    mWSheet.Cells[73, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InterestAccruedButNotDue2;
        //                    mWSheet.Cells[73, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InterestAccruedButNotDue3;
        //                    mWSheet.Cells[73, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InterestAccruedButNotDue4;

        //                    mWSheet.Cells[74, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DepositsReceived1;
        //                    mWSheet.Cells[74, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DepositsReceived2;
        //                    mWSheet.Cells[74, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DepositsReceived3;
        //                    mWSheet.Cells[74, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DepositsReceived4;

        //                    mWSheet.Cells[75, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesReceived1;
        //                    mWSheet.Cells[75, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesReceived2;
        //                    mWSheet.Cells[75, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesReceived3;
        //                    mWSheet.Cells[75, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesReceived4;

        //                    mWSheet.Cells[76, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentLiabilities1;
        //                    mWSheet.Cells[76, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentLiabilities2;
        //                    mWSheet.Cells[76, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentLiabilities3;
        //                    mWSheet.Cells[76, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentLiabilities4;

        //                    mWSheet.Cells[77, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DeferredtaxLiability1;
        //                    mWSheet.Cells[77, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DeferredtaxLiability2;
        //                    mWSheet.Cells[77, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DeferredtaxLiability3;
        //                    mWSheet.Cells[77, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DeferredtaxLiability4;

        //                    mWSheet.Cells[78, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ReceivablesSecuritised1;
        //                    mWSheet.Cells[78, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ReceivablesSecuritised2;
        //                    mWSheet.Cells[78, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ReceivablesSecuritised3;
        //                    mWSheet.Cells[78, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ReceivablesSecuritised4;

        //                    mWSheet.Cells[80, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForLoanLosses1;
        //                    mWSheet.Cells[80, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForLoanLosses2;
        //                    mWSheet.Cells[80, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForLoanLosses3;
        //                    mWSheet.Cells[80, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForLoanLosses4;

        //                    mWSheet.Cells[81, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors1;
        //                    mWSheet.Cells[81, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors2;
        //                    mWSheet.Cells[81, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors3;
        //                    mWSheet.Cells[81, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors4;

        //                    mWSheet.Cells[82, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDepreciation1;
        //                    mWSheet.Cells[82, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDepreciation2;
        //                    mWSheet.Cells[82, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDepreciation3;
        //                    mWSheet.Cells[82, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDepreciation4;

        //                    mWSheet.Cells[83, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets1;
        //                    mWSheet.Cells[83, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets2;
        //                    mWSheet.Cells[83, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets3;
        //                    mWSheet.Cells[83, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets4;

        //                    mWSheet.Cells[84, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDividend1;
        //                    mWSheet.Cells[84, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDividend2;
        //                    mWSheet.Cells[84, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDividend3;
        //                    mWSheet.Cells[84, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDividend4;

        //                    mWSheet.Cells[85, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForTaxes1;
        //                    mWSheet.Cells[85, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForTaxes2;
        //                    mWSheet.Cells[85, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForTaxes3;
        //                    mWSheet.Cells[85, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForTaxes4;

        //                    mWSheet.Cells[86, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes1;
        //                    mWSheet.Cells[86, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes2;
        //                    mWSheet.Cells[86, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes3;
        //                    mWSheet.Cells[86, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes4;

        //                    mWSheet.Cells[87, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForExpenses1;
        //                    mWSheet.Cells[87, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForExpenses2;
        //                    mWSheet.Cells[87, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForExpenses3;
        //                    mWSheet.Cells[87, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForExpenses4;

        //                    mWSheet.Cells[88, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherProvisions1;
        //                    mWSheet.Cells[88, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherProvisions2;
        //                    mWSheet.Cells[88, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherProvisions3;
        //                    mWSheet.Cells[88, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherProvisions4;

        //                    #region NBH_BalanceSheet_Asset_Output

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.FixedAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[43, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.FixedAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[43, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.FixedAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[43, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.FixedAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[43, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[47, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[47, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[47, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[47, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[59, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[59, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[59, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[59, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[72, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[72, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[72, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[72, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[79, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[79, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[79, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[79, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[89, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[89, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[89, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[89, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.TotalAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[90, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.TotalAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[90, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.TotalAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[90, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.TotalAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[90, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ErrorCheck1 = Convert.ToString(mWSheet.Cells[91, 2].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ErrorCheck2 = Convert.ToString(mWSheet.Cells[91, 3].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ErrorCheck3 = Convert.ToString(mWSheet.Cells[91, 4].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ErrorCheck4 = Convert.ToString(mWSheet.Cells[91, 5].Value2);

        //                    #endregion

        //                    #endregion

        //                    #region NHB_OtherBalanceSheet_Disclosures

        //                    mWSheet.Cells[102, 2] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage1))/100;
        //                    mWSheet.Cells[102, 3] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage2))/100;
        //                    mWSheet.Cells[102, 4] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage3))/100;
        //                    mWSheet.Cells[102, 5] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage4))/100;

        //                    mWSheet.Cells[103, 2] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage1))/100;
        //                    mWSheet.Cells[103, 3] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage2))/100;
        //                    mWSheet.Cells[103, 4] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage3))/100;
        //                    mWSheet.Cells[103, 5] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage4))/100;

        //                    mWSheet.Cells[104, 2] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage1))/100;
        //                    mWSheet.Cells[104, 3] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage2))/100;
        //                    mWSheet.Cells[104, 4] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage3))/100;
        //                    mWSheet.Cells[104, 5] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage4))/100;

        //                    mWSheet.Cells[105, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage1;
        //                    mWSheet.Cells[105, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage2;
        //                    mWSheet.Cells[105, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage3;
        //                    mWSheet.Cells[105, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage4;

        //                    mWSheet.Cells[106, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage1;
        //                    mWSheet.Cells[106, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage2;
        //                    mWSheet.Cells[106, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage3;
        //                    mWSheet.Cells[106, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage4;

        //                    mWSheet.Cells[107, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage1;
        //                    mWSheet.Cells[107, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage2;
        //                    mWSheet.Cells[107, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage3;
        //                    mWSheet.Cells[107, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage4;

        //                    mWSheet.Cells[108, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.GrossNPAs1;
        //                    mWSheet.Cells[108, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.GrossNPAs2;
        //                    mWSheet.Cells[108, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.GrossNPAs3;
        //                    mWSheet.Cells[108, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.GrossNPAs4;

        //                    mWSheet.Cells[109, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld1;
        //                    mWSheet.Cells[109, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld2;
        //                    mWSheet.Cells[109, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld3;
        //                    mWSheet.Cells[109, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld4;

        //                    mWSheet.Cells[110, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.NetNPAs1;
        //                    mWSheet.Cells[110, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.NetNPAs2;
        //                    mWSheet.Cells[110, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.NetNPAs3;
        //                    mWSheet.Cells[110, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.NetNPAs4;

        //                    #endregion

        //                    #region NHB_Contingent Liabilities

        //                    mWSheet.Cells[93, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts1;
        //                    mWSheet.Cells[93, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts2;
        //                    mWSheet.Cells[93, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts3;
        //                    mWSheet.Cells[93, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts4;

        //                    mWSheet.Cells[94, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.GuaranteesGiven1;
        //                    mWSheet.Cells[94, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.GuaranteesGiven2;
        //                    mWSheet.Cells[94, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.GuaranteesGiven3;
        //                    mWSheet.Cells[94, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.GuaranteesGiven4;

        //                    mWSheet.Cells[95, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments1;
        //                    mWSheet.Cells[95, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments2;
        //                    mWSheet.Cells[95, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments3;
        //                    mWSheet.Cells[95, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments4;

        //                    mWSheet.Cells[96, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts1;
        //                    mWSheet.Cells[96, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts2;
        //                    mWSheet.Cells[96, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts3;
        //                    mWSheet.Cells[96, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts4;

        //                    mWSheet.Cells[97, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts1;
        //                    mWSheet.Cells[97, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts2;
        //                    mWSheet.Cells[97, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts3;
        //                    mWSheet.Cells[97, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts4;

        //                    mWSheet.Cells[98, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations1;
        //                    mWSheet.Cells[98, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations2;
        //                    mWSheet.Cells[98, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations3;
        //                    mWSheet.Cells[98, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations4;

        //                    mWSheet.Cells[99, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts1;
        //                    mWSheet.Cells[99, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts2;
        //                    mWSheet.Cells[99, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts3;
        //                    mWSheet.Cells[99, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts4;

        //                    mWSheet.Cells[100, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.OtherItems1;
        //                    mWSheet.Cells[100, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.OtherItems2;
        //                    mWSheet.Cells[100, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.OtherItems3;
        //                    mWSheet.Cells[100, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.OtherItems4;

        //                    #endregion

        //                    #region NHB_Profit&LossStatement

        //                    mWSheet.Cells[112, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PeriodEndingDate1_ProfitAndLoss;
        //                    mWSheet.Cells[112, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PeriodEndingDate2_ProfitAndLoss;
        //                    mWSheet.Cells[112, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PeriodEndingDate3_ProfitAndLoss;
        //                    mWSheet.Cells[112, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PeriodEndingDate4_ProfitAndLoss;

        //                    mWSheet.Cells[115, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals1;
        //                    mWSheet.Cells[115, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals2;
        //                    mWSheet.Cells[115, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals3;
        //                    mWSheet.Cells[115, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals4;

        //                    mWSheet.Cells[116, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies1;
        //                    mWSheet.Cells[116, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies2;
        //                    mWSheet.Cells[116, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies3;
        //                    mWSheet.Cells[116, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies4;

        //                    mWSheet.Cells[117, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherInterestIncome1;
        //                    mWSheet.Cells[117, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherInterestIncome2;
        //                    mWSheet.Cells[117, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherInterestIncome3;
        //                    mWSheet.Cells[117, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherInterestIncome4;

        //                    mWSheet.Cells[118, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm1;
        //                    mWSheet.Cells[118, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm2;
        //                    mWSheet.Cells[118, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm3;
        //                    mWSheet.Cells[118, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm4;

        //                    mWSheet.Cells[119, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm1;
        //                    mWSheet.Cells[119, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm2;
        //                    mWSheet.Cells[119, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm3;
        //                    mWSheet.Cells[119, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm4;

        //                    mWSheet.Cells[121, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.FeesReceived1;
        //                    mWSheet.Cells[121, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.FeesReceived2;
        //                    mWSheet.Cells[121, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.FeesReceived3;
        //                    mWSheet.Cells[121, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.FeesReceived4;

        //                    mWSheet.Cells[122, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage1;
        //                    mWSheet.Cells[122, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage2;
        //                    mWSheet.Cells[122, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage3;
        //                    mWSheet.Cells[122, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage4;

        //                    mWSheet.Cells[123, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments1;
        //                    mWSheet.Cells[123, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments2;
        //                    mWSheet.Cells[123, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments3;
        //                    mWSheet.Cells[123, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments4;

        //                    mWSheet.Cells[124, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleAssets1;
        //                    mWSheet.Cells[124, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleAssets2;
        //                    mWSheet.Cells[124, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleAssets3;
        //                    mWSheet.Cells[124, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleAssets4;

        //                    mWSheet.Cells[125, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions1;
        //                    mWSheet.Cells[125, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions2;
        //                    mWSheet.Cells[125, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions3;
        //                    mWSheet.Cells[125, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions4;

        //                    mWSheet.Cells[126, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherServiceIncome1;
        //                    mWSheet.Cells[126, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherServiceIncome2;
        //                    mWSheet.Cells[126, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherServiceIncome3;
        //                    mWSheet.Cells[126, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherServiceIncome4;

        //                    mWSheet.Cells[127, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets1;
        //                    mWSheet.Cells[127, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets2;
        //                    mWSheet.Cells[127, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets3;
        //                    mWSheet.Cells[127, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets4;

        //                    mWSheet.Cells[128, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherNonOperatingIncome1;
        //                    mWSheet.Cells[128, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherNonOperatingIncome2;
        //                    mWSheet.Cells[128, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherNonOperatingIncome3;
        //                    mWSheet.Cells[128, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherNonOperatingIncome4;

        //                    mWSheet.Cells[131, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnDeposits1;
        //                    mWSheet.Cells[131, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnDeposits2;
        //                    mWSheet.Cells[131, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnDeposits3;
        //                    mWSheet.Cells[131, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnDeposits4;

        //                    mWSheet.Cells[132, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnBorrowings1;
        //                    mWSheet.Cells[132, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnBorrowings2;
        //                    mWSheet.Cells[132, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnBorrowings3;
        //                    mWSheet.Cells[132, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnBorrowings4;

        //                    mWSheet.Cells[134, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherFinancialCharges1;
        //                    mWSheet.Cells[134, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherFinancialCharges2;
        //                    mWSheet.Cells[134, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherFinancialCharges3;
        //                    mWSheet.Cells[134, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherFinancialCharges4;

        //                    mWSheet.Cells[135, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PersonnelExpenses1;
        //                    mWSheet.Cells[135, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PersonnelExpenses2;
        //                    mWSheet.Cells[135, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PersonnelExpenses3;
        //                    mWSheet.Cells[135, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PersonnelExpenses4;

        //                    mWSheet.Cells[137, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpenses1;
        //                    mWSheet.Cells[137, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpenses2;
        //                    mWSheet.Cells[137, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpenses3;
        //                    mWSheet.Cells[137, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpenses4;

        //                    mWSheet.Cells[138, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff1;
        //                    mWSheet.Cells[138, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff2;
        //                    mWSheet.Cells[138, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff3;
        //                    mWSheet.Cells[138, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff4;

        //                    mWSheet.Cells[139, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets1;
        //                    mWSheet.Cells[139, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets2;
        //                    mWSheet.Cells[139, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets3;
        //                    mWSheet.Cells[139, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets4;

        //                    mWSheet.Cells[140, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.Depreciation1;
        //                    mWSheet.Cells[140, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.Depreciation2;
        //                    mWSheet.Cells[140, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.Depreciation3;
        //                    mWSheet.Cells[140, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.Depreciation4;

        //                    mWSheet.Cells[142, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForLoanLosses1;
        //                    mWSheet.Cells[142, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForLoanLosses2;
        //                    mWSheet.Cells[142, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForLoanLosses3;
        //                    mWSheet.Cells[142, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForLoanLosses4;

        //                    mWSheet.Cells[143, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund1;
        //                    mWSheet.Cells[143, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund2;
        //                    mWSheet.Cells[143, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund3;
        //                    mWSheet.Cells[143, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund4;

        //                    mWSheet.Cells[144, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack1;
        //                    mWSheet.Cells[144, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack2;
        //                    mWSheet.Cells[144, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack3;
        //                    mWSheet.Cells[144, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack4;

        //                    mWSheet.Cells[145, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff1;
        //                    mWSheet.Cells[145, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff2;
        //                    mWSheet.Cells[145, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff3;
        //                    mWSheet.Cells[145, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff4;

        //                    mWSheet.Cells[146, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherAdjustments1;
        //                    mWSheet.Cells[146, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherAdjustments2;
        //                    mWSheet.Cells[146, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherAdjustments3;
        //                    mWSheet.Cells[146, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherAdjustments4;

        //                    mWSheet.Cells[149, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CurrentTax1;
        //                    mWSheet.Cells[149, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CurrentTax2;
        //                    mWSheet.Cells[149, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CurrentTax3;
        //                    mWSheet.Cells[149, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CurrentTax4;

        //                    mWSheet.Cells[150, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.DeferredTax1;
        //                    mWSheet.Cells[150, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.DeferredTax2;
        //                    mWSheet.Cells[150, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.DeferredTax3;
        //                    mWSheet.Cells[150, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.DeferredTax4;

        //                    mWSheet.Cells[152, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PreferenceDividend_Tax1;
        //                    mWSheet.Cells[152, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PreferenceDividend_Tax2;
        //                    mWSheet.Cells[152, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PreferenceDividend_Tax3;
        //                    mWSheet.Cells[152, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PreferenceDividend_Tax4;

        //                    mWSheet.Cells[153, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.EquityDividend_Tax1;
        //                    mWSheet.Cells[153, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.EquityDividend_Tax2;
        //                    mWSheet.Cells[153, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.EquityDividend_Tax3;
        //                    mWSheet.Cells[153, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.EquityDividend_Tax4;



        //                    #region NHB_Profit&LossStatement Output

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[113, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[113, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[113, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[113, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestIncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[114, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestIncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[114, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestIncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[114, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestIncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[114, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[120, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[120, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[120, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[120, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[129, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[129, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[129, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[129, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[130, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[130, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[130, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[130, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestPaidOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[133, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestPaidOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[133, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestPaidOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[133, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestPaidOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[133, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpensesOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[136, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpensesOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[136, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpensesOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[136, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpensesOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[136, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.LoanLosses1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[141, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.LoanLosses2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[141, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.LoanLosses3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[141, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.LoanLosses4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[141, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[147, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[147, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[147, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[147, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.TaxExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[148, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.TaxExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[148, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.TaxExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[148, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.TaxExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[148, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[151, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[151, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[151, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[151, 5].Value2));

        //                    #endregion

        //                    #endregion

        //                    #region NHB_ALM_Statement_Latests

        //                    mWSheet.Range["B155"].Value = riskModelExcelEntity.NHB_ALM_Statement_Latests.Statement_Date;

        //                    mWSheet.Cells[157, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Day1to14DaysInflow;
        //                    mWSheet.Cells[157, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Day1to14DaysOurflow;

        //                    mWSheet.Cells[158, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Day14DaysTo1MonthInflow;
        //                    mWSheet.Cells[158, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Day14DaysTo1MonthOurflow;

        //                    mWSheet.Cells[159, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month1To2MonthsInflow;
        //                    mWSheet.Cells[159, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month1To2MonthsOurflow;

        //                    mWSheet.Cells[160, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month2To3MonthsInflow;
        //                    mWSheet.Cells[160, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month2To3MonthsOurflow;

        //                    mWSheet.Cells[161, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month3To6MonthsInflow;
        //                    mWSheet.Cells[161, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month3To6MonthsOurflow;

        //                    mWSheet.Cells[162, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month6MonthsTo1YearInflow;
        //                    mWSheet.Cells[162, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month6MonthsTo1YearOurflow;

        //                    mWSheet.Cells[163, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year1To3YearsInflow;
        //                    mWSheet.Cells[163, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year1To3YearsOurflow;

        //                    mWSheet.Cells[164, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year3To5YearsInflow;
        //                    mWSheet.Cells[164, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year3To5YearsOurflow;

        //                    mWSheet.Cells[165, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year5To7YearsInflow;
        //                    mWSheet.Cells[165, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year5To7YearsOurflow;

        //                    mWSheet.Cells[166, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year7To10YearsInflow;
        //                    mWSheet.Cells[166, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year7To10YearsOurflow;

        //                    mWSheet.Cells[167, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Over10YearsInflow;
        //                    mWSheet.Cells[167, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Over10YearsOurflow;

        //                    #region NHB_ALM_Statement_Latest_Output

        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Day1to14DaysMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[157, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Day14DaysTo1MonthMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[158, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Month1To2MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[159, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Month2To3MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[160, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Month3To6MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[161, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Month6MonthsTo1YearMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[162, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Year1To3YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[163, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Year3To5YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[164, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Year5To7YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[165, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Year7To10YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[166, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Over10YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[167, 4].Value2));

        //                    #endregion

        //                    #endregion

        //                    #region NHB_KeyRatios

        //                    riskModelExcelEntity.NHB_KeyRatios.TotalAssets1 = Convert.ToInt32(mWSheet.Cells[169, 2].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TotalAssets2 = Convert.ToInt32(mWSheet.Cells[169, 3].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TotalAssets3 = Convert.ToInt32(mWSheet.Cells[169, 4].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TotalAssets4 = Convert.ToInt32(mWSheet.Cells[169, 5].Value2);

        //                    riskModelExcelEntity.NHB_KeyRatios.GrossNPAPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[170, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GrossNPAPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[170, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GrossNPAPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[170, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GrossNPAPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[170, 5].Value2) * 100, 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.ALMMismatchPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[171, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.ALMMismatchPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[171, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.ALMMismatchPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[171, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.ALMMismatchPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[171, 5].Value2) * 100, 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.NetWorth1 = Convert.ToInt32(mWSheet.Cells[172, 2].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetWorth2 = Convert.ToInt32(mWSheet.Cells[172, 3].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetWorth3 = Convert.ToInt32(mWSheet.Cells[172, 4].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetWorth4 = Convert.ToInt32(mWSheet.Cells[172, 5].Value2);

        //                    riskModelExcelEntity.NHB_KeyRatios.CRARPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[173, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.CRARPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[173, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.CRARPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[173, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.CRARPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[173, 5].Value2) * 100, 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.GearingPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[174, 2].Value2), 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GearingPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[174, 3].Value2), 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GearingPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[174, 4].Value2), 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GearingPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[174, 5].Value2), 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.TangibleNWNetNPA1 = Convert.ToInt32(mWSheet.Cells[175, 2].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TangibleNWNetNPA2 = Convert.ToInt32(mWSheet.Cells[175, 3].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TangibleNWNetNPA3 = Convert.ToInt32(mWSheet.Cells[175, 4].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TangibleNWNetNPA4 = Convert.ToInt32(mWSheet.Cells[175, 5].Value2);

        //                    riskModelExcelEntity.NHB_KeyRatios.NetMarginPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[176, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetMarginPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[176, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetMarginPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[176, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetMarginPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[176, 5].Value2) * 100, 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageFundsDeployedPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[177, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageFundsDeployedPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[177, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageFundsDeployedPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[177, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageFundsDeployedPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[177, 5].Value2) * 100, 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageNetWorthPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[178, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageNetWorthPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[178, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageNetWorthPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[178, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageNetWorthPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[178, 5].Value2) * 100, 2);

        //                    #endregion

        //                    #region NHB_Industry_RiskInputs

        //                    mWSheet.Range["B180"].Value = riskModelExcelEntity.NHB_Industry_RiskInputs.FinancialPerformanceofPlayer;
        //                    mWSheet.Range["B181"].Value = riskModelExcelEntity.NHB_Industry_RiskInputs.ExtentOfCompetition;
        //                    mWSheet.Range["B182"].Value = riskModelExcelEntity.NHB_Industry_RiskInputs.ProspectOfRealEstateMarket;
        //                    mWSheet.Range["B183"].Value = riskModelExcelEntity.NHB_Industry_RiskInputs.RegulatoryImpact;

        //                    #endregion

        //                    #region NHB_Business_RiskInputs

        //                    mWSheet.Range["B185"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.RankOfMarketPosition;
        //                    mWSheet.Range["B186"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.GeographicalDiversification;
        //                    mWSheet.Range["B187"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.ProductMix;
        //                    mWSheet.Range["B188"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.CustomerMix;
        //                    mWSheet.Range["B189"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.CostOfResources;
        //                    mWSheet.Range["B190"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.TotalAssetGrowth;
        //                    mWSheet.Range["B191"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.DiversificationOfFundingProfile;


        //                    #endregion

        //                    #region NHB_Financial_RiskInputs

        //                    mWSheet.Range["B193"].Value = riskModelExcelEntity.NHB_Financial_RiskInputs.CompanysAbility;

        //                    #endregion

        //                    #region NHB_Management_RiskInputs

        //                    mWSheet.Range["B195"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.AbilityToMeetRevenueProjection;
        //                    mWSheet.Range["B196"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.AbilityToMeetProfitProjection;
        //                    mWSheet.Range["B197"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.PastPaymentRecord;
        //                    mWSheet.Range["B198"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.RiskManagementSystem;
        //                    mWSheet.Range["B199"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.ManagementCredibility;
        //                    mWSheet.Range["B200"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.ManagementExperienceAndCompetence;
        //                    mWSheet.Range["B201"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.RiskAppetite;


        //                    #endregion

        //                    #region NHB_NotchUp_CriteriaInputs

        //                    mWSheet.Range["B203"].Value = riskModelExcelEntity.NHB_NotchUp_CriteriaInputs.ShareholdingStructure;
        //                    mWSheet.Range["B204"].Value = riskModelExcelEntity.NHB_NotchUp_CriteriaInputs.ManagementControl;
        //                    mWSheet.Range["B205"].Value = riskModelExcelEntity.NHB_NotchUp_CriteriaInputs.StatedPostureOfTheParent;
        //                    mWSheet.Range["B206"].Value = riskModelExcelEntity.NHB_NotchUp_CriteriaInputs.PastTrackRecord;
        //                    mWSheet.Range["B207"].Value = riskModelExcelEntity.NHB_NotchUp_CriteriaInputs.BrandName;

        //                    #endregion

        //                    #region Risk Model Outputs

        //                    mWSheet = (Worksheet)mWorkSheets.get_Item(3);

        //                    NHB_RiskModel_Outputss NHB_RiskModel_Outputss = new NHB_RiskModel_Outputss()
        //                    {
        //                        #region Industry Risk_Outputs
        //                        IndustryRiskFinancialPerformanceOfPlayersWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[2, 6].Value2),
        //                        IndustryRiskFinancialPerformanceOfPlayersValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[2, 7].Value2),
        //                        IndustryRiskFinancialPerformanceOfPlayersScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[2, 8].Value2),
        //                        IndustryRiskCompetitionsWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[3, 6].Value2),
        //                        IndustryRiskCompetitionsValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[3, 7].Value2),
        //                        IndustryRiskCompetitionsScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[3, 8].Value2),
        //                        IndustryRiskProspectOfRealEstateMarketWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[4, 6].Value2),
        //                        IndustryRiskProspectOfRealEstateMarketValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[4, 7].Value2),
        //                        IndustryRiskProspectOfRealEstateMarketScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[4, 8].Value2),
        //                        IndustryRiskRegulatoryImpactGovernmentPolicyWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[5, 6].Value2),
        //                        IndustryRiskRegulatoryImpactGovernmentPolicyValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[5, 7].Value2),
        //                        IndustryRiskRegulatoryImpactGovernmentPolicyScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[5, 8].Value2),
        //                        #endregion

        //                        #region Business Risk_Outputs
        //                        BusinessRiskMarketPositionRankWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[6, 6].Value2),
        //                        BusinessRiskMarketPositionRankValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[6, 7].Value2),
        //                        BusinessRiskMarketPositionRankScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[6, 8].Value2),
        //                        BusinessRiskMarketPositionGeographicalDiversificationWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[7, 6].Value2),
        //                        BusinessRiskMarketPositionGeographicalDiversificationValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[7, 7].Value2),
        //                        BusinessRiskMarketPositionGeographicalDiversificationScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[7, 8].Value2),
        //                        BusinessRiskAssetQualityProductMixWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[8, 6].Value2),
        //                        BusinessRiskAssetQualityProductMixValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[8, 7].Value2),
        //                        BusinessRiskAssetQualityProductMixScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[8, 8].Value2),
        //                        BusinessRiskAssetQualityCustomerMixWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[9, 6].Value2),
        //                        BusinessRiskAssetQualityCustomerMixValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[9, 7].Value2),
        //                        BusinessRiskAssetQualityCustomerMixScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[9, 8].Value2),
        //                        BusinessRiskAssetQualityGrossNPAWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[10, 6].Value2),
        //                        BusinessRiskAssetQualityGrossNPAValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[10, 7].Value2),
        //                        BusinessRiskAssetQualityGrossNPAScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[10, 8].Value2),
        //                        BusinessRiskOperatingEfficiencyCostOfResourcesWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[11, 6].Value2),
        //                        BusinessRiskOperatingEfficiencyCostOfResourcesValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[11, 7].Value2),
        //                        BusinessRiskOperatingEfficiencyCostOfResourcesScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[11, 8].Value2),
        //                        BusinessRiskOperatingEfficiencyTotalAssetGrowthWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[12, 6].Value2),
        //                        BusinessRiskOperatingEfficiencyTotalAssetGrowthValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[12, 7].Value2),
        //                        BusinessRiskOperatingEfficiencyTotalAssetGrowthScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[12, 8].Value2),
        //                        BusinessRiskOperatingEfficiencyDiversityOfResourcesWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[13, 6].Value2),
        //                        BusinessRiskOperatingEfficiencyDiversityOfResourcesValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[13, 7].Value2),
        //                        BusinessRiskOperatingEfficiencyDiversityOfResourcesScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[13, 8].Value2),
        //                        BusinessRiskTotalAssetBaseWeight = Convert.ToString(mWSheet.Cells[14, 6].Value2) == "-2146826246" ? "#N/A" : mWSheet.Cells[14, 6].Value2,
        //                        BusinessRiskTotalAssetBaseValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[14, 7].Value2),
        //                        BusinessRiskTotalAssetBaseScore = Convert.ToString(mWSheet.Cells[14, 8].Value2),
        //                        #endregion

        //                        #region Financial Risk_Outputs
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[15, 6].Value2),
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[15, 7].Value2),
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[15, 8].Value2),
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[16, 6].Value2),
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[16, 7].Value2),
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[16, 8].Value2),
        //                        FinancialRiskCapitalTangibleNetworthWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[17, 6].Value2),
        //                        FinancialRiskCapitalTangibleNetworthValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[17, 7].Value2),
        //                        FinancialRiskCapitalTangibleNetworthScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[17, 8].Value2),
        //                        FinancialRiskCapitalAdequacyRatioWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[18, 6].Value2),
        //                        FinancialRiskCapitalAdequacyRatioValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[18, 7].Value2),
        //                        FinancialRiskCapitalAdequacyRatioScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[18, 8].Value2),
        //                        FinancialRiskCapitalGearingWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[19, 6].Value2),
        //                        FinancialRiskCapitalGearingValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[19, 7].Value2),
        //                        FinancialRiskCapitalGearingScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[19, 8].Value2),
        //                        FinancialRiskEarningsTangibleNetworthNetNPAWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[20, 6].Value2),
        //                        FinancialRiskEarningsTangibleNetworthNetNPAValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[20, 7].Value2),
        //                        FinancialRiskEarningsTangibleNetworthNetNPAScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[20, 8].Value2),
        //                        FinancialRiskEarningsNetProfitMarginWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[21, 6].Value2),
        //                        FinancialRiskEarningsNetProfitMarginValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[21, 7].Value2),
        //                        FinancialRiskEarningsNetProfitMarginScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[21, 8].Value2),
        //                        FinancialRiskEarningsReturnOnAssetsWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[22, 6].Value2),
        //                        FinancialRiskEarningsReturnOnAssetsValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[22, 7].Value2),
        //                        FinancialRiskEarningsReturnOnAssetsScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[22, 8].Value2),
        //                        FinancialRiskEarningsReturnOnNetworthWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[23, 6].Value2),
        //                        FinancialRiskEarningsReturnOnNetworthValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[23, 7].Value2),
        //                        FinancialRiskEarningsReturnOnNetworthScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[23, 8].Value2),
        //                        #endregion

        //                        #region Management Risk_Outputs
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[24, 6].Value2),
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[24, 7].Value2),
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[24, 8].Value2),
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[25, 6].Value2),
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[25, 7].Value2),
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[25, 8].Value2),
        //                        ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[26, 6].Value2),
        //                        ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[26, 7].Value2),
        //                        ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[26, 8].Value2),
        //                        ManagementRiskTrackRecordRiskManagementSystemWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[27, 6].Value2),
        //                        ManagementRiskTrackRecordRiskManagementSystemValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[27, 7].Value2),
        //                        ManagementRiskTrackRecordRiskManagementSystemScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[27, 8].Value2),
        //                        ManagementRiskKeyFactorsCredibilityWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[28, 6].Value2),
        //                        ManagementRiskKeyFactorsCredibilityValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[28, 7].Value2),
        //                        ManagementRiskKeyFactorsCredibilityScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[28, 8].Value2),
        //                        ManagementRiskKeyFactorsCompetenceAndExperienceWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[29, 6].Value2),
        //                        ManagementRiskKeyFactorsCompetenceAndExperienceValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[29, 7].Value2),
        //                        ManagementRiskKeyFactorsCompetenceAndExperienceScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[29, 8].Value2),
        //                        ManagementRiskKeyFactorsRiskAppetiteWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[30, 6].Value2),
        //                        ManagementRiskKeyFactorsRiskAppetiteValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[30, 7].Value2),
        //                        ManagementRiskKeyFactorsRiskAppetiteScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[30, 8].Value2),
        //                        #endregion

        //                        #region NotchUp Criteria_Outputs
        //                        NotchUpCriteriaOwnershipShareholdingStructureWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[31, 6].Value2),
        //                        NotchUpCriteriaOwnershipShareholdingStructureValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[31, 7].Value2),
        //                        NotchUpCriteriaOwnershipShareholdingStructureScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[31, 8].Value2),
        //                        NotchUpCriteriaManagementControlWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[32, 6].Value2),
        //                        NotchUpCriteriaManagementControlValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[32, 7].Value2),
        //                        NotchUpCriteriaManagementControlScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[32, 8].Value2),
        //                        NotchUpCriteriaStatedPostureOfTheParentWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[33, 6].Value2),
        //                        NotchUpCriteriaStatedPostureOfTheParentValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[33, 7].Value2),
        //                        NotchUpCriteriaStatedPostureOfTheParentScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[33, 8].Value2),
        //                        NotchUpCriteriaPastTrackRecordWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[34, 6].Value2),
        //                        NotchUpCriteriaPastTrackRecordValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[34, 7].Value2),
        //                        NotchUpCriteriaPastTrackRecordScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[34, 8].Value2),
        //                        NotchUpCriteriaBrandNameWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[35, 6].Value2),
        //                        NotchUpCriteriaBrandNameValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[35, 7].Value2),
        //                        NotchUpCriteriaBrandNameScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[35, 8].Value2),
        //                        #endregion

        //                        #region Outputs                        
        //                        IndustryRiskOutput = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[36, 6].Value2),
        //                        BusinessRiskOutput = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[37, 6].Value2),
        //                        FinancialRiskOutput = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[38, 6].Value2),
        //                        ManagementRiskOutput = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[39, 6].Value2),
        //                        OverAllScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[40, 6].Value2),
        //                        PreNotchUpRating = Convert.ToString(mWSheet.Cells[41, 6].Value2) == "-2146826246" ? "#N/A" : Convert.ToString(mWSheet.Cells[41, 6].Value2),
        //                        ParentRating = Convert.ToString(mWSheet.Cells[42, 6].Value2) == "-2146826246" ? "#N/A" : Convert.ToString(mWSheet.Cells[42, 6].Value2),
        //                        FinalRating = Convert.ToString(mWSheet.Cells[43, 6].Value2) == "-2146826246" ? "#N/A" : Convert.ToString(mWSheet.Cells[43, 6].Value2),
        //                        #endregion
        //                    };
        //                    riskModelExcelEntity.NHB_RiskModel_Outputs = NHB_RiskModel_Outputss;
        //                    #endregion

        //                    RiskModelExcelEntity companyBasicDetails = new RiskModelExcelEntity()
        //                    {
        //                        CompanyId = riskModelExcelEntity.CompanyId,
        //                        LocationId = riskModelExcelEntity.LocationId,
        //                        DateOfInput = riskModelExcelEntity.DateOfInput,
        //                        FinancialYearEndingDate = riskModelExcelEntity.FinancialYearEndingDate,
        //                        CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
        //                        ParentCompanyIsExist = riskModelExcelEntity.ParentCompanyIsExist,
        //                        ParentCompanyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.ParentCompanyId),
        //                        ParentRating = riskModelExcelEntity.ParentRating,
        //                        CreatedDateTime = riskModelExcelEntity.CreatedDateTime
        //                    };

        //                    detailID = companyDAL.SaveCompanyBasicDetailsAsDraft(userId, roleId, companyBasicDetails);

        //                    if (detailID > 0)
        //                    {
        //                        status = companyDAL.SaveCompanyBalanceSheetLiabilitiesAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_BalanceSheets_Liabilities)
        //                        && companyDAL.SaveCompanyBalanceSheetAssetsAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_BalanceSheet_Assets)
        //                        && companyDAL.SaveCompanyOtherBalanceSheetDisclosuresAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures)
        //                        && companyDAL.SaveCompanyContingentLiabilitiesAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_Contingent_Liabilities)
        //                        && companyDAL.SaveCompanyProfitAndLossStatementsAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_ProfitAndLossStatements)
        //                        && companyDAL.SaveCompanyALMStatementLatestsAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_ALM_Statement_Latests)
        //                        && companyDAL.SaveCompanyKeyRatiosAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_KeyRatios)
        //                        && companyDAL.SaveCompanyIndustryRiskInputsAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_Industry_RiskInputs)
        //                        && companyDAL.SaveCompanyBusinessRiskInputsAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_Business_RiskInputs)
        //                        && companyDAL.SaveCompanyFinancialRiskInputsAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_Financial_RiskInputs)
        //                        && companyDAL.SaveCompanyManagementRiskInputsAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_Management_RiskInputs)
        //                        && companyDAL.SaveCompanyNotchUpCriteriaInputsAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_NotchUp_CriteriaInputs)
        //                        && companyDAL.SaveCompanyRiskModelOutputsAsDraft(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_RiskModel_Outputs);

        //                    }


        //                    mWorkBook.Save();
        //                    mWorkBook.Close(1, null, null);
        //                    xlApp.Quit();

        //                    mWSheet = null;
        //                    mWorkBook = null;
        //                    mWorkSheets = null;
        //                    xlApp = null;

        //                    GC.Collect();
        //                    GC.WaitForPendingFinalizers();
        //                    GC.Collect();
        //                    GC.WaitForPendingFinalizers();
        //                    status = true;
        //                }
        //            }
        //            else
        //            {

        //                ViewBag.Error = "Sorry!!!...Your Session has been Expired";
        //                status = false;
        //            }
        //        }
        //        else
        //        {
        //            if (!string.IsNullOrWhiteSpace(riskModelFilePath))
        //            {
        //                mWorkBook = xlApp.Workbooks.Open(riskModelFilePath, 0, false, 5, "", "", true, XlPlatform.xlWindows, "", true, false, 0, true, false, false);
        //                mWorkSheets = mWorkBook.Worksheets;
        //                //Get the already exists sheet
        //                mWSheet = (Worksheet)mWorkSheets.get_Item(1);

        //                if (riskModelExcelEntity != null)
        //                {
        //                    #region NHB_Details

        //                    mWSheet.Cells[1, 2] = riskModelExcelEntity.DateOfInput;
        //                    mWSheet.Cells[2, 2] = riskModelExcelEntity.CompanyId;
        //                    string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
        //                    mWSheet.Cells[3, 2] = companyName;
        //                    string location = companyDAL.GetLocationByID(riskModelExcelEntity.LocationId);
        //                    mWSheet.Cells[4, 2] = location;
        //                    mWSheet.Cells[5, 2] = riskModelExcelEntity.FinancialYearEndingDate;
        //                    mWSheet.Cells[6, 2] = riskModelExcelEntity.CurrencyUnits;
        //                    mWSheet.Cells[7, 2] = riskModelExcelEntity.ParentCompanyIsExist;
        //                    string parentCompanyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.ParentCompanyId);
        //                    mWSheet.Cells[8, 2] = parentCompanyName;
        //                    mWSheet.Cells[9, 2] = riskModelExcelEntity.ParentRating;

        //                    #endregion

        //                    #region NHB_BalanceSheets_Liabilities

        //                    mWSheet.Cells[11, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate1_Liabilities;
        //                    mWSheet.Cells[11, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate2_Liabilities;
        //                    mWSheet.Cells[11, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate3_Liabilities;
        //                    mWSheet.Cells[11, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate4_Liabilities;

        //                    mWSheet.Cells[12, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesType1;
        //                    mWSheet.Cells[12, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesType2;
        //                    mWSheet.Cells[12, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesType3;
        //                    mWSheet.Cells[12, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesType4;

        //                    mWSheet.Cells[14, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up1;
        //                    mWSheet.Cells[14, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up2;
        //                    mWSheet.Cells[14, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up3;
        //                    mWSheet.Cells[14, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up4;

        //                    mWSheet.Cells[15, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.EquityShareWarrant1;
        //                    mWSheet.Cells[15, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.EquityShareWarrant2;
        //                    mWSheet.Cells[15, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.EquityShareWarrant3;
        //                    mWSheet.Cells[15, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.EquityShareWarrant4;

        //                    mWSheet.Cells[17, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalReserves1;
        //                    mWSheet.Cells[17, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalReserves2;
        //                    mWSheet.Cells[17, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalReserves3;
        //                    mWSheet.Cells[17, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalReserves4;

        //                    mWSheet.Cells[18, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.GeneralReserves1;
        //                    mWSheet.Cells[18, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.GeneralReserves2;
        //                    mWSheet.Cells[18, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.GeneralReserves3;
        //                    mWSheet.Cells[18, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.GeneralReserves4;

        //                    mWSheet.Cells[19, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SharePremium1;
        //                    mWSheet.Cells[19, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SharePremium2;
        //                    mWSheet.Cells[19, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SharePremium3;
        //                    mWSheet.Cells[19, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SharePremium4;

        //                    mWSheet.Cells[20, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves1;
        //                    mWSheet.Cells[20, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves2;
        //                    mWSheet.Cells[20, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves3;
        //                    mWSheet.Cells[20, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves4;

        //                    mWSheet.Cells[21, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherReserves1;
        //                    mWSheet.Cells[21, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherReserves2;
        //                    mWSheet.Cells[21, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherReserves3;
        //                    mWSheet.Cells[21, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherReserves4;

        //                    mWSheet.Cells[22, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.RevenueReserves1;
        //                    mWSheet.Cells[22, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.RevenueReserves2;
        //                    mWSheet.Cells[22, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.RevenueReserves3;
        //                    mWSheet.Cells[22, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.RevenueReserves4;

        //                    mWSheet.Cells[23, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.IntangibleAssets1;
        //                    mWSheet.Cells[23, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.IntangibleAssets2;
        //                    mWSheet.Cells[23, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.IntangibleAssets3;
        //                    mWSheet.Cells[23, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.IntangibleAssets4;

        //                    mWSheet.Cells[25, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CommercialPaper1;
        //                    mWSheet.Cells[25, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CommercialPaper2;
        //                    mWSheet.Cells[25, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CommercialPaper3;
        //                    mWSheet.Cells[25, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CommercialPaper4;

        //                    mWSheet.Cells[26, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.InterCorporateDeposits1;
        //                    mWSheet.Cells[26, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.InterCorporateDeposits2;
        //                    mWSheet.Cells[26, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.InterCorporateDeposits3;
        //                    mWSheet.Cells[26, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.InterCorporateDeposits4;

        //                    mWSheet.Cells[27, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney1;
        //                    mWSheet.Cells[27, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney2;
        //                    mWSheet.Cells[27, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney3;
        //                    mWSheet.Cells[27, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney4;

        //                    mWSheet.Cells[28, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherBorrowings1;
        //                    mWSheet.Cells[28, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherBorrowings2;
        //                    mWSheet.Cells[28, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherBorrowings3;
        //                    mWSheet.Cells[28, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.OtherBorrowings4;

        //                    mWSheet.Cells[29, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear1;
        //                    mWSheet.Cells[29, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear2;
        //                    mWSheet.Cells[29, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear3;
        //                    mWSheet.Cells[29, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear4;

        //                    mWSheet.Cells[30, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PublicDeposits1;
        //                    mWSheet.Cells[30, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PublicDeposits2;
        //                    mWSheet.Cells[30, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PublicDeposits3;
        //                    mWSheet.Cells[30, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PublicDeposits4;

        //                    mWSheet.Cells[31, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ShortTermBorrowings1;
        //                    mWSheet.Cells[31, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ShortTermBorrowings2;
        //                    mWSheet.Cells[31, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ShortTermBorrowings3;
        //                    mWSheet.Cells[31, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ShortTermBorrowings4;

        //                    mWSheet.Cells[32, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB1;
        //                    mWSheet.Cells[32, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB2;
        //                    mWSheet.Cells[32, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB3;
        //                    mWSheet.Cells[32, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB4;

        //                    mWSheet.Cells[33, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers1;
        //                    mWSheet.Cells[33, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers2;
        //                    mWSheet.Cells[33, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers3;
        //                    mWSheet.Cells[33, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers4;

        //                    mWSheet.Cells[34, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB1;
        //                    mWSheet.Cells[34, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB2;
        //                    mWSheet.Cells[34, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB3;
        //                    mWSheet.Cells[34, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB4;

        //                    mWSheet.Cells[35, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers1;
        //                    mWSheet.Cells[35, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers2;
        //                    mWSheet.Cells[35, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers3;
        //                    mWSheet.Cells[35, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers4;

        //                    mWSheet.Cells[36, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings1;
        //                    mWSheet.Cells[36, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings2;
        //                    mWSheet.Cells[36, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings3;
        //                    mWSheet.Cells[36, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings4;

        //                    mWSheet.Cells[37, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency1;
        //                    mWSheet.Cells[37, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency2;
        //                    mWSheet.Cells[37, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency3;
        //                    mWSheet.Cells[37, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency4;

        //                    mWSheet.Cells[38, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties1;
        //                    mWSheet.Cells[38, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties2;
        //                    mWSheet.Cells[38, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties3;
        //                    mWSheet.Cells[38, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties4;

        //                    mWSheet.Cells[39, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.HybridInstruments1;
        //                    mWSheet.Cells[39, 3] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.HybridInstruments2;
        //                    mWSheet.Cells[39, 4] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.HybridInstruments3;
        //                    mWSheet.Cells[39, 5] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.HybridInstruments4;

        //                    #region NBH_BalanceSheets_Liabilities_Outputs


        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalPEOutput1 = ExtensionMethod.GetValues(mWSheet.Cells[13, 2].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalPEOutput2 = ExtensionMethod.GetValues(mWSheet.Cells[13, 3].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalPEOutput3 = ExtensionMethod.GetValues(mWSheet.Cells[13, 4].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.CapitalPEOutput4 = ExtensionMethod.GetValues(mWSheet.Cells[13, 5].Value2);

                           
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput1 = Convert.ToString(mWSheet.Cells[16, 2].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput2 = Convert.ToString(mWSheet.Cells[16, 3].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput3 = Convert.ToString(mWSheet.Cells[16, 4].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput4 = Convert.ToString(mWSheet.Cells[16, 5].Value2);

        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsOutput1 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[24, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsOutput2 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[24, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsOutput3 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[24, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.BorrowingsOutput4 = Convert.ToString(ExtensionMethod.GetValues(mWSheet.Cells[24, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[40, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[40, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[40, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[40, 5].Value2));

        //                    #endregion

        //                    #endregion

        //                    #region NBH_BalanceSheet_Assets

        //                    mWSheet.Cells[42, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PeriodEndingDate1_Assets;
        //                    mWSheet.Cells[42, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PeriodEndingDate2_Assets;
        //                    mWSheet.Cells[42, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PeriodEndingDate3_Assets;
        //                    mWSheet.Cells[42, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PeriodEndingDate4_Assets;

        //                    mWSheet.Cells[44, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OwnedNetBlock1;
        //                    mWSheet.Cells[44, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OwnedNetBlock2;
        //                    mWSheet.Cells[44, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OwnedNetBlock3;
        //                    mWSheet.Cells[44, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OwnedNetBlock4;

        //                    mWSheet.Cells[45, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LeasedNetBlock1;
        //                    mWSheet.Cells[45, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LeasedNetBlock2;
        //                    mWSheet.Cells[45, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LeasedNetBlock3;
        //                    mWSheet.Cells[45, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LeasedNetBlock4;

        //                    mWSheet.Cells[46, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CapitalWorkInProgress1;
        //                    mWSheet.Cells[46, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CapitalWorkInProgress2;
        //                    mWSheet.Cells[46, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CapitalWorkInProgress3;
        //                    mWSheet.Cells[46, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CapitalWorkInProgress4;

        //                    mWSheet.Cells[48, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted1;
        //                    mWSheet.Cells[48, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted2;
        //                    mWSheet.Cells[48, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted3;
        //                    mWSheet.Cells[48, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted4;

        //                    mWSheet.Cells[49, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted1;
        //                    mWSheet.Cells[49, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted2;
        //                    mWSheet.Cells[49, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted3;
        //                    mWSheet.Cells[49, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted4;

        //                    mWSheet.Cells[50, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.StateGovernmentSecurities1;
        //                    mWSheet.Cells[50, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.StateGovernmentSecurities2;
        //                    mWSheet.Cells[50, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.StateGovernmentSecurities3;
        //                    mWSheet.Cells[50, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.StateGovernmentSecurities4;

        //                    mWSheet.Cells[51, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds1;
        //                    mWSheet.Cells[51, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds2;
        //                    mWSheet.Cells[51, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds3;
        //                    mWSheet.Cells[51, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds4;

        //                    mWSheet.Cells[52, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPublicSectorBonds1;
        //                    mWSheet.Cells[52, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPublicSectorBonds2;
        //                    mWSheet.Cells[52, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPublicSectorBonds3;
        //                    mWSheet.Cells[52, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPublicSectorBonds4;

        //                    mWSheet.Cells[53, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade1;
        //                    mWSheet.Cells[53, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade2;
        //                    mWSheet.Cells[53, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade3;
        //                    mWSheet.Cells[53, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade4;

        //                    mWSheet.Cells[54, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds1;
        //                    mWSheet.Cells[54, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds2;
        //                    mWSheet.Cells[54, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds3;
        //                    mWSheet.Cells[54, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds4;

        //                    mWSheet.Cells[55, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.MutualFunds1;
        //                    mWSheet.Cells[55, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.MutualFunds2;
        //                    mWSheet.Cells[55, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.MutualFunds3;
        //                    mWSheet.Cells[55, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.MutualFunds4;

        //                    mWSheet.Cells[56, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ListedEquity1;
        //                    mWSheet.Cells[56, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ListedEquity2;
        //                    mWSheet.Cells[56, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ListedEquity3;
        //                    mWSheet.Cells[56, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ListedEquity4;

        //                    mWSheet.Cells[57, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnlistedEquity1;
        //                    mWSheet.Cells[57, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnlistedEquity2;
        //                    mWSheet.Cells[57, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnlistedEquity3;
        //                    mWSheet.Cells[57, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnlistedEquity4;

        //                    mWSheet.Cells[58, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates1;
        //                    mWSheet.Cells[58, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates2;
        //                    mWSheet.Cells[58, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates3;
        //                    mWSheet.Cells[58, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates4;

        //                    mWSheet.Cells[60, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.HirePurchaseReceivables1;
        //                    mWSheet.Cells[60, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.HirePurchaseReceivables2;
        //                    mWSheet.Cells[60, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.HirePurchaseReceivables3;
        //                    mWSheet.Cells[60, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.HirePurchaseReceivables4;

        //                    mWSheet.Cells[61, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.FinanceLeases1;
        //                    mWSheet.Cells[61, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.FinanceLeases2;
        //                    mWSheet.Cells[61, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.FinanceLeases3;
        //                    mWSheet.Cells[61, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.FinanceLeases4;

        //                    mWSheet.Cells[62, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.SecuredLoans1;
        //                    mWSheet.Cells[62, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.SecuredLoans2;
        //                    mWSheet.Cells[62, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.SecuredLoans3;
        //                    mWSheet.Cells[62, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.SecuredLoans4;

        //                    mWSheet.Cells[63, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnsecuredLoans1;
        //                    mWSheet.Cells[63, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnsecuredLoans2;
        //                    mWSheet.Cells[63, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnsecuredLoans3;
        //                    mWSheet.Cells[63, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.UnsecuredLoans4;

        //                    mWSheet.Cells[64, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.Debtors1;
        //                    mWSheet.Cells[64, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.Debtors2;
        //                    mWSheet.Cells[64, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.Debtors3;
        //                    mWSheet.Cells[64, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.Debtors4;

        //                    mWSheet.Cells[65, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.BillsDiscounted1;
        //                    mWSheet.Cells[65, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.BillsDiscounted2;
        //                    mWSheet.Cells[65, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.BillsDiscounted3;
        //                    mWSheet.Cells[65, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.BillsDiscounted4;

        //                    mWSheet.Cells[66, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherInterestBearingLoans1;
        //                    mWSheet.Cells[66, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherInterestBearingLoans2;
        //                    mWSheet.Cells[66, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherInterestBearingLoans3;
        //                    mWSheet.Cells[66, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherInterestBearingLoans4;

        //                    mWSheet.Cells[67, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LoansToRelatedParties1;
        //                    mWSheet.Cells[67, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LoansToRelatedParties2;
        //                    mWSheet.Cells[67, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LoansToRelatedParties3;
        //                    mWSheet.Cells[67, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.LoansToRelatedParties4;

        //                    mWSheet.Cells[68, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CashAndBank1;
        //                    mWSheet.Cells[68, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CashAndBank2;
        //                    mWSheet.Cells[68, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CashAndBank3;
        //                    mWSheet.Cells[68, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.CashAndBank4;

        //                    mWSheet.Cells[69, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesPaid1;
        //                    mWSheet.Cells[69, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesPaid2;
        //                    mWSheet.Cells[69, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesPaid3;
        //                    mWSheet.Cells[69, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesPaid4;

        //                    mWSheet.Cells[70, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentAssets1;
        //                    mWSheet.Cells[70, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentAssets2;
        //                    mWSheet.Cells[70, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentAssets3;
        //                    mWSheet.Cells[70, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentAssets4;

        //                    mWSheet.Cells[71, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets1;
        //                    mWSheet.Cells[71, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets2;
        //                    mWSheet.Cells[71, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets3;
        //                    mWSheet.Cells[71, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets4;

        //                    mWSheet.Cells[73, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InterestAccruedButNotDue1;
        //                    mWSheet.Cells[73, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InterestAccruedButNotDue2;
        //                    mWSheet.Cells[73, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InterestAccruedButNotDue3;
        //                    mWSheet.Cells[73, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.InterestAccruedButNotDue4;

        //                    mWSheet.Cells[74, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DepositsReceived1;
        //                    mWSheet.Cells[74, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DepositsReceived2;
        //                    mWSheet.Cells[74, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DepositsReceived3;
        //                    mWSheet.Cells[74, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DepositsReceived4;

        //                    mWSheet.Cells[75, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesReceived1;
        //                    mWSheet.Cells[75, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesReceived2;
        //                    mWSheet.Cells[75, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesReceived3;
        //                    mWSheet.Cells[75, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.AdvancesReceived4;

        //                    mWSheet.Cells[76, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentLiabilities1;
        //                    mWSheet.Cells[76, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentLiabilities2;
        //                    mWSheet.Cells[76, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentLiabilities3;
        //                    mWSheet.Cells[76, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherCurrentLiabilities4;

        //                    mWSheet.Cells[77, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DeferredtaxLiability1;
        //                    mWSheet.Cells[77, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DeferredtaxLiability2;
        //                    mWSheet.Cells[77, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DeferredtaxLiability3;
        //                    mWSheet.Cells[77, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.DeferredtaxLiability4;

        //                    mWSheet.Cells[78, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ReceivablesSecuritised1;
        //                    mWSheet.Cells[78, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ReceivablesSecuritised2;
        //                    mWSheet.Cells[78, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ReceivablesSecuritised3;
        //                    mWSheet.Cells[78, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ReceivablesSecuritised4;

        //                    mWSheet.Cells[80, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForLoanLosses1;
        //                    mWSheet.Cells[80, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForLoanLosses2;
        //                    mWSheet.Cells[80, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForLoanLosses3;
        //                    mWSheet.Cells[80, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForLoanLosses4;

        //                    mWSheet.Cells[81, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors1;
        //                    mWSheet.Cells[81, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors2;
        //                    mWSheet.Cells[81, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors3;
        //                    mWSheet.Cells[81, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors4;

        //                    mWSheet.Cells[82, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDepreciation1;
        //                    mWSheet.Cells[82, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDepreciation2;
        //                    mWSheet.Cells[82, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDepreciation3;
        //                    mWSheet.Cells[82, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDepreciation4;

        //                    mWSheet.Cells[83, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets1;
        //                    mWSheet.Cells[83, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets2;
        //                    mWSheet.Cells[83, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets3;
        //                    mWSheet.Cells[83, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets4;

        //                    mWSheet.Cells[84, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDividend1;
        //                    mWSheet.Cells[84, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDividend2;
        //                    mWSheet.Cells[84, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDividend3;
        //                    mWSheet.Cells[84, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDividend4;

        //                    mWSheet.Cells[85, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForTaxes1;
        //                    mWSheet.Cells[85, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForTaxes2;
        //                    mWSheet.Cells[85, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForTaxes3;
        //                    mWSheet.Cells[85, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForTaxes4;

        //                    mWSheet.Cells[86, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes1;
        //                    mWSheet.Cells[86, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes2;
        //                    mWSheet.Cells[86, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes3;
        //                    mWSheet.Cells[86, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes4;

        //                    mWSheet.Cells[87, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForExpenses1;
        //                    mWSheet.Cells[87, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForExpenses2;
        //                    mWSheet.Cells[87, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForExpenses3;
        //                    mWSheet.Cells[87, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionForExpenses4;

        //                    mWSheet.Cells[88, 2] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherProvisions1;
        //                    mWSheet.Cells[88, 3] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherProvisions2;
        //                    mWSheet.Cells[88, 4] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherProvisions3;
        //                    mWSheet.Cells[88, 5] = riskModelExcelEntity.NHB_BalanceSheet_Assets.OtherProvisions4;

        //                    #region NBH_BalanceSheet_Asset_Output

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.FixedAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[43, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.FixedAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[43, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.FixedAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[43, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.FixedAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[43, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[47, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[47, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[47, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.InvestmentsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[47, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[59, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[59, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[59, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[59, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[72, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[72, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[72, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[72, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[79, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[79, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[79, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ProvisionsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[79, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[89, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[89, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[89, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[89, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.TotalAssetsOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[90, 2].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.TotalAssetsOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[90, 3].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.TotalAssetsOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[90, 4].Value2));
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.TotalAssetsOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[90, 5].Value2));

        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ErrorCheck1 = Convert.ToString(mWSheet.Cells[91, 2].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ErrorCheck2 = Convert.ToString(mWSheet.Cells[91, 3].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ErrorCheck3 = Convert.ToString(mWSheet.Cells[91, 4].Value2);
        //                    riskModelExcelEntity.NHB_BalanceSheet_Assets.ErrorCheck4 = Convert.ToString(mWSheet.Cells[91, 5].Value2);

        //                    #endregion

        //                    #endregion

        //                    #region NHB_OtherBalanceSheet_Disclosures

        //                    mWSheet.Cells[102, 2] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage1)) / 100;
        //                    mWSheet.Cells[102, 3] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage2)) / 100;
        //                    mWSheet.Cells[102, 4] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage3)) / 100;
        //                    mWSheet.Cells[102, 5] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage4)) / 100;

        //                    mWSheet.Cells[103, 2] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage1)) / 100;
        //                    mWSheet.Cells[103, 3] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage2)) / 100;
        //                    mWSheet.Cells[103, 4] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage3)) / 100;
        //                    mWSheet.Cells[103, 5] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage4)) / 100;

        //                    mWSheet.Cells[104, 2] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage1)) / 100;
        //                    mWSheet.Cells[104, 3] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage2)) / 100;
        //                    mWSheet.Cells[104, 4] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage3)) / 100;
        //                    mWSheet.Cells[104, 5] = (Convert.ToDouble(riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage4)) / 100;

        //                    mWSheet.Cells[105, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage1;
        //                    mWSheet.Cells[105, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage2;
        //                    mWSheet.Cells[105, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage3;
        //                    mWSheet.Cells[105, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage4;

        //                    mWSheet.Cells[106, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage1;
        //                    mWSheet.Cells[106, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage2;
        //                    mWSheet.Cells[106, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage3;
        //                    mWSheet.Cells[106, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage4;

        //                    mWSheet.Cells[107, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage1;
        //                    mWSheet.Cells[107, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage2;
        //                    mWSheet.Cells[107, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage3;
        //                    mWSheet.Cells[107, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage4;

        //                    mWSheet.Cells[108, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.GrossNPAs1;
        //                    mWSheet.Cells[108, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.GrossNPAs2;
        //                    mWSheet.Cells[108, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.GrossNPAs3;
        //                    mWSheet.Cells[108, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.GrossNPAs4;

        //                    mWSheet.Cells[109, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld1;
        //                    mWSheet.Cells[109, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld2;
        //                    mWSheet.Cells[109, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld3;
        //                    mWSheet.Cells[109, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld4;

        //                    mWSheet.Cells[110, 2] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.NetNPAs1;
        //                    mWSheet.Cells[110, 3] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.NetNPAs2;
        //                    mWSheet.Cells[110, 4] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.NetNPAs3;
        //                    mWSheet.Cells[110, 5] = riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures.NetNPAs4;

        //                    #endregion

        //                    #region NHB_Contingent Liabilities

        //                    mWSheet.Cells[93, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts1;
        //                    mWSheet.Cells[93, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts2;
        //                    mWSheet.Cells[93, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts3;
        //                    mWSheet.Cells[93, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts4;

        //                    mWSheet.Cells[94, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.GuaranteesGiven1;
        //                    mWSheet.Cells[94, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.GuaranteesGiven2;
        //                    mWSheet.Cells[94, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.GuaranteesGiven3;
        //                    mWSheet.Cells[94, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.GuaranteesGiven4;

        //                    mWSheet.Cells[95, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments1;
        //                    mWSheet.Cells[95, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments2;
        //                    mWSheet.Cells[95, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments3;
        //                    mWSheet.Cells[95, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments4;

        //                    mWSheet.Cells[96, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts1;
        //                    mWSheet.Cells[96, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts2;
        //                    mWSheet.Cells[96, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts3;
        //                    mWSheet.Cells[96, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts4;

        //                    mWSheet.Cells[97, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts1;
        //                    mWSheet.Cells[97, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts2;
        //                    mWSheet.Cells[97, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts3;
        //                    mWSheet.Cells[97, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts4;

        //                    mWSheet.Cells[98, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations1;
        //                    mWSheet.Cells[98, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations2;
        //                    mWSheet.Cells[98, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations3;
        //                    mWSheet.Cells[98, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations4;

        //                    mWSheet.Cells[99, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts1;
        //                    mWSheet.Cells[99, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts2;
        //                    mWSheet.Cells[99, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts3;
        //                    mWSheet.Cells[99, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts4;

        //                    mWSheet.Cells[100, 2] = riskModelExcelEntity.NHB_Contingent_Liabilities.OtherItems1;
        //                    mWSheet.Cells[100, 3] = riskModelExcelEntity.NHB_Contingent_Liabilities.OtherItems2;
        //                    mWSheet.Cells[100, 4] = riskModelExcelEntity.NHB_Contingent_Liabilities.OtherItems3;
        //                    mWSheet.Cells[100, 5] = riskModelExcelEntity.NHB_Contingent_Liabilities.OtherItems4;

        //                    #endregion

        //                    #region NHB_Profit&LossStatement

        //                    mWSheet.Cells[112, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PeriodEndingDate1_ProfitAndLoss;
        //                    mWSheet.Cells[112, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PeriodEndingDate2_ProfitAndLoss;
        //                    mWSheet.Cells[112, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PeriodEndingDate3_ProfitAndLoss;
        //                    mWSheet.Cells[112, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PeriodEndingDate4_ProfitAndLoss;

        //                    mWSheet.Cells[115, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals1;
        //                    mWSheet.Cells[115, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals2;
        //                    mWSheet.Cells[115, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals3;
        //                    mWSheet.Cells[115, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals4;

        //                    mWSheet.Cells[116, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies1;
        //                    mWSheet.Cells[116, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies2;
        //                    mWSheet.Cells[116, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies3;
        //                    mWSheet.Cells[116, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies4;

        //                    mWSheet.Cells[117, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherInterestIncome1;
        //                    mWSheet.Cells[117, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherInterestIncome2;
        //                    mWSheet.Cells[117, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherInterestIncome3;
        //                    mWSheet.Cells[117, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherInterestIncome4;

        //                    mWSheet.Cells[118, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm1;
        //                    mWSheet.Cells[118, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm2;
        //                    mWSheet.Cells[118, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm3;
        //                    mWSheet.Cells[118, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm4;

        //                    mWSheet.Cells[119, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm1;
        //                    mWSheet.Cells[119, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm2;
        //                    mWSheet.Cells[119, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm3;
        //                    mWSheet.Cells[119, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm4;

        //                    mWSheet.Cells[121, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.FeesReceived1;
        //                    mWSheet.Cells[121, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.FeesReceived2;
        //                    mWSheet.Cells[121, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.FeesReceived3;
        //                    mWSheet.Cells[121, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.FeesReceived4;

        //                    mWSheet.Cells[122, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage1;
        //                    mWSheet.Cells[122, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage2;
        //                    mWSheet.Cells[122, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage3;
        //                    mWSheet.Cells[122, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage4;

        //                    mWSheet.Cells[123, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments1;
        //                    mWSheet.Cells[123, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments2;
        //                    mWSheet.Cells[123, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments3;
        //                    mWSheet.Cells[123, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments4;

        //                    mWSheet.Cells[124, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleAssets1;
        //                    mWSheet.Cells[124, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleAssets2;
        //                    mWSheet.Cells[124, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleAssets3;
        //                    mWSheet.Cells[124, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossSaleAssets4;

        //                    mWSheet.Cells[125, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions1;
        //                    mWSheet.Cells[125, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions2;
        //                    mWSheet.Cells[125, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions3;
        //                    mWSheet.Cells[125, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions4;

        //                    mWSheet.Cells[126, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherServiceIncome1;
        //                    mWSheet.Cells[126, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherServiceIncome2;
        //                    mWSheet.Cells[126, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherServiceIncome3;
        //                    mWSheet.Cells[126, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherServiceIncome4;

        //                    mWSheet.Cells[127, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets1;
        //                    mWSheet.Cells[127, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets2;
        //                    mWSheet.Cells[127, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets3;
        //                    mWSheet.Cells[127, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets4;

        //                    mWSheet.Cells[128, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherNonOperatingIncome1;
        //                    mWSheet.Cells[128, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherNonOperatingIncome2;
        //                    mWSheet.Cells[128, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherNonOperatingIncome3;
        //                    mWSheet.Cells[128, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherNonOperatingIncome4;

        //                    mWSheet.Cells[131, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnDeposits1;
        //                    mWSheet.Cells[131, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnDeposits2;
        //                    mWSheet.Cells[131, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnDeposits3;
        //                    mWSheet.Cells[131, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnDeposits4;

        //                    mWSheet.Cells[132, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnBorrowings1;
        //                    mWSheet.Cells[132, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnBorrowings2;
        //                    mWSheet.Cells[132, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnBorrowings3;
        //                    mWSheet.Cells[132, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestOnBorrowings4;

        //                    mWSheet.Cells[134, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherFinancialCharges1;
        //                    mWSheet.Cells[134, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherFinancialCharges2;
        //                    mWSheet.Cells[134, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherFinancialCharges3;
        //                    mWSheet.Cells[134, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherFinancialCharges4;

        //                    mWSheet.Cells[135, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PersonnelExpenses1;
        //                    mWSheet.Cells[135, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PersonnelExpenses2;
        //                    mWSheet.Cells[135, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PersonnelExpenses3;
        //                    mWSheet.Cells[135, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PersonnelExpenses4;

        //                    mWSheet.Cells[137, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpenses1;
        //                    mWSheet.Cells[137, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpenses2;
        //                    mWSheet.Cells[137, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpenses3;
        //                    mWSheet.Cells[137, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpenses4;

        //                    mWSheet.Cells[138, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff1;
        //                    mWSheet.Cells[138, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff2;
        //                    mWSheet.Cells[138, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff3;
        //                    mWSheet.Cells[138, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff4;

        //                    mWSheet.Cells[139, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets1;
        //                    mWSheet.Cells[139, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets2;
        //                    mWSheet.Cells[139, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets3;
        //                    mWSheet.Cells[139, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets4;

        //                    mWSheet.Cells[140, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.Depreciation1;
        //                    mWSheet.Cells[140, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.Depreciation2;
        //                    mWSheet.Cells[140, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.Depreciation3;
        //                    mWSheet.Cells[140, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.Depreciation4;

        //                    mWSheet.Cells[142, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForLoanLosses1;
        //                    mWSheet.Cells[142, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForLoanLosses2;
        //                    mWSheet.Cells[142, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForLoanLosses3;
        //                    mWSheet.Cells[142, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForLoanLosses4;

        //                    mWSheet.Cells[143, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund1;
        //                    mWSheet.Cells[143, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund2;
        //                    mWSheet.Cells[143, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund3;
        //                    mWSheet.Cells[143, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund4;

        //                    mWSheet.Cells[144, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack1;
        //                    mWSheet.Cells[144, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack2;
        //                    mWSheet.Cells[144, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack3;
        //                    mWSheet.Cells[144, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack4;

        //                    mWSheet.Cells[145, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff1;
        //                    mWSheet.Cells[145, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff2;
        //                    mWSheet.Cells[145, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff3;
        //                    mWSheet.Cells[145, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff4;

        //                    mWSheet.Cells[146, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherAdjustments1;
        //                    mWSheet.Cells[146, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherAdjustments2;
        //                    mWSheet.Cells[146, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherAdjustments3;
        //                    mWSheet.Cells[146, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherAdjustments4;

        //                    mWSheet.Cells[149, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CurrentTax1;
        //                    mWSheet.Cells[149, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CurrentTax2;
        //                    mWSheet.Cells[149, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CurrentTax3;
        //                    mWSheet.Cells[149, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.CurrentTax4;

        //                    mWSheet.Cells[150, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.DeferredTax1;
        //                    mWSheet.Cells[150, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.DeferredTax2;
        //                    mWSheet.Cells[150, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.DeferredTax3;
        //                    mWSheet.Cells[150, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.DeferredTax4;

        //                    mWSheet.Cells[152, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PreferenceDividend_Tax1;
        //                    mWSheet.Cells[152, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PreferenceDividend_Tax2;
        //                    mWSheet.Cells[152, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PreferenceDividend_Tax3;
        //                    mWSheet.Cells[152, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.PreferenceDividend_Tax4;

        //                    mWSheet.Cells[153, 2] = riskModelExcelEntity.NHB_ProfitAndLossStatements.EquityDividend_Tax1;
        //                    mWSheet.Cells[153, 3] = riskModelExcelEntity.NHB_ProfitAndLossStatements.EquityDividend_Tax2;
        //                    mWSheet.Cells[153, 4] = riskModelExcelEntity.NHB_ProfitAndLossStatements.EquityDividend_Tax3;
        //                    mWSheet.Cells[153, 5] = riskModelExcelEntity.NHB_ProfitAndLossStatements.EquityDividend_Tax4;



        //                    #region NHB_Profit&LossStatement Output

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[113, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[113, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[113, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.IncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[113, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestIncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[114, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestIncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[114, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestIncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[114, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestIncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[114, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[120, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[120, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[120, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[120, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[129, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[129, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[129, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[129, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[130, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[130, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[130, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[130, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestPaidOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[133, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestPaidOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[133, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestPaidOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[133, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.InterestPaidOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[133, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpensesOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[136, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpensesOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[136, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpensesOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[136, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.OperatingExpensesOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[136, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.LoanLosses1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[141, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.LoanLosses2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[141, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.LoanLosses3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[141, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.LoanLosses4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[141, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[147, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[147, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[147, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[147, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.TaxExpenseOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[148, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.TaxExpenseOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[148, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.TaxExpenseOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[148, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.TaxExpenseOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[148, 5].Value2));

        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput1 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[151, 2].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput2 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[151, 3].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput3 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[151, 4].Value2));
        //                    riskModelExcelEntity.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput4 = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[151, 5].Value2));

        //                    #endregion

        //                    #endregion

        //                    #region NHB_ALM_Statement_Latests

        //                    mWSheet.Range["B155"].Value = riskModelExcelEntity.NHB_ALM_Statement_Latests.Statement_Date;

        //                    mWSheet.Cells[157, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Day1to14DaysInflow;
        //                    mWSheet.Cells[157, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Day1to14DaysOurflow;

        //                    mWSheet.Cells[158, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Day14DaysTo1MonthInflow;
        //                    mWSheet.Cells[158, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Day14DaysTo1MonthOurflow;

        //                    mWSheet.Cells[159, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month1To2MonthsInflow;
        //                    mWSheet.Cells[159, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month1To2MonthsOurflow;

        //                    mWSheet.Cells[160, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month2To3MonthsInflow;
        //                    mWSheet.Cells[160, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month2To3MonthsOurflow;

        //                    mWSheet.Cells[161, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month3To6MonthsInflow;
        //                    mWSheet.Cells[161, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month3To6MonthsOurflow;

        //                    mWSheet.Cells[162, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month6MonthsTo1YearInflow;
        //                    mWSheet.Cells[162, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Month6MonthsTo1YearOurflow;

        //                    mWSheet.Cells[163, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year1To3YearsInflow;
        //                    mWSheet.Cells[163, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year1To3YearsOurflow;

        //                    mWSheet.Cells[164, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year3To5YearsInflow;
        //                    mWSheet.Cells[164, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year3To5YearsOurflow;

        //                    mWSheet.Cells[165, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year5To7YearsInflow;
        //                    mWSheet.Cells[165, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year5To7YearsOurflow;

        //                    mWSheet.Cells[166, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year7To10YearsInflow;
        //                    mWSheet.Cells[166, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Year7To10YearsOurflow;

        //                    mWSheet.Cells[167, 2] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Over10YearsInflow;
        //                    mWSheet.Cells[167, 3] = riskModelExcelEntity.NHB_ALM_Statement_Latests.Over10YearsOurflow;

        //                    #region NHB_ALM_Statement_Latest_Output

        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Day1to14DaysMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[157, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Day14DaysTo1MonthMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[158, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Month1To2MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[159, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Month2To3MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[160, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Month3To6MonthsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[161, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Month6MonthsTo1YearMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[162, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Year1To3YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[163, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Year3To5YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[164, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Year5To7YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[165, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Year7To10YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[166, 4].Value2));
        //                    riskModelExcelEntity.NHB_ALM_Statement_Latests.Over10YearsMismatch = ExtensionMethod.GetValues(Convert.ToDouble(mWSheet.Cells[167, 4].Value2));

        //                    #endregion

        //                    #endregion

        //                    #region NHB_KeyRatios

        //                    riskModelExcelEntity.NHB_KeyRatios.TotalAssets1 = Convert.ToInt32(mWSheet.Cells[169, 2].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TotalAssets2 = Convert.ToInt32(mWSheet.Cells[169, 3].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TotalAssets3 = Convert.ToInt32(mWSheet.Cells[169, 4].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TotalAssets4 = Convert.ToInt32(mWSheet.Cells[169, 5].Value2);

        //                    riskModelExcelEntity.NHB_KeyRatios.GrossNPAPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[170, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GrossNPAPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[170, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GrossNPAPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[170, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GrossNPAPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[170, 5].Value2) * 100, 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.ALMMismatchPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[171, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.ALMMismatchPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[171, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.ALMMismatchPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[171, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.ALMMismatchPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[171, 5].Value2) * 100, 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.NetWorth1 = Convert.ToInt32(mWSheet.Cells[172, 2].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetWorth2 = Convert.ToInt32(mWSheet.Cells[172, 3].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetWorth3 = Convert.ToInt32(mWSheet.Cells[172, 4].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetWorth4 = Convert.ToInt32(mWSheet.Cells[172, 5].Value2);

        //                    riskModelExcelEntity.NHB_KeyRatios.CRARPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[173, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.CRARPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[173, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.CRARPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[173, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.CRARPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[173, 5].Value2) * 100, 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.GearingPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[174, 2].Value2), 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GearingPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[174, 3].Value2), 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GearingPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[174, 4].Value2), 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.GearingPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[174, 5].Value2), 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.TangibleNWNetNPA1 = Convert.ToInt32(mWSheet.Cells[175, 2].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TangibleNWNetNPA2 = Convert.ToInt32(mWSheet.Cells[175, 3].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TangibleNWNetNPA3 = Convert.ToInt32(mWSheet.Cells[175, 4].Value2);
        //                    riskModelExcelEntity.NHB_KeyRatios.TangibleNWNetNPA4 = Convert.ToInt32(mWSheet.Cells[175, 5].Value2);

        //                    riskModelExcelEntity.NHB_KeyRatios.NetMarginPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[176, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetMarginPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[176, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetMarginPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[176, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.NetMarginPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[176, 5].Value2) * 100, 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageFundsDeployedPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[177, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageFundsDeployedPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[177, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageFundsDeployedPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[177, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageFundsDeployedPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[177, 5].Value2) * 100, 2);

        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageNetWorthPercentage1 = Math.Round(Convert.ToDecimal(mWSheet.Cells[178, 2].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageNetWorthPercentage2 = Math.Round(Convert.ToDecimal(mWSheet.Cells[178, 3].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageNetWorthPercentage3 = Math.Round(Convert.ToDecimal(mWSheet.Cells[178, 4].Value2) * 100, 2);
        //                    riskModelExcelEntity.NHB_KeyRatios.PATAverageNetWorthPercentage4 = Math.Round(Convert.ToDecimal(mWSheet.Cells[178, 5].Value2) * 100, 2);

        //                    #endregion

        //                    #region NHB_Industry_RiskInputs

        //                    mWSheet.Range["B180"].Value = riskModelExcelEntity.NHB_Industry_RiskInputs.FinancialPerformanceofPlayer;
        //                    mWSheet.Range["B181"].Value = riskModelExcelEntity.NHB_Industry_RiskInputs.ExtentOfCompetition;
        //                    mWSheet.Range["B182"].Value = riskModelExcelEntity.NHB_Industry_RiskInputs.ProspectOfRealEstateMarket;
        //                    mWSheet.Range["B183"].Value = riskModelExcelEntity.NHB_Industry_RiskInputs.RegulatoryImpact;

        //                    #endregion

        //                    #region NHB_Business_RiskInputs

        //                    mWSheet.Range["B185"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.RankOfMarketPosition;
        //                    mWSheet.Range["B186"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.GeographicalDiversification;
        //                    mWSheet.Range["B187"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.ProductMix;
        //                    mWSheet.Range["B188"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.CustomerMix;
        //                    mWSheet.Range["B189"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.CostOfResources;
        //                    mWSheet.Range["B190"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.TotalAssetGrowth;
        //                    mWSheet.Range["B191"].Value = riskModelExcelEntity.NHB_Business_RiskInputs.DiversificationOfFundingProfile;


        //                    #endregion

        //                    #region NHB_Financial_RiskInputs

        //                    mWSheet.Range["B193"].Value = riskModelExcelEntity.NHB_Financial_RiskInputs.CompanysAbility;

        //                    #endregion

        //                    #region NHB_Management_RiskInputs

        //                    mWSheet.Range["B195"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.AbilityToMeetRevenueProjection;
        //                    mWSheet.Range["B196"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.AbilityToMeetProfitProjection;
        //                    mWSheet.Range["B197"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.PastPaymentRecord;
        //                    mWSheet.Range["B198"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.RiskManagementSystem;
        //                    mWSheet.Range["B199"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.ManagementCredibility;
        //                    mWSheet.Range["B200"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.ManagementExperienceAndCompetence;
        //                    mWSheet.Range["B201"].Value = riskModelExcelEntity.NHB_Management_RiskInputs.RiskAppetite;


        //                    #endregion

        //                    #region NHB_NotchUp_CriteriaInputs

        //                    mWSheet.Range["B203"].Value = riskModelExcelEntity.NHB_NotchUp_CriteriaInputs.ShareholdingStructure;
        //                    mWSheet.Range["B204"].Value = riskModelExcelEntity.NHB_NotchUp_CriteriaInputs.ManagementControl;
        //                    mWSheet.Range["B205"].Value = riskModelExcelEntity.NHB_NotchUp_CriteriaInputs.StatedPostureOfTheParent;
        //                    mWSheet.Range["B206"].Value = riskModelExcelEntity.NHB_NotchUp_CriteriaInputs.PastTrackRecord;
        //                    mWSheet.Range["B207"].Value = riskModelExcelEntity.NHB_NotchUp_CriteriaInputs.BrandName;

        //                    #endregion

        //                    #region Risk Model Outputs

        //                    mWSheet = (Worksheet)mWorkSheets.get_Item(3);

        //                    NHB_RiskModel_Outputss NHB_RiskModel_Outputss = new NHB_RiskModel_Outputss()
        //                    {
        //                        #region Industry Risk_Outputs
        //                        IndustryRiskFinancialPerformanceOfPlayersWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[2, 6].Value2),
        //                        IndustryRiskFinancialPerformanceOfPlayersValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[2, 7].Value2),
        //                        IndustryRiskFinancialPerformanceOfPlayersScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[2, 8].Value2),
        //                        IndustryRiskCompetitionsWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[3, 6].Value2),
        //                        IndustryRiskCompetitionsValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[3, 7].Value2),
        //                        IndustryRiskCompetitionsScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[3, 8].Value2),
        //                        IndustryRiskProspectOfRealEstateMarketWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[4, 6].Value2),
        //                        IndustryRiskProspectOfRealEstateMarketValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[4, 7].Value2),
        //                        IndustryRiskProspectOfRealEstateMarketScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[4, 8].Value2),
        //                        IndustryRiskRegulatoryImpactGovernmentPolicyWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[5, 6].Value2),
        //                        IndustryRiskRegulatoryImpactGovernmentPolicyValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[5, 7].Value2),
        //                        IndustryRiskRegulatoryImpactGovernmentPolicyScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[5, 8].Value2),
        //                        #endregion

        //                        #region Business Risk_Outputs
        //                        BusinessRiskMarketPositionRankWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[6, 6].Value2),
        //                        BusinessRiskMarketPositionRankValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[6, 7].Value2),
        //                        BusinessRiskMarketPositionRankScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[6, 8].Value2),
        //                        BusinessRiskMarketPositionGeographicalDiversificationWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[7, 6].Value2),
        //                        BusinessRiskMarketPositionGeographicalDiversificationValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[7, 7].Value2),
        //                        BusinessRiskMarketPositionGeographicalDiversificationScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[7, 8].Value2),
        //                        BusinessRiskAssetQualityProductMixWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[8, 6].Value2),
        //                        BusinessRiskAssetQualityProductMixValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[8, 7].Value2),
        //                        BusinessRiskAssetQualityProductMixScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[8, 8].Value2),
        //                        BusinessRiskAssetQualityCustomerMixWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[9, 6].Value2),
        //                        BusinessRiskAssetQualityCustomerMixValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[9, 7].Value2),
        //                        BusinessRiskAssetQualityCustomerMixScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[9, 8].Value2),
        //                        BusinessRiskAssetQualityGrossNPAWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[10, 6].Value2),
        //                        BusinessRiskAssetQualityGrossNPAValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[10, 7].Value2),
        //                        BusinessRiskAssetQualityGrossNPAScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[10, 8].Value2),
        //                        BusinessRiskOperatingEfficiencyCostOfResourcesWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[11, 6].Value2),
        //                        BusinessRiskOperatingEfficiencyCostOfResourcesValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[11, 7].Value2),
        //                        BusinessRiskOperatingEfficiencyCostOfResourcesScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[11, 8].Value2),
        //                        BusinessRiskOperatingEfficiencyTotalAssetGrowthWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[12, 6].Value2),
        //                        BusinessRiskOperatingEfficiencyTotalAssetGrowthValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[12, 7].Value2),
        //                        BusinessRiskOperatingEfficiencyTotalAssetGrowthScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[12, 8].Value2),
        //                        BusinessRiskOperatingEfficiencyDiversityOfResourcesWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[13, 6].Value2),
        //                        BusinessRiskOperatingEfficiencyDiversityOfResourcesValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[13, 7].Value2),
        //                        BusinessRiskOperatingEfficiencyDiversityOfResourcesScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[13, 8].Value2),
        //                        BusinessRiskTotalAssetBaseWeight = Convert.ToString(mWSheet.Cells[14, 6].Value2) == "-2146826246" ? "#N/A" : mWSheet.Cells[14, 6].Value2,
        //                        BusinessRiskTotalAssetBaseValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[14, 7].Value2),
        //                        BusinessRiskTotalAssetBaseScore = Convert.ToString(mWSheet.Cells[14, 8].Value2),
        //                        #endregion

        //                        #region Financial Risk_Outputs
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[15, 6].Value2),
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[15, 7].Value2),
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[15, 8].Value2),
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[16, 6].Value2),
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[16, 7].Value2),
        //                        FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[16, 8].Value2),
        //                        FinancialRiskCapitalTangibleNetworthWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[17, 6].Value2),
        //                        FinancialRiskCapitalTangibleNetworthValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[17, 7].Value2),
        //                        FinancialRiskCapitalTangibleNetworthScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[17, 8].Value2),
        //                        FinancialRiskCapitalAdequacyRatioWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[18, 6].Value2),
        //                        FinancialRiskCapitalAdequacyRatioValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[18, 7].Value2),
        //                        FinancialRiskCapitalAdequacyRatioScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[18, 8].Value2),
        //                        FinancialRiskCapitalGearingWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[19, 6].Value2),
        //                        FinancialRiskCapitalGearingValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[19, 7].Value2),
        //                        FinancialRiskCapitalGearingScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[19, 8].Value2),
        //                        FinancialRiskEarningsTangibleNetworthNetNPAWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[20, 6].Value2),
        //                        FinancialRiskEarningsTangibleNetworthNetNPAValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[20, 7].Value2),
        //                        FinancialRiskEarningsTangibleNetworthNetNPAScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[20, 8].Value2),
        //                        FinancialRiskEarningsNetProfitMarginWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[21, 6].Value2),
        //                        FinancialRiskEarningsNetProfitMarginValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[21, 7].Value2),
        //                        FinancialRiskEarningsNetProfitMarginScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[21, 8].Value2),
        //                        FinancialRiskEarningsReturnOnAssetsWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[22, 6].Value2),
        //                        FinancialRiskEarningsReturnOnAssetsValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[22, 7].Value2),
        //                        FinancialRiskEarningsReturnOnAssetsScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[22, 8].Value2),
        //                        FinancialRiskEarningsReturnOnNetworthWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[23, 6].Value2),
        //                        FinancialRiskEarningsReturnOnNetworthValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[23, 7].Value2),
        //                        FinancialRiskEarningsReturnOnNetworthScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[23, 8].Value2),
        //                        #endregion

        //                        #region Management Risk_Outputs
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[24, 6].Value2),
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[24, 7].Value2),
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[24, 8].Value2),
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[25, 6].Value2),
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[25, 7].Value2),
        //                        ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[25, 8].Value2),
        //                        ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[26, 6].Value2),
        //                        ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[26, 7].Value2),
        //                        ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[26, 8].Value2),
        //                        ManagementRiskTrackRecordRiskManagementSystemWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[27, 6].Value2),
        //                        ManagementRiskTrackRecordRiskManagementSystemValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[27, 7].Value2),
        //                        ManagementRiskTrackRecordRiskManagementSystemScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[27, 8].Value2),
        //                        ManagementRiskKeyFactorsCredibilityWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[28, 6].Value2),
        //                        ManagementRiskKeyFactorsCredibilityValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[28, 7].Value2),
        //                        ManagementRiskKeyFactorsCredibilityScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[28, 8].Value2),
        //                        ManagementRiskKeyFactorsCompetenceAndExperienceWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[29, 6].Value2),
        //                        ManagementRiskKeyFactorsCompetenceAndExperienceValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[29, 7].Value2),
        //                        ManagementRiskKeyFactorsCompetenceAndExperienceScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[29, 8].Value2),
        //                        ManagementRiskKeyFactorsRiskAppetiteWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[30, 6].Value2),
        //                        ManagementRiskKeyFactorsRiskAppetiteValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[30, 7].Value2),
        //                        ManagementRiskKeyFactorsRiskAppetiteScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[30, 8].Value2),
        //                        #endregion

        //                        #region NotchUp Criteria_Outputs
        //                        NotchUpCriteriaOwnershipShareholdingStructureWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[31, 6].Value2),
        //                        NotchUpCriteriaOwnershipShareholdingStructureValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[31, 7].Value2),
        //                        NotchUpCriteriaOwnershipShareholdingStructureScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[31, 8].Value2),
        //                        NotchUpCriteriaManagementControlWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[32, 6].Value2),
        //                        NotchUpCriteriaManagementControlValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[32, 7].Value2),
        //                        NotchUpCriteriaManagementControlScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[32, 8].Value2),
        //                        NotchUpCriteriaStatedPostureOfTheParentWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[33, 6].Value2),
        //                        NotchUpCriteriaStatedPostureOfTheParentValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[33, 7].Value2),
        //                        NotchUpCriteriaStatedPostureOfTheParentScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[33, 8].Value2),
        //                        NotchUpCriteriaPastTrackRecordWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[34, 6].Value2),
        //                        NotchUpCriteriaPastTrackRecordValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[34, 7].Value2),
        //                        NotchUpCriteriaPastTrackRecordScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[34, 8].Value2),
        //                        NotchUpCriteriaBrandNameWeight = ExtensionMethod.OutputFormattingsDouble(mWSheet.Cells[35, 6].Value2),
        //                        NotchUpCriteriaBrandNameValue = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[35, 7].Value2),
        //                        NotchUpCriteriaBrandNameScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[35, 8].Value2),
        //                        #endregion

        //                        #region Outputs                        
        //                        IndustryRiskOutput = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[36, 6].Value2),
        //                        BusinessRiskOutput = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[37, 6].Value2),
        //                        FinancialRiskOutput = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[38, 6].Value2),
        //                        ManagementRiskOutput = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[39, 6].Value2),
        //                        OverAllScore = ExtensionMethod.OutputFormattingsDecimal(mWSheet.Cells[40, 6].Value2),
        //                        PreNotchUpRating = Convert.ToString(mWSheet.Cells[41, 6].Value2) == "-2146826246" ? "#N/A" : Convert.ToString(mWSheet.Cells[41, 6].Value2),
        //                        ParentRating = Convert.ToString(mWSheet.Cells[42, 6].Value2) == "-2146826246" ? "#N/A" : Convert.ToString(mWSheet.Cells[42, 6].Value2),
        //                        FinalRating = Convert.ToString(mWSheet.Cells[43, 6].Value2) == "-2146826246" ? "#N/A" : Convert.ToString(mWSheet.Cells[43, 6].Value2),
        //                        #endregion
        //                    };
        //                    riskModelExcelEntity.NHB_RiskModel_Outputs = NHB_RiskModel_Outputss;
        //                    #endregion

        //                    RiskModelExcelEntity companyBasicDetails = new RiskModelExcelEntity()
        //                    {
        //                        CompanyId = riskModelExcelEntity.CompanyId,
        //                        LocationId = riskModelExcelEntity.LocationId,
        //                        DateOfInput = riskModelExcelEntity.DateOfInput,
        //                        FinancialYearEndingDate = riskModelExcelEntity.FinancialYearEndingDate,
        //                        CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
        //                        ParentCompanyIsExist = riskModelExcelEntity.ParentCompanyIsExist,
        //                        ParentCompanyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.ParentCompanyId),
        //                        ParentRating = riskModelExcelEntity.ParentRating,
        //                        CreatedDateTime = riskModelExcelEntity.CreatedDateTime
        //                    };

        //                    detailID = companyDAL.SaveCompanyBasicDetails(userId, roleId, companyBasicDetails);

        //                    if (detailID > 0)
        //                    {
        //                        status = companyDAL.SaveCompanyBalanceSheetLiabilities(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_BalanceSheets_Liabilities)
        //                        && companyDAL.SaveCompanyBalanceSheetAssets(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_BalanceSheet_Assets)
        //                        && companyDAL.SaveCompanyOtherBalanceSheetDisclosures(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_OtherBalanceSheet_Disclosures)
        //                        && companyDAL.SaveCompanyContingentLiabilities(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_Contingent_Liabilities)
        //                        && companyDAL.SaveCompanyProfitAndLossStatements(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_ProfitAndLossStatements)
        //                        && companyDAL.SaveCompanyALMStatementLatests(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_ALM_Statement_Latests)
        //                        && companyDAL.SaveCompanyKeyRatios(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_KeyRatios)
        //                        && companyDAL.SaveCompanyIndustryRiskInputs(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_Industry_RiskInputs)
        //                        && companyDAL.SaveCompanyBusinessRiskInputs(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_Business_RiskInputs)
        //                        && companyDAL.SaveCompanyFinancialRiskInputs(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_Financial_RiskInputs)
        //                        && companyDAL.SaveCompanyManagementRiskInputs(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_Management_RiskInputs)
        //                        && companyDAL.SaveCompanyNotchUpCriteriaInputs(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_NotchUp_CriteriaInputs)
        //                        && companyDAL.SaveCompanyRiskModelOutputs(userId, roleId, detailID, companyBasicDetails.CreatedDateTime, riskModelExcelEntity.NHB_RiskModel_Outputs);

        //                    }


        //                    //status = companyDAL.SaveCompanyDetails(userId, roleId, companyBasicDetails);

        //                    mWorkBook.Save();
        //                    mWorkBook.Close(1, null, null);
        //                    xlApp.Quit();

        //                    mWSheet = null;
        //                    mWorkBook = null;
        //                    mWorkSheets = null;
        //                    xlApp = null;

        //                    GC.Collect();
        //                    GC.WaitForPendingFinalizers();
        //                    GC.Collect();
        //                    GC.WaitForPendingFinalizers();

        //                    if (riskModelFilePath != null)
        //                    {
        //                        if (System.IO.File.Exists(riskModelFilePath))
        //                        {
        //                            System.IO.File.Delete(riskModelFilePath);
        //                        }
        //                    }
        //                    status = true;
        //                }
        //                else
        //                {

        //                    ViewBag.Error = "Sorry!!!...Your Session has been Expired";
        //                    status = false;
        //                }
        //            }
        //            else
        //            {
        //                message = ModelState.Values.Where(value => value.Errors.Count > 0).FirstOrDefault().Errors.FirstOrDefault().ErrorMessage;
        //                status = false;
        //            }

        //        }

        //    }
        //    catch (Exception exception)
        //    {
        //        if (mWorkBook != null)
        //            mWorkBook.Close();

        //        if (xlApp != null)
        //            xlApp.Quit();

        //        mWSheet = null;
        //        mWorkBook = null;
        //        xlApp = null;

        //        GC.Collect();
        //        GC.WaitForPendingFinalizers();
        //        GC.Collect();
        //        GC.WaitForPendingFinalizers();

        //        ErrorLogger.LogError(exception);
        //        message = exception.Message;
        //    }
        //    finally
        //    {
        //        if (mWorkBook != null)
        //            mWorkBook.Close();

        //        if (xlApp != null)
        //            xlApp.Quit();

        //        mWSheet = null;
        //        mWorkBook = null;
        //        xlApp = null;

        //        GC.Collect();
        //        GC.WaitForPendingFinalizers();
        //        GC.Collect();
        //        GC.WaitForPendingFinalizers();
        //    }

        //    return Json(new
        //    {
        //        Status = status,
        //        Message = message,
        //        Result = riskModelExcelEntity,
        //    }, JsonRequestBehavior.AllowGet);
        //}

    }
}

