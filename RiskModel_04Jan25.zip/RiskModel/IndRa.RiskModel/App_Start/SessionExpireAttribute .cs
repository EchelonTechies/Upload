﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;

namespace IndRa.RiskModel
{
    //  [AttributeUsage(AttributeTargets.Method, Inherited = true, AllowMultiple = false)]
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class SessionExpireAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            HttpContext context = HttpContext.Current;
            if (context.Session != null)
            {
                if (context.Session.IsNewSession)
                {
                    string sessionCookie = context.Request.Headers["Cookie"];

                    if ((sessionCookie != null) && (sessionCookie.IndexOf("ASP.NET_SessionId") >= 0))
                    {
                        string redirectTo = "~/Account/Login";
                        if (!string.IsNullOrEmpty(context.Request.RawUrl))
                        {
                            //redirectTo = string.Format("~/Home/Login?ReturnUrl={0}", HttpUtility.UrlEncode(context.Request.RawUrl));
                            filterContext.Result = new RedirectResult(redirectTo);
                            return;
                        }
                        // FormsAuthentication.SignOut();
                        //if (!string.IsNullOrEmpty(context.Request.RawUrl) && 
                        //    (context.Request.RawUrl != "/Account/Login" && (context.Request.RawUrl != "/RCN/Account/Login" || context.Request.RawUrl != "/RCN_UAT/Account/Login"
                        //    || context.Request.RawUrl != "~/RCN/Account/Login" || context.Request.RawUrl != "~/RCN_UAT/Account/Login"))
                        //    )
                        //{
                        //    filterContext.HttpContext.Response.Redirect(FormsAuthentication.LoginUrl);
                        //    return;
                        //}
                    }
                }
            }

            base.OnActionExecuting(filterContext);
        }
    }

}