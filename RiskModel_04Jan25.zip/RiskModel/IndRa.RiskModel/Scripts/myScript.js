﻿/// <reference path="jquery-3.3.1.intellisense.js" />
$(function () {
    $(".ToolTip option").each(function (i) {
        if (i > 0) {
            var title = $(this).val();
            $(this).attr("title", title);
        }
    });
});

//$(document).ready(function () {
//    $('.RiskOutputs').hide();
//    $('.RiskContainer').show();
//    $("#tab13Label").hide();
//    $(".ParentCompany").hide();
//    $(".ParentRating").hide();
//    $("#btnNext1").hide();

//    $('.reportCreatedDateTime').datepicker({
//        format: 'dd-M-yyyy',
//        autoclose: true
//    });
//    $('#DateOfInput').datepicker({
//        format: 'dd-M-yyyy',
//        autoclose: true
//    });

//    $('#FinancialYearEndingDate').datepicker({
//        format: 'dd-M-yyyy',
//        autoclose: true
//    });

//    $('#PeriodEndingDate1_Liabilities').datepicker({
//        format: 'dd-M-yy',
//        autoclose: true
//    });

//    $('#PeriodEndingDate2_Liabilities').datepicker({
//        format: 'dd-M-yy',
//        autoclose: true
//    });

//    $('#PeriodEndingDate3_Liabilities').datepicker({
//        format: 'dd-M-yy',
//        autoclose: true
//    });

//    $('#PeriodEndingDate4_Liabilities').datepicker({
//        format: 'dd-M-yy',
//        autoclose: true,
//    });

//    $('button[name="buttonCompanySave"]').click(function () {
//        $('#ButtonValue').val(this.value);
//    });

//    $('#Statement_Date').datepicker({
//        format: 'dd-M-yy',
//        autoclose: true
//    });


//});

//$('#PeriodEndingDate1_Liabilities').change(function () {
//    var endDate = $(this).val();
//    $('#PeriodEndingDate1_Assets').val(endDate);
//    $('#PeriodEndingDate1_ProfitAndLoss').val(endDate);
//    $('#PeriodEndingDate1_KeyRatios').val(endDate);
//});

//$('#PeriodEndingDate2_Liabilities').change(function () {
//    var endDate = $(this).val();
//    $('#PeriodEndingDate2_Assets').val(endDate);
//    $('#PeriodEndingDate2_ProfitAndLoss').val(endDate);
//    $('#PeriodEndingDate2_KeyRatios').val(endDate);
//});

//$('#PeriodEndingDate3_Liabilities').change(function () {
//    var endDate = $(this).val();
//    $('#PeriodEndingDate3_Assets').val(endDate);
//    $('#PeriodEndingDate3_ProfitAndLoss').val(endDate);
//    $('#PeriodEndingDate3_KeyRatios').val(endDate);
//});

//$('#PeriodEndingDate4_Liabilities').change(function () {
//    var endDate = $(this).val();
//    $('#PeriodEndingDate4_Assets').val(endDate);
//    $('#PeriodEndingDate4_ProfitAndLoss').val(endDate);
//    $('#PeriodEndingDate4_KeyRatios').val(endDate);
//});

//On Company Change Logic
//$('#CompanyId').change(function () {
//    var companyID = $("#CompanyId").val();
//    var URI = encodeURI("../Company/CheckIfCompanyExistAndGetDetails");
//    $.ajax({
//        type: "GET",
//        url: URI,
//        data: { 'CompanyId': companyID },
//        success: function (result) {

//            if (result.Result.ParentCompanyIsExist == "Yes") {
//                //$("#ParentCompanyId").prop('disabled', false);
//                $("#tab13Label").show();
//                $(".ParentCompany").show();
//                $("#btnNext1").show();
//                $(".ParentRating").show();
//                $("#btnSave1").hide();
//                $("#btnApprove1").hide();
//                $("#btnApprove2").show();
//            }
//            else {
//                $("#tab13Label").hide();
//                $(".ParentCompany").hide();
//                $(".ParentRating").hide();
//                $("#btnSave1").show();
//                $("#btnNext1").hide();
//            }

//            if (result.Result.DetailsId != 0) {

//                //#region Basic Details
//                $("#LocationId").val(result.Result.LocationId);
//                $("#DateOfInput").val(moment(result.Result.DateOfInput).format("DD-MMM-YYYY"));
//                $("#FinancialYearEndingDate").val(moment(result.Result.FinancialYearEndingDate).format("DD-MMM-YYYY"));
//                $("#CurrencyUnits").val(result.Result.CurrencyUnits);
//                $("#ParentCompanyIsExist").val(result.Result.ParentCompanyIsExist);
//                $("#ParentCompanyId").val(result.Result.ParentCompanyId);
//                $("#ParentRating").val(result.Result.ParentRating);
//                //#endregion


//                //#region BalanceSheets_Liabilities
//                if (result.Result.NHB_BalanceSheets_Liabilities != null) {
//                    $("#PeriodEndingDate1_Liabilities").val(result.Result.NHB_BalanceSheets_Liabilities.PeriodEndingDate1_Liabilities == null ? "" : moment(result.Result.NHB_BalanceSheets_Liabilities.PeriodEndingDate1_Liabilities).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate2_Liabilities").val(result.Result.NHB_BalanceSheets_Liabilities.PeriodEndingDate2_Liabilities == null ? "" : moment(result.Result.NHB_BalanceSheets_Liabilities.PeriodEndingDate2_Liabilities).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate3_Liabilities").val(result.Result.NHB_BalanceSheets_Liabilities.PeriodEndingDate3_Liabilities == null ? "" : moment(result.Result.NHB_BalanceSheets_Liabilities.PeriodEndingDate3_Liabilities).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate4_Liabilities").val(result.Result.NHB_BalanceSheets_Liabilities.PeriodEndingDate4_Liabilities == null ? "" : moment(result.Result.NHB_BalanceSheets_Liabilities.PeriodEndingDate4_Liabilities).format("DD-MMM-YY"));
//                    $("#LiabilitiesType1").val(result.Result.NHB_BalanceSheets_Liabilities.LiabilitiesType1);
//                    $("#LiabilitiesType2").val(result.Result.NHB_BalanceSheets_Liabilities.LiabilitiesType2);
//                    $("#LiabilitiesType3").val(result.Result.NHB_BalanceSheets_Liabilities.LiabilitiesType3);
//                    $("#LiabilitiesType4").val(result.Result.NHB_BalanceSheets_Liabilities.LiabilitiesType4);
//                    $("#CapitalPEOutput1").val(result.Result.NHB_BalanceSheets_Liabilities.CapitalPEOutput1);
//                    $("#CapitalPEOutput2").val(result.Result.NHB_BalanceSheets_Liabilities.CapitalPEOutput2);
//                    $("#CapitalPEOutput3").val(result.Result.NHB_BalanceSheets_Liabilities.CapitalPEOutput3);
//                    $("#CapitalPEOutput4").val(result.Result.NHB_BalanceSheets_Liabilities.CapitalPEOutput4);
//                    $("#CalledAndPaid_Up1").val(result.Result.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up1);
//                    $("#CalledAndPaid_Up2").val(result.Result.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up2);
//                    $("#CalledAndPaid_Up3").val(result.Result.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up3);
//                    $("#CalledAndPaid_Up4").val(result.Result.NHB_BalanceSheets_Liabilities.CalledAndPaid_Up4);
//                    $("#EquityShareWarrant1").val(result.Result.NHB_BalanceSheets_Liabilities.EquityShareWarrant1);
//                    $("#EquityShareWarrant2").val(result.Result.NHB_BalanceSheets_Liabilities.EquityShareWarrant2);
//                    $("#EquityShareWarrant3").val(result.Result.NHB_BalanceSheets_Liabilities.EquityShareWarrant3);
//                    $("#EquityShareWarrant4").val(result.Result.NHB_BalanceSheets_Liabilities.EquityShareWarrant4);
//                    $("#ReservesAndSurplusOutput1").val(result.Result.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput1);
//                    $("#ReservesAndSurplusOutput2").val(result.Result.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput2);
//                    $("#ReservesAndSurplusOutput3").val(result.Result.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput3);
//                    $("#ReservesAndSurplusOutput4").val(result.Result.NHB_BalanceSheets_Liabilities.ReservesAndSurplusOutput4);
//                    $("#CapitalReserves1").val(result.Result.NHB_BalanceSheets_Liabilities.CapitalReserves1);
//                    $("#CapitalReserves2").val(result.Result.NHB_BalanceSheets_Liabilities.CapitalReserves2);
//                    $("#CapitalReserves3").val(result.Result.NHB_BalanceSheets_Liabilities.CapitalReserves3);
//                    $("#CapitalReserves4").val(result.Result.NHB_BalanceSheets_Liabilities.CapitalReserves4);
//                    $("#GeneralReserves1").val(result.Result.NHB_BalanceSheets_Liabilities.GeneralReserves1);
//                    $("#GeneralReserves2").val(result.Result.NHB_BalanceSheets_Liabilities.GeneralReserves2);
//                    $("#GeneralReserves3").val(result.Result.NHB_BalanceSheets_Liabilities.GeneralReserves3);
//                    $("#GeneralReserves4").val(result.Result.NHB_BalanceSheets_Liabilities.GeneralReserves4);
//                    $("#SharePremium1").val(result.Result.NHB_BalanceSheets_Liabilities.SharePremium1);
//                    $("#SharePremium2").val(result.Result.NHB_BalanceSheets_Liabilities.SharePremium2);
//                    $("#SharePremium3").val(result.Result.NHB_BalanceSheets_Liabilities.SharePremium3);
//                    $("#SharePremium4").val(result.Result.NHB_BalanceSheets_Liabilities.SharePremium4);
//                    $("#SpecialPurposeReserves1").val(result.Result.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves1);
//                    $("#SpecialPurposeReserves2").val(result.Result.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves2);
//                    $("#SpecialPurposeReserves3").val(result.Result.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves3);
//                    $("#SpecialPurposeReserves4").val(result.Result.NHB_BalanceSheets_Liabilities.SpecialPurposeReserves4);
//                    $("#OtherReserves1").val(result.Result.NHB_BalanceSheets_Liabilities.OtherReserves1);
//                    $("#OtherReserves2").val(result.Result.NHB_BalanceSheets_Liabilities.OtherReserves2);
//                    $("#OtherReserves3").val(result.Result.NHB_BalanceSheets_Liabilities.OtherReserves3);
//                    $("#OtherReserves4").val(result.Result.NHB_BalanceSheets_Liabilities.OtherReserves4);
//                    $("#RevenueReserves1").val(result.Result.NHB_BalanceSheets_Liabilities.RevenueReserves1);
//                    $("#RevenueReserves2").val(result.Result.NHB_BalanceSheets_Liabilities.RevenueReserves2);
//                    $("#RevenueReserves3").val(result.Result.NHB_BalanceSheets_Liabilities.RevenueReserves3);
//                    $("#RevenueReserves4").val(result.Result.NHB_BalanceSheets_Liabilities.RevenueReserves4);
//                    $("#IntangibleAssets1").val(result.Result.NHB_BalanceSheets_Liabilities.IntangibleAssets1);
//                    $("#IntangibleAssets2").val(result.Result.NHB_BalanceSheets_Liabilities.IntangibleAssets2);
//                    $("#IntangibleAssets3").val(result.Result.NHB_BalanceSheets_Liabilities.IntangibleAssets3);
//                    $("#IntangibleAssets4").val(result.Result.NHB_BalanceSheets_Liabilities.IntangibleAssets4);
//                    $("#BorrowingsOutput1").val(result.Result.NHB_BalanceSheets_Liabilities.BorrowingsOutput1);
//                    $("#BorrowingsOutput2").val(result.Result.NHB_BalanceSheets_Liabilities.BorrowingsOutput2);
//                    $("#BorrowingsOutput3").val(result.Result.NHB_BalanceSheets_Liabilities.BorrowingsOutput3);
//                    $("#BorrowingsOutput4").val(result.Result.NHB_BalanceSheets_Liabilities.BorrowingsOutput4);
//                    $("#CommercialPaper1").val(result.Result.NHB_BalanceSheets_Liabilities.CommercialPaper1);
//                    $("#CommercialPaper2").val(result.Result.NHB_BalanceSheets_Liabilities.CommercialPaper2);
//                    $("#CommercialPaper3").val(result.Result.NHB_BalanceSheets_Liabilities.CommercialPaper3);
//                    $("#CommercialPaper4").val(result.Result.NHB_BalanceSheets_Liabilities.CommercialPaper4);
//                    $("#InterCorporateDeposits1").val(result.Result.NHB_BalanceSheets_Liabilities.InterCorporateDeposits1);
//                    $("#InterCorporateDeposits2").val(result.Result.NHB_BalanceSheets_Liabilities.InterCorporateDeposits2);
//                    $("#InterCorporateDeposits3").val(result.Result.NHB_BalanceSheets_Liabilities.InterCorporateDeposits3);
//                    $("#InterCorporateDeposits4").val(result.Result.NHB_BalanceSheets_Liabilities.InterCorporateDeposits4);
//                    $("#CallAndNoticeMoney1").val(result.Result.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney1);
//                    $("#CallAndNoticeMoney2").val(result.Result.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney2);
//                    $("#CallAndNoticeMoney3").val(result.Result.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney3);
//                    $("#CallAndNoticeMoney4").val(result.Result.NHB_BalanceSheets_Liabilities.CallAndNoticeMoney4);
//                    $("#OtherBorrowings1").val(result.Result.NHB_BalanceSheets_Liabilities.OtherBorrowings1);
//                    $("#OtherBorrowings2").val(result.Result.NHB_BalanceSheets_Liabilities.OtherBorrowings2);
//                    $("#OtherBorrowings3").val(result.Result.NHB_BalanceSheets_Liabilities.OtherBorrowings3);
//                    $("#OtherBorrowings4").val(result.Result.NHB_BalanceSheets_Liabilities.OtherBorrowings4);
//                    $("#LongTermBorrowingsWithinYear1").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear1);
//                    $("#LongTermBorrowingsWithinYear2").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear2);
//                    $("#LongTermBorrowingsWithinYear3").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear3);
//                    $("#LongTermBorrowingsWithinYear4").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsWithinYear4);
//                    $("#PublicDeposits1").val(result.Result.NHB_BalanceSheets_Liabilities.PublicDeposits1);
//                    $("#PublicDeposits2").val(result.Result.NHB_BalanceSheets_Liabilities.PublicDeposits2);
//                    $("#PublicDeposits3").val(result.Result.NHB_BalanceSheets_Liabilities.PublicDeposits3);
//                    $("#PublicDeposits4").val(result.Result.NHB_BalanceSheets_Liabilities.PublicDeposits4);
//                    $("#ShortTermBorrowings1").val(result.Result.NHB_BalanceSheets_Liabilities.ShortTermBorrowings1);
//                    $("#ShortTermBorrowings2").val(result.Result.NHB_BalanceSheets_Liabilities.ShortTermBorrowings2);
//                    $("#ShortTermBorrowings3").val(result.Result.NHB_BalanceSheets_Liabilities.ShortTermBorrowings3);
//                    $("#ShortTermBorrowings4").val(result.Result.NHB_BalanceSheets_Liabilities.ShortTermBorrowings4);
//                    $("#LongTermBorrowingsFloatingNHB1").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB1);
//                    $("#LongTermBorrowingsFloatingNHB2").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB2);
//                    $("#LongTermBorrowingsFloatingNHB3").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB3);
//                    $("#LongTermBorrowingsFloatingNHB4").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingNHB4);
//                    $("#LongTermBorrowingsFloatingOthers1").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers1);
//                    $("#LongTermBorrowingsFloatingOthers2").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers2);
//                    $("#LongTermBorrowingsFloatingOthers3").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers3);
//                    $("#LongTermBorrowingsFloatingOthers4").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFloatingOthers4);
//                    $("#LongTermBorrowingsFixedNHB1").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB1);
//                    $("#LongTermBorrowingsFixedNHB2").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB2);
//                    $("#LongTermBorrowingsFixedNHB3").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB3);
//                    $("#LongTermBorrowingsFixedNHB4").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedNHB4);
//                    $("#LongTermBorrowingsFixedOthers1").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers1);
//                    $("#LongTermBorrowingsFixedOthers2").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers2);
//                    $("#LongTermBorrowingsFixedOthers3").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers3);
//                    $("#LongTermBorrowingsFixedOthers4").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermBorrowingsFixedOthers4);
//                    $("#UnsecuredLongTermBorrowings1").val(result.Result.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings1);
//                    $("#UnsecuredLongTermBorrowings2").val(result.Result.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings2);
//                    $("#UnsecuredLongTermBorrowings3").val(result.Result.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings3);
//                    $("#UnsecuredLongTermBorrowings4").val(result.Result.NHB_BalanceSheets_Liabilities.UnsecuredLongTermBorrowings4);
//                    $("#LongTermForeignCurrency1").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency1);
//                    $("#LongTermForeignCurrency2").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency2);
//                    $("#LongTermForeignCurrency3").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency3);
//                    $("#LongTermForeignCurrency4").val(result.Result.NHB_BalanceSheets_Liabilities.LongTermForeignCurrency4);
//                    $("#BorrowingsFromRelatedParties1").val(result.Result.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties1);
//                    $("#BorrowingsFromRelatedParties2").val(result.Result.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties2);
//                    $("#BorrowingsFromRelatedParties3").val(result.Result.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties3);
//                    $("#BorrowingsFromRelatedParties4").val(result.Result.NHB_BalanceSheets_Liabilities.BorrowingsFromRelatedParties4);
//                    $("#HybridInstruments1").val(result.Result.NHB_BalanceSheets_Liabilities.HybridInstruments1);
//                    $("#HybridInstruments2").val(result.Result.NHB_BalanceSheets_Liabilities.HybridInstruments2);
//                    $("#HybridInstruments3").val(result.Result.NHB_BalanceSheets_Liabilities.HybridInstruments3);
//                    $("#HybridInstruments4").val(result.Result.NHB_BalanceSheets_Liabilities.HybridInstruments4);
//                    $("#LiabilitiesAndCapitalTotalOutput1").val(result.Result.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput1);
//                    $("#LiabilitiesAndCapitalTotalOutput2").val(result.Result.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput2);
//                    $("#LiabilitiesAndCapitalTotalOutput3").val(result.Result.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput3);
//                    $("#LiabilitiesAndCapitalTotalOutput4").val(result.Result.NHB_BalanceSheets_Liabilities.LiabilitiesAndCapitalTotalOutput4);
//                }
//                //#endregion


//                //#region BalanceSheets_Assets   
//                if (result.Result.NHB_BalanceSheet_Assets != null) {

//                    $("#PeriodEndingDate1_Assets").val(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate1_Assets == null ? "" : moment(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate1_Assets).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate2_Assets").val(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate2_Assets == null ? "" : moment(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate2_Assets).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate3_Assets").val(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate3_Assets == null ? "" : moment(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate3_Assets).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate4_Assets").val(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate4_Assets == null ? "" : moment(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate4_Assets).format("DD-MMM-YY"));
//                    $("#FixedAssetsOutput1").val(result.Result.NHB_BalanceSheet_Assets.FixedAssetsOutput1);
//                    $("#FixedAssetsOutput2").val(result.Result.NHB_BalanceSheet_Assets.FixedAssetsOutput2);
//                    $("#FixedAssetsOutput3").val(result.Result.NHB_BalanceSheet_Assets.FixedAssetsOutput3);
//                    $("#FixedAssetsOutput4").val(result.Result.NHB_BalanceSheet_Assets.FixedAssetsOutput4);
//                    $("#OwnedNetBlock1").val(result.Result.NHB_BalanceSheet_Assets.OwnedNetBlock1);
//                    $("#OwnedNetBlock2").val(result.Result.NHB_BalanceSheet_Assets.OwnedNetBlock2);
//                    $("#OwnedNetBlock3").val(result.Result.NHB_BalanceSheet_Assets.OwnedNetBlock3);
//                    $("#OwnedNetBlock4").val(result.Result.NHB_BalanceSheet_Assets.OwnedNetBlock4);
//                    $("#LeasedNetBlock1").val(result.Result.NHB_BalanceSheet_Assets.LeasedNetBlock1);
//                    $("#LeasedNetBlock2").val(result.Result.NHB_BalanceSheet_Assets.LeasedNetBlock2);
//                    $("#LeasedNetBlock3").val(result.Result.NHB_BalanceSheet_Assets.LeasedNetBlock3);
//                    $("#LeasedNetBlock4").val(result.Result.NHB_BalanceSheet_Assets.LeasedNetBlock4);
//                    $("#CapitalWorkInProgress1").val(result.Result.NHB_BalanceSheet_Assets.CapitalWorkInProgress1);
//                    $("#CapitalWorkInProgress2").val(result.Result.NHB_BalanceSheet_Assets.CapitalWorkInProgress2);
//                    $("#CapitalWorkInProgress3").val(result.Result.NHB_BalanceSheet_Assets.CapitalWorkInProgress3);
//                    $("#CapitalWorkInProgress4").val(result.Result.NHB_BalanceSheet_Assets.CapitalWorkInProgress4);
//                    $("#InvestmentsOutput1").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsOutput1);
//                    $("#InvestmentsOutput2").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsOutput2);
//                    $("#InvestmentsOutput3").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsOutput3);
//                    $("#InvestmentsOutput4").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsOutput4);
//                    $("#CentralGovernmentSecuritiesQuoted1").val(result.Result.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted1);
//                    $("#CentralGovernmentSecuritiesQuoted2").val(result.Result.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted2);
//                    $("#CentralGovernmentSecuritiesQuoted3").val(result.Result.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted3);
//                    $("#CentralGovernmentSecuritiesQuoted4").val(result.Result.NHB_BalanceSheet_Assets.CentralGovernmentSecuritiesQuoted4);
//                    $("#CentralGovernmentDebtUnquoted1").val(result.Result.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted1);
//                    $("#CentralGovernmentDebtUnquoted2").val(result.Result.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted2);
//                    $("#CentralGovernmentDebtUnquoted3").val(result.Result.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted3);
//                    $("#CentralGovernmentDebtUnquoted4").val(result.Result.NHB_BalanceSheet_Assets.CentralGovernmentDebtUnquoted4);
//                    $("#StateGovernmentSecurities1").val(result.Result.NHB_BalanceSheet_Assets.StateGovernmentSecurities1);
//                    $("#StateGovernmentSecurities2").val(result.Result.NHB_BalanceSheet_Assets.StateGovernmentSecurities2);
//                    $("#StateGovernmentSecurities3").val(result.Result.NHB_BalanceSheet_Assets.StateGovernmentSecurities3);
//                    $("#StateGovernmentSecurities4").val(result.Result.NHB_BalanceSheet_Assets.StateGovernmentSecurities4);
//                    $("#GuaranteedPublicSectorBonds1").val(result.Result.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds1);
//                    $("#GuaranteedPublicSectorBonds2").val(result.Result.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds2);
//                    $("#GuaranteedPublicSectorBonds3").val(result.Result.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds3);
//                    $("#GuaranteedPublicSectorBonds4").val(result.Result.NHB_BalanceSheet_Assets.GuaranteedPublicSectorBonds4);
//                    $("#OtherPublicSectorBonds1").val(result.Result.NHB_BalanceSheet_Assets.OtherPublicSectorBonds1);
//                    $("#OtherPublicSectorBonds2").val(result.Result.NHB_BalanceSheet_Assets.OtherPublicSectorBonds2);
//                    $("#OtherPublicSectorBonds3").val(result.Result.NHB_BalanceSheet_Assets.OtherPublicSectorBonds3);
//                    $("#OtherPublicSectorBonds4").val(result.Result.NHB_BalanceSheet_Assets.OtherPublicSectorBonds4);
//                    $("#PrivateSectorBondsInvestmentGrade1").val(result.Result.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade1);
//                    $("#PrivateSectorBondsInvestmentGrade2").val(result.Result.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade2);
//                    $("#PrivateSectorBondsInvestmentGrade3").val(result.Result.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade3);
//                    $("#PrivateSectorBondsInvestmentGrade4").val(result.Result.NHB_BalanceSheet_Assets.PrivateSectorBondsInvestmentGrade4);
//                    $("#OtherPrivateSectorBonds1").val(result.Result.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds1);
//                    $("#OtherPrivateSectorBonds2").val(result.Result.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds2);
//                    $("#OtherPrivateSectorBonds3").val(result.Result.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds3);
//                    $("#OtherPrivateSectorBonds4").val(result.Result.NHB_BalanceSheet_Assets.OtherPrivateSectorBonds4);
//                    $("#MutualFunds1").val(result.Result.NHB_BalanceSheet_Assets.MutualFunds1);
//                    $("#MutualFunds2").val(result.Result.NHB_BalanceSheet_Assets.MutualFunds2);
//                    $("#MutualFunds3").val(result.Result.NHB_BalanceSheet_Assets.MutualFunds3);
//                    $("#MutualFunds4").val(result.Result.NHB_BalanceSheet_Assets.MutualFunds4);
//                    $("#ListedEquity1").val(result.Result.NHB_BalanceSheet_Assets.ListedEquity1);
//                    $("#ListedEquity2").val(result.Result.NHB_BalanceSheet_Assets.ListedEquity2);
//                    $("#ListedEquity3").val(result.Result.NHB_BalanceSheet_Assets.ListedEquity3);
//                    $("#ListedEquity4").val(result.Result.NHB_BalanceSheet_Assets.ListedEquity4);
//                    $("#UnlistedEquity1").val(result.Result.NHB_BalanceSheet_Assets.UnlistedEquity1);
//                    $("#UnlistedEquity2").val(result.Result.NHB_BalanceSheet_Assets.UnlistedEquity2);
//                    $("#UnlistedEquity3").val(result.Result.NHB_BalanceSheet_Assets.UnlistedEquity3);
//                    $("#UnlistedEquity4").val(result.Result.NHB_BalanceSheet_Assets.UnlistedEquity4);
//                    $("#InvestmentsInParentAndSubsidiariesAndAssociates1").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates1);
//                    $("#InvestmentsInParentAndSubsidiariesAndAssociates2").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates2);
//                    $("#InvestmentsInParentAndSubsidiariesAndAssociates3").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates3);
//                    $("#InvestmentsInParentAndSubsidiariesAndAssociates4").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsInParentAndSubsidiariesAndAssociates4);
//                    $("#CurrentAssetsOutput1").val(result.Result.NHB_BalanceSheet_Assets.CurrentAssetsOutput1);
//                    $("#CurrentAssetsOutput2").val(result.Result.NHB_BalanceSheet_Assets.CurrentAssetsOutput2);
//                    $("#CurrentAssetsOutput3").val(result.Result.NHB_BalanceSheet_Assets.CurrentAssetsOutput3);
//                    $("#CurrentAssetsOutput4").val(result.Result.NHB_BalanceSheet_Assets.CurrentAssetsOutput4);
//                    $("#HirePurchaseReceivables1").val(result.Result.NHB_BalanceSheet_Assets.HirePurchaseReceivables1);
//                    $("#HirePurchaseReceivables2").val(result.Result.NHB_BalanceSheet_Assets.HirePurchaseReceivables2);
//                    $("#HirePurchaseReceivables3").val(result.Result.NHB_BalanceSheet_Assets.HirePurchaseReceivables3);
//                    $("#HirePurchaseReceivables4").val(result.Result.NHB_BalanceSheet_Assets.HirePurchaseReceivables4);
//                    $("#FinanceLeases1").val(result.Result.NHB_BalanceSheet_Assets.FinanceLeases1);
//                    $("#FinanceLeases2").val(result.Result.NHB_BalanceSheet_Assets.FinanceLeases2);
//                    $("#FinanceLeases3").val(result.Result.NHB_BalanceSheet_Assets.FinanceLeases3);
//                    $("#FinanceLeases4").val(result.Result.NHB_BalanceSheet_Assets.FinanceLeases4);
//                    $("#SecuredLoans1").val(result.Result.NHB_BalanceSheet_Assets.SecuredLoans1);
//                    $("#SecuredLoans2").val(result.Result.NHB_BalanceSheet_Assets.SecuredLoans2);
//                    $("#SecuredLoans3").val(result.Result.NHB_BalanceSheet_Assets.SecuredLoans3);
//                    $("#SecuredLoans4").val(result.Result.NHB_BalanceSheet_Assets.SecuredLoans4);
//                    $("#UnsecuredLoans1").val(result.Result.NHB_BalanceSheet_Assets.UnsecuredLoans1);
//                    $("#UnsecuredLoans2").val(result.Result.NHB_BalanceSheet_Assets.UnsecuredLoans2);
//                    $("#UnsecuredLoans3").val(result.Result.NHB_BalanceSheet_Assets.UnsecuredLoans3);
//                    $("#UnsecuredLoans4").val(result.Result.NHB_BalanceSheet_Assets.UnsecuredLoans4);
//                    $("#Debtors1").val(result.Result.NHB_BalanceSheet_Assets.Debtors1);
//                    $("#Debtors2").val(result.Result.NHB_BalanceSheet_Assets.Debtors2);
//                    $("#Debtors3").val(result.Result.NHB_BalanceSheet_Assets.Debtors3);
//                    $("#Debtors4").val(result.Result.NHB_BalanceSheet_Assets.Debtors4);
//                    $("#BillsDiscounted1").val(result.Result.NHB_BalanceSheet_Assets.BillsDiscounted1);
//                    $("#BillsDiscounted2").val(result.Result.NHB_BalanceSheet_Assets.BillsDiscounted2);
//                    $("#BillsDiscounted3").val(result.Result.NHB_BalanceSheet_Assets.BillsDiscounted3);
//                    $("#BillsDiscounted4").val(result.Result.NHB_BalanceSheet_Assets.BillsDiscounted4);
//                    $("#OtherInterestBearingLoans1").val(result.Result.NHB_BalanceSheet_Assets.OtherInterestBearingLoans1);
//                    $("#OtherInterestBearingLoans2").val(result.Result.NHB_BalanceSheet_Assets.OtherInterestBearingLoans2);
//                    $("#OtherInterestBearingLoans3").val(result.Result.NHB_BalanceSheet_Assets.OtherInterestBearingLoans3);
//                    $("#OtherInterestBearingLoans4").val(result.Result.NHB_BalanceSheet_Assets.OtherInterestBearingLoans4);
//                    $("#LoansToRelatedParties1").val(result.Result.NHB_BalanceSheet_Assets.LoansToRelatedParties1);
//                    $("#LoansToRelatedParties2").val(result.Result.NHB_BalanceSheet_Assets.LoansToRelatedParties2);
//                    $("#LoansToRelatedParties3").val(result.Result.NHB_BalanceSheet_Assets.LoansToRelatedParties3);
//                    $("#LoansToRelatedParties4").val(result.Result.NHB_BalanceSheet_Assets.LoansToRelatedParties4);
//                    $("#CashAndBank1").val(result.Result.NHB_BalanceSheet_Assets.CashAndBank1);
//                    $("#CashAndBank2").val(result.Result.NHB_BalanceSheet_Assets.CashAndBank2);
//                    $("#CashAndBank3").val(result.Result.NHB_BalanceSheet_Assets.CashAndBank3);
//                    $("#CashAndBank4").val(result.Result.NHB_BalanceSheet_Assets.CashAndBank4);
//                    $("#AdvancesPaid1").val(result.Result.NHB_BalanceSheet_Assets.AdvancesPaid1);
//                    $("#AdvancesPaid2").val(result.Result.NHB_BalanceSheet_Assets.AdvancesPaid2);
//                    $("#AdvancesPaid3").val(result.Result.NHB_BalanceSheet_Assets.AdvancesPaid3);
//                    $("#AdvancesPaid4").val(result.Result.NHB_BalanceSheet_Assets.AdvancesPaid4);
//                    $("#OtherCurrentAssets1").val(result.Result.NHB_BalanceSheet_Assets.OtherCurrentAssets1);
//                    $("#OtherCurrentAssets2").val(result.Result.NHB_BalanceSheet_Assets.OtherCurrentAssets2);
//                    $("#OtherCurrentAssets3").val(result.Result.NHB_BalanceSheet_Assets.OtherCurrentAssets3);
//                    $("#OtherCurrentAssets4").val(result.Result.NHB_BalanceSheet_Assets.OtherCurrentAssets4);
//                    $("#InvestmentsInSecuritisedAssets1").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets1);
//                    $("#InvestmentsInSecuritisedAssets2").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets2);
//                    $("#InvestmentsInSecuritisedAssets3").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets3);
//                    $("#InvestmentsInSecuritisedAssets4").val(result.Result.NHB_BalanceSheet_Assets.InvestmentsInSecuritisedAssets4);
//                    $("#CurrentLiabilitiesOutput1").val(result.Result.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput1);
//                    $("#CurrentLiabilitiesOutput2").val(result.Result.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput2);
//                    $("#CurrentLiabilitiesOutput3").val(result.Result.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput3);
//                    $("#CurrentLiabilitiesOutput4").val(result.Result.NHB_BalanceSheet_Assets.CurrentLiabilitiesOutput4);
//                    $("#InterestAccruedButNotDue1").val(result.Result.NHB_BalanceSheet_Assets.InterestAccruedButNotDue1);
//                    $("#InterestAccruedButNotDue2").val(result.Result.NHB_BalanceSheet_Assets.InterestAccruedButNotDue2);
//                    $("#InterestAccruedButNotDue3").val(result.Result.NHB_BalanceSheet_Assets.InterestAccruedButNotDue3);
//                    $("#InterestAccruedButNotDue4").val(result.Result.NHB_BalanceSheet_Assets.InterestAccruedButNotDue4);
//                    $("#DepositsReceived1").val(result.Result.NHB_BalanceSheet_Assets.DepositsReceived1);
//                    $("#DepositsReceived2").val(result.Result.NHB_BalanceSheet_Assets.DepositsReceived2);
//                    $("#DepositsReceived3").val(result.Result.NHB_BalanceSheet_Assets.DepositsReceived3);
//                    $("#DepositsReceived4").val(result.Result.NHB_BalanceSheet_Assets.DepositsReceived4);
//                    $("#AdvancesReceived1").val(result.Result.NHB_BalanceSheet_Assets.AdvancesReceived1);
//                    $("#AdvancesReceived2").val(result.Result.NHB_BalanceSheet_Assets.AdvancesReceived2);
//                    $("#AdvancesReceived3").val(result.Result.NHB_BalanceSheet_Assets.AdvancesReceived3);
//                    $("#AdvancesReceived4").val(result.Result.NHB_BalanceSheet_Assets.AdvancesReceived4);
//                    $("#OtherCurrentLiabilities1").val(result.Result.NHB_BalanceSheet_Assets.OtherCurrentLiabilities1);
//                    $("#OtherCurrentLiabilities2").val(result.Result.NHB_BalanceSheet_Assets.OtherCurrentLiabilities2);
//                    $("#OtherCurrentLiabilities3").val(result.Result.NHB_BalanceSheet_Assets.OtherCurrentLiabilities3);
//                    $("#OtherCurrentLiabilities4").val(result.Result.NHB_BalanceSheet_Assets.OtherCurrentLiabilities4);
//                    $("#DeferredtaxLiability1").val(result.Result.NHB_BalanceSheet_Assets.DeferredtaxLiability1);
//                    $("#DeferredtaxLiability2").val(result.Result.NHB_BalanceSheet_Assets.DeferredtaxLiability2);
//                    $("#DeferredtaxLiability3").val(result.Result.NHB_BalanceSheet_Assets.DeferredtaxLiability3);
//                    $("#DeferredtaxLiability4").val(result.Result.NHB_BalanceSheet_Assets.DeferredtaxLiability4);
//                    $("#ReceivablesSecuritised1").val(result.Result.NHB_BalanceSheet_Assets.ReceivablesSecuritised1);
//                    $("#ReceivablesSecuritised2").val(result.Result.NHB_BalanceSheet_Assets.ReceivablesSecuritised2);
//                    $("#ReceivablesSecuritised3").val(result.Result.NHB_BalanceSheet_Assets.ReceivablesSecuritised3);
//                    $("#ReceivablesSecuritised4").val(result.Result.NHB_BalanceSheet_Assets.ReceivablesSecuritised4);
//                    $("#ProvisionsOutput1").val(result.Result.NHB_BalanceSheet_Assets.ProvisionsOutput1);
//                    $("#ProvisionsOutput2").val(result.Result.NHB_BalanceSheet_Assets.ProvisionsOutput2);
//                    $("#ProvisionsOutput3").val(result.Result.NHB_BalanceSheet_Assets.ProvisionsOutput3);
//                    $("#ProvisionsOutput4").val(result.Result.NHB_BalanceSheet_Assets.ProvisionsOutput4);
//                    $("#ProvisionForLoanLosses1").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForLoanLosses1);
//                    $("#ProvisionForLoanLosses2").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForLoanLosses2);
//                    $("#ProvisionForLoanLosses3").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForLoanLosses3);
//                    $("#ProvisionForLoanLosses4").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForLoanLosses4);
//                    $("#ProvisionForDoubtfulDebtors1").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors1);
//                    $("#ProvisionForDoubtfulDebtors2").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors2);
//                    $("#ProvisionForDoubtfulDebtors3").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors3);
//                    $("#ProvisionForDoubtfulDebtors4").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDoubtfulDebtors4);
//                    $("#ProvisionForDepreciation1").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDepreciation1);
//                    $("#ProvisionForDepreciation2").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDepreciation2);
//                    $("#ProvisionForDepreciation3").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDepreciation3);
//                    $("#ProvisionForDepreciation4").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDepreciation4);
//                    $("#ProvisionForImpairmentofAssets1").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets1);
//                    $("#ProvisionForImpairmentofAssets2").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets2);
//                    $("#ProvisionForImpairmentofAssets3").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets3);
//                    $("#ProvisionForImpairmentofAssets4").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForImpairmentofAssets4);
//                    $("#ProvisionForDividend1").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDividend1);
//                    $("#ProvisionForDividend2").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDividend2);
//                    $("#ProvisionForDividend3").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDividend3);
//                    $("#ProvisionForDividend4").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDividend4);
//                    $("#ProvisionForTaxes1").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForTaxes1);
//                    $("#ProvisionForTaxes2").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForTaxes2);
//                    $("#ProvisionForTaxes3").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForTaxes3);
//                    $("#ProvisionForTaxes4").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForTaxes4);
//                    $("#ProvisionForDeferredTaxes1").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes1);
//                    $("#ProvisionForDeferredTaxes2").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes2);
//                    $("#ProvisionForDeferredTaxes3").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes3);
//                    $("#ProvisionForDeferredTaxes4").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForDeferredTaxes4);
//                    $("#ProvisionForExpenses1").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForExpenses1);
//                    $("#ProvisionForExpenses2").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForExpenses2);
//                    $("#ProvisionForExpenses3").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForExpenses3);
//                    $("#ProvisionForExpenses4").val(result.Result.NHB_BalanceSheet_Assets.ProvisionForExpenses4);
//                    $("#OtherProvisions1").val(result.Result.NHB_BalanceSheet_Assets.OtherProvisions1);
//                    $("#OtherProvisions2").val(result.Result.NHB_BalanceSheet_Assets.OtherProvisions2);
//                    $("#OtherProvisions3").val(result.Result.NHB_BalanceSheet_Assets.OtherProvisions3);
//                    $("#OtherProvisions4").val(result.Result.NHB_BalanceSheet_Assets.OtherProvisions4);
//                    $("#NetCurrentAssetsOutput1").val(result.Result.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput1);
//                    $("#NetCurrentAssetsOutput2").val(result.Result.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput2);
//                    $("#NetCurrentAssetsOutput3").val(result.Result.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput3);
//                    $("#NetCurrentAssetsOutput4").val(result.Result.NHB_BalanceSheet_Assets.NetCurrentAssetsOutput4);
//                    $("#TotalAssetsOutput1").val(result.Result.NHB_BalanceSheet_Assets.TotalAssetsOutput1);
//                    $("#TotalAssetsOutput2").val(result.Result.NHB_BalanceSheet_Assets.TotalAssetsOutput2);
//                    $("#TotalAssetsOutput3").val(result.Result.NHB_BalanceSheet_Assets.TotalAssetsOutput3);
//                    $("#TotalAssetsOutput4").val(result.Result.NHB_BalanceSheet_Assets.TotalAssetsOutput4);
//                    $("#ErrorCheck1").val(result.Result.NHB_BalanceSheet_Assets.ErrorCheck1);
//                    $("#ErrorCheck2").val(result.Result.NHB_BalanceSheet_Assets.ErrorCheck2);
//                    $("#ErrorCheck3").val(result.Result.NHB_BalanceSheet_Assets.ErrorCheck3);
//                    $("#ErrorCheck4").val(result.Result.NHB_BalanceSheet_Assets.ErrorCheck4);
//                }
//                //#endregion


//                //#region Contingent-Liabilities
//                if (result.Result.NHB_Contingent_Liabilities != null) {
//                    $("#LiabilityOnSecuritisationContracts1").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts1);
//                    $("#LiabilityOnSecuritisationContracts2").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts2);
//                    $("#LiabilityOnSecuritisationContracts3").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts3);
//                    $("#LiabilityOnSecuritisationContracts4").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnSecuritisationContracts4);
//                    $("#GuaranteesGiven1").val(result.Result.NHB_Contingent_Liabilities.GuaranteesGiven1);
//                    $("#GuaranteesGiven2").val(result.Result.NHB_Contingent_Liabilities.GuaranteesGiven2);
//                    $("#GuaranteesGiven3").val(result.Result.NHB_Contingent_Liabilities.GuaranteesGiven3);
//                    $("#GuaranteesGiven4").val(result.Result.NHB_Contingent_Liabilities.GuaranteesGiven4);
//                    $("#LiabilityOnPartlyPaidInvestments1").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments1);
//                    $("#LiabilityOnPartlyPaidInvestments2").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments2);
//                    $("#LiabilityOnPartlyPaidInvestments3").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments3);
//                    $("#LiabilityOnPartlyPaidInvestments4").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnPartlyPaidInvestments4);
//                    $("#LiabilityOnForeignExchangContracts1").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts1);
//                    $("#LiabilityOnForeignExchangContracts2").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts2);
//                    $("#LiabilityOnForeignExchangContracts3").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts3);
//                    $("#LiabilityOnForeignExchangContracts4").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnForeignExchangContracts4);
//                    $("#LiabilityOnDerivativeContracts1").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts1);
//                    $("#LiabilityOnDerivativeContracts2").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts2);
//                    $("#LiabilityOnDerivativeContracts3").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts3);
//                    $("#LiabilityOnDerivativeContracts4").val(result.Result.NHB_Contingent_Liabilities.LiabilityOnDerivativeContracts4);
//                    $("#EndorsementsAndAcceptancesAndOtherObligations1").val(result.Result.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations1);
//                    $("#EndorsementsAndAcceptancesAndOtherObligations2").val(result.Result.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations2);
//                    $("#EndorsementsAndAcceptancesAndOtherObligations3").val(result.Result.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations3);
//                    $("#EndorsementsAndAcceptancesAndOtherObligations4").val(result.Result.NHB_Contingent_Liabilities.EndorsementsAndAcceptancesAndOtherObligations4);
//                    $("#ClaimsNotAcknowledgedAsDebts1").val(result.Result.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts1);
//                    $("#ClaimsNotAcknowledgedAsDebts2").val(result.Result.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts2);
//                    $("#ClaimsNotAcknowledgedAsDebts3").val(result.Result.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts3);
//                    $("#ClaimsNotAcknowledgedAsDebts4").val(result.Result.NHB_Contingent_Liabilities.ClaimsNotAcknowledgedAsDebts4);
//                    $("#OtherItems1").val(result.Result.NHB_Contingent_Liabilities.OtherItems1);
//                    $("#OtherItems2").val(result.Result.NHB_Contingent_Liabilities.OtherItems2);
//                    $("#OtherItems3").val(result.Result.NHB_Contingent_Liabilities.OtherItems3);
//                    $("#OtherItems4").val(result.Result.NHB_Contingent_Liabilities.OtherItems4);
//                }
//                //#endregion


//                //#region Other BalanceSheets_Disclosures
//                if (result.Result.NHB_OtherBalanceSheet_Disclosures != null) {
//                    $("#TierICapitalRatioPercentage1").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage1);
//                    $("#TierICapitalRatioPercentage2").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage2);
//                    $("#TierICapitalRatioPercentage3").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage3);
//                    $("#TierICapitalRatioPercentage4").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TierICapitalRatioPercentage4);
//                    $("#TierIICapitalRatioPercentage1").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage1);
//                    $("#TierIICapitalRatioPercentage2").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage2);
//                    $("#TierIICapitalRatioPercentage3").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage3);
//                    $("#TierIICapitalRatioPercentage4").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TierIICapitalRatioPercentage4);
//                    $("#TotalCapitalRatioPercentage1").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage1);
//                    $("#TotalCapitalRatioPercentage2").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage2);
//                    $("#TotalCapitalRatioPercentage3").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage3);
//                    $("#TotalCapitalRatioPercentage4").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TotalCapitalRatioPercentage4);
//                    $("#ThirdPartyOriginationsAndServicingPercentage1").val(result.Result.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage1);
//                    $("#ThirdPartyOriginationsAndServicingPercentage2").val(result.Result.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage2);
//                    $("#ThirdPartyOriginationsAndServicingPercentage3").val(result.Result.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage3);
//                    $("#ThirdPartyOriginationsAndServicingPercentage4").val(result.Result.NHB_OtherBalanceSheet_Disclosures.ThirdPartyOriginationsAndServicingPercentage4);
//                    $("#SecuritisedPortfolioOutstandingPercentage1").val(result.Result.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage1);
//                    $("#SecuritisedPortfolioOutstandingPercentage2").val(result.Result.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage2);
//                    $("#SecuritisedPortfolioOutstandingPercentage3").val(result.Result.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage3);
//                    $("#SecuritisedPortfolioOutstandingPercentage4").val(result.Result.NHB_OtherBalanceSheet_Disclosures.SecuritisedPortfolioOutstandingPercentage4);
//                    $("#TotalManagedAssetsPercentage1").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage1);
//                    $("#TotalManagedAssetsPercentage2").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage2);
//                    $("#TotalManagedAssetsPercentage3").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage3);
//                    $("#TotalManagedAssetsPercentage4").val(result.Result.NHB_OtherBalanceSheet_Disclosures.TotalManagedAssetsPercentage4);
//                    $("#GrossNPAs1").val(result.Result.NHB_OtherBalanceSheet_Disclosures.GrossNPAs1);
//                    $("#GrossNPAs2").val(result.Result.NHB_OtherBalanceSheet_Disclosures.GrossNPAs2);
//                    $("#GrossNPAs3").val(result.Result.NHB_OtherBalanceSheet_Disclosures.GrossNPAs3);
//                    $("#GrossNPAs4").val(result.Result.NHB_OtherBalanceSheet_Disclosures.GrossNPAs4);
//                    $("#SpecificLossProvisionsHeld1").val(result.Result.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld1);
//                    $("#SpecificLossProvisionsHeld2").val(result.Result.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld2);
//                    $("#SpecificLossProvisionsHeld3").val(result.Result.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld3);
//                    $("#SpecificLossProvisionsHeld4").val(result.Result.NHB_OtherBalanceSheet_Disclosures.SpecificLossProvisionsHeld4);
//                    $("#NetNPAs1").val(result.Result.NHB_OtherBalanceSheet_Disclosures.NetNPAs1);
//                    $("#NetNPAs2").val(result.Result.NHB_OtherBalanceSheet_Disclosures.NetNPAs2);
//                    $("#NetNPAs3").val(result.Result.NHB_OtherBalanceSheet_Disclosures.NetNPAs3);
//                    $("#NetNPAs4").val(result.Result.NHB_OtherBalanceSheet_Disclosures.NetNPAs4);
//                }

//                //#endregion


//                //#region Profit and Loss Statement
//                if (result.Result.NHB_ProfitAndLossStatements != null) {
//                    $("#PeriodEndingDate1_ProfitAndLoss").val(result.Result.NHB_ProfitAndLossStatements.PeriodEndingDate1_ProfitAndLoss == null ? "" : moment(result.Result.NHB_ProfitAndLossStatements.PeriodEndingDate1_ProfitAndLoss).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate2_ProfitAndLoss").val(result.Result.NHB_ProfitAndLossStatements.PeriodEndingDate2_ProfitAndLoss == null ? "" : moment(result.Result.NHB_ProfitAndLossStatements.PeriodEndingDate2_ProfitAndLoss).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate3_ProfitAndLoss").val(result.Result.NHB_ProfitAndLossStatements.PeriodEndingDate3_ProfitAndLoss == null ? "" : moment(result.Result.NHB_ProfitAndLossStatements.PeriodEndingDate3_ProfitAndLoss).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate4_ProfitAndLoss").val(result.Result.NHB_ProfitAndLossStatements.PeriodEndingDate4_ProfitAndLoss == null ? "" : moment(result.Result.NHB_ProfitAndLossStatements.PeriodEndingDate4_ProfitAndLoss).format("DD-MMM-YY"));
//                    $("#IncomeOutput1").val(result.Result.NHB_ProfitAndLossStatements.IncomeOutput1);
//                    $("#IncomeOutput2").val(result.Result.NHB_ProfitAndLossStatements.IncomeOutput2);
//                    $("#IncomeOutput3").val(result.Result.NHB_ProfitAndLossStatements.IncomeOutput3);
//                    $("#IncomeOutput4").val(result.Result.NHB_ProfitAndLossStatements.IncomeOutput4);
//                    $("#InterestIncomeOutput1").val(result.Result.NHB_ProfitAndLossStatements.InterestIncomeOutput1);
//                    $("#InterestIncomeOutput2").val(result.Result.NHB_ProfitAndLossStatements.InterestIncomeOutput2);
//                    $("#InterestIncomeOutput3").val(result.Result.NHB_ProfitAndLossStatements.InterestIncomeOutput3);
//                    $("#InterestIncomeOutput4").val(result.Result.NHB_ProfitAndLossStatements.InterestIncomeOutput4);
//                    $("#InterestonHousingLoansIndividuals1").val(result.Result.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals1);
//                    $("#InterestonHousingLoansIndividuals2").val(result.Result.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals2);
//                    $("#InterestonHousingLoansIndividuals3").val(result.Result.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals3);
//                    $("#InterestonHousingLoansIndividuals4").val(result.Result.NHB_ProfitAndLossStatements.InterestonHousingLoansIndividuals4);
//                    $("#InterestonHousingLoansCorporateBodies1").val(result.Result.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies1);
//                    $("#InterestonHousingLoansCorporateBodies2").val(result.Result.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies2);
//                    $("#InterestonHousingLoansCorporateBodies3").val(result.Result.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies3);
//                    $("#InterestonHousingLoansCorporateBodies4").val(result.Result.NHB_ProfitAndLossStatements.InterestonHousingLoansCorporateBodies4);
//                    $("#OtherInterestIncome1").val(result.Result.NHB_ProfitAndLossStatements.OtherInterestIncome1);
//                    $("#OtherInterestIncome2").val(result.Result.NHB_ProfitAndLossStatements.OtherInterestIncome2);
//                    $("#OtherInterestIncome3").val(result.Result.NHB_ProfitAndLossStatements.OtherInterestIncome3);
//                    $("#OtherInterestIncome4").val(result.Result.NHB_ProfitAndLossStatements.OtherInterestIncome4);
//                    $("#IncomeFromInvestmentsShortTerm1").val(result.Result.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm1);
//                    $("#IncomeFromInvestmentsShortTerm2").val(result.Result.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm2);
//                    $("#IncomeFromInvestmentsShortTerm3").val(result.Result.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm3);
//                    $("#IncomeFromInvestmentsShortTerm4").val(result.Result.NHB_ProfitAndLossStatements.IncomeFromInvestmentsShortTerm4);
//                    $("#IncomeFromInvestmentsLongTerm1").val(result.Result.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm1);
//                    $("#IncomeFromInvestmentsLongTerm2").val(result.Result.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm2);
//                    $("#IncomeFromInvestmentsLongTerm3").val(result.Result.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm3);
//                    $("#IncomeFromInvestmentsLongTerm4").val(result.Result.NHB_ProfitAndLossStatements.IncomeFromInvestmentsLongTerm4);
//                    $("#OtherOperatingIncomeOutput1").val(result.Result.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput1);
//                    $("#OtherOperatingIncomeOutput2").val(result.Result.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput2);
//                    $("#OtherOperatingIncomeOutput3").val(result.Result.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput3);
//                    $("#OtherOperatingIncomeOutput4").val(result.Result.NHB_ProfitAndLossStatements.OtherOperatingIncomeOutput4);
//                    $("#FeesReceived1").val(result.Result.NHB_ProfitAndLossStatements.FeesReceived1);
//                    $("#FeesReceived2").val(result.Result.NHB_ProfitAndLossStatements.FeesReceived2);
//                    $("#FeesReceived3").val(result.Result.NHB_ProfitAndLossStatements.FeesReceived3);
//                    $("#FeesReceived4").val(result.Result.NHB_ProfitAndLossStatements.FeesReceived4);
//                    $("#CommisionsAndExchangeAndBrokerage1").val(result.Result.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage1);
//                    $("#CommisionsAndExchangeAndBrokerage2").val(result.Result.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage2);
//                    $("#CommisionsAndExchangeAndBrokerage3").val(result.Result.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage3);
//                    $("#CommisionsAndExchangeAndBrokerage4").val(result.Result.NHB_ProfitAndLossStatements.CommisionsAndExchangeAndBrokerage4);
//                    $("#ProfitLossSaleInvestments1").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments1);
//                    $("#ProfitLossSaleInvestments2").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments2);
//                    $("#ProfitLossSaleInvestments3").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments3);
//                    $("#ProfitLossSaleInvestments4").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossSaleInvestments4);
//                    $("#ProfitLossSaleAssets1").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossSaleAssets1);
//                    $("#ProfitLossSaleAssets2").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossSaleAssets2);
//                    $("#ProfitLossSaleAssets3").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossSaleAssets3);
//                    $("#ProfitLossSaleAssets4").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossSaleAssets4);
//                    $("#ProfitLossExchangeTransactions1").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions1);
//                    $("#ProfitLossExchangeTransactions2").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions2);
//                    $("#ProfitLossExchangeTransactions3").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions3);
//                    $("#ProfitLossExchangeTransactions4").val(result.Result.NHB_ProfitAndLossStatements.ProfitLossExchangeTransactions4);
//                    $("#OtherServiceIncome1").val(result.Result.NHB_ProfitAndLossStatements.OtherServiceIncome1);
//                    $("#OtherServiceIncome2").val(result.Result.NHB_ProfitAndLossStatements.OtherServiceIncome2);
//                    $("#OtherServiceIncome3").val(result.Result.NHB_ProfitAndLossStatements.OtherServiceIncome3);
//                    $("#OtherServiceIncome4").val(result.Result.NHB_ProfitAndLossStatements.OtherServiceIncome4);
//                    $("#GainOnSaleOfSecuritisedAssets1").val(result.Result.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets1);
//                    $("#GainOnSaleOfSecuritisedAssets2").val(result.Result.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets2);
//                    $("#GainOnSaleOfSecuritisedAssets3").val(result.Result.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets3);
//                    $("#GainOnSaleOfSecuritisedAssets4").val(result.Result.NHB_ProfitAndLossStatements.GainOnSaleOfSecuritisedAssets4);
//                    $("#OtherNonOperatingIncome1").val(result.Result.NHB_ProfitAndLossStatements.OtherNonOperatingIncome1);
//                    $("#OtherNonOperatingIncome2").val(result.Result.NHB_ProfitAndLossStatements.OtherNonOperatingIncome2);
//                    $("#OtherNonOperatingIncome3").val(result.Result.NHB_ProfitAndLossStatements.OtherNonOperatingIncome3);
//                    $("#OtherNonOperatingIncome4").val(result.Result.NHB_ProfitAndLossStatements.OtherNonOperatingIncome4);
//                    $("#ExpenseOutput1").val(result.Result.NHB_ProfitAndLossStatements.ExpenseOutput1);
//                    $("#ExpenseOutput2").val(result.Result.NHB_ProfitAndLossStatements.ExpenseOutput2);
//                    $("#ExpenseOutput3").val(result.Result.NHB_ProfitAndLossStatements.ExpenseOutput3);
//                    $("#ExpenseOutput4").val(result.Result.NHB_ProfitAndLossStatements.ExpenseOutput4);
//                    $("#InterestExpenseOutput1").val(result.Result.NHB_ProfitAndLossStatements.InterestExpenseOutput1);
//                    $("#InterestExpenseOutput2").val(result.Result.NHB_ProfitAndLossStatements.InterestExpenseOutput2);
//                    $("#InterestExpenseOutput3").val(result.Result.NHB_ProfitAndLossStatements.InterestExpenseOutput3);
//                    $("#InterestExpenseOutput4").val(result.Result.NHB_ProfitAndLossStatements.InterestExpenseOutput4);
//                    $("#InterestOnDeposits1").val(result.Result.NHB_ProfitAndLossStatements.InterestOnDeposits1);
//                    $("#InterestOnDeposits2").val(result.Result.NHB_ProfitAndLossStatements.InterestOnDeposits2);
//                    $("#InterestOnDeposits3").val(result.Result.NHB_ProfitAndLossStatements.InterestOnDeposits3);
//                    $("#InterestOnDeposits4").val(result.Result.NHB_ProfitAndLossStatements.InterestOnDeposits4);
//                    $("#InterestOnBorrowings1").val(result.Result.NHB_ProfitAndLossStatements.InterestOnBorrowings1);
//                    $("#InterestOnBorrowings2").val(result.Result.NHB_ProfitAndLossStatements.InterestOnBorrowings2);
//                    $("#InterestOnBorrowings3").val(result.Result.NHB_ProfitAndLossStatements.InterestOnBorrowings3);
//                    $("#InterestOnBorrowings4").val(result.Result.NHB_ProfitAndLossStatements.InterestOnBorrowings4);
//                    $("#InterestPaidOutput1").val(result.Result.NHB_ProfitAndLossStatements.InterestPaidOutput1);
//                    $("#InterestPaidOutput2").val(result.Result.NHB_ProfitAndLossStatements.InterestPaidOutput2);
//                    $("#InterestPaidOutput3").val(result.Result.NHB_ProfitAndLossStatements.InterestPaidOutput3);
//                    $("#InterestPaidOutput4").val(result.Result.NHB_ProfitAndLossStatements.InterestPaidOutput4);
//                    $("#OtherFinancialCharges1").val(result.Result.NHB_ProfitAndLossStatements.OtherFinancialCharges1);
//                    $("#OtherFinancialCharges2").val(result.Result.NHB_ProfitAndLossStatements.OtherFinancialCharges2);
//                    $("#OtherFinancialCharges3").val(result.Result.NHB_ProfitAndLossStatements.OtherFinancialCharges3);
//                    $("#OtherFinancialCharges4").val(result.Result.NHB_ProfitAndLossStatements.OtherFinancialCharges4);
//                    $("#PersonnelExpenses1").val(result.Result.NHB_ProfitAndLossStatements.PersonnelExpenses1);
//                    $("#PersonnelExpenses2").val(result.Result.NHB_ProfitAndLossStatements.PersonnelExpenses2);
//                    $("#PersonnelExpenses3").val(result.Result.NHB_ProfitAndLossStatements.PersonnelExpenses3);
//                    $("#PersonnelExpenses4").val(result.Result.NHB_ProfitAndLossStatements.PersonnelExpenses4);
//                    $("#OperatingExpensesOutput1").val(result.Result.NHB_ProfitAndLossStatements.OperatingExpensesOutput1);
//                    $("#OperatingExpensesOutput2").val(result.Result.NHB_ProfitAndLossStatements.OperatingExpensesOutput2);
//                    $("#OperatingExpensesOutput3").val(result.Result.NHB_ProfitAndLossStatements.OperatingExpensesOutput3);
//                    $("#OperatingExpensesOutput4").val(result.Result.NHB_ProfitAndLossStatements.OperatingExpensesOutput4);
//                    $("#OperatingExpenses1").val(result.Result.NHB_ProfitAndLossStatements.OperatingExpenses1);
//                    $("#OperatingExpenses2").val(result.Result.NHB_ProfitAndLossStatements.OperatingExpenses2);
//                    $("#OperatingExpenses3").val(result.Result.NHB_ProfitAndLossStatements.OperatingExpenses3);
//                    $("#OperatingExpenses4").val(result.Result.NHB_ProfitAndLossStatements.OperatingExpenses4);
//                    $("#MiscellaneousExpensesWrittenOff1").val(result.Result.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff1);
//                    $("#MiscellaneousExpensesWrittenOff2").val(result.Result.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff2);
//                    $("#MiscellaneousExpensesWrittenOff3").val(result.Result.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff3);
//                    $("#MiscellaneousExpensesWrittenOff4").val(result.Result.NHB_ProfitAndLossStatements.MiscellaneousExpensesWrittenOff4);
//                    $("#ProvisionForImpairmentInValueOfAssets1").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets1);
//                    $("#ProvisionForImpairmentInValueOfAssets2").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets2);
//                    $("#ProvisionForImpairmentInValueOfAssets3").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets3);
//                    $("#ProvisionForImpairmentInValueOfAssets4").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForImpairmentInValueOfAssets4);
//                    $("#Depreciation1").val(result.Result.NHB_ProfitAndLossStatements.Depreciation1);
//                    $("#Depreciation2").val(result.Result.NHB_ProfitAndLossStatements.Depreciation2);
//                    $("#Depreciation3").val(result.Result.NHB_ProfitAndLossStatements.Depreciation3);
//                    $("#Depreciation4").val(result.Result.NHB_ProfitAndLossStatements.Depreciation4);
//                    $("#LoanLosses1").val(result.Result.NHB_ProfitAndLossStatements.LoanLosses1);
//                    $("#LoanLosses2").val(result.Result.NHB_ProfitAndLossStatements.LoanLosses2);
//                    $("#LoanLosses3").val(result.Result.NHB_ProfitAndLossStatements.LoanLosses3);
//                    $("#LoanLosses4").val(result.Result.NHB_ProfitAndLossStatements.LoanLosses4);
//                    $("#PLProvisionForLoanLosses1").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForLoanLosses1);
//                    $("#PLProvisionForLoanLosses2").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForLoanLosses2);
//                    $("#PLProvisionForLoanLosses3").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForLoanLosses3);
//                    $("#PLProvisionForLoanLosses4").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForLoanLosses4);
//                    $("#ProvisionForInterestOnIncomeTaxRefund1").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund1);
//                    $("#ProvisionForInterestOnIncomeTaxRefund2").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund2);
//                    $("#ProvisionForInterestOnIncomeTaxRefund3").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund3);
//                    $("#ProvisionForInterestOnIncomeTaxRefund4").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForInterestOnIncomeTaxRefund4);
//                    $("#ProvisionForBadDebtsWrittenBack1").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack1);
//                    $("#ProvisionForBadDebtsWrittenBack2").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack2);
//                    $("#ProvisionForBadDebtsWrittenBack3").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack3);
//                    $("#ProvisionForBadDebtsWrittenBack4").val(result.Result.NHB_ProfitAndLossStatements.ProvisionForBadDebtsWrittenBack4);
//                    $("#OtherCreditAssetsWrittenOff1").val(result.Result.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff1);
//                    $("#OtherCreditAssetsWrittenOff2").val(result.Result.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff2);
//                    $("#OtherCreditAssetsWrittenOff3").val(result.Result.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff3);
//                    $("#OtherCreditAssetsWrittenOff4").val(result.Result.NHB_ProfitAndLossStatements.OtherCreditAssetsWrittenOff4);
//                    $("#OtherAdjustments1").val(result.Result.NHB_ProfitAndLossStatements.OtherAdjustments1);
//                    $("#OtherAdjustments2").val(result.Result.NHB_ProfitAndLossStatements.OtherAdjustments2);
//                    $("#OtherAdjustments3").val(result.Result.NHB_ProfitAndLossStatements.OtherAdjustments3);
//                    $("#OtherAdjustments4").val(result.Result.NHB_ProfitAndLossStatements.OtherAdjustments4);
//                    $("#ProfitBeforeTaxOutput1").val(result.Result.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput1);
//                    $("#ProfitBeforeTaxOutput2").val(result.Result.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput2);
//                    $("#ProfitBeforeTaxOutput3").val(result.Result.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput3);
//                    $("#ProfitBeforeTaxOutput4").val(result.Result.NHB_ProfitAndLossStatements.ProfitBeforeTaxOutput4);
//                    $("#TaxExpenseOutput1").val(result.Result.NHB_ProfitAndLossStatements.TaxExpenseOutput1);
//                    $("#TaxExpenseOutput2").val(result.Result.NHB_ProfitAndLossStatements.TaxExpenseOutput2);
//                    $("#TaxExpenseOutput3").val(result.Result.NHB_ProfitAndLossStatements.TaxExpenseOutput3);
//                    $("#TaxExpenseOutput4").val(result.Result.NHB_ProfitAndLossStatements.TaxExpenseOutput4);
//                    $("#CurrentTax1").val(result.Result.NHB_ProfitAndLossStatements.CurrentTax1);
//                    $("#CurrentTax2").val(result.Result.NHB_ProfitAndLossStatements.CurrentTax2);
//                    $("#CurrentTax3").val(result.Result.NHB_ProfitAndLossStatements.CurrentTax3);
//                    $("#CurrentTax4").val(result.Result.NHB_ProfitAndLossStatements.CurrentTax4);
//                    $("#DeferredTax1").val(result.Result.NHB_ProfitAndLossStatements.DeferredTax1);
//                    $("#DeferredTax2").val(result.Result.NHB_ProfitAndLossStatements.DeferredTax2);
//                    $("#DeferredTax3").val(result.Result.NHB_ProfitAndLossStatements.DeferredTax3);
//                    $("#DeferredTax4").val(result.Result.NHB_ProfitAndLossStatements.DeferredTax4);
//                    $("#ProfitAfterTaxOutput1").val(result.Result.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput1);
//                    $("#ProfitAfterTaxOutput2").val(result.Result.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput2);
//                    $("#ProfitAfterTaxOutput3").val(result.Result.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput3);
//                    $("#ProfitAfterTaxOutput4").val(result.Result.NHB_ProfitAndLossStatements.ProfitAfterTaxOutput4);
//                    $("#PreferenceDividend_Tax1").val(result.Result.NHB_ProfitAndLossStatements.PreferenceDividend_Tax1);
//                    $("#PreferenceDividend_Tax2").val(result.Result.NHB_ProfitAndLossStatements.PreferenceDividend_Tax2);
//                    $("#PreferenceDividend_Tax3").val(result.Result.NHB_ProfitAndLossStatements.PreferenceDividend_Tax3);
//                    $("#PreferenceDividend_Tax4").val(result.Result.NHB_ProfitAndLossStatements.PreferenceDividend_Tax4);
//                    $("#EquityDividend_Tax1").val(result.Result.NHB_ProfitAndLossStatements.EquityDividend_Tax1);
//                    $("#EquityDividend_Tax2").val(result.Result.NHB_ProfitAndLossStatements.EquityDividend_Tax2);
//                    $("#EquityDividend_Tax3").val(result.Result.NHB_ProfitAndLossStatements.EquityDividend_Tax3);
//                    $("#EquityDividend_Tax4").val(result.Result.NHB_ProfitAndLossStatements.EquityDividend_Tax4);
//                }
//                //#endregion


//                //#region ALM_StatementLatests
//                if (result.Result.NHB_ALM_Statement_Latests != null) {
//                    $("#Statement_Date").val(result.Result.NHB_ALM_Statement_Latests.Statement_Date == null ? "" : moment(result.Result.NHB_ALM_Statement_Latests.Statement_Date).format("DD-MMM-YYYY"));
//                    $("#Day1to14DaysInflow").val(result.Result.NHB_ALM_Statement_Latests.Day1to14DaysInflow);
//                    $("#Day1to14DaysInflow").val(result.Result.NHB_ALM_Statement_Latests.Day1to14DaysInflow);
//                    $("#Day1to14DaysOurflow").val(result.Result.NHB_ALM_Statement_Latests.Day1to14DaysOurflow);
//                    $("#Day1to14DaysMismatch").val(result.Result.NHB_ALM_Statement_Latests.Day1to14DaysMismatch);
//                    $("#Day14DaysTo1MonthInflow").val(result.Result.NHB_ALM_Statement_Latests.Day14DaysTo1MonthInflow);
//                    $("#Day14DaysTo1MonthOurflow").val(result.Result.NHB_ALM_Statement_Latests.Day14DaysTo1MonthOurflow);
//                    $("#Day14DaysTo1MonthMismatch").val(result.Result.NHB_ALM_Statement_Latests.Day14DaysTo1MonthMismatch);
//                    $("#Month1To2MonthsInflow").val(result.Result.NHB_ALM_Statement_Latests.Month1To2MonthsInflow);
//                    $("#Month1To2MonthsOurflow").val(result.Result.NHB_ALM_Statement_Latests.Month1To2MonthsOurflow);
//                    $("#Month1To2MonthsMismatch").val(result.Result.NHB_ALM_Statement_Latests.Month1To2MonthsMismatch);
//                    $("#Month2To3MonthsInflow").val(result.Result.NHB_ALM_Statement_Latests.Month2To3MonthsInflow);
//                    $("#Month2To3MonthsOurflow").val(result.Result.NHB_ALM_Statement_Latests.Month2To3MonthsOurflow);
//                    $("#Month2To3MonthsMismatch").val(result.Result.NHB_ALM_Statement_Latests.Month2To3MonthsMismatch);
//                    $("#Month3To6MonthsInflow").val(result.Result.NHB_ALM_Statement_Latests.Month3To6MonthsInflow);
//                    $("#Month3To6MonthsOurflow").val(result.Result.NHB_ALM_Statement_Latests.Month3To6MonthsOurflow);
//                    $("#Month3To6MonthsMismatch").val(result.Result.NHB_ALM_Statement_Latests.Month3To6MonthsMismatch);
//                    $("#Month6MonthsTo1YearInflow").val(result.Result.NHB_ALM_Statement_Latests.Month6MonthsTo1YearInflow);
//                    $("#Month6MonthsTo1YearOurflow").val(result.Result.NHB_ALM_Statement_Latests.Month6MonthsTo1YearOurflow);
//                    $("#Month6MonthsTo1YearMismatch").val(result.Result.NHB_ALM_Statement_Latests.Month6MonthsTo1YearMismatch);
//                    $("#Year1To3YearsInflow").val(result.Result.NHB_ALM_Statement_Latests.Year1To3YearsInflow);
//                    $("#Year1To3YearsOurflow").val(result.Result.NHB_ALM_Statement_Latests.Year1To3YearsOurflow);
//                    $("#Year1To3YearsMismatch").val(result.Result.NHB_ALM_Statement_Latests.Year1To3YearsMismatch);
//                    $("#Year3To5YearsInflow").val(result.Result.NHB_ALM_Statement_Latests.Year3To5YearsInflow);
//                    $("#Year3To5YearsOurflow").val(result.Result.NHB_ALM_Statement_Latests.Year3To5YearsOurflow);
//                    $("#Year3To5YearsMismatch").val(result.Result.NHB_ALM_Statement_Latests.Year3To5YearsMismatch);
//                    $("#Year5To7YearsInflow").val(result.Result.NHB_ALM_Statement_Latests.Year5To7YearsInflow);
//                    $("#Year5To7YearsOurflow").val(result.Result.NHB_ALM_Statement_Latests.Year5To7YearsOurflow);
//                    $("#Year5To7YearsMismatch").val(result.Result.NHB_ALM_Statement_Latests.Year5To7YearsMismatch);
//                    $("#Year7To10YearsInflow").val(result.Result.NHB_ALM_Statement_Latests.Year7To10YearsInflow);
//                    $("#Year7To10YearsOurflow").val(result.Result.NHB_ALM_Statement_Latests.Year7To10YearsOurflow);
//                    $("#Year7To10YearsMismatch").val(result.Result.NHB_ALM_Statement_Latests.Year7To10YearsMismatch);
//                    $("#Over10YearsInflow").val(result.Result.NHB_ALM_Statement_Latests.Over10YearsInflow);
//                    $("#Over10YearsOurflow").val(result.Result.NHB_ALM_Statement_Latests.Over10YearsOurflow);
//                    $("#Over10YearsMismatch").val(result.Result.NHB_ALM_Statement_Latests.Over10YearsMismatch);
//                }

//                //#endregion 


//                //#region KeyRatio
//                if (result.Result.NHB_KeyRatios != null) {
//                    $("#PeriodEndingDate1_KeyRatios").val(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate1_Assets == null ? "" : moment(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate1_Assets).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate2_KeyRatios").val(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate2_Assets == null ? "" : moment(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate2_Assets).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate3_KeyRatios").val(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate3_Assets == null ? "" : moment(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate3_Assets).format("DD-MMM-YY"));
//                    $("#PeriodEndingDate4_KeyRatios").val(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate4_Assets == null ? "" : moment(result.Result.NHB_BalanceSheet_Assets.PeriodEndingDate4_Assets).format("DD-MMM-YY"));
//                    $("#TotalAssets1").val(result.Result.NHB_KeyRatios.TotalAssets1);
//                    $("#TotalAssets2").val(result.Result.NHB_KeyRatios.TotalAssets2);
//                    $("#TotalAssets3").val(result.Result.NHB_KeyRatios.TotalAssets3);
//                    $("#TotalAssets4").val(result.Result.NHB_KeyRatios.TotalAssets4);
//                    $("#GrossNPAPercentage1").val(result.Result.NHB_KeyRatios.GrossNPAPercentage1 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.GrossNPAPercentage1);
//                    $("#GrossNPAPercentage2").val(result.Result.NHB_KeyRatios.GrossNPAPercentage2 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.GrossNPAPercentage2);
//                    $("#GrossNPAPercentage3").val(result.Result.NHB_KeyRatios.GrossNPAPercentage3 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.GrossNPAPercentage3);
//                    $("#GrossNPAPercentage4").val(result.Result.NHB_KeyRatios.GrossNPAPercentage4 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.GrossNPAPercentage4);
//                    $("#ALMMismatchPercentage1").val(result.Result.NHB_KeyRatios.ALMMismatchPercentage1 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.ALMMismatchPercentage1);
//                    $("#ALMMismatchPercentage2").val(result.Result.NHB_KeyRatios.ALMMismatchPercentage2 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.ALMMismatchPercentage2);
//                    $("#ALMMismatchPercentage3").val(result.Result.NHB_KeyRatios.ALMMismatchPercentage3 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.ALMMismatchPercentage3);
//                    $("#ALMMismatchPercentage4").val(result.Result.NHB_KeyRatios.ALMMismatchPercentage4 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.ALMMismatchPercentage4);
//                    $("#NetWorth1").val(result.Result.NHB_KeyRatios.NetWorth1);
//                    $("#NetWorth2").val(result.Result.NHB_KeyRatios.NetWorth2);
//                    $("#NetWorth3").val(result.Result.NHB_KeyRatios.NetWorth3);
//                    $("#NetWorth4").val(result.Result.NHB_KeyRatios.NetWorth4);
//                    $("#CRARPercentage1").val(result.Result.NHB_KeyRatios.CRARPercentage1);
//                    $("#CRARPercentage2").val(result.Result.NHB_KeyRatios.CRARPercentage2);
//                    $("#CRARPercentage3").val(result.Result.NHB_KeyRatios.CRARPercentage3);
//                    $("#CRARPercentage4").val(result.Result.NHB_KeyRatios.CRARPercentage4);
//                    $("#GearingPercentage1").val(result.Result.NHB_KeyRatios.GearingPercentage1 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.GearingPercentage1);
//                    $("#GearingPercentage2").val(result.Result.NHB_KeyRatios.GearingPercentage2 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.GearingPercentage2);
//                    $("#GearingPercentage3").val(result.Result.NHB_KeyRatios.GearingPercentage3 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.GearingPercentage3);
//                    $("#GearingPercentage4").val(result.Result.NHB_KeyRatios.GearingPercentage4 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.GearingPercentage4);
//                    $("#TangibleNWNetNPA1").val(result.Result.NHB_KeyRatios.TangibleNWNetNPA1);
//                    $("#TangibleNWNetNPA2").val(result.Result.NHB_KeyRatios.TangibleNWNetNPA2);
//                    $("#TangibleNWNetNPA3").val(result.Result.NHB_KeyRatios.TangibleNWNetNPA3);
//                    $("#TangibleNWNetNPA4").val(result.Result.NHB_KeyRatios.TangibleNWNetNPA4);
//                    $("#NetMarginPercentage1").val(result.Result.NHB_KeyRatios.NetMarginPercentage1 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.NetMarginPercentage1);
//                    $("#NetMarginPercentage2").val(result.Result.NHB_KeyRatios.NetMarginPercentage2 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.NetMarginPercentage2);
//                    $("#NetMarginPercentage3").val(result.Result.NHB_KeyRatios.NetMarginPercentage3 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.NetMarginPercentage3);
//                    $("#NetMarginPercentage4").val(result.Result.NHB_KeyRatios.NetMarginPercentage4 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.NetMarginPercentage4);
//                    $("#PATAverageFundsDeployedPercentage1").val(result.Result.NHB_KeyRatios.PATAverageFundsDeployedPercentage1 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.PATAverageFundsDeployedPercentage1);
//                    $("#PATAverageFundsDeployedPercentage2").val(result.Result.NHB_KeyRatios.PATAverageFundsDeployedPercentage2 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.PATAverageFundsDeployedPercentage2);
//                    $("#PATAverageFundsDeployedPercentage3").val(result.Result.NHB_KeyRatios.PATAverageFundsDeployedPercentage3 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.PATAverageFundsDeployedPercentage3);
//                    $("#PATAverageFundsDeployedPercentage4").val(result.Result.NHB_KeyRatios.PATAverageFundsDeployedPercentage4 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.PATAverageFundsDeployedPercentage4);
//                    $("#PATAverageNetWorthPercentage1").val(result.Result.NHB_KeyRatios.PATAverageNetWorthPercentage1 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.PATAverageNetWorthPercentage1);
//                    $("#PATAverageNetWorthPercentage2").val(result.Result.NHB_KeyRatios.PATAverageNetWorthPercentage2 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.PATAverageNetWorthPercentage2);
//                    $("#PATAverageNetWorthPercentage3").val(result.Result.NHB_KeyRatios.PATAverageNetWorthPercentage3 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.PATAverageNetWorthPercentage3);
//                    $("#PATAverageNetWorthPercentage4").val(result.Result.NHB_KeyRatios.PATAverageNetWorthPercentage4 == "-2146826281" ? "#DIV/0!" : result.Result.NHB_KeyRatios.PATAverageNetWorthPercentage4);
//                }

//                //#endregion 


//                //#region Industry_RiskInputs
//                if (result.Result.NHB_Industry_RiskInputs != null) {
//                    $("#FinancialPerformanceofPlayer").val(result.Result.NHB_Industry_RiskInputs.FinancialPerformanceofPlayer);
//                    $("#ExtentOfCompetition").val(result.Result.NHB_Industry_RiskInputs.ExtentOfCompetition);
//                    $("#ProspectOfRealEstateMarket").val(result.Result.NHB_Industry_RiskInputs.ProspectOfRealEstateMarket);
//                    $("#RegulatoryImpact").val(result.Result.NHB_Industry_RiskInputs.RegulatoryImpact);
//                }

//                //#endregion


//                //#region Business_RiskInputs
//                if (result.Result.NHB_Business_RiskInputs != null) {
//                    $("#RankOfMarketPosition").val(result.Result.NHB_Business_RiskInputs.RankOfMarketPosition);
//                    $("#GeographicalDiversification").val(result.Result.NHB_Business_RiskInputs.GeographicalDiversification);
//                    $("#ProductMix").val(result.Result.NHB_Business_RiskInputs.ProductMix);
//                    $("#CustomerMix").val(result.Result.NHB_Business_RiskInputs.CustomerMix);
//                    $("#CostOfResources").val(result.Result.NHB_Business_RiskInputs.CostOfResources);
//                    $("#TotalAssetGrowth").val(result.Result.NHB_Business_RiskInputs.TotalAssetGrowth);
//                    $("#DiversificationOfFundingProfile").val(result.Result.NHB_Business_RiskInputs.DiversificationOfFundingProfile);
//                }

//                //#endregion


//                //#region Financial_RiskInputs
//                if (result.Result.NHB_Financial_RiskInputs != null) {
//                    $("#CompanysAbility").val(result.Result.NHB_Financial_RiskInputs.CompanysAbility);
//                }

//                //#endregion


//                //#region Management_RiskInputs
//                if (result.Result.NHB_Management_RiskInputs != null) {
//                    $("#AbilityToMeetRevenueProjection").val(result.Result.NHB_Management_RiskInputs.AbilityToMeetRevenueProjection);
//                    $("#AbilityToMeetProfitProjection").val(result.Result.NHB_Management_RiskInputs.AbilityToMeetProfitProjection);
//                    $("#PastPaymentRecord").val(result.Result.NHB_Management_RiskInputs.PastPaymentRecord);
//                    $("#RiskManagementSystem").val(result.Result.NHB_Management_RiskInputs.RiskManagementSystem);
//                    $("#ManagementCredibility").val(result.Result.NHB_Management_RiskInputs.ManagementCredibility);
//                    $("#ManagementExperienceAndCompetence").val(result.Result.NHB_Management_RiskInputs.ManagementExperienceAndCompetence);
//                    $("#RiskAppetite").val(result.Result.NHB_Management_RiskInputs.RiskAppetite);
//                }

//                //#endregion


//                //#region NotchUp_CriteriaInputs
//                if (result.Result.NHB_NotchUp_CriteriaInputs != null) {
//                    $("#ShareholdingStructure").val(result.Result.NHB_NotchUp_CriteriaInputs.ShareholdingStructure);
//                    $("#ManagementControl").val(result.Result.NHB_NotchUp_CriteriaInputs.ManagementControl);
//                    $("#StatedPostureOfTheParent").val(result.Result.NHB_NotchUp_CriteriaInputs.StatedPostureOfTheParent);
//                    $("#PastTrackRecord").val(result.Result.NHB_NotchUp_CriteriaInputs.PastTrackRecord);
//                    $("#BrandName").val(result.Result.NHB_NotchUp_CriteriaInputs.BrandName)
//                }
//                //#endregion 

//                //#region Output
//                if (result.Result.NHB_RiskModel_Outputs != null) {

//                    $("#IndustryRiskFinancialPerformanceOfPlayersWeight").val(result.Result.NHB_RiskModel_Outputs.IndustryRiskFinancialPerformanceOfPlayersWeight);
//                    $("#IndustryRiskFinancialPerformanceOfPlayersValue").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskFinancialPerformanceOfPlayersValue);
//                    $("#IndustryRiskFinancialPerformanceOfPlayersScore").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskFinancialPerformanceOfPlayersScore);

//                    $("#IndustryRiskCompetitionsWeight").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskCompetitionsWeight);
//                    $("#IndustryRiskCompetitionsValue").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskCompetitionsValue);
//                    $("#IndustryRiskCompetitionsScore").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskCompetitionsScore);

//                    $("#IndustryRiskProspectOfRealEstateMarketWeight").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskProspectOfRealEstateMarketWeight);
//                    $("#IndustryRiskProspectOfRealEstateMarketValue").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskProspectOfRealEstateMarketValue);
//                    $("#IndustryRiskProspectOfRealEstateMarketScore").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskProspectOfRealEstateMarketScore);

//                    $("#IndustryRiskRegulatoryImpactGovernmentPolicyWeight").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskRegulatoryImpactGovernmentPolicyWeight);
//                    $("#IndustryRiskRegulatoryImpactGovernmentPolicyValue").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskRegulatoryImpactGovernmentPolicyValue);
//                    $("#IndustryRiskRegulatoryImpactGovernmentPolicyScore").val(result.Result.Result.NHB_RiskModel_Outputs.IndustryRiskRegulatoryImpactGovernmentPolicyScore);

//                    $("#BusinessRiskMarketPositionRankWeight").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskMarketPositionRankWeight);
//                    $("#BusinessRiskMarketPositionRankValue").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskMarketPositionRankValue);
//                    $("#BusinessRiskMarketPositionRankScore").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskMarketPositionRankScore);

//                    $("#BusinessRiskMarketPositionGeographicalDiversificationWeight").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskMarketPositionGeographicalDiversificationWeight);
//                    $("#BusinessRiskMarketPositionGeographicalDiversificationValue").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskMarketPositionGeographicalDiversificationValue);
//                    $("#BusinessRiskMarketPositionGeographicalDiversificationScore").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskMarketPositionGeographicalDiversificationScore);

//                    $("#BusinessRiskAssetQualityProductMixWeight").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskAssetQualityProductMixWeight);
//                    $("#BusinessRiskAssetQualityProductMixValue").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskAssetQualityProductMixValue);
//                    $("#BusinessRiskAssetQualityProductMixScore").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskAssetQualityProductMixScore);

//                    $("#BusinessRiskAssetQualityCustomerMixWeight").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskAssetQualityCustomerMixWeight);
//                    $("#BusinessRiskAssetQualityCustomerMixValue").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskAssetQualityCustomerMixValue);
//                    $("#BusinessRiskAssetQualityCustomerMixScore").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskAssetQualityCustomerMixScore);

//                    $("#BusinessRiskAssetQualityGrossNPAWeight").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskAssetQualityGrossNPAWeight);
//                    $("#BusinessRiskAssetQualityGrossNPAValue").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskAssetQualityGrossNPAValue);
//                    $("#BusinessRiskAssetQualityGrossNPAScore").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskAssetQualityGrossNPAScore);

//                    $("#BusinessRiskOperatingEfficiencyCostOfResourcesWeight").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskOperatingEfficiencyCostOfResourcesWeight);
//                    $("#BusinessRiskOperatingEfficiencyCostOfResourcesValue").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskOperatingEfficiencyCostOfResourcesValue);
//                    $("#BusinessRiskOperatingEfficiencyCostOfResourcesScore").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskOperatingEfficiencyCostOfResourcesScore);

//                    $("#BusinessRiskOperatingEfficiencyTotalAssetGrowthWeight").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskOperatingEfficiencyTotalAssetGrowthWeight);
//                    $("#BusinessRiskOperatingEfficiencyTotalAssetGrowthValue").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskOperatingEfficiencyTotalAssetGrowthValue);
//                    $("#BusinessRiskOperatingEfficiencyTotalAssetGrowthScore").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskOperatingEfficiencyTotalAssetGrowthScore);

//                    $("#BusinessRiskOperatingEfficiencyDiversityOfResourcesWeight").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskOperatingEfficiencyDiversityOfResourcesWeight);
//                    $("#BusinessRiskOperatingEfficiencyDiversityOfResourcesValue").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskOperatingEfficiencyDiversityOfResourcesValue);
//                    $("#BusinessRiskOperatingEfficiencyDiversityOfResourcesScore").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskOperatingEfficiencyDiversityOfResourcesScore);

//                    $("#BusinessRiskTotalAssetBaseWeight").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskTotalAssetBaseWeight);
//                    $("#BusinessRiskTotalAssetBaseValue").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskTotalAssetBaseValue);
//                    $("#BusinessRiskTotalAssetBaseScore").val(result.Result.Result.NHB_RiskModel_Outputs.BusinessRiskTotalAssetBaseScore);

//                    $("#FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchWeight").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchWeight);
//                    $("#FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchValue").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchValue);
//                    $("#FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchScore").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchScore);

//                    $("#FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementWeight").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementWeight);
//                    $("#FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementValue").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementValue);
//                    $("#FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementScore").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementScore);

//                    $("#FinancialRiskCapitalTangibleNetworthWeight").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskCapitalTangibleNetworthWeight);
//                    $("#FinancialRiskCapitalTangibleNetworthValue").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskCapitalTangibleNetworthValue);
//                    $("#FinancialRiskCapitalTangibleNetworthScore").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskCapitalTangibleNetworthScore);

//                    $("#FinancialRiskCapitalAdequacyRatioWeight").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskCapitalAdequacyRatioWeight);
//                    $("#FinancialRiskCapitalAdequacyRatioValue").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskCapitalAdequacyRatioValue);
//                    $("#FinancialRiskCapitalAdequacyRatioScore").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskCapitalAdequacyRatioScore);

//                    $("#FinancialRiskCapitalGearingWeight").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskCapitalGearingWeight);
//                    $("#FinancialRiskCapitalGearingValue").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskCapitalGearingValue);
//                    $("#FinancialRiskCapitalGearingScore").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskCapitalGearingScore);

//                    $("#FinancialRiskEarningsTangibleNetworthNetNPAWeight").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsTangibleNetworthNetNPAWeight);
//                    $("#FinancialRiskEarningsTangibleNetworthNetNPAValue").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsTangibleNetworthNetNPAValue);
//                    $("#FinancialRiskEarningsTangibleNetworthNetNPAScore").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsTangibleNetworthNetNPAScore);

//                    $("#FinancialRiskEarningsNetProfitMarginWeight").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsNetProfitMarginWeight);
//                    $("#FinancialRiskEarningsNetProfitMarginValue").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsNetProfitMarginValue);
//                    $("#FinancialRiskEarningsNetProfitMarginScore").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsNetProfitMarginScore);

//                    $("#FinancialRiskEarningsReturnOnAssetsWeight").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsReturnOnAssetsWeight);
//                    $("#FinancialRiskEarningsReturnOnAssetsValue").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsReturnOnAssetsValue);
//                    $("#FinancialRiskEarningsReturnOnAssetsScore").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsReturnOnAssetsScore);

//                    $("#FinancialRiskEarningsReturnOnNetworthWeight").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsReturnOnNetworthWeight);
//                    $("#FinancialRiskEarningsReturnOnNetworthValue").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsReturnOnNetworthValue);
//                    $("#FinancialRiskEarningsReturnOnNetworthScore").val(result.Result.Result.NHB_RiskModel_Outputs.FinancialRiskEarningsReturnOnNetworthScore);

//                    $("#ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsWeight").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsWeight);
//                    $("#ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsValue").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsValue);
//                    $("#ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsScore").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsScore);

//                    $("#ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsWeight").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsWeight);
//                    $("#ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsValue").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsValue);
//                    $("#ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsScore").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsScore);

//                    $("#ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsWeight").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsWeight);
//                    $("#ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsValue").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsValue);
//                    $("#ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsScore").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsScore);

//                    $("#ManagementRiskTrackRecordRiskManagementSystemWeight").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordRiskManagementSystemWeight);
//                    $("#ManagementRiskTrackRecordRiskManagementSystemValue").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordRiskManagementSystemValue);
//                    $("#ManagementRiskTrackRecordRiskManagementSystemScore").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskTrackRecordRiskManagementSystemScore);

//                    $("#ManagementRiskKeyFactorsCredibilityWeight").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskKeyFactorsCredibilityWeight);
//                    $("#ManagementRiskKeyFactorsCredibilityValue").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskKeyFactorsCredibilityValue);
//                    $("#ManagementRiskKeyFactorsCredibilityScore").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskKeyFactorsCredibilityScore);

//                    $("#ManagementRiskKeyFactorsCompetenceAndExperienceWeight").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskKeyFactorsCompetenceAndExperienceWeight);
//                    $("#ManagementRiskKeyFactorsCompetenceAndExperienceValue").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskKeyFactorsCompetenceAndExperienceValue);
//                    $("#ManagementRiskKeyFactorsCompetenceAndExperienceScore").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskKeyFactorsCompetenceAndExperienceScore);

//                    $("#ManagementRiskKeyFactorsRiskAppetiteWeight").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskKeyFactorsRiskAppetiteWeight);
//                    $("#ManagementRiskKeyFactorsRiskAppetiteValue").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskKeyFactorsRiskAppetiteValue);
//                    $("#ManagementRiskKeyFactorsRiskAppetiteScore").val(result.Result.Result.NHB_RiskModel_Outputs.ManagementRiskKeyFactorsRiskAppetiteScore);

//                    $("#NotchUpCriteriaOwnershipShareholdingStructureWeight").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaOwnershipShareholdingStructureWeight);
//                    $("#NotchUpCriteriaOwnershipShareholdingStructureValue").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaOwnershipShareholdingStructureValue);
//                    $("#NotchUpCriteriaOwnershipShareholdingStructureScore").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaOwnershipShareholdingStructureScore);

//                    $("#NotchUpCriteriaManagementControlWeight").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaManagementControlWeight);
//                    $("#NotchUpCriteriaManagementControlValue").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaManagementControlValue);
//                    $("#NotchUpCriteriaManagementControlScore").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaManagementControlScore);

//                    $("#NotchUpCriteriaStatedPostureOfTheParentWeight").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaStatedPostureOfTheParentWeight);
//                    $("#NotchUpCriteriaStatedPostureOfTheParentValue").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaStatedPostureOfTheParentValue);
//                    $("#NotchUpCriteriaStatedPostureOfTheParentScore").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaStatedPostureOfTheParentScore);

//                    $("#NotchUpCriteriaPastTrackRecordWeight").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaPastTrackRecordWeight);
//                    $("#NotchUpCriteriaPastTrackRecordValue").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaPastTrackRecordValue);
//                    $("#NotchUpCriteriaPastTrackRecordScore").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaPastTrackRecordScore);

//                    $("#NotchUpCriteriaBrandNameWeight").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaBrandNameWeight);
//                    $("#NotchUpCriteriaBrandNameValue").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaBrandNameValue);
//                    $("#NotchUpCriteriaBrandNameScore").val(result.Result.Result.NHB_RiskModel_Outputs.NotchUpCriteriaBrandNameScore);
//                }
//                //endregion
//            }
//            else {


//                //#region Basic Details
//                $("#LocationId").val("");
//                $("#DateOfInput").val("");
//                $("#FinancialYearEndingDate").val("");
//                $("#CurrencyUnits").val("");
//                $("#ParentCompanyIsExist").val("");
//                $("#ParentCompanyId").val("");
//                $("#ParentRatingId").val("");
//                //#endregion


//                //#region BalanceSheets_Liabilities
//                $("#PeriodEndingDate1_Liabilities").val("");
//                $("#PeriodEndingDate2_Liabilities").val("");
//                $("#PeriodEndingDate3_Liabilities").val("");
//                $("#PeriodEndingDate4_Liabilities").val("");
//                $("#LiabilitiesType1").val("");
//                $("#LiabilitiesType2").val("");
//                $("#LiabilitiesType3").val("");
//                $("#LiabilitiesType4").val("");
//                $("#CapitalPEOutput1").val("");
//                $("#CapitalPEOutput2").val("");
//                $("#CapitalPEOutput3").val("");
//                $("#CapitalPEOutput4").val("");
//                $("#CalledAndPaid_Up1").val("");
//                $("#CalledAndPaid_Up2").val("");
//                $("#CalledAndPaid_Up3").val("");
//                $("#CalledAndPaid_Up4").val("");
//                $("#EquityShareWarrant1").val("");
//                $("#EquityShareWarrant2").val("");
//                $("#EquityShareWarrant3").val("");
//                $("#EquityShareWarrant4").val("");
//                $("#ReservesAndSurplusOutput1").val("");
//                $("#ReservesAndSurplusOutput2").val("");
//                $("#ReservesAndSurplusOutput3").val("");
//                $("#ReservesAndSurplusOutput4").val("");
//                $("#CapitalReserves1").val("");
//                $("#CapitalReserves2").val("");
//                $("#CapitalReserves3").val("");
//                $("#CapitalReserves4").val("");
//                $("#GeneralReserves1").val("");
//                $("#GeneralReserves2").val("");
//                $("#GeneralReserves3").val("");
//                $("#GeneralReserves4").val("");
//                $("#SharePremium1").val("");
//                $("#SharePremium2").val("");
//                $("#SharePremium3").val("");
//                $("#SharePremium4").val("");
//                $("#SpecialPurposeReserves1").val("");
//                $("#SpecialPurposeReserves2").val("");
//                $("#SpecialPurposeReserves3").val("");
//                $("#SpecialPurposeReserves4").val("");
//                $("#OtherReserves1").val("");
//                $("#OtherReserves2").val("");
//                $("#OtherReserves3").val("");
//                $("#OtherReserves4").val("");
//                $("#RevenueReserves1").val("");
//                $("#RevenueReserves2").val("");
//                $("#RevenueReserves3").val("");
//                $("#RevenueReserves4").val("");
//                $("#IntangibleAssets1").val("");
//                $("#IntangibleAssets2").val("");
//                $("#IntangibleAssets3").val("");
//                $("#IntangibleAssets4").val("");
//                $("#BorrowingsOutput1").val("");
//                $("#BorrowingsOutput2").val("");
//                $("#BorrowingsOutput3").val("");
//                $("#BorrowingsOutput4").val("");
//                $("#CommercialPaper1").val("");
//                $("#CommercialPaper2").val("");
//                $("#CommercialPaper3").val("");
//                $("#CommercialPaper4").val("");
//                $("#InterCorporateDeposits1").val("");
//                $("#InterCorporateDeposits2").val("");
//                $("#InterCorporateDeposits3").val("");
//                $("#InterCorporateDeposits4").val("");
//                $("#CallAndNoticeMoney1").val("");
//                $("#CallAndNoticeMoney2").val("");
//                $("#CallAndNoticeMoney3").val("");
//                $("#CallAndNoticeMoney4").val("");
//                $("#OtherBorrowings1").val("");
//                $("#OtherBorrowings2").val("");
//                $("#OtherBorrowings3").val("");
//                $("#OtherBorrowings4").val("");
//                $("#LongTermBorrowingsWithinYear1").val("");
//                $("#LongTermBorrowingsWithinYear2").val("");
//                $("#LongTermBorrowingsWithinYear3").val("");
//                $("#LongTermBorrowingsWithinYear4").val("");
//                $("#PublicDeposits1").val("");
//                $("#PublicDeposits2").val("");
//                $("#PublicDeposits3").val("");
//                $("#PublicDeposits4").val("");
//                $("#ShortTermBorrowings1").val("");
//                $("#ShortTermBorrowings2").val("");
//                $("#ShortTermBorrowings3").val("");
//                $("#ShortTermBorrowings4").val("");
//                $("#LongTermBorrowingsFloatingNHB1").val("");
//                $("#LongTermBorrowingsFloatingNHB2").val("");
//                $("#LongTermBorrowingsFloatingNHB3").val("");
//                $("#LongTermBorrowingsFloatingNHB4").val("");
//                $("#LongTermBorrowingsFloatingOthers1").val("");
//                $("#LongTermBorrowingsFloatingOthers2").val("");
//                $("#LongTermBorrowingsFloatingOthers3").val("");
//                $("#LongTermBorrowingsFloatingOthers4").val("");
//                $("#LongTermBorrowingsFixedNHB1").val("");
//                $("#LongTermBorrowingsFixedNHB2").val("");
//                $("#LongTermBorrowingsFixedNHB3").val("");
//                $("#LongTermBorrowingsFixedNHB4").val("");
//                $("#LongTermBorrowingsFixedOthers1").val("");
//                $("#LongTermBorrowingsFixedOthers2").val("");
//                $("#LongTermBorrowingsFixedOthers3").val("");
//                $("#LongTermBorrowingsFixedOthers4").val("");
//                $("#UnsecuredLongTermBorrowings1").val("");
//                $("#UnsecuredLongTermBorrowings2").val("");
//                $("#UnsecuredLongTermBorrowings3").val("");
//                $("#UnsecuredLongTermBorrowings4").val("");
//                $("#LongTermForeignCurrency1").val("");
//                $("#LongTermForeignCurrency2").val("");
//                $("#LongTermForeignCurrency3").val("");
//                $("#LongTermForeignCurrency4").val("");
//                $("#BorrowingsFromRelatedParties1").val("");
//                $("#BorrowingsFromRelatedParties2").val("");
//                $("#BorrowingsFromRelatedParties3").val("");
//                $("#BorrowingsFromRelatedParties4").val("");
//                $("#HybridInstruments1").val("");
//                $("#HybridInstruments2").val("");
//                $("#HybridInstruments3").val("");
//                $("#HybridInstruments4").val("");
//                $("#LiabilitiesAndCapitalTotalOutput1").val("");
//                $("#LiabilitiesAndCapitalTotalOutput2").val("");
//                $("#LiabilitiesAndCapitalTotalOutput3").val("");
//                $("#LiabilitiesAndCapitalTotalOutput4").val("");
//                //#endregion


//                //#region BalanceSheets_Assets   
//                $("#PeriodEndingDate1_Assets").val("");
//                $("#PeriodEndingDate2_Assets").val("");
//                $("#PeriodEndingDate3_Assets").val("");
//                $("#PeriodEndingDate4_Assets").val("");
//                $("#FixedAssetsOutput1").val("");
//                $("#FixedAssetsOutput2").val("");
//                $("#FixedAssetsOutput3").val("");
//                $("#FixedAssetsOutput4").val("");
//                $("#OwnedNetBlock1").val("");
//                $("#OwnedNetBlock2").val("");
//                $("#OwnedNetBlock3").val("");
//                $("#OwnedNetBlock4").val("");
//                $("#LeasedNetBlock1").val("");
//                $("#LeasedNetBlock2").val("");
//                $("#LeasedNetBlock3").val("");
//                $("#LeasedNetBlock4").val("");
//                $("#CapitalWorkInProgress1").val("");
//                $("#CapitalWorkInProgress2").val("");
//                $("#CapitalWorkInProgress3").val("");
//                $("#CapitalWorkInProgress4").val("");
//                $("#InvestmentsOutput1").val("");
//                $("#InvestmentsOutput2").val("");
//                $("#InvestmentsOutput3").val("");
//                $("#InvestmentsOutput4").val("");
//                $("#CentralGovernmentSecuritiesQuoted1").val("");
//                $("#CentralGovernmentSecuritiesQuoted2").val("");
//                $("#CentralGovernmentSecuritiesQuoted3").val("");
//                $("#CentralGovernmentSecuritiesQuoted4").val("");
//                $("#CentralGovernmentDebtUnquoted1").val("");
//                $("#CentralGovernmentDebtUnquoted2").val("");
//                $("#CentralGovernmentDebtUnquoted3").val("");
//                $("#CentralGovernmentDebtUnquoted4").val("");
//                $("#StateGovernmentSecurities1").val("");
//                $("#StateGovernmentSecurities2").val("");
//                $("#StateGovernmentSecurities3").val("");
//                $("#StateGovernmentSecurities4").val("");
//                $("#GuaranteedPublicSectorBonds1").val("");
//                $("#GuaranteedPublicSectorBonds2").val("");
//                $("#GuaranteedPublicSectorBonds3").val("");
//                $("#GuaranteedPublicSectorBonds4").val("");
//                $("#OtherPublicSectorBonds1").val("");
//                $("#OtherPublicSectorBonds2").val("");
//                $("#OtherPublicSectorBonds3").val("");
//                $("#OtherPublicSectorBonds4").val("");
//                $("#PrivateSectorBondsInvestmentGrade1").val("");
//                $("#PrivateSectorBondsInvestmentGrade2").val("");
//                $("#PrivateSectorBondsInvestmentGrade3").val("");
//                $("#PrivateSectorBondsInvestmentGrade4").val("");
//                $("#OtherPrivateSectorBonds1").val("");
//                $("#OtherPrivateSectorBonds2").val("");
//                $("#OtherPrivateSectorBonds3").val("");
//                $("#OtherPrivateSectorBonds4").val("");
//                $("#MutualFunds1").val("");
//                $("#MutualFunds2").val("");
//                $("#MutualFunds3").val("");
//                $("#MutualFunds4").val("");
//                $("#ListedEquity1").val("");
//                $("#ListedEquity2").val("");
//                $("#ListedEquity3").val("");
//                $("#ListedEquity4").val("");
//                $("#UnlistedEquity1").val("");
//                $("#UnlistedEquity2").val("");
//                $("#UnlistedEquity3").val("");
//                $("#UnlistedEquity4").val("");
//                $("#InvestmentsInParentAndSubsidiariesAndAssociates1").val("");
//                $("#InvestmentsInParentAndSubsidiariesAndAssociates2").val("");
//                $("#InvestmentsInParentAndSubsidiariesAndAssociates3").val("");
//                $("#InvestmentsInParentAndSubsidiariesAndAssociates4").val("");
//                $("#CurrentAssetsOutput1").val("");
//                $("#CurrentAssetsOutput2").val("");
//                $("#CurrentAssetsOutput3").val("");
//                $("#CurrentAssetsOutput4").val("");
//                $("#HirePurchaseReceivables1").val("");
//                $("#HirePurchaseReceivables2").val("");
//                $("#HirePurchaseReceivables3").val("");
//                $("#HirePurchaseReceivables4").val("");
//                $("#FinanceLeases1").val("");
//                $("#FinanceLeases2").val("");
//                $("#FinanceLeases3").val("");
//                $("#FinanceLeases4").val("");
//                $("#SecuredLoans1").val("");
//                $("#SecuredLoans2").val("");
//                $("#SecuredLoans3").val("");
//                $("#SecuredLoans4").val("");
//                $("#UnsecuredLoans1").val("");
//                $("#UnsecuredLoans2").val("");
//                $("#UnsecuredLoans3").val("");
//                $("#UnsecuredLoans4").val("");
//                $("#Debtors1").val("");
//                $("#Debtors2").val("");
//                $("#Debtors3").val("");
//                $("#Debtors4").val("");
//                $("#BillsDiscounted1").val("");
//                $("#BillsDiscounted2").val("");
//                $("#BillsDiscounted3").val("");
//                $("#BillsDiscounted4").val("");
//                $("#OtherInterestBearingLoans1").val("");
//                $("#OtherInterestBearingLoans2").val("");
//                $("#OtherInterestBearingLoans3").val("");
//                $("#OtherInterestBearingLoans4").val("");
//                $("#LoansToRelatedParties1").val("");
//                $("#LoansToRelatedParties2").val("");
//                $("#LoansToRelatedParties3").val("");
//                $("#LoansToRelatedParties4").val("");
//                $("#CashAndBank1").val("");
//                $("#CashAndBank2").val("");
//                $("#CashAndBank3").val("");
//                $("#CashAndBank4").val("");
//                $("#AdvancesPaid1").val("");
//                $("#AdvancesPaid2").val("");
//                $("#AdvancesPaid3").val("");
//                $("#AdvancesPaid4").val("");
//                $("#OtherCurrentAssets1").val("");
//                $("#OtherCurrentAssets2").val("");
//                $("#OtherCurrentAssets3").val("");
//                $("#OtherCurrentAssets4").val("");
//                $("#InvestmentsInSecuritisedAssets1").val("");
//                $("#InvestmentsInSecuritisedAssets2").val("");
//                $("#InvestmentsInSecuritisedAssets3").val("");
//                $("#InvestmentsInSecuritisedAssets4").val("");
//                $("#CurrentLiabilitiesOutput1").val("");
//                $("#CurrentLiabilitiesOutput2").val("");
//                $("#CurrentLiabilitiesOutput3").val("");
//                $("#CurrentLiabilitiesOutput4").val("");
//                $("#InterestAccruedButNotDue1").val("");
//                $("#InterestAccruedButNotDue2").val("");
//                $("#InterestAccruedButNotDue3").val("");
//                $("#InterestAccruedButNotDue4").val("");
//                $("#DepositsReceived1").val("");
//                $("#DepositsReceived2").val("");
//                $("#DepositsReceived3").val("");
//                $("#DepositsReceived4").val("");
//                $("#AdvancesReceived1").val("");
//                $("#AdvancesReceived2").val("");
//                $("#AdvancesReceived3").val("");
//                $("#AdvancesReceived4").val("");
//                $("#OtherCurrentLiabilities1").val("");
//                $("#OtherCurrentLiabilities2").val("");
//                $("#OtherCurrentLiabilities3").val("");
//                $("#OtherCurrentLiabilities4").val("");
//                $("#DeferredtaxLiability1").val("");
//                $("#DeferredtaxLiability2").val("");
//                $("#DeferredtaxLiability3").val("");
//                $("#DeferredtaxLiability4").val("");
//                $("#ReceivablesSecuritised1").val("");
//                $("#ReceivablesSecuritised2").val("");
//                $("#ReceivablesSecuritised3").val("");
//                $("#ReceivablesSecuritised4").val("");
//                $("#ProvisionsOutput1").val("");
//                $("#ProvisionsOutput2").val("");
//                $("#ProvisionsOutput3").val("");
//                $("#ProvisionsOutput4").val("");
//                $("#ProvisionForLoanLosses1").val("");
//                $("#ProvisionForLoanLosses2").val("");
//                $("#ProvisionForLoanLosses3").val("");
//                $("#ProvisionForLoanLosses4").val("");
//                $("#ProvisionForDoubtfulDebtors1").val("");
//                $("#ProvisionForDoubtfulDebtors2").val("");
//                $("#ProvisionForDoubtfulDebtors3").val("");
//                $("#ProvisionForDoubtfulDebtors4").val("");
//                $("#ProvisionForDepreciation1").val("");
//                $("#ProvisionForDepreciation2").val("");
//                $("#ProvisionForDepreciation3").val("");
//                $("#ProvisionForDepreciation4").val("");
//                $("#ProvisionForImpairmentofAssets1").val("");
//                $("#ProvisionForImpairmentofAssets2").val("");
//                $("#ProvisionForImpairmentofAssets3").val("");
//                $("#ProvisionForImpairmentofAssets4").val("");
//                $("#ProvisionForDividend1").val("");
//                $("#ProvisionForDividend2").val("");
//                $("#ProvisionForDividend3").val("");
//                $("#ProvisionForDividend4").val("");
//                $("#ProvisionForTaxes1").val("");
//                $("#ProvisionForTaxes2").val("");
//                $("#ProvisionForTaxes3").val("");
//                $("#ProvisionForTaxes4").val("");
//                $("#ProvisionForDeferredTaxes1").val("");
//                $("#ProvisionForDeferredTaxes2").val("");
//                $("#ProvisionForDeferredTaxes3").val("");
//                $("#ProvisionForDeferredTaxes4").val("");
//                $("#ProvisionForExpenses1").val("");
//                $("#ProvisionForExpenses2").val("");
//                $("#ProvisionForExpenses3").val("");
//                $("#ProvisionForExpenses4").val("");
//                $("#OtherProvisions1").val("");
//                $("#OtherProvisions2").val("");
//                $("#OtherProvisions3").val("");
//                $("#OtherProvisions4").val("");
//                $("#NetCurrentAssetsOutput1").val("");
//                $("#NetCurrentAssetsOutput2").val("");
//                $("#NetCurrentAssetsOutput3").val("");
//                $("#NetCurrentAssetsOutput4").val("");
//                $("#TotalAssetsOutput1").val("");
//                $("#TotalAssetsOutput2").val("");
//                $("#TotalAssetsOutput3").val("");
//                $("#TotalAssetsOutput4").val("");
//                $("#ErrorCheck1").val("");
//                $("#ErrorCheck2").val("");
//                $("#ErrorCheck3").val("");
//                $("#ErrorCheck4").val("");
//                //#endregion


//                //#region Contingent-Liabilities
//                $("#LiabilityOnSecuritisationContracts1").val("");
//                $("#LiabilityOnSecuritisationContracts2").val("");
//                $("#LiabilityOnSecuritisationContracts3").val("");
//                $("#LiabilityOnSecuritisationContracts4").val("");
//                $("#GuaranteesGiven1").val("");
//                $("#GuaranteesGiven2").val("");
//                $("#GuaranteesGiven3").val("");
//                $("#GuaranteesGiven4").val("");
//                $("#LiabilityOnPartlyPaidInvestments1").val("");
//                $("#LiabilityOnPartlyPaidInvestments2").val("");
//                $("#LiabilityOnPartlyPaidInvestments3").val("");
//                $("#LiabilityOnPartlyPaidInvestments4").val("");
//                $("#LiabilityOnForeignExchangContracts1").val("");
//                $("#LiabilityOnForeignExchangContracts2").val("");
//                $("#LiabilityOnForeignExchangContracts3").val("");
//                $("#LiabilityOnForeignExchangContracts4").val("");
//                $("#LiabilityOnDerivativeContracts1").val("");
//                $("#LiabilityOnDerivativeContracts2").val("");
//                $("#LiabilityOnDerivativeContracts3").val("");
//                $("#LiabilityOnDerivativeContracts4").val("");
//                $("#EndorsementsAndAcceptancesAndOtherObligations1").val("");
//                $("#EndorsementsAndAcceptancesAndOtherObligations2").val("");
//                $("#EndorsementsAndAcceptancesAndOtherObligations3").val("");
//                $("#EndorsementsAndAcceptancesAndOtherObligations4").val("");
//                $("#ClaimsNotAcknowledgedAsDebts1").val("");
//                $("#ClaimsNotAcknowledgedAsDebts2").val("");
//                $("#ClaimsNotAcknowledgedAsDebts3").val("");
//                $("#ClaimsNotAcknowledgedAsDebts4").val("");
//                $("#OtherItems1").val("");
//                $("#OtherItems2").val("");
//                $("#OtherItems3").val("");
//                $("#OtherItems4").val("");
//                //#endregion


//                //#region Other BalanceSheets_Disclosures
//                $("#TierICapitalRatioPercentage1").val("");
//                $("#TierICapitalRatioPercentage2").val("");
//                $("#TierICapitalRatioPercentage3").val("");
//                $("#TierICapitalRatioPercentage4").val("");
//                $("#TierIICapitalRatioPercentage1").val("");
//                $("#TierIICapitalRatioPercentage2").val("");
//                $("#TierIICapitalRatioPercentage3").val("");
//                $("#TierIICapitalRatioPercentage4").val("");
//                $("#TotalCapitalRatioPercentage1").val("");
//                $("#TotalCapitalRatioPercentage2").val("");
//                $("#TotalCapitalRatioPercentage3").val("");
//                $("#TotalCapitalRatioPercentage4").val("");
//                $("#ThirdPartyOriginationsAndServicingPercentage1").val("");
//                $("#ThirdPartyOriginationsAndServicingPercentage2").val("");
//                $("#ThirdPartyOriginationsAndServicingPercentage3").val("");
//                $("#ThirdPartyOriginationsAndServicingPercentage4").val("");
//                $("#SecuritisedPortfolioOutstandingPercentage1").val("");
//                $("#SecuritisedPortfolioOutstandingPercentage2").val("");
//                $("#SecuritisedPortfolioOutstandingPercentage3").val("");
//                $("#SecuritisedPortfolioOutstandingPercentage4").val("");
//                $("#TotalManagedAssetsPercentage1").val("");
//                $("#TotalManagedAssetsPercentage2").val("");
//                $("#TotalManagedAssetsPercentage3").val("");
//                $("#TotalManagedAssetsPercentage4").val("");
//                $("#GrossNPAs1").val("");
//                $("#GrossNPAs2").val("");
//                $("#GrossNPAs3").val("");
//                $("#GrossNPAs4").val("");
//                $("#SpecificLossProvisionsHeld1").val("");
//                $("#SpecificLossProvisionsHeld2").val("");
//                $("#SpecificLossProvisionsHeld3").val("");
//                $("#SpecificLossProvisionsHeld4").val("");
//                $("#NetNPAs1").val("");
//                $("#NetNPAs2").val("");
//                $("#NetNPAs3").val("");
//                $("#NetNPAs4").val("");
//                //#endregion


//                //#region Profit and Loss Statement
//                $("#PeriodEndingDate1_ProfitAndLoss").val("");
//                $("#PeriodEndingDate2_ProfitAndLoss").val("");
//                $("#PeriodEndingDate3_ProfitAndLoss").val("");
//                $("#PeriodEndingDate4_ProfitAndLoss").val("");
//                $("#IncomeOutput1").val("");
//                $("#IncomeOutput2").val("");
//                $("#IncomeOutput3").val("");
//                $("#IncomeOutput4").val("");
//                $("#InterestIncomeOutput1").val("");
//                $("#InterestIncomeOutput2").val("");
//                $("#InterestIncomeOutput3").val("");
//                $("#InterestIncomeOutput4").val("");
//                $("#InterestonHousingLoansIndividuals1").val("");
//                $("#InterestonHousingLoansIndividuals2").val("");
//                $("#InterestonHousingLoansIndividuals3").val("");
//                $("#InterestonHousingLoansIndividuals4").val("");
//                $("#InterestonHousingLoansCorporateBodies1").val("");
//                $("#InterestonHousingLoansCorporateBodies2").val("");
//                $("#InterestonHousingLoansCorporateBodies3").val("");
//                $("#InterestonHousingLoansCorporateBodies4").val("");
//                $("#OtherInterestIncome1").val("");
//                $("#OtherInterestIncome2").val("");
//                $("#OtherInterestIncome3").val("");
//                $("#OtherInterestIncome4").val("");
//                $("#IncomeFromInvestmentsShortTerm1").val("");
//                $("#IncomeFromInvestmentsShortTerm2").val("");
//                $("#IncomeFromInvestmentsShortTerm3").val("");
//                $("#IncomeFromInvestmentsShortTerm4").val("");
//                $("#IncomeFromInvestmentsLongTerm1").val("");
//                $("#IncomeFromInvestmentsLongTerm2").val("");
//                $("#IncomeFromInvestmentsLongTerm3").val("");
//                $("#IncomeFromInvestmentsLongTerm4").val("");
//                $("#OtherOperatingIncomeOutput1").val("");
//                $("#OtherOperatingIncomeOutput2").val("");
//                $("#OtherOperatingIncomeOutput3").val("");
//                $("#OtherOperatingIncomeOutput4").val("");
//                $("#FeesReceived1").val("");
//                $("#FeesReceived2").val("");
//                $("#FeesReceived3").val("");
//                $("#FeesReceived4").val("");
//                $("#CommisionsAndExchangeAndBrokerage1").val("");
//                $("#CommisionsAndExchangeAndBrokerage2").val("");
//                $("#CommisionsAndExchangeAndBrokerage3").val("");
//                $("#CommisionsAndExchangeAndBrokerage4").val("");
//                $("#ProfitLossSaleInvestments1").val("");
//                $("#ProfitLossSaleInvestments2").val("");
//                $("#ProfitLossSaleInvestments3").val("");
//                $("#ProfitLossSaleInvestments4").val("");
//                $("#ProfitLossSaleAssets1").val("");
//                $("#ProfitLossSaleAssets2").val("");
//                $("#ProfitLossSaleAssets3").val("");
//                $("#ProfitLossSaleAssets4").val("");
//                $("#ProfitLossExchangeTransactions1").val("");
//                $("#ProfitLossExchangeTransactions2").val("");
//                $("#ProfitLossExchangeTransactions3").val("");
//                $("#ProfitLossExchangeTransactions4").val("");
//                $("#OtherServiceIncome1").val("");
//                $("#OtherServiceIncome2").val("");
//                $("#OtherServiceIncome3").val("");
//                $("#OtherServiceIncome4").val("");
//                $("#GainOnSaleOfSecuritisedAssets1").val("");
//                $("#GainOnSaleOfSecuritisedAssets2").val("");
//                $("#GainOnSaleOfSecuritisedAssets3").val("");
//                $("#GainOnSaleOfSecuritisedAssets4").val("");
//                $("#OtherNonOperatingIncome1").val("");
//                $("#OtherNonOperatingIncome2").val("");
//                $("#OtherNonOperatingIncome3").val("");
//                $("#OtherNonOperatingIncome4").val("");
//                $("#ExpenseOutput1").val("");
//                $("#ExpenseOutput2").val("");
//                $("#ExpenseOutput3").val("");
//                $("#ExpenseOutput4").val("");
//                $("#InterestExpenseOutput1").val("");
//                $("#InterestExpenseOutput2").val("");
//                $("#InterestExpenseOutput3").val("");
//                $("#InterestExpenseOutput4").val("");
//                $("#InterestOnDeposits1").val("");
//                $("#InterestOnDeposits2").val("");
//                $("#InterestOnDeposits3").val("");
//                $("#InterestOnDeposits4").val("");
//                $("#InterestOnBorrowings1").val("");
//                $("#InterestOnBorrowings2").val("");
//                $("#InterestOnBorrowings3").val("");
//                $("#InterestOnBorrowings4").val("");
//                $("#InterestPaidOutput1").val("");
//                $("#InterestPaidOutput2").val("");
//                $("#InterestPaidOutput3").val("");
//                $("#InterestPaidOutput4").val("");
//                $("#OtherFinancialCharges1").val("");
//                $("#OtherFinancialCharges2").val("");
//                $("#OtherFinancialCharges3").val("");
//                $("#OtherFinancialCharges4").val("");
//                $("#PersonnelExpenses1").val("");
//                $("#PersonnelExpenses2").val("");
//                $("#PersonnelExpenses3").val("");
//                $("#PersonnelExpenses4").val("");
//                $("#OperatingExpensesOutput1").val("");
//                $("#OperatingExpensesOutput2").val("");
//                $("#OperatingExpensesOutput3").val("");
//                $("#OperatingExpensesOutput4").val("");
//                $("#OperatingExpenses1").val("");
//                $("#OperatingExpenses2").val("");
//                $("#OperatingExpenses3").val("");
//                $("#OperatingExpenses4").val("");
//                $("#MiscellaneousExpensesWrittenOff1").val("");
//                $("#MiscellaneousExpensesWrittenOff2").val("");
//                $("#MiscellaneousExpensesWrittenOff3").val("");
//                $("#MiscellaneousExpensesWrittenOff4").val("");
//                $("#ProvisionForImpairmentInValueOfAssets1").val("");
//                $("#ProvisionForImpairmentInValueOfAssets2").val("");
//                $("#ProvisionForImpairmentInValueOfAssets3").val("");
//                $("#ProvisionForImpairmentInValueOfAssets4").val("");
//                $("#Depreciation1").val("");
//                $("#Depreciation2").val("");
//                $("#Depreciation3").val("");
//                $("#Depreciation4").val("");
//                $("#LoanLosses1").val("");
//                $("#LoanLosses2").val("");
//                $("#LoanLosses3").val("");
//                $("#LoanLosses4").val("");
//                $("#PLProvisionForLoanLosses1").val("");
//                $("#PLProvisionForLoanLosses2").val("");
//                $("#PLProvisionForLoanLosses3").val("");
//                $("#PLProvisionForLoanLosses4").val("");
//                $("#ProvisionForInterestOnIncomeTaxRefund1").val("");
//                $("#ProvisionForInterestOnIncomeTaxRefund2").val("");
//                $("#ProvisionForInterestOnIncomeTaxRefund3").val("");
//                $("#ProvisionForInterestOnIncomeTaxRefund4").val("");
//                $("#ProvisionForBadDebtsWrittenBack1").val("");
//                $("#ProvisionForBadDebtsWrittenBack2").val("");
//                $("#ProvisionForBadDebtsWrittenBack3").val("");
//                $("#ProvisionForBadDebtsWrittenBack4").val("");
//                $("#OtherCreditAssetsWrittenOff1").val("");
//                $("#OtherCreditAssetsWrittenOff2").val("");
//                $("#OtherCreditAssetsWrittenOff3").val("");
//                $("#OtherCreditAssetsWrittenOff4").val("");
//                $("#OtherAdjustments1").val("");
//                $("#OtherAdjustments2").val("");
//                $("#OtherAdjustments3").val("");
//                $("#OtherAdjustments4").val("");
//                $("#ProfitBeforeTaxOutput1").val("");
//                $("#ProfitBeforeTaxOutput2").val("");
//                $("#ProfitBeforeTaxOutput3").val("");
//                $("#ProfitBeforeTaxOutput4").val("");
//                $("#TaxExpenseOutput1").val("");
//                $("#TaxExpenseOutput2").val("");
//                $("#TaxExpenseOutput3").val("");
//                $("#TaxExpenseOutput4").val("");
//                $("#CurrentTax1").val("");
//                $("#CurrentTax2").val("");
//                $("#CurrentTax3").val("");
//                $("#CurrentTax4").val("");
//                $("#DeferredTax1").val("");
//                $("#DeferredTax2").val("");
//                $("#DeferredTax3").val("");
//                $("#DeferredTax4").val("");
//                $("#ProfitAfterTaxOutput1").val("");
//                $("#ProfitAfterTaxOutput2").val("");
//                $("#ProfitAfterTaxOutput3").val("");
//                $("#ProfitAfterTaxOutput4").val("");
//                $("#PreferenceDividend_Tax1").val("");
//                $("#PreferenceDividend_Tax2").val("");
//                $("#PreferenceDividend_Tax3").val("");
//                $("#PreferenceDividend_Tax4").val("");
//                $("#EquityDividend_Tax1").val("");
//                $("#EquityDividend_Tax2").val("");
//                $("#EquityDividend_Tax3").val("");
//                $("#EquityDividend_Tax4").val("");
//                //#endregion


//                //#region ALM_StatementLatests
//                $("#Statement_Date").val("");
//                $("#Day1to14DaysInflow").val("");
//                $("#Day1to14DaysInflow").val("");
//                $("#Day1to14DaysOurflow").val("");
//                $("#Day1to14DaysMismatch").val("");
//                $("#Day14DaysTo1MonthInflow").val("");
//                $("#Day14DaysTo1MonthOurflow").val("");
//                $("#Day14DaysTo1MonthMismatch").val("");
//                $("#Month1To2MonthsInflow").val("");
//                $("#Month1To2MonthsOurflow").val("");
//                $("#Month1To2MonthsMismatch").val("");
//                $("#Month2To3MonthsInflow").val("");
//                $("#Month2To3MonthsOurflow").val("");
//                $("#Month2To3MonthsMismatch").val("");
//                $("#Month3To6MonthsInflow").val("");
//                $("#Month3To6MonthsOurflow").val("");
//                $("#Month3To6MonthsMismatch").val("");
//                $("#Month6MonthsTo1YearInflow").val("");
//                $("#Month6MonthsTo1YearOurflow").val("");
//                $("#Month6MonthsTo1YearMismatch").val("");
//                $("#Year1To3YearsInflow").val("");
//                $("#Year1To3YearsOurflow").val("");
//                $("#Year1To3YearsMismatch").val("");
//                $("#Year3To5YearsInflow").val("");
//                $("#Year3To5YearsOurflow").val("");
//                $("#Year3To5YearsMismatch").val("");
//                $("#Year5To7YearsInflow").val("");
//                $("#Year5To7YearsOurflow").val("");
//                $("#Year5To7YearsMismatch").val("");
//                $("#Year7To10YearsInflow").val("");
//                $("#Year7To10YearsOurflow").val("");
//                $("#Year7To10YearsMismatch").val("");
//                $("#Over10YearsInflow").val("");
//                $("#Over10YearsOurflow").val("");
//                $("#Over10YearsMismatch").val("");
//                //#endregion 


//                //#region KeyRatio
//                $("#TotalAssets1").val("");
//                $("#TotalAssets2").val("");
//                $("#TotalAssets3").val("");
//                $("#TotalAssets4").val("");
//                $("#GrossNPAPercentage1").val("");
//                $("#GrossNPAPercentage2").val("");
//                $("#GrossNPAPercentage3").val("");
//                $("#GrossNPAPercentage4").val("");
//                $("#ALMMismatchPercentage1").val("");
//                $("#ALMMismatchPercentage2").val("");
//                $("#ALMMismatchPercentage3").val("");
//                $("#ALMMismatchPercentage4").val("");
//                $("#NetWorth1").val("");
//                $("#NetWorth2").val("");
//                $("#NetWorth3").val("");
//                $("#NetWorth4").val("");
//                $("#CRARPercentage1").val("");
//                $("#CRARPercentage2").val("");
//                $("#CRARPercentage3").val("");
//                $("#CRARPercentage4").val("");
//                $("#GearingPercentage1").val("");
//                $("#GearingPercentage2").val("");
//                $("#GearingPercentage3").val("");
//                $("#GearingPercentage4").val("");
//                $("#TangibleNWNetNPA1").val("");
//                $("#TangibleNWNetNPA2").val("");
//                $("#TangibleNWNetNPA3").val("");
//                $("#TangibleNWNetNPA4").val("");
//                $("#NetMarginPercentage1").val("");
//                $("#NetMarginPercentage2").val("");
//                $("#NetMarginPercentage3").val("");
//                $("#NetMarginPercentage4").val("");
//                $("#PATAverageFundsDeployedPercentage1").val("");
//                $("#PATAverageFundsDeployedPercentage2").val("");
//                $("#PATAverageFundsDeployedPercentage3").val("");
//                $("#PATAverageFundsDeployedPercentage4").val("");
//                $("#PATAverageNetWorthPercentage1").val("");
//                $("#PATAverageNetWorthPercentage2").val("");
//                $("#PATAverageNetWorthPercentage3").val("");
//                $("#PATAverageNetWorthPercentage4").val("");
//                //#endregion 
//            }
//        }
//    });
//});

$('#ParentCompanyIsExist').change(function () {
    if ($("#ParentCompanyIsExist").val() == "Yes") {
        //$("#ParentCompanyId").prop('disabled', false);
        $("#tab13Label").show();
        $(".ParentCompany").show();
        $("#btnNext1").show();
        $(".ParentRating").show();
        $("#btnSave1").hide();
        $("#btnApprove1").hide();
        $("#btnApprove2").show();
    }
    else {

        $("#tab13Label").hide();
        $(".ParentCompany").hide();
        $(".ParentRating").hide();
        $("#btnSave1").show();
        $("#btnNext1").hide();
        $("#btnApprove2").show();
        $("#btnApprove1").show();
    }

});

function DownloadCompanyOutputDetails() {
    var model = {
        reportCreatedDateTime: $(".reportCreatedDateTime").val(),
        reportCompany: $(".reportCompany").val()
    }
    var URI = encodeURI("../Company/DownloadCompanyOutputDetails");
    $.ajax({
        type: "POST",
        url: URI,
        data: { 'CompanyId': model.reportCompany, 'CreatedDateTime': model.reportCreatedDateTime },
        success: function (result) {
            if(result.status == true)
            {
                var URI = encodeURI("../Company/DownloadOutputExcelFile?fileName=" + result.fileName);
                if (result.fileName != "") {
                    window.location.href = URI;
                    $('#myModal').modal('hide');
                    $(".reportCreatedDateTime").val('');
                    $(".reportCompany").val('');
                }
            }    
    }
    });
}