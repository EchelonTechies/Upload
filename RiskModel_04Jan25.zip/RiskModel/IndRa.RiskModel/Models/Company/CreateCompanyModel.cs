﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace IndRa.RiskModel.Models.Company
{
    public class CreateCompanyModel
    {
        public CreateCompanyModel()
        {
            //TODO;
        }

        public int CompanyId { get; set; }

        [Display(Name ="Company")]
        [Required(ErrorMessage = "Please, Enter Company Name.")]
        public string CompanyName { get; set; }


        [Display(Name = "Segment")]
        [Required(ErrorMessage = "Please, Select Segment Name.")]
        public short? ModelId { get; set; }

        [Display(Name = "Assigned Analyst")]
        public int? AssignedAnalystId { get; set; }

        public string PanCard { get; set; }

        public int UserId { get; set; }

    }
}