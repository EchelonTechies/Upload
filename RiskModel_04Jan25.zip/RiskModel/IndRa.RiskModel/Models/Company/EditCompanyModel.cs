﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace IndRa.RiskModel.Models.Company
{
    public class EditCompanyModel
    {
        public EditCompanyModel()
        {
            //TODO;
        }

        public int CompanyId { get; set; }

        [Required(ErrorMessage = "Please, Enter Company Name.")]
        public string CompanyName { get; set; }

        public short? ModelId { get; set; }

        public int? AssignedAnalystId { get; set; }

        public string PanCard { get; set; }

    }
}