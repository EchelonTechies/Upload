﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndRa.RiskModel.Models.User
{
    public class UserModel
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserCode { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public string ActivationCode { get; set; }
        public string Salt { get; set; }
    }
}