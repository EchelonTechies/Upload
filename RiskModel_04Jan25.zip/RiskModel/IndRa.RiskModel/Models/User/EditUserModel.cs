﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace IndRa.RiskModel.Models.User
{
    public class EditUserModel
    {
        public EditUserModel()
        {
            //  TODO;
        }

        public int UserID { get; set; }

        [Required(ErrorMessage = "Please, Enter First Name.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please, Enter Last Name.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please, Enter User Code.")]
        [Remote("IsUserNameUnique", "account", ErrorMessage = "This User code is already used.")]
        public string UserCode { get; set; }

        public int RoleId { get; set; }

        [Required(ErrorMessage = "Please, Enter Email Address.")]
        [EmailAddress(ErrorMessage = "Please enter a valid Email Address")]
        [Remote("IsEmailIdUnique", "account", ErrorMessage = "This Email Address is already used.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please, Enter User Role.")]
        public string UserRole { get; set; }

        [MembershipPassword(ErrorMessage = "Please, Enter Password")]
        public string Password { get; set; }

        public string UserName { get; set; }

        public bool IsActive { get; set; }
    }
}