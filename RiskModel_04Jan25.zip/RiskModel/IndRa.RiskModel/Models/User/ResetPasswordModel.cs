﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace IndRa.RiskModel.Models.User
{
    public class ResetPasswordModel
    {
        public ResetPasswordModel()
        {

        }

        public string UserID { get; set; }


        public string EmailAddress { get; set; }

        [Display(Name = "New Password")]
        [Required(ErrorMessage = "Please enter new password. ")]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        public string NewPassword { get; set; }

        [Display(Name = "Confirm password")]
        [Required(ErrorMessage = "Please enter confirm password.")]
        [Compare("NewPassword", ErrorMessage = "The password and confirmation password do not match.")]
        public string Confirmpassword { get; set; }
    }
}