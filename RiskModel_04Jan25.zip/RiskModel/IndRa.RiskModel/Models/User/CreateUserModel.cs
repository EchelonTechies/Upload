﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace IndRa.RiskModel.Models.User
{
    public class CreateUserModel
    {
        public CreateUserModel()
        {
            //TODO;
        }
        public int UserID { get; set; }

        [Display(Name ="First Name")]
        [Required(ErrorMessage = "Please, Enter First Name.")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Please, Enter Last Name.")]
        public string LastName { get; set; }

        [Display(Name = "User Name")]
        [Required(ErrorMessage = "Please, Enter User Name.")]
        public string UserName { get; set; }

        [Display(Name = "User Code")]
        [Required(ErrorMessage = "Please, Enter User Code.")]
        public string UserCode { get; set; }

        [Display(Name = "User Email")]
        [Required(ErrorMessage = "Please, Enter Email Address.")]
        [EmailAddress(ErrorMessage = "Please enter a valid Email Address")]
        [Remote("IsEmailIdUnique", "account", ErrorMessage = "This Email Address is already used.")]
        public string Email { get; set; }

        [Display(Name = "User Role")]
        [Required(ErrorMessage = "Please, Enter User Role.")]
        public string UserRole { get; set; }

        public string Password { get; set; }

        [Display(Name = "Is User Active")]
        public bool IsActive { get; set; }



    }
}