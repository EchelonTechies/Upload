﻿using System;

namespace IndRa.RiskModel.DAL.Helpers
{
    public class ExtensionMethod
    {
        public static decimal? GetValues(string Value)
        {
            decimal? value = 0;
            if (Value == null)
            {
                value = 0;
            }
            else
            {
                value = Convert.ToDecimal(Value);
            }
            return value;
        }

        public static string GetImportValues(double? Value)
        {
            string value = "";
            if (Value == 0 || Value == null)
            {
                value = "0";
            }
            else
            {
                //value = Convert.ToString(Math.Round(Value.Value));
                value = Convert.ToString(Math.Round(Value.Value,2));
             
            }
            return value;
        }

        public static string GetImportOtherBalanceSheetValues(double Value)
        {
            string value = "";
            if (Value == 0)
            {
                value = "0";
            }
            else
            {
                value = Convert.ToString(Math.Round(Convert.ToDouble(Value) * 100, 2));
            }
            return value;
        }

        public static string GetImportValuesforpercentage(double Value)
        {

            string value = "";
            if (Value == 0)
            {
                value = "0";
            }
            else
            {
                value = Convert.ToString(Value * 100);

            }
            return value;
        }

        public static string GetFormattedData(string Value)
        {
            string value = "";
            if(Value == null)
            {
                value = "0";
            }
            else
            {
                value = Convert.ToString(Convert.ToDouble(Value) / 100);
            }
            return value;
        }
    }
}
