﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndRa.RiskModel.Helpers
{
    public enum RolesEnum
    {
        SuperAdmin = 1,
        Admin = 2,
        Analyst = 3
    }

    public enum EmailTemplateEnum
    {
        MasterTemplate = 1,
        PasswordResetTemplate = 2,
        AssignedEntityTemplate = 3,
        ApprovedEntityTemplate = 4
    }

    public enum ButtonValue
    {
        Download = 1,
        ComputeOutput = 2,
        SaveAsDraft = 3,
        SubmitForApporval = 4,
        ApproveDetails = 5,
        ReviewDetails = 6
    }

    public enum ModelsEnum
    {
        HFC = 1,
        SCB = 2,
        SFB = 3,
        ACHFS = 4,
        ARDB = 5,
        RRB = 6,
        StCoop = 7,
        UCB = 8,
        PFRM = 9,
        HFCNew = 10,
    }

    public enum SubjectiveParametersEnum
    {
        PropensitySupportInstitution = 1,
        BusinessModel = 2,
        ManagementQuality = 3,
        CorporateGovernance = 4,
        UnderwritingStandards = 5,
        RiskManagementSystemMonotoring = 6,
        AdverseNews = 7,
        ConductAccount = 8,
        ProspectKeyMarkets = 9,
        GeographicalDiversification = 10,
        DiversityResources = 11,
        AccessFunds = 12,
        ContingencyFundingPlanNextOneyear = 13,
        AccessEKuberRTGS = 14,
        IndependenceBoardDirectors = 15,
        RecentClimaticCondition = 16,
        NABARDReFinanceRisk = 17,
        CorporateSocialResponsibility = 18,
        SMA1SMA2UnderLoanPortfolio = 19,
        DefaultwithOtherLenders = 20
    }
}
