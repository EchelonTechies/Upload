﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Text;
using IndRa.RiskModel.DAL.Entities;
using DocumentFormat.OpenXml.Spreadsheet;
using System.ComponentModel;
using IndRa.RiskModel.DAL.DataAccess;
using System.Data.Entity.Validation;
using IndRa.RiskModel.DAL.DAL;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Reflection;

namespace IndRa.RiskModel.DAL
{
    public class CommonDAL
    {
        HelperDAL _helperDAL = null;
        IndRaDBcontext dbContext = null;

        public CommonDAL()
        {
            _helperDAL = new HelperDAL();
            dbContext = new IndRaDBcontext();
        }

        public string GetRatingPD(string ratingID)
        {
            string pdValue = dbContext.ModelGradeRatingMappings.Where(a => a.Grade == ratingID).Select(a => a.PD).FirstOrDefault();
            return pdValue;
        }

        public string GetFinancialYearEndDate(DateTime dateOfInput)
        {
            try
            {
                DataTable dataTable = null;
                ReportsDAL rDaL = new ReportsDAL();

                SqlParameter param1 = new SqlParameter("@DateOfInput", SqlDbType.DateTime);
                param1.Value = dateOfInput;

                using (dataTable = rDaL.GetDataSetResult("RM_GetFinYearEndDate", param1).Tables[0])
                {
                    if (dataTable.Rows.Count > 0)
                    {
                        return dataTable.Rows[0][0].ToString();
                    }
                }
                return "";
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public DataTable GetPreviousKeyFinancialsData(string companyId, DateTime periodEndDate)
        {
            try
            {
                DataTable dataTable = null;
                ReportsDAL rDaL = new ReportsDAL();

                SqlParameter param1 = new SqlParameter("@CompanyId", SqlDbType.VarChar);
                param1.Value = companyId;

                SqlParameter param2 = new SqlParameter("@PeriodEndDate", SqlDbType.DateTime);
                param2.Value = periodEndDate;

                using (dataTable = rDaL.GetDataSetResult("RM_GetPreviousKeyFinancialsData", param1, param2).Tables[0])
                {
                    return dataTable;
                }
                return dataTable;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<DashboardAnalystEntity> GetNHBDetailList(int roleID, int userID)
        {
            List<DashboardAnalystEntity> objList = null;

            try
            {
                DataTable dataTable = null;
                ReportsDAL rDaL = new ReportsDAL();

                SqlParameter param1 = new SqlParameter("@UserId", SqlDbType.VarChar);
                param1.Value = userID;

                using (dataTable = rDaL.GetDataSetResult("RM_Analyst_Dashboard", param1).Tables[0])
                {
                    objList = ConvertDataTable<DashboardAnalystEntity>(dataTable);
                    return objList;
                }
            }
            catch (Exception ex)
            {
                return null;
            }

            //var result = (from T0 in dbContext.NHB_Details
            //              join T1 in dbContext.Companies
            //              on T0.CompanyId equals T1.CompanyId
            //              join T2 in dbContext.Models
            //              on T1.ModelId equals T2.ModelId
            //              join T3 in dbContext.Users
            //              on T0.CreatedBy equals T3.UserId
            //              where T0.CreatedBy == userID
            //              && (T0.isMigrate == null || T0.isMigrate == false)
            //              orderby T0.DetailsId descending
            //              select new DashboardEntity
            //              {
            //                  DetailsId = T0.DetailsId,
            //                  CompanyId = T0.CompanyId,
            //                  ModelId = T1.ModelId,
            //                  CompanyName = T1.CompanyName,
            //                  ModelName = T2.ModelName,
            //                  AnalystName = T3.FirstName + " " + T3.LastName,
            //                  //DateOfInput = T0.DateOfInput.ToString(),
            //                  FinalRating = T0.FinalRating == null ? "" : T0.FinalRating,
            //                  createdDate = T0.CreatedDateTime.ToString(),
            //                  FinancialYear = T0.FinYear,
            //                  Status = T0.IsFinal.HasValue ? (T0.IsFinal.Value == true ? "Approved" : "Pending") : "Pending",
            //              });

            //objList = result.ToList();
            //return objList;

        }


        public DataTable GetOutputDetailsReport(string modelId, string detailsId,int logID)
        {
            try
            {
                DataTable dataTable = null;
                ReportsDAL rDaL = new ReportsDAL();

                SqlParameter param1 = new SqlParameter("@ModelId", SqlDbType.VarChar);
                param1.Value = modelId;

                SqlParameter param2 = new SqlParameter("@DetailsId", SqlDbType.VarChar);
                param2.Value = detailsId;

                SqlParameter param3 = new SqlParameter("@LogId", SqlDbType.Int);
                param3.Value = logID;

                using (dataTable = rDaL.GetDataSetResult("RM_GetOutPutDetailsById", param1, param2,param3).Tables[0])
                {
                    return dataTable;
                }
            }
            catch
            {
                return null;
            }
        }

        public DataTable GetOutputDetailsForExcelReport(string modelId, string detailsId, int logID)
        {
            try
            {
                DataTable dataTable = null;
                ReportsDAL rDaL = new ReportsDAL();

                SqlParameter param1 = new SqlParameter("@ModelId", SqlDbType.VarChar);
                param1.Value = modelId;

                SqlParameter param2 = new SqlParameter("@DetailsId", SqlDbType.VarChar);
                param2.Value = detailsId;

                SqlParameter param3 = new SqlParameter("@LogId", SqlDbType.Int);
                param3.Value = logID;

                using (dataTable = rDaL.GetDataSetResult("RM_GetOutputDetailsExcelById", param1, param2, param3).Tables[0])
                {
                    return dataTable;
                }
            }
            catch
            {
                return null;
            }
        }


        public List<AnalystEntity> GetEntityAnalystList(string searchText)
        {
            try
            {
                DataTable dataTable = null;
                ReportsDAL rDaL = new ReportsDAL();
                List<AnalystEntity> objList = null;

                SqlParameter param1 = new SqlParameter("@SearchText", SqlDbType.VarChar);
                param1.Value = searchText;

                using (dataTable = rDaL.GetDataSetResult("RM_EntityAnalyst", param1).Tables[0])
                //using (dataTable = rDaL.GetDataSetResult("RM_EntityAnalyst").Tables[0])
                {
                    objList = ConvertDataTable<AnalystEntity>(dataTable);
                    return objList;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<DashboardAnalystEntity> GetPendingApprovalList(int roleID, int userID)
        {
            List<DashboardAnalystEntity> objList = null;

            try
            {
                DataTable dataTable = null;
                ReportsDAL rDaL = new ReportsDAL();

                SqlParameter param1 = new SqlParameter("@UserId", SqlDbType.VarChar);
                param1.Value = userID;

                using (dataTable = rDaL.GetDataSetResult("RM_Analyst_Dashboard", param1).Tables[0])
                {
                    objList = ConvertDataTable<DashboardAnalystEntity>(dataTable);
                    return objList;
                }
            }
            catch (Exception ex)
            {
                return null;
            }

            //List<DashboardEntity> objList = null;
            //var result = (from T0 in dbContext.NHB_Details
            //              join T1 in dbContext.Companies
            //              on T0.CompanyId equals T1.CompanyId
            //              join T2 in dbContext.Models
            //              on T1.ModelId equals T2.ModelId
            //              join T3 in dbContext.Users
            //              on T0.CreatedBy equals T3.UserId
            //              where T0.isMigrate == null || T0.isMigrate == false
            //              orderby T0.DetailsId descending
            //              select new DashboardEntity
            //              {
            //                  DetailsId = T0.DetailsId,
            //                  CompanyId = T0.CompanyId,
            //                  ModelId = T1.ModelId,
            //                  CompanyName = T1.CompanyName,
            //                  ModelName = T2.ModelName,
            //                  AnalystName = T3.FirstName + " " + T3.LastName,
            //                  //DateOfInput = T0.DateOfInput.ToString(),
            //                  FinalRating = T0.FinalRating == null ? "" : T0.FinalRating,
            //                  createdDate = T0.CreatedDateTime.ToString(),
            //                  FinancialYear = T0.FinYear,
            //                  Status = T0.IsFinal.HasValue ? (T0.IsFinal.Value == true ? "Approved" : "Pending") : "Pending",
            //              });

            //objList = result.ToList();
            //return objList;
        }

        public List<DashboardAnalystEntity> GetApprovalListByDetailsId(int userID, int detailsID)
        {
            List<DashboardAnalystEntity> objList = null;

            try
            {
                DataTable dataTable = null;
                ReportsDAL rDaL = new ReportsDAL();

                SqlParameter param1 = new SqlParameter("@UserId", SqlDbType.VarChar);
                param1.Value = userID;

                SqlParameter param2 = new SqlParameter("@DetailsId", SqlDbType.VarChar);
                param2.Value = detailsID;

                using (dataTable = rDaL.GetDataSetResult("RM_Analyst_Dashboard_Detail", param1, param2).Tables[0])
                {
                    objList = ConvertDataTable<DashboardAnalystEntity>(dataTable);
                    return objList;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public List<CompanyEntity> GetRecentCompanyList(string fromDate, string toDate)
        {
            try
            {
                DataTable dataTable = null;
                ReportsDAL rDaL = new ReportsDAL();
                List<CompanyEntity> objList = null;

                SqlParameter param1 = new SqlParameter("@FROMDATE", SqlDbType.VarChar);
                param1.Value = fromDate;

                SqlParameter param2 = new SqlParameter("@TODATE", SqlDbType.VarChar);
                param2.Value = toDate;

                using (dataTable = rDaL.GetDataSetResult("RM_GetRecentCompanyList", param1, param2).Tables[0])
                {
                    objList = ConvertDataTable<CompanyEntity>(dataTable);
                    return objList;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string GetFinYearBasedOnDate(DateTime dateOfInput)
        {
            try
            {
                DataTable dataTable = null;
                ReportsDAL rDaL = new ReportsDAL();

                SqlParameter param1 = new SqlParameter("@DateOfInput", SqlDbType.DateTime);
                param1.Value = dateOfInput;

                using (dataTable = rDaL.GetDataSetResult("RM_GetFinYearBasedOnDate", param1).Tables[0])
                {
                    if (dataTable.Rows.Count > 0)
                    {
                        return dataTable.Rows[0][0].ToString();
                    }
                }
                return "";
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public static List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }

        private static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    try
                    {
                        if (pro.Name == column.ColumnName)
                            pro.SetValue(obj, dr[column.ColumnName], null);
                        else
                            continue;
                    }
                    catch { }
                }
            }
            return obj;
        }

        // Key finanical - parameter's Definition
        public List<ParameterDefinitionEntity> GetParameterDefinition(int ModelId)
        {
            List<ParameterDefinitionEntity> data = new List<ParameterDefinitionEntity>();
            data = dbContext.KeyFinancials_Definition.Where(a => a.ModelId == ModelId).Select(a => new ParameterDefinitionEntity { Parameters = a.Parameters, Definitions = a.Definitions }).ToList();
            return data;
        }

        // Final Rating - parameter's Definition
        public DataTable GetFinalRatingDefinition(int modelId, int detailsId)
        {
            try
            {
                DataTable dataTable = null;

                SqlParameter param1 = new SqlParameter("@ModelId", SqlDbType.VarChar);
                param1.Value = modelId;

                SqlParameter param2 = new SqlParameter("@DetailsId", SqlDbType.VarChar);
                param2.Value = detailsId;

                ReportsDAL rDAL = new ReportsDAL();
                using (dataTable = rDAL.GetDataSetResult("RM_GetFinalRatingTitle", param1, param2).Tables[0])
                {
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<ParameterDefinitionEntity> GetSubjectiveParameterDefinition(int modelId, int headerId)
        {
            List<ParameterDefinitionEntity> data = new List<ParameterDefinitionEntity>();

            try
            {
                DataTable dataTable = null;

                SqlParameter param1 = new SqlParameter("@ModelId", SqlDbType.Int);
                param1.Value = modelId;

                SqlParameter param2 = new SqlParameter("@HeaderId", SqlDbType.Int);
                param2.Value = headerId;

                ReportsDAL rDAL = new ReportsDAL();
                using (dataTable = rDAL.GetDataSetResult("RM_Get_SubjectiveParameters_Definations", param1, param2).Tables[0])
                {
                    data = ConvertDataTable<ParameterDefinitionEntity>(dataTable);
                }
            }
            catch (Exception ex)
            {
                return null;
            }

            return data;

        }

        public DataSet GetDataSetResult(string commandText, params SqlParameter[] parameters)
        {
            DataSet retVal = new DataSet();
            string strConn = dbContext.Database.Connection.ConnectionString;
            SqlConnection con = new SqlConnection(strConn);
            SqlCommand cmdReport = new SqlCommand(commandText, con);
            SqlDataAdapter daReport = new SqlDataAdapter(cmdReport);
            using (cmdReport)
            {
                cmdReport.CommandType = CommandType.StoredProcedure;
                cmdReport.Parameters.AddRange(parameters);
                daReport.Fill(retVal);
            }
            return retVal;
        }

        public DataTable GetDataTable(string commandText,CommandType commandType ,params SqlParameter[] parameters)
        {
            DataTable retVal = new DataTable();
            string strConn = dbContext.Database.Connection.ConnectionString;
            SqlConnection con = new SqlConnection(strConn);
            SqlCommand cmdReport = new SqlCommand(commandText, con);
            SqlDataAdapter daReport = new SqlDataAdapter(cmdReport);
            using (cmdReport)
            {
                cmdReport.CommandType = commandType;
                cmdReport.Parameters.AddRange(parameters);
                daReport.Fill(retVal);
            }
            return retVal;
        }

    }

}