﻿
using IndRa.RiskModel.DAL.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.DAL
{
    public class EmailTemplateDAL
    {
        private IndRaDBcontext DbContext { get; set; }

        public EmailTemplateDAL(IndRaDBcontext dbContext)
        {
            DbContext = dbContext;
        }

        public EmailTemplate GetByID(int ID)
        {
            return (from ET in DbContext.EmailTemplates
                    where ET.EmailTemplateID == (int)ID
                    select ET).SingleOrDefault();
        }
    }
}
