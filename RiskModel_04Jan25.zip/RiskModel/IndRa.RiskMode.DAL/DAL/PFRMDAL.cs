﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Text;
using IndRa.RiskModel.DAL.Entities;
using System.Reflection;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using IndRa.RiskModel.DAL.DataAccess;
using System.Data.Entity.Validation;
using IndRa.RiskModel.DAL.DAL;
using System.Data.Entity;
using IndRa.RiskModel.DAL.Helpers;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using IndRa.RiskModel.Helpers;
//using Microsoft.Office.Interop.Excel;

namespace IndRa.RiskModel.DAL
{
    public class PFRMDAL
    {
        HelperDAL _helperDAL = null;
        IndRaDBcontext dbContext = new IndRaDBcontext();

        public PFRMDAL()
        {
            _helperDAL = new HelperDAL();
        }

        public PFRM_BasicDetailsEntity GetBasicDetails(int detailsId)
        {
            PFRM_BasicDetailsEntity basicDetails = new PFRM_BasicDetailsEntity();
            PFRM_SponsorRiskAssessmentEntity sponsorRiskAssessmentEntity = new PFRM_SponsorRiskAssessmentEntity();
            PFRM_ConstructionRiskAssessmentEntity constructionRiskAssessmentEntity = new PFRM_ConstructionRiskAssessmentEntity();
            PFRM_MarketRiskAssessmentEntity marketRiskAssessmentEntity = new PFRM_MarketRiskAssessmentEntity();
            PFRM_ProjectCostViablityEntity projectCostViablityEntity = new PFRM_ProjectCostViablityEntity();
            PFRM_ConductProjectAccountEntity conductProjectAccountEntity = new PFRM_ConductProjectAccountEntity();
            PFRM_PrivateSectorAgencyFinancialInputEntity privateSectorAgencyFinancialInputEntity = new PFRM_PrivateSectorAgencyFinancialInputEntity();
            PFRM_PublicSectorAgencyFinancialInputEntity publicSectorAgencyFinancialInputEntity = new PFRM_PublicSectorAgencyFinancialInputEntity();
            PFRM_MicroFinanceInstitutionEntity microFinanceInstitutionEntity = new PFRM_MicroFinanceInstitutionEntity();
            PFRM_ProjectStatusEntity projectStatusEntity = new PFRM_ProjectStatusEntity();

            List<PFRM_OutputDetailsEntity> outputDetails = new List<PFRM_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details.Where(data => data.DetailsId == detailsId).Select(x => new PFRM_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = 0,

                FinYear = x.FinYear,
                DateOfInput = x.DateOfInput,
                //CreatedDateTime = x.CreatedDateTime.Value,

                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                PromoterName = x.PromoterName,
                ProjectTypeId = x.ProjectTypeId,
                IsFinal = x.IsFinal.Value,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

            }).FirstOrDefault();

            sponsorRiskAssessmentEntity = dbContext.PFRM_SponsorRiskAssessment.Where(data => data.DetailsId == detailsId).Select(sponsorRiskAssessment => new PFRM_SponsorRiskAssessmentEntity
            {
                EquityparticipationPromoters = sponsorRiskAssessment.EquityparticipationPromoters,
                ProjectEquityTotalNetWorthPromoters = sponsorRiskAssessment.ProjectEquityTotalNetWorthPromoters,
                //AbilityFundCostOverruns = sponsorRiskAssessment.AbilityFundCostOverruns,
                //AbilityHandleProjectsHand = sponsorRiskAssessment.AbilityHandleProjectsHand,
                //CompetenceSeniorManagementSector = sponsorRiskAssessment.CompetenceSeniorManagementSector,
                CompetenceSeniorManagementProjectExecution = sponsorRiskAssessment.CompetenceSeniorManagementProjectExecution,
                //ManagementIntegrity = sponsorRiskAssessment.ManagementIntegrity,
                CreditTrackRecord = sponsorRiskAssessment.CreditTrackRecord,
                //GeneralReputation = sponsorRiskAssessment.GeneralReputation,
                //IntraPromoterConflicts = sponsorRiskAssessment.IntraPromoterConflicts,
                //PastTrackRecordProjects = sponsorRiskAssessment.PastTrackRecordProjects,
                //BankingHistory = sponsorRiskAssessment.BankingHistory,
                //TransferOwnershipTrackRecord = sponsorRiskAssessment.TransferOwnershipTrackRecord,
                //DisputeLitigationTrackRecordDeveloper = sponsorRiskAssessment.DisputeLitigationTrackRecordDeveloper,
                //MarketingSalesPerformance = sponsorRiskAssessment.MarketingSalesPerformance,
                //ClientileCustomerSatisfaction = sponsorRiskAssessment.ClientileCustomerSatisfaction,
            }).FirstOrDefault();

            constructionRiskAssessmentEntity = dbContext.PFRM_ConstructionRiskAssessment.Where(data => data.DetailsId == detailsId).Select(constructionRiskAssessment => new PFRM_ConstructionRiskAssessmentEntity
            {
                LandAvailabillity = constructionRiskAssessment.LandAvailabillity,
                LabourAvailabillity = constructionRiskAssessment.LabourAvailabillity,
                InfrastructureConnection = constructionRiskAssessment.InfrastructureConnection,
                AvailabilityUtility = constructionRiskAssessment.AvailabilityUtility,
                //LegalRisk = constructionRiskAssessment.LegalRisk,
                PermitsLicenses = constructionRiskAssessment.PermitsLicenses,
            }).FirstOrDefault();

            marketRiskAssessmentEntity = dbContext.PFRM_MarketRiskAssessment.Where(data => data.DetailsId == detailsId).Select(marketRiskAssessment => new PFRM_MarketRiskAssessmentEntity
            {
                StateEconomy = marketRiskAssessment.StateEconomy,
                RegulatoryIssuesFiscalPolicyDependence = marketRiskAssessment.RegulatoryIssuesFiscalPolicyDependence,
                EnvironmentalImpact = marketRiskAssessment.EnvironmentalImpact,
                //DemandSupplySituation = marketRiskAssessment.DemandSupplySituation,
                OfftakePriceCompetitiveness = marketRiskAssessment.OfftakePriceCompetitiveness,
                ExtentIntegratedProductOffering = marketRiskAssessment.ExtentIntegratedProductOffering,

            }).FirstOrDefault();

            projectCostViablityEntity = dbContext.PFRM_ProjectCostViablity.Where(data => data.DetailsId == detailsId).Select(projectCostViablity => new PFRM_ProjectCostViablityEntity
            {
                ProjectedDebtServiceCoverageRatio = projectCostViablity.ProjectedDebtServiceCoverageRatio,
                InternalRateReturn = projectCostViablity.InternalRateReturn,
                FirmnessProjectCost = projectCostViablity.FirmnessProjectCost,
                //CertaintyConstructionCost = projectCostViablity.CertaintyConstructionCost,
                SensitivityAnalysis = projectCostViablity.SensitivityAnalysis,
                ContingentLiability = projectCostViablity.ContingentLiability,
                //FundTransferMechansim = projectCostViablity.FundTransferMechansim,
                SecurityandGovernmentSupport = projectCostViablity.SecurityandGovernmentSupport,
                ForceMajeureRisk = projectCostViablity.ForceMajeureRisk,
                InterestRateHedging = projectCostViablity.InterestRateHedging,
                DebtEquityRatio = projectCostViablity.DebtEquityRatio,
            }).FirstOrDefault();

            conductProjectAccountEntity = dbContext.PFRM_ConductProjectAccount.Where(data => data.DetailsId == detailsId).Select(conductProjectAccount => new PFRM_ConductProjectAccountEntity
            {
                ActualScheduleVersusProjectPlan = conductProjectAccount.ActualScheduleVersusProjectPlan,
                PercentageProjectCompletion = conductProjectAccount.PercentageProjectCompletion,
                Moratorium = conductProjectAccount.Moratorium,
            }).FirstOrDefault();

            projectStatusEntity = dbContext.PFRM_ProjectStatus.Where(data => data.DetailsId == detailsId).Select(projectStatus => new PFRM_ProjectStatusEntity
            {
                ProjectDesignStructure = projectStatus.ProjectDesignStructure,
                DetailedProjectFeasibilityReport = projectStatus.DetailedProjectFeasibilityReport,
                //StatusProjectClearances = projectStatus.StatusProjectClearances,
                //StatusFinancialclosure = projectStatus.StatusFinancialclosure,
            }).FirstOrDefault();

            privateSectorAgencyFinancialInputEntity = dbContext.PFRM_PrivateSectorAgencyFinancialInput.Where(data => data.DetailsId == detailsId).Select(privateSectorAgencyFinancialInput => new PFRM_PrivateSectorAgencyFinancialInputEntity
            {
                NetWorthLastAccountingYear = privateSectorAgencyFinancialInput.NetWorthLastAccountingYear,
                ReturnCapitalEmployedLastAccountingyearPer = privateSectorAgencyFinancialInput.ReturnCapitalEmployedLastAccountingyear,
                DebtEBITDALastAccountingYear = privateSectorAgencyFinancialInput.DebtEBITDALastAccountingYear,
                InterestCoverageLastAccountingYear = privateSectorAgencyFinancialInput.InterestCoverageLastAccountingYear,
                CashInterestCoveragelastAccountingYear = privateSectorAgencyFinancialInput.CashInterestCoveragelastAccountingYear,
            }).FirstOrDefault();

            publicSectorAgencyFinancialInputEntity = dbContext.PFRM_PublicSectorAgencyFinancialInput.Where(data => data.DetailsId == detailsId).Select(publicSectorAgencyFinancialInput => new PFRM_PublicSectorAgencyFinancialInputEntity
            {
                TaxRevenueCollectionEfficiencyPer = publicSectorAgencyFinancialInput.TaxRevenueCollectionEfficiency,
                AverageLCRLastThreeyears = publicSectorAgencyFinancialInput.AverageLCRLastThreeyears,
                LCRLastAccountingYear = publicSectorAgencyFinancialInput.LCRLastAccountingYear,
                SurplusGenerationLastAccountingYearPer = publicSectorAgencyFinancialInput.SurplusGenerationLastAccountingYear,
                AverageSurplusGenerationLastThreeYearsPer = publicSectorAgencyFinancialInput.AverageSurplusGenerationLastThreeYears,

            }).FirstOrDefault();

            microFinanceInstitutionEntity = dbContext.PFRM_MicroFinanceInstitution.Where(data => data.DetailsId == detailsId).Select(MicroFinanceInstitution => new PFRM_MicroFinanceInstitutionEntity
            {
                CRARLastAccountingYearPer = MicroFinanceInstitution.CRARLastAccountingYear,
                PortfolioRiskGreaterNintyDaysPer = MicroFinanceInstitution.PortfolioRiskGreaterNintyDays,
                MicroReturnCapitalEmployedLastAccountingYearPer = MicroFinanceInstitution.ReturnCapitalEmployedLastAccountingYear,
                OperationalSelfSufficiency = MicroFinanceInstitution.OperationalSelfSufficiency,
                AveragePortfolioDeployedRsCrore = MicroFinanceInstitution.AveragePortfolioDeployedRsCrore,
            }).FirstOrDefault();

            outputDetails = dbContext.PFRM_Output_Details.Where(data => data.DetailsId == detailsId).Select(output => new PFRM_OutputDetailsEntity
            {
                Parameter_Name = output.Parameter_Name,
                Values = output.Values,
                Rank = output.Rank,
                Score = output.Score,
                Comment = (string.IsNullOrEmpty(output.Comment)) ? "" : output.Comment,
            }).ToList();


            basicDetails.PFRM_SponsorRiskAssessmentEntity = sponsorRiskAssessmentEntity;
            basicDetails.PFRM_ConstructionRiskAssessmentEntity = constructionRiskAssessmentEntity;
            basicDetails.PFRM_MarketRiskAssessmentEntity = marketRiskAssessmentEntity;
            basicDetails.PFRM_ProjectCostViablityEntity = projectCostViablityEntity;
            basicDetails.PFRM_ConductProjectAccountEntity = conductProjectAccountEntity;
            basicDetails.PFRM_ProjectStatusEntity = projectStatusEntity;
            basicDetails.PFRM_PrivateSectorAgencyFinancialInputEntity = privateSectorAgencyFinancialInputEntity;
            basicDetails.PFRM_PublicSectorAgencyFinancialInputEntity = publicSectorAgencyFinancialInputEntity;
            basicDetails.PFRM_MicroFinanceInstitutionEntity = microFinanceInstitutionEntity;
            basicDetails.PFRM_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public PFRM_BasicDetailsEntity GetBasicDetails_Archive(int detailsId, short logId)
        {
            PFRM_BasicDetailsEntity basicDetails = new PFRM_BasicDetailsEntity();
            PFRM_SponsorRiskAssessmentEntity sponsorRiskAssessmentEntity = new PFRM_SponsorRiskAssessmentEntity();
            PFRM_ConstructionRiskAssessmentEntity constructionRiskAssessmentEntity = new PFRM_ConstructionRiskAssessmentEntity();
            PFRM_MarketRiskAssessmentEntity marketRiskAssessmentEntity = new PFRM_MarketRiskAssessmentEntity();
            PFRM_ProjectCostViablityEntity projectCostViablityEntity = new PFRM_ProjectCostViablityEntity();
            PFRM_ConductProjectAccountEntity conductProjectAccountEntity = new PFRM_ConductProjectAccountEntity();
            PFRM_PrivateSectorAgencyFinancialInputEntity privateSectorAgencyFinancialInputEntity = new PFRM_PrivateSectorAgencyFinancialInputEntity();
            PFRM_PublicSectorAgencyFinancialInputEntity publicSectorAgencyFinancialInputEntity = new PFRM_PublicSectorAgencyFinancialInputEntity();
            PFRM_MicroFinanceInstitutionEntity microFinanceInstitutionEntity = new PFRM_MicroFinanceInstitutionEntity();
            PFRM_ProjectStatusEntity projectStatusEntity = new PFRM_ProjectStatusEntity();

            List<PFRM_OutputDetailsEntity> outputDetails = new List<PFRM_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(x => new PFRM_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = logId,

                FinYear = x.FinYear,
                DateOfInput = x.DateOfInput,

                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                PromoterName = x.PromoterName,
                ProjectTypeId = x.ProjectTypeId,
                IsFinal = x.IsFinal.Value,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

            }).FirstOrDefault();

            sponsorRiskAssessmentEntity = dbContext.PFRM_SponsorRiskAssessment_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(sponsorRiskAssessment => new PFRM_SponsorRiskAssessmentEntity
            {
                EquityparticipationPromoters = sponsorRiskAssessment.EquityparticipationPromoters,
                ProjectEquityTotalNetWorthPromoters = sponsorRiskAssessment.ProjectEquityTotalNetWorthPromoters,
                //AbilityFundCostOverruns = sponsorRiskAssessment.AbilityFundCostOverruns,
                //AbilityHandleProjectsHand = sponsorRiskAssessment.AbilityHandleProjectsHand,
                //CompetenceSeniorManagementSector = sponsorRiskAssessment.CompetenceSeniorManagementSector,
                CompetenceSeniorManagementProjectExecution = sponsorRiskAssessment.CompetenceSeniorManagementProjectExecution,
                //ManagementIntegrity = sponsorRiskAssessment.ManagementIntegrity,
                CreditTrackRecord = sponsorRiskAssessment.CreditTrackRecord,
                //GeneralReputation = sponsorRiskAssessment.GeneralReputation,
                //IntraPromoterConflicts = sponsorRiskAssessment.IntraPromoterConflicts,
                //PastTrackRecordProjects = sponsorRiskAssessment.PastTrackRecordProjects,
                //BankingHistory = sponsorRiskAssessment.BankingHistory,
                //TransferOwnershipTrackRecord = sponsorRiskAssessment.TransferOwnershipTrackRecord,
                //DisputeLitigationTrackRecordDeveloper = sponsorRiskAssessment.DisputeLitigationTrackRecordDeveloper,
                //MarketingSalesPerformance = sponsorRiskAssessment.MarketingSalesPerformance,
                //ClientileCustomerSatisfaction = sponsorRiskAssessment.ClientileCustomerSatisfaction,
            }).FirstOrDefault();

            constructionRiskAssessmentEntity = dbContext.PFRM_ConstructionRiskAssessment_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(constructionRiskAssessment => new PFRM_ConstructionRiskAssessmentEntity
            {
                LandAvailabillity = constructionRiskAssessment.LandAvailabillity,
                LabourAvailabillity = constructionRiskAssessment.LabourAvailabillity,
                InfrastructureConnection = constructionRiskAssessment.InfrastructureConnection,
                AvailabilityUtility = constructionRiskAssessment.AvailabilityUtility,
                //LegalRisk = constructionRiskAssessment.LegalRisk,
                PermitsLicenses = constructionRiskAssessment.PermitsLicenses,
            }).FirstOrDefault();

            marketRiskAssessmentEntity = dbContext.PFRM_MarketRiskAssessment_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(marketRiskAssessment => new PFRM_MarketRiskAssessmentEntity
            {
                StateEconomy = marketRiskAssessment.StateEconomy,
                RegulatoryIssuesFiscalPolicyDependence = marketRiskAssessment.RegulatoryIssuesFiscalPolicyDependence,
                EnvironmentalImpact = marketRiskAssessment.EnvironmentalImpact,
                //DemandSupplySituation = marketRiskAssessment.DemandSupplySituation,
                OfftakePriceCompetitiveness = marketRiskAssessment.OfftakePriceCompetitiveness,
                ExtentIntegratedProductOffering = marketRiskAssessment.ExtentIntegratedProductOffering,

            }).FirstOrDefault();

            projectCostViablityEntity = dbContext.PFRM_ProjectCostViablity_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(projectCostViablity => new PFRM_ProjectCostViablityEntity
            {
                ProjectedDebtServiceCoverageRatio = projectCostViablity.ProjectedDebtServiceCoverageRatio,
                InternalRateReturn = projectCostViablity.InternalRateReturn,
                FirmnessProjectCost = projectCostViablity.FirmnessProjectCost,
                //CertaintyConstructionCost = projectCostViablity.CertaintyConstructionCost,
                SensitivityAnalysis = projectCostViablity.SensitivityAnalysis,
                ContingentLiability = projectCostViablity.ContingentLiability,
                //FundTransferMechansim = projectCostViablity.FundTransferMechansim,
                SecurityandGovernmentSupport = projectCostViablity.SecurityandGovernmentSupport,
                ForceMajeureRisk = projectCostViablity.ForceMajeureRisk,
                InterestRateHedging = projectCostViablity.InterestRateHedging,
                DebtEquityRatio = projectCostViablity.DebtEquityRatio,
            }).FirstOrDefault();

            conductProjectAccountEntity = dbContext.PFRM_ConductProjectAccount_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(conductProjectAccount => new PFRM_ConductProjectAccountEntity
            {
                ActualScheduleVersusProjectPlan = conductProjectAccount.ActualScheduleVersusProjectPlan,
                PercentageProjectCompletion = conductProjectAccount.PercentageProjectCompletion,
                Moratorium = conductProjectAccount.Moratorium,
            }).FirstOrDefault();

            projectStatusEntity = dbContext.PFRM_ProjectStatus_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(projectStatus => new PFRM_ProjectStatusEntity
            {
                ProjectDesignStructure = projectStatus.ProjectDesignStructure,
                DetailedProjectFeasibilityReport = projectStatus.DetailedProjectFeasibilityReport,
                //StatusProjectClearances = projectStatus.StatusProjectClearances,
                //StatusFinancialclosure = projectStatus.StatusFinancialclosure,
            }).FirstOrDefault();

            privateSectorAgencyFinancialInputEntity = dbContext.PFRM_PrivateSectorAgencyFinancialInput_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(privateSectorAgencyFinancialInput => new PFRM_PrivateSectorAgencyFinancialInputEntity
            {
                NetWorthLastAccountingYear = privateSectorAgencyFinancialInput.NetWorthLastAccountingYear,
                ReturnCapitalEmployedLastAccountingyearPer = privateSectorAgencyFinancialInput.ReturnCapitalEmployedLastAccountingyear,
                DebtEBITDALastAccountingYear = privateSectorAgencyFinancialInput.DebtEBITDALastAccountingYear,
                InterestCoverageLastAccountingYear = privateSectorAgencyFinancialInput.InterestCoverageLastAccountingYear,
                CashInterestCoveragelastAccountingYear = privateSectorAgencyFinancialInput.CashInterestCoveragelastAccountingYear,
            }).FirstOrDefault();

            publicSectorAgencyFinancialInputEntity = dbContext.PFRM_PublicSectorAgencyFinancialInput_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(publicSectorAgencyFinancialInput => new PFRM_PublicSectorAgencyFinancialInputEntity
            {
                TaxRevenueCollectionEfficiencyPer = publicSectorAgencyFinancialInput.TaxRevenueCollectionEfficiency,
                AverageLCRLastThreeyears = publicSectorAgencyFinancialInput.AverageLCRLastThreeyears,
                LCRLastAccountingYear = publicSectorAgencyFinancialInput.LCRLastAccountingYear,
                SurplusGenerationLastAccountingYearPer = publicSectorAgencyFinancialInput.SurplusGenerationLastAccountingYear,
                AverageSurplusGenerationLastThreeYearsPer = publicSectorAgencyFinancialInput.AverageSurplusGenerationLastThreeYears,

            }).FirstOrDefault();

            microFinanceInstitutionEntity = dbContext.PFRM_MicroFinanceInstitution_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(MicroFinanceInstitution => new PFRM_MicroFinanceInstitutionEntity
            {
                CRARLastAccountingYearPer = MicroFinanceInstitution.CRARLastAccountingYear,
                PortfolioRiskGreaterNintyDaysPer = MicroFinanceInstitution.PortfolioRiskGreaterNintyDays,
                MicroReturnCapitalEmployedLastAccountingYearPer = MicroFinanceInstitution.ReturnCapitalEmployedLastAccountingYear,
                OperationalSelfSufficiency = MicroFinanceInstitution.OperationalSelfSufficiency,
                AveragePortfolioDeployedRsCrore = MicroFinanceInstitution.AveragePortfolioDeployedRsCrore,
            }).FirstOrDefault();

            outputDetails = dbContext.PFRM_Output_Details_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(output => new PFRM_OutputDetailsEntity
            {
                Parameter_Name = output.Parameter_Name,
                Values = output.Values,
                Rank = output.Rank,
                Score = output.Score,
                Comment = (string.IsNullOrEmpty(output.Comment)) ? "" : output.Comment,
            }).ToList();


            basicDetails.PFRM_SponsorRiskAssessmentEntity = sponsorRiskAssessmentEntity;
            basicDetails.PFRM_ConstructionRiskAssessmentEntity = constructionRiskAssessmentEntity;
            basicDetails.PFRM_MarketRiskAssessmentEntity = marketRiskAssessmentEntity;
            basicDetails.PFRM_ProjectCostViablityEntity = projectCostViablityEntity;
            basicDetails.PFRM_ConductProjectAccountEntity = conductProjectAccountEntity;
            basicDetails.PFRM_ProjectStatusEntity = projectStatusEntity;
            basicDetails.PFRM_PrivateSectorAgencyFinancialInputEntity = privateSectorAgencyFinancialInputEntity;
            basicDetails.PFRM_PublicSectorAgencyFinancialInputEntity = publicSectorAgencyFinancialInputEntity;
            basicDetails.PFRM_MicroFinanceInstitutionEntity = microFinanceInstitutionEntity;
            basicDetails.PFRM_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public int GetRowNo(DataTable dt, string rowName)
        {
            int rowNo = -1;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][0].ToString() == rowName)
                {
                    return rowNo;
                }
            }
            return rowNo;
        }

        public PFRM_BasicDetailsEntity ImportCompanyDetailsFromExcel_old(string filePath, string fileName, string workSheet, int userId)
        {

            PFRM_BasicDetailsEntity basicDetails = new PFRM_BasicDetailsEntity();
            PFRM_ConductProjectAccountEntity conductProjectAccountEntity = new PFRM_ConductProjectAccountEntity();
            PFRM_ConstructionRiskAssessmentEntity constructionRiskAssessmentEntity = new PFRM_ConstructionRiskAssessmentEntity();
            PFRM_MarketRiskAssessmentEntity marketRiskAssessmentEntity = new PFRM_MarketRiskAssessmentEntity();
            PFRM_MicroFinanceInstitutionEntity microFinanceInstitutionEntity = new PFRM_MicroFinanceInstitutionEntity();
            PFRM_PrivateSectorAgencyFinancialInputEntity privateSectorAgencyFinancialInputEntity = new PFRM_PrivateSectorAgencyFinancialInputEntity();
            PFRM_ProjectCostViablityEntity projectCostViablityEntity = new PFRM_ProjectCostViablityEntity();
            PFRM_ProjectStatusEntity projectStatusEntity = new PFRM_ProjectStatusEntity();
            PFRM_PublicSectorAgencyFinancialInputEntity publicSectorAgencyFinancialInputEntity = new PFRM_PublicSectorAgencyFinancialInputEntity();
            PFRM_SponsorRiskAssessmentEntity sponsorRiskAssessmentEntity = new PFRM_SponsorRiskAssessmentEntity();

            string value = "";
            DataTable dtExcel = null;
            DataTable dtTranspose = null;

            dtTranspose = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);
            //dtTranspose = _helperDAL.GenerateTransposedTable(dtExcel);
            int rowNo = 0;
            if (dtTranspose.Rows.Count > 0)
            {
                // get values for Basic Details
                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(basicDetails);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            rowNo = GetRowNo(dtTranspose, property.DisplayName);
                            if (rowNo == -1)
                            {
                                continue;
                            }
                            value = dtTranspose.Rows[rowNo][1].ToString();

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }
                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(basicDetails, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for conduct Project Account
                properties = TypeDescriptor.GetProperties(conductProjectAccountEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(conductProjectAccountEntity, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for construction Risk Assessment Entity
                properties = TypeDescriptor.GetProperties(constructionRiskAssessmentEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(constructionRiskAssessmentEntity, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for Market Risk Assessment Entity
                properties = TypeDescriptor.GetProperties(marketRiskAssessmentEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(marketRiskAssessmentEntity, safeValue);
                        }
                    }
                    catch { }

                }
                // get values for micro Finance Institution 
                properties = TypeDescriptor.GetProperties(microFinanceInstitutionEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(microFinanceInstitutionEntity, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for private Sector Agency Financial Input 
                properties = TypeDescriptor.GetProperties(privateSectorAgencyFinancialInputEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(privateSectorAgencyFinancialInputEntity, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for public Sector Agency Financial Input 
                properties = TypeDescriptor.GetProperties(publicSectorAgencyFinancialInputEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(publicSectorAgencyFinancialInputEntity, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for project Cost Viablity 
                properties = TypeDescriptor.GetProperties(projectCostViablityEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(projectCostViablityEntity, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for project Status 
                properties = TypeDescriptor.GetProperties(projectStatusEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(projectStatusEntity, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for sponsor Risk Assessment
                properties = TypeDescriptor.GetProperties(sponsorRiskAssessmentEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);

                            if (displayName == "Marketing/ Sales Performance (average for last 3 years)" || displayName == "Dispute and Litigation track record of the developer")
                            {

                            }
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(sponsorRiskAssessmentEntity, safeValue);
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }


                basicDetails.PFRM_ConductProjectAccountEntity = conductProjectAccountEntity;
                basicDetails.PFRM_ConstructionRiskAssessmentEntity = constructionRiskAssessmentEntity;
                basicDetails.PFRM_MarketRiskAssessmentEntity = marketRiskAssessmentEntity;
                basicDetails.PFRM_MicroFinanceInstitutionEntity = microFinanceInstitutionEntity;
                basicDetails.PFRM_PrivateSectorAgencyFinancialInputEntity = privateSectorAgencyFinancialInputEntity;
                basicDetails.PFRM_ProjectCostViablityEntity = projectCostViablityEntity;
                basicDetails.PFRM_ProjectStatusEntity = projectStatusEntity;
                basicDetails.PFRM_PublicSectorAgencyFinancialInputEntity = publicSectorAgencyFinancialInputEntity;
                basicDetails.PFRM_SponsorRiskAssessmentEntity = sponsorRiskAssessmentEntity;

                CompanyDAL companyDAL = new CompanyDAL();
                int companyID = companyDAL.GetCompanyIDByCompanyName(basicDetails.CompanyName, userId);

                short projectTypeID = companyDAL.GetProjectTypeIDByName(basicDetails.ProjectTypeName);
                basicDetails.ProjectTypeId = projectTypeID;
                basicDetails.CompanyId = companyID;
                CommonDAL commonDAL = new CommonDAL();
                string finYear = commonDAL.GetFinYearBasedOnDate(DateTime.Now);
                basicDetails.FinYear = finYear;
                //if (basicDetails.DateOfInput.HasValue)
                //{
                //    DateTime dateOfInput = basicDetails.DateOfInput.Value;
                //    string finYear = commonDAL.GetFinYearBasedOnDate(basicDetails.DateOfInput.Value);
                //    basicDetails.FinYear = finYear;
                //}
            }

            return basicDetails;

        }

        public PFRM_BasicDetailsEntity ImportCompanyDetailsFromExcel(string filePath, string fileName, string workSheet, int userId)
        {

            PFRM_BasicDetailsEntity basicDetails = new PFRM_BasicDetailsEntity();
            PFRM_ConductProjectAccountEntity conductProjectAccountEntity = new PFRM_ConductProjectAccountEntity();
            PFRM_ConstructionRiskAssessmentEntity constructionRiskAssessmentEntity = new PFRM_ConstructionRiskAssessmentEntity();
            PFRM_MarketRiskAssessmentEntity marketRiskAssessmentEntity = new PFRM_MarketRiskAssessmentEntity();
            PFRM_MicroFinanceInstitutionEntity microFinanceInstitutionEntity = new PFRM_MicroFinanceInstitutionEntity();
            PFRM_PrivateSectorAgencyFinancialInputEntity privateSectorAgencyFinancialInputEntity = new PFRM_PrivateSectorAgencyFinancialInputEntity();
            PFRM_ProjectCostViablityEntity projectCostViablityEntity = new PFRM_ProjectCostViablityEntity();
            PFRM_ProjectStatusEntity projectStatusEntity = new PFRM_ProjectStatusEntity();
            PFRM_PublicSectorAgencyFinancialInputEntity publicSectorAgencyFinancialInputEntity = new PFRM_PublicSectorAgencyFinancialInputEntity();
            PFRM_SponsorRiskAssessmentEntity sponsorRiskAssessmentEntity = new PFRM_SponsorRiskAssessmentEntity();

            string value = "";
            DataTable dtExcel = null;
            DataTable dtTranspose = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);
            dtTranspose = _helperDAL.GenerateTransposedTable(dtExcel);

            if (dtTranspose.Rows.Count > 0)
            {
                // get values for Basic Details
                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(basicDetails);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            value = dtTranspose.Rows[0][property.DisplayName].ToString();

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }
                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(basicDetails, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for conduct Project Account
                properties = TypeDescriptor.GetProperties(conductProjectAccountEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(conductProjectAccountEntity, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for construction Risk Assessment Entity
                properties = TypeDescriptor.GetProperties(constructionRiskAssessmentEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(constructionRiskAssessmentEntity, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for Market Risk Assessment Entity
                properties = TypeDescriptor.GetProperties(marketRiskAssessmentEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(marketRiskAssessmentEntity, safeValue);
                        }
                    }
                    catch { }

                }
                // get values for micro Finance Institution 
                properties = TypeDescriptor.GetProperties(microFinanceInstitutionEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(microFinanceInstitutionEntity, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for private Sector Agency Financial Input 
                properties = TypeDescriptor.GetProperties(privateSectorAgencyFinancialInputEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ').Trim();
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(privateSectorAgencyFinancialInputEntity, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for public Sector Agency Financial Input 
                properties = TypeDescriptor.GetProperties(publicSectorAgencyFinancialInputEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ').Trim();
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(publicSectorAgencyFinancialInputEntity, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for project Cost Viablity 
                properties = TypeDescriptor.GetProperties(projectCostViablityEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ').Trim();
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(projectCostViablityEntity, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for project Status 
                properties = TypeDescriptor.GetProperties(projectStatusEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ').Trim();
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(projectStatusEntity, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for sponsor Risk Assessment
                properties = TypeDescriptor.GetProperties(sponsorRiskAssessmentEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);

                            if (displayName == "Marketing/ Sales Performance (average for last 3 years)" || displayName == "Dispute and Litigation track record of the developer")
                            {

                            }
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ').Trim();
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(sponsorRiskAssessmentEntity, safeValue);
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }


                basicDetails.PFRM_ConductProjectAccountEntity = conductProjectAccountEntity;
                basicDetails.PFRM_ConstructionRiskAssessmentEntity = constructionRiskAssessmentEntity;
                basicDetails.PFRM_MarketRiskAssessmentEntity = marketRiskAssessmentEntity;
                basicDetails.PFRM_MicroFinanceInstitutionEntity = microFinanceInstitutionEntity;
                basicDetails.PFRM_PrivateSectorAgencyFinancialInputEntity = privateSectorAgencyFinancialInputEntity;
                basicDetails.PFRM_ProjectCostViablityEntity = projectCostViablityEntity;
                basicDetails.PFRM_ProjectStatusEntity = projectStatusEntity;
                basicDetails.PFRM_PublicSectorAgencyFinancialInputEntity = publicSectorAgencyFinancialInputEntity;
                basicDetails.PFRM_SponsorRiskAssessmentEntity = sponsorRiskAssessmentEntity;

                CompanyDAL companyDAL = new CompanyDAL();
                int companyID = companyDAL.GetCompanyIDByCompanyName(basicDetails.CompanyName, userId);

                short projectTypeID = companyDAL.GetProjectTypeIDByName(basicDetails.ProjectTypeName);
                basicDetails.ProjectTypeId = projectTypeID;
                basicDetails.CompanyId = companyID;
            }

            return basicDetails;

        }

        public List<PFRM_OutputDetailsEntity> GetOutputFromExcel(string filePath, string fileName, string workSheet, int userId)
        {
            List<PFRM_OutputDetailsEntity> outputDetailsEntity = new List<PFRM_OutputDetailsEntity>();
            DataTable dtExcel = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);

            string paramterName = "";
            if (dtExcel.Rows.Count > 0)
            {
                short row = 0;
                for (int i = 0; i < 66; i++)
                {
                    PFRM_OutputDetailsEntity newRow = new PFRM_OutputDetailsEntity();
                    newRow.LineId = row;
                    paramterName = dtExcel.Rows[i][0].ToString();
                    string rank = dtExcel.Rows[i][1].ToString();
                    if (string.IsNullOrEmpty(rank))
                    {
                        continue;
                    }

                    newRow.Parameter_Name = paramterName;
                    newRow.Rank = dtExcel.Rows[i]["Rank"].ToString();
                    newRow.Score = dtExcel.Rows[i]["Score"].ToString();

                    outputDetailsEntity.Add(newRow);
                    row++;
                }
            }

            return outputDetailsEntity;

        }

        public int SaveCompanyBasicDetailsAsDraft(int userId, int roleId, PFRM_BasicDetailsEntity riskModelExcelEntity, out int basicDetails_ArchiveId, out short logID)
        {
            int detailsId = 0;
            basicDetails_ArchiveId = 0;
            CompanyDAL companyDAL = new CompanyDAL();

            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                bool isRecordExist = companyDAL.CheckIfAlreadyExists_CompanyDetails(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                if (isRecordExist == true && riskModelExcelEntity.DetailsId == 0)
                {
                    detailsId = companyDAL.GetCompanyBasicDetailsID(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                    riskModelExcelEntity.DetailsId = detailsId;
                }
                if (riskModelExcelEntity.ButtonValue == ButtonValue.SubmitForApporval.ToString()) //"SubmitForApporval"
                {
                    riskModelExcelEntity.SubmitForApproval = true;
                    riskModelExcelEntity.SubmitForApprovalDate = DateTime.Now;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                {
                    riskModelExcelEntity.ApprovedDate = DateTime.Now;
                    riskModelExcelEntity.ReviewedDate = null;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ReviewDetails.ToString())
                {
                    riskModelExcelEntity.ReviewedDate = DateTime.Now;
                    riskModelExcelEntity.ApprovedDate = null;
                }
                logID = companyDAL.GetNHBLogId(riskModelExcelEntity.DetailsId);

                NHB_Details_Archive nHB_Details_Archive = new NHB_Details_Archive
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,

                    ProjectTypeId = riskModelExcelEntity.ProjectTypeId,
                    PromoterName = riskModelExcelEntity.PromoterName,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                    IsDraft = true
                };

                NHB_Details nHB_Details = new NHB_Details
                {
                    UserId = userId,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,

                    ProjectTypeId = riskModelExcelEntity.ProjectTypeId,
                    PromoterName = riskModelExcelEntity.PromoterName,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                };

                NHB_Details_Final nHB_Details_Final = new NHB_Details_Final
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,

                    ProjectTypeId = riskModelExcelEntity.ProjectTypeId,
                    PromoterName = riskModelExcelEntity.PromoterName,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                };

                if (userId != 0)
                {
                    #region Add Data

                    if (nHB_Details != null && companyDAL.CheckIfAlreadyExists_CompanyDetails(nHB_Details.CompanyId, nHB_Details.FinYear) == false)
                    {
                        try
                        {
                            detailsId = (int)AddCompanyDetails(nHB_Details);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Data

                    else
                    {
                        try
                        {
                            NHB_Details details = dbContext.NHB_Details.Where(detail => detail.DetailsId == nHB_Details.DetailsId).FirstOrDefault();
                            if (details != null)
                            {
                                details.UserId = nHB_Details.UserId;
                                details.FinYear = nHB_Details.FinYear;
                                details.CompanyId = nHB_Details.CompanyId;
                                details.DateOfInput = nHB_Details.DateOfInput;
                                details.ProjectTypeId = nHB_Details.ProjectTypeId;
                                details.PromoterName = nHB_Details.PromoterName;
                                details.SubmitForApproval = nHB_Details.SubmitForApproval;
                                details.SubmitForApprovalDate = nHB_Details.SubmitForApprovalDate;
                                details.ApprovedDate = nHB_Details.ApprovedDate;
                                details.ReviewedDate = nHB_Details.ReviewedDate;
                                details.FinalRating = nHB_Details.FinalRating;
                                details.PD = nHB_Details.PD;
                                details.Comments = nHB_Details.Comments;

                                details.UpdatedBy = nHB_Details.UpdatedBy;
                                details.UpdatedDateTime = nHB_Details.UpdatedDateTime;
                                details.IsFinal = nHB_Details.IsFinal;
                                dbContext.SaveChanges();
                                detailsId = details.DetailsId;
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return -1;
                            }
                        }
                        catch (Exception exception)
                        {
                            throw exception;
                        }
                    }

                    #endregion

                    #region Final Data Add

                    if (nHB_Details.IsFinal == true)
                    {
                        try
                        {
                            companyDAL.AddCompanyDetails_Final(nHB_Details_Final);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    if (isRecordExist == false)
                    {
                        nHB_Details_Archive.UpdatedBy = null;
                        nHB_Details_Archive.UpdatedDateTime = null;
                    }
                    else
                    {
                        nHB_Details_Archive.CreatedBy = null;
                        nHB_Details_Archive.CreatedDateTime = null;
                    }

                    nHB_Details_Archive.DetailsId = detailsId;
                    basicDetails_ArchiveId = (int)AddCompanyDetails_Archive(nHB_Details_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return detailsId;

        }

        public object AddCompanyDetails(NHB_Details nhb_Details)
        {
            try
            {
                dbContext.NHB_Details.Add(nhb_Details);
                dbContext.SaveChanges();
                return nhb_Details.DetailsId;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public object AddCompanyDetails_Archive(NHB_Details_Archive nHB_Details_Archive)
        {
            try
            {
                dbContext.NHB_Details_Archive.Add(nHB_Details_Archive);
                dbContext.SaveChanges();
                return nHB_Details_Archive.Details_ArchiveId;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_SponsorRiskAssessment(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, PFRM_SponsorRiskAssessmentEntity sponsorRiskAssessmentEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                PFRM_SponsorRiskAssessment_Archive sponsorRiskAssessment_Archive = new PFRM_SponsorRiskAssessment_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,
                    UserId = userId,

                    EquityparticipationPromoters = sponsorRiskAssessmentEntity.EquityparticipationPromoters,
                    ProjectEquityTotalNetWorthPromoters = sponsorRiskAssessmentEntity.ProjectEquityTotalNetWorthPromoters,
                    //AbilityFundCostOverruns = sponsorRiskAssessmentEntity.AbilityFundCostOverruns,
                    //AbilityHandleProjectsHand = sponsorRiskAssessmentEntity.AbilityHandleProjectsHand,
                    //CompetenceSeniorManagementSector = sponsorRiskAssessmentEntity.CompetenceSeniorManagementSector,
                    CompetenceSeniorManagementProjectExecution = sponsorRiskAssessmentEntity.CompetenceSeniorManagementProjectExecution,
                    //ManagementIntegrity = sponsorRiskAssessmentEntity.ManagementIntegrity,
                    CreditTrackRecord = sponsorRiskAssessmentEntity.CreditTrackRecord,
                    //GeneralReputation = sponsorRiskAssessmentEntity.GeneralReputation,
                    //IntraPromoterConflicts = sponsorRiskAssessmentEntity.IntraPromoterConflicts,
                    //PastTrackRecordProjects = sponsorRiskAssessmentEntity.PastTrackRecordProjects,
                    //BankingHistory = sponsorRiskAssessmentEntity.BankingHistory,
                    //TransferOwnershipTrackRecord = sponsorRiskAssessmentEntity.TransferOwnershipTrackRecord,
                    //DisputeLitigationTrackRecordDeveloper = sponsorRiskAssessmentEntity.DisputeLitigationTrackRecordDeveloper,
                    //MarketingSalesPerformance = sponsorRiskAssessmentEntity.MarketingSalesPerformance,
                    //ClientileCustomerSatisfaction = sponsorRiskAssessmentEntity.ClientileCustomerSatisfaction,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                PFRM_SponsorRiskAssessment sponsorRiskAssessment = new PFRM_SponsorRiskAssessment
                {
                    DetailsId = detailID,

                    EquityparticipationPromoters = sponsorRiskAssessmentEntity.EquityparticipationPromoters,
                    ProjectEquityTotalNetWorthPromoters = sponsorRiskAssessmentEntity.ProjectEquityTotalNetWorthPromoters,
                    //AbilityFundCostOverruns = sponsorRiskAssessmentEntity.AbilityFundCostOverruns,
                    //AbilityHandleProjectsHand = sponsorRiskAssessmentEntity.AbilityHandleProjectsHand,
                    //CompetenceSeniorManagementSector = sponsorRiskAssessmentEntity.CompetenceSeniorManagementSector,
                    CompetenceSeniorManagementProjectExecution = sponsorRiskAssessmentEntity.CompetenceSeniorManagementProjectExecution,
                    //ManagementIntegrity = sponsorRiskAssessmentEntity.ManagementIntegrity,
                    CreditTrackRecord = sponsorRiskAssessmentEntity.CreditTrackRecord,
                    //GeneralReputation = sponsorRiskAssessmentEntity.GeneralReputation,
                    //IntraPromoterConflicts = sponsorRiskAssessmentEntity.IntraPromoterConflicts,
                    //PastTrackRecordProjects = sponsorRiskAssessmentEntity.PastTrackRecordProjects,
                    //BankingHistory = sponsorRiskAssessmentEntity.BankingHistory,
                    //TransferOwnershipTrackRecord = sponsorRiskAssessmentEntity.TransferOwnershipTrackRecord,
                    //DisputeLitigationTrackRecordDeveloper = sponsorRiskAssessmentEntity.DisputeLitigationTrackRecordDeveloper,
                    //MarketingSalesPerformance = sponsorRiskAssessmentEntity.MarketingSalesPerformance,
                    //ClientileCustomerSatisfaction = sponsorRiskAssessmentEntity.ClientileCustomerSatisfaction,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (sponsorRiskAssessment != null && CheckIfAlreadyExists_SponsorRiskAssessment(detailID) == false)
                    {
                        try
                        {
                            status = Add_SponsorRiskAssessment(sponsorRiskAssessment);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            PFRM_SponsorRiskAssessment sponsorRiskAssessment_Update = dbContext.PFRM_SponsorRiskAssessment.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            sponsorRiskAssessment_Update.EquityparticipationPromoters = sponsorRiskAssessmentEntity.EquityparticipationPromoters;
                            sponsorRiskAssessment_Update.ProjectEquityTotalNetWorthPromoters = sponsorRiskAssessmentEntity.ProjectEquityTotalNetWorthPromoters;
                            //sponsorRiskAssessment_Update.AbilityFundCostOverruns = sponsorRiskAssessmentEntity.AbilityFundCostOverruns;
                            //sponsorRiskAssessment_Update.AbilityHandleProjectsHand = sponsorRiskAssessmentEntity.AbilityHandleProjectsHand;
                            //sponsorRiskAssessment_Update.CompetenceSeniorManagementSector = sponsorRiskAssessmentEntity.CompetenceSeniorManagementSector;
                            sponsorRiskAssessment_Update.CompetenceSeniorManagementProjectExecution = sponsorRiskAssessmentEntity.CompetenceSeniorManagementProjectExecution;
                            //sponsorRiskAssessment_Update.ManagementIntegrity = sponsorRiskAssessmentEntity.ManagementIntegrity;
                            sponsorRiskAssessment_Update.CreditTrackRecord = sponsorRiskAssessmentEntity.CreditTrackRecord;
                            //sponsorRiskAssessment_Update.GeneralReputation = sponsorRiskAssessmentEntity.GeneralReputation;
                            //sponsorRiskAssessment_Update.IntraPromoterConflicts = sponsorRiskAssessmentEntity.IntraPromoterConflicts;
                            //sponsorRiskAssessment_Update.PastTrackRecordProjects = sponsorRiskAssessmentEntity.PastTrackRecordProjects;
                            //sponsorRiskAssessment_Update.BankingHistory = sponsorRiskAssessmentEntity.BankingHistory;
                            //sponsorRiskAssessment_Update.TransferOwnershipTrackRecord = sponsorRiskAssessmentEntity.TransferOwnershipTrackRecord;
                            //sponsorRiskAssessment_Update.DisputeLitigationTrackRecordDeveloper = sponsorRiskAssessmentEntity.DisputeLitigationTrackRecordDeveloper;
                            //sponsorRiskAssessment_Update.MarketingSalesPerformance = sponsorRiskAssessmentEntity.MarketingSalesPerformance;
                            //sponsorRiskAssessment_Update.ClientileCustomerSatisfaction = sponsorRiskAssessmentEntity.ClientileCustomerSatisfaction;
                            sponsorRiskAssessment_Update.UpdatedBy = userId;
                            sponsorRiskAssessment_Update.UpdatedDateTime = DateTime.Now;
                            dbContext.SaveChanges();
                            status = true;

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                            return false;
                        }
                    }

                    #endregion

                    status = Add_SponsorRiskAssessment_Archive(sponsorRiskAssessment_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_SponsorRiskAssessment(PFRM_SponsorRiskAssessment sponsorRiskAssessment)
        {
            try
            {
                dbContext.PFRM_SponsorRiskAssessment.Add(sponsorRiskAssessment);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_SponsorRiskAssessment_Archive(PFRM_SponsorRiskAssessment_Archive sponsorRiskAssessment_Archive)
        {
            try
            {
                dbContext.PFRM_SponsorRiskAssessment_Archive.Add(sponsorRiskAssessment_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }


        public bool SaveAsDraft_ConductProjectAccount(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, PFRM_ConductProjectAccountEntity conductProjectAccountEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                PFRM_ConductProjectAccount_Archive conductProjectAccount_Archive = new PFRM_ConductProjectAccount_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,
                    UserId = userId,

                    ActualScheduleVersusProjectPlan = conductProjectAccountEntity.ActualScheduleVersusProjectPlan,
                    PercentageProjectCompletion = conductProjectAccountEntity.PercentageProjectCompletion,
                    Moratorium = conductProjectAccountEntity.Moratorium,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                PFRM_ConductProjectAccount conductProjectAccount = new PFRM_ConductProjectAccount
                {
                    DetailsId = detailID,

                    ActualScheduleVersusProjectPlan = conductProjectAccountEntity.ActualScheduleVersusProjectPlan,
                    PercentageProjectCompletion = conductProjectAccountEntity.PercentageProjectCompletion,
                    Moratorium = conductProjectAccountEntity.Moratorium,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (conductProjectAccount != null && CheckIfAlreadyExists_ConductProjectAccount(detailID) == false)
                    {
                        try
                        {
                            status = Add_ConductProjectAccount(conductProjectAccount);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            PFRM_ConductProjectAccount conductProjectAccount_Update = dbContext.PFRM_ConductProjectAccount.Where(detail => detail.DetailsId == detailID).FirstOrDefault();

                            conductProjectAccount_Update.ActualScheduleVersusProjectPlan = conductProjectAccountEntity.ActualScheduleVersusProjectPlan;
                            conductProjectAccount_Update.PercentageProjectCompletion = conductProjectAccountEntity.PercentageProjectCompletion;
                            conductProjectAccount_Update.Moratorium = conductProjectAccountEntity.Moratorium;

                            conductProjectAccount_Update.UpdatedBy = userId;
                            conductProjectAccount_Update.UpdatedDateTime = DateTime.Now;
                            dbContext.SaveChanges();
                            status = true;

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                            return false;
                        }
                    }

                    #endregion

                    status = Add_ConductProjectAccount_Archive(conductProjectAccount_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_ConductProjectAccount(PFRM_ConductProjectAccount conductProjectAccount)
        {
            try
            {
                dbContext.PFRM_ConductProjectAccount.Add(conductProjectAccount);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_ConductProjectAccount_Archive(PFRM_ConductProjectAccount_Archive conductProjectAccount_Archive)
        {
            try
            {
                dbContext.PFRM_ConductProjectAccount_Archive.Add(conductProjectAccount_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }


        public bool SaveAsDraft_ConstructionRiskAssessment(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, PFRM_ConstructionRiskAssessmentEntity constructionRiskAssessmentEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                PFRM_ConstructionRiskAssessment_Archive constructionRiskAssessment_Archive = new PFRM_ConstructionRiskAssessment_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,
                    UserId = userId,

                    LandAvailabillity = constructionRiskAssessmentEntity.LandAvailabillity,
                    LabourAvailabillity = constructionRiskAssessmentEntity.LabourAvailabillity,
                    InfrastructureConnection = constructionRiskAssessmentEntity.InfrastructureConnection,
                    AvailabilityUtility = constructionRiskAssessmentEntity.AvailabilityUtility,
                    //LegalRisk = constructionRiskAssessmentEntity.LegalRisk,
                    PermitsLicenses = constructionRiskAssessmentEntity.PermitsLicenses,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                PFRM_ConstructionRiskAssessment constructionRiskAssessment = new PFRM_ConstructionRiskAssessment
                {
                    DetailsId = detailID,

                    LandAvailabillity = constructionRiskAssessmentEntity.LandAvailabillity,
                    LabourAvailabillity = constructionRiskAssessmentEntity.LabourAvailabillity,
                    InfrastructureConnection = constructionRiskAssessmentEntity.InfrastructureConnection,
                    AvailabilityUtility = constructionRiskAssessmentEntity.AvailabilityUtility,
                    //LegalRisk = constructionRiskAssessmentEntity.LegalRisk,
                    PermitsLicenses = constructionRiskAssessmentEntity.PermitsLicenses,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (constructionRiskAssessment != null && CheckIfAlreadyExists_ConstructionRiskAssessment(detailID) == false)
                    {
                        try
                        {
                            status = Add_ConstructionRiskAssessment(constructionRiskAssessment);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            PFRM_ConstructionRiskAssessment constructionRiskAssessment_Update = dbContext.PFRM_ConstructionRiskAssessment.Where(detail => detail.DetailsId == detailID).FirstOrDefault();


                            constructionRiskAssessment_Update.LandAvailabillity = constructionRiskAssessmentEntity.LandAvailabillity;
                            constructionRiskAssessment_Update.LabourAvailabillity = constructionRiskAssessmentEntity.LabourAvailabillity;
                            constructionRiskAssessment_Update.InfrastructureConnection = constructionRiskAssessmentEntity.InfrastructureConnection;
                            constructionRiskAssessment_Update.AvailabilityUtility = constructionRiskAssessmentEntity.AvailabilityUtility;
                            //constructionRiskAssessment_Update.LegalRisk = constructionRiskAssessmentEntity.LegalRisk;
                            constructionRiskAssessment_Update.PermitsLicenses = constructionRiskAssessmentEntity.PermitsLicenses;

                            constructionRiskAssessment_Update.UpdatedBy = userId;
                            constructionRiskAssessment_Update.UpdatedDateTime = DateTime.Now;

                            dbContext.SaveChanges();
                            status = true;

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                            return false;
                        }
                    }

                    #endregion

                    status = Add_ConstructionRiskAssessment_Archive(constructionRiskAssessment_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_ConstructionRiskAssessment(PFRM_ConstructionRiskAssessment constructionRiskAssessment)
        {
            try
            {
                dbContext.PFRM_ConstructionRiskAssessment.Add(constructionRiskAssessment);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_ConstructionRiskAssessment_Archive(PFRM_ConstructionRiskAssessment_Archive constructionRiskAssessment_Archive)
        {
            try
            {
                dbContext.PFRM_ConstructionRiskAssessment_Archive.Add(constructionRiskAssessment_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_MarketRiskAssessment(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, PFRM_MarketRiskAssessmentEntity marketRiskAssessmentEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                PFRM_MarketRiskAssessment_Archive marketRiskAssessment_Archive = new PFRM_MarketRiskAssessment_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,
                    UserId = userId,

                    StateEconomy = marketRiskAssessmentEntity.StateEconomy,
                    RegulatoryIssuesFiscalPolicyDependence = marketRiskAssessmentEntity.RegulatoryIssuesFiscalPolicyDependence,
                    EnvironmentalImpact = marketRiskAssessmentEntity.EnvironmentalImpact,
                    //DemandSupplySituation = marketRiskAssessmentEntity.DemandSupplySituation,
                    OfftakePriceCompetitiveness = marketRiskAssessmentEntity.OfftakePriceCompetitiveness,
                    ExtentIntegratedProductOffering = marketRiskAssessmentEntity.ExtentIntegratedProductOffering,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                PFRM_MarketRiskAssessment marketRiskAssessment = new PFRM_MarketRiskAssessment
                {
                    DetailsId = detailID,

                    StateEconomy = marketRiskAssessmentEntity.StateEconomy,
                    RegulatoryIssuesFiscalPolicyDependence = marketRiskAssessmentEntity.RegulatoryIssuesFiscalPolicyDependence,
                    EnvironmentalImpact = marketRiskAssessmentEntity.EnvironmentalImpact,
                    //DemandSupplySituation = marketRiskAssessmentEntity.DemandSupplySituation,
                    OfftakePriceCompetitiveness = marketRiskAssessmentEntity.OfftakePriceCompetitiveness,
                    ExtentIntegratedProductOffering = marketRiskAssessmentEntity.ExtentIntegratedProductOffering,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (marketRiskAssessment != null && CheckIfAlreadyExists_MarketRiskAssessment(detailID) == false)
                    {
                        try
                        {
                            status = Add_MarketRiskAssessment(marketRiskAssessment);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            PFRM_MarketRiskAssessment marketRiskAssessment_Update = dbContext.PFRM_MarketRiskAssessment.Where(detail => detail.DetailsId == detailID).FirstOrDefault();

                            marketRiskAssessment_Update.StateEconomy = marketRiskAssessmentEntity.StateEconomy;
                            marketRiskAssessment_Update.RegulatoryIssuesFiscalPolicyDependence = marketRiskAssessmentEntity.RegulatoryIssuesFiscalPolicyDependence;
                            marketRiskAssessment_Update.EnvironmentalImpact = marketRiskAssessmentEntity.EnvironmentalImpact;
                            //marketRiskAssessment_Update.DemandSupplySituation = marketRiskAssessmentEntity.DemandSupplySituation;
                            marketRiskAssessment_Update.OfftakePriceCompetitiveness = marketRiskAssessmentEntity.OfftakePriceCompetitiveness;
                            marketRiskAssessment_Update.ExtentIntegratedProductOffering = marketRiskAssessmentEntity.ExtentIntegratedProductOffering;

                            marketRiskAssessment_Update.UpdatedBy = userId;
                            marketRiskAssessment_Update.UpdatedDateTime = DateTime.Now;

                            dbContext.SaveChanges();
                            status = true;

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                            return false;
                        }
                    }

                    #endregion

                    status = Add_MarketRiskAssessment_Archive(marketRiskAssessment_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_MarketRiskAssessment(PFRM_MarketRiskAssessment marketRiskAssessment)
        {
            try
            {
                dbContext.PFRM_MarketRiskAssessment.Add(marketRiskAssessment);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_MarketRiskAssessment_Archive(PFRM_MarketRiskAssessment_Archive marketRiskAssessment_Archive)
        {
            try
            {
                dbContext.PFRM_MarketRiskAssessment_Archive.Add(marketRiskAssessment_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_MicroFinanceInstitution(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, PFRM_MicroFinanceInstitutionEntity microFinanceInstitutionEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                PFRM_MicroFinanceInstitution_Archive microFinanceInstitution_Archive = new PFRM_MicroFinanceInstitution_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,
                    UserId = userId,

                    CRARLastAccountingYear = microFinanceInstitutionEntity.CRARLastAccountingYearPer,
                    PortfolioRiskGreaterNintyDays = microFinanceInstitutionEntity.PortfolioRiskGreaterNintyDaysPer,
                    ReturnCapitalEmployedLastAccountingYear = microFinanceInstitutionEntity.MicroReturnCapitalEmployedLastAccountingYearPer,
                    OperationalSelfSufficiency = microFinanceInstitutionEntity.OperationalSelfSufficiency,
                    AveragePortfolioDeployedRsCrore = microFinanceInstitutionEntity.AveragePortfolioDeployedRsCrore,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                PFRM_MicroFinanceInstitution microFinanceInstitution = new PFRM_MicroFinanceInstitution
                {
                    DetailsId = detailID,

                    CRARLastAccountingYear = microFinanceInstitutionEntity.CRARLastAccountingYearPer,
                    PortfolioRiskGreaterNintyDays = microFinanceInstitutionEntity.PortfolioRiskGreaterNintyDaysPer,
                    ReturnCapitalEmployedLastAccountingYear = microFinanceInstitutionEntity.MicroReturnCapitalEmployedLastAccountingYearPer,
                    OperationalSelfSufficiency = microFinanceInstitutionEntity.OperationalSelfSufficiency,
                    AveragePortfolioDeployedRsCrore = microFinanceInstitutionEntity.AveragePortfolioDeployedRsCrore,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (microFinanceInstitution != null && CheckIfAlreadyExists_MicroFinanceInstitution(detailID) == false)
                    {
                        try
                        {
                            status = Add_MicroFinanceInstitution(microFinanceInstitution);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            PFRM_MicroFinanceInstitution microFinanceInstitution_Update = dbContext.PFRM_MicroFinanceInstitution.Where(detail => detail.DetailsId == detailID).FirstOrDefault();

                            microFinanceInstitution_Update.CRARLastAccountingYear = microFinanceInstitutionEntity.CRARLastAccountingYearPer;
                            microFinanceInstitution_Update.PortfolioRiskGreaterNintyDays = microFinanceInstitutionEntity.PortfolioRiskGreaterNintyDaysPer;
                            microFinanceInstitution_Update.ReturnCapitalEmployedLastAccountingYear = microFinanceInstitutionEntity.MicroReturnCapitalEmployedLastAccountingYearPer;
                            microFinanceInstitution_Update.OperationalSelfSufficiency = microFinanceInstitutionEntity.OperationalSelfSufficiency;
                            microFinanceInstitution_Update.AveragePortfolioDeployedRsCrore = microFinanceInstitutionEntity.AveragePortfolioDeployedRsCrore;

                            microFinanceInstitution_Update.UpdatedBy = userId;
                            microFinanceInstitution_Update.UpdatedDateTime = DateTime.Now;

                            dbContext.SaveChanges();
                            status = true;

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                            return false;
                        }
                    }

                    #endregion

                    status = Add_MicroFinanceInstitution_Archive(microFinanceInstitution_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_MicroFinanceInstitution(PFRM_MicroFinanceInstitution microFinanceInstitution)
        {
            try
            {
                dbContext.PFRM_MicroFinanceInstitution.Add(microFinanceInstitution);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_MicroFinanceInstitution_Archive(PFRM_MicroFinanceInstitution_Archive microFinanceInstitution_Archive)
        {
            try
            {
                dbContext.PFRM_MicroFinanceInstitution_Archive.Add(microFinanceInstitution_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_PrivateSectorAgencyFinancialInput(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, PFRM_PrivateSectorAgencyFinancialInputEntity privateSectorAgencyFinancialInputEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                PFRM_PrivateSectorAgencyFinancialInput_Archive privateSectorAgencyFinancialInput_Archive = new PFRM_PrivateSectorAgencyFinancialInput_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,
                    UserId = userId,

                    NetWorthLastAccountingYear = privateSectorAgencyFinancialInputEntity.NetWorthLastAccountingYear,
                    ReturnCapitalEmployedLastAccountingyear = privateSectorAgencyFinancialInputEntity.ReturnCapitalEmployedLastAccountingyearPer,
                    DebtEBITDALastAccountingYear = privateSectorAgencyFinancialInputEntity.DebtEBITDALastAccountingYear,
                    InterestCoverageLastAccountingYear = privateSectorAgencyFinancialInputEntity.InterestCoverageLastAccountingYear,
                    CashInterestCoveragelastAccountingYear = privateSectorAgencyFinancialInputEntity.CashInterestCoveragelastAccountingYear,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                PFRM_PrivateSectorAgencyFinancialInput privateSectorAgencyFinancialInput = new PFRM_PrivateSectorAgencyFinancialInput
                {
                    DetailsId = detailID,

                    NetWorthLastAccountingYear = privateSectorAgencyFinancialInputEntity.NetWorthLastAccountingYear,
                    ReturnCapitalEmployedLastAccountingyear = privateSectorAgencyFinancialInputEntity.ReturnCapitalEmployedLastAccountingyearPer,
                    DebtEBITDALastAccountingYear = privateSectorAgencyFinancialInputEntity.DebtEBITDALastAccountingYear,
                    InterestCoverageLastAccountingYear = privateSectorAgencyFinancialInputEntity.InterestCoverageLastAccountingYear,
                    CashInterestCoveragelastAccountingYear = privateSectorAgencyFinancialInputEntity.CashInterestCoveragelastAccountingYear,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (privateSectorAgencyFinancialInput != null && CheckIfAlreadyExists_PrivateSectorAgencyFinancialInput(detailID) == false)
                    {
                        try
                        {
                            status = Add_PrivateSectorAgencyFinancialInput(privateSectorAgencyFinancialInput);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            PFRM_PrivateSectorAgencyFinancialInput privateSectorAgencyFinancialInput_Update = dbContext.PFRM_PrivateSectorAgencyFinancialInput.Where(detail => detail.DetailsId == detailID).FirstOrDefault();

                            privateSectorAgencyFinancialInput_Update.NetWorthLastAccountingYear = privateSectorAgencyFinancialInputEntity.NetWorthLastAccountingYear;
                            privateSectorAgencyFinancialInput_Update.ReturnCapitalEmployedLastAccountingyear = privateSectorAgencyFinancialInputEntity.ReturnCapitalEmployedLastAccountingyearPer;
                            privateSectorAgencyFinancialInput_Update.DebtEBITDALastAccountingYear = privateSectorAgencyFinancialInputEntity.DebtEBITDALastAccountingYear;
                            privateSectorAgencyFinancialInput_Update.InterestCoverageLastAccountingYear = privateSectorAgencyFinancialInputEntity.InterestCoverageLastAccountingYear;
                            privateSectorAgencyFinancialInput_Update.CashInterestCoveragelastAccountingYear = privateSectorAgencyFinancialInputEntity.CashInterestCoveragelastAccountingYear;

                            privateSectorAgencyFinancialInput_Update.UpdatedBy = userId;
                            privateSectorAgencyFinancialInput_Update.UpdatedDateTime = DateTime.Now;

                            dbContext.SaveChanges();
                            status = true;

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                            return false;
                        }
                    }

                    #endregion

                    status = Add_PrivateSectorAgencyFinancialInput_Archive(privateSectorAgencyFinancialInput_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_PrivateSectorAgencyFinancialInput(PFRM_PrivateSectorAgencyFinancialInput privateSectorAgencyFinancialInput)
        {
            try
            {
                dbContext.PFRM_PrivateSectorAgencyFinancialInput.Add(privateSectorAgencyFinancialInput);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_PrivateSectorAgencyFinancialInput_Archive(PFRM_PrivateSectorAgencyFinancialInput_Archive privateSectorAgencyFinancialInput_Archive)
        {
            try
            {
                dbContext.PFRM_PrivateSectorAgencyFinancialInput_Archive.Add(privateSectorAgencyFinancialInput_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_PublicSectorAgencyFinancialInput(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, PFRM_PublicSectorAgencyFinancialInputEntity publicSectorAgencyFinancialInputEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                PFRM_PublicSectorAgencyFinancialInput_Archive publicSectorAgencyFinancialInput_Archive = new PFRM_PublicSectorAgencyFinancialInput_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,
                    UserId = userId,

                    TaxRevenueCollectionEfficiency = publicSectorAgencyFinancialInputEntity.TaxRevenueCollectionEfficiencyPer,
                    AverageLCRLastThreeyears = publicSectorAgencyFinancialInputEntity.AverageLCRLastThreeyears,
                    LCRLastAccountingYear = publicSectorAgencyFinancialInputEntity.LCRLastAccountingYear,
                    SurplusGenerationLastAccountingYear = publicSectorAgencyFinancialInputEntity.SurplusGenerationLastAccountingYearPer,
                    AverageSurplusGenerationLastThreeYears = publicSectorAgencyFinancialInputEntity.AverageSurplusGenerationLastThreeYearsPer,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                PFRM_PublicSectorAgencyFinancialInput publicSectorAgencyFinancialInput = new PFRM_PublicSectorAgencyFinancialInput
                {
                    DetailsId = detailID,

                    TaxRevenueCollectionEfficiency = publicSectorAgencyFinancialInputEntity.TaxRevenueCollectionEfficiencyPer,
                    AverageLCRLastThreeyears = publicSectorAgencyFinancialInputEntity.AverageLCRLastThreeyears,
                    LCRLastAccountingYear = publicSectorAgencyFinancialInputEntity.LCRLastAccountingYear,
                    SurplusGenerationLastAccountingYear = publicSectorAgencyFinancialInputEntity.SurplusGenerationLastAccountingYearPer,
                    AverageSurplusGenerationLastThreeYears = publicSectorAgencyFinancialInputEntity.AverageSurplusGenerationLastThreeYearsPer,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (publicSectorAgencyFinancialInput != null && CheckIfAlreadyExists_PublicSectorAgencyFinancialInput(detailID) == false)
                    {
                        try
                        {
                            status = Add_PublicSectorAgencyFinancialInput(publicSectorAgencyFinancialInput);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            PFRM_PublicSectorAgencyFinancialInput publicSectorAgencyFinancialInput_Update = dbContext.PFRM_PublicSectorAgencyFinancialInput.Where(detail => detail.DetailsId == detailID).FirstOrDefault();

                            publicSectorAgencyFinancialInput_Update.TaxRevenueCollectionEfficiency = publicSectorAgencyFinancialInputEntity.TaxRevenueCollectionEfficiencyPer;
                            publicSectorAgencyFinancialInput_Update.AverageLCRLastThreeyears = publicSectorAgencyFinancialInputEntity.AverageLCRLastThreeyears;
                            publicSectorAgencyFinancialInput_Update.LCRLastAccountingYear = publicSectorAgencyFinancialInputEntity.LCRLastAccountingYear;
                            publicSectorAgencyFinancialInput_Update.SurplusGenerationLastAccountingYear = publicSectorAgencyFinancialInputEntity.SurplusGenerationLastAccountingYearPer;
                            publicSectorAgencyFinancialInput_Update.AverageSurplusGenerationLastThreeYears = publicSectorAgencyFinancialInputEntity.AverageSurplusGenerationLastThreeYearsPer;

                            publicSectorAgencyFinancialInput_Update.UpdatedBy = userId;
                            publicSectorAgencyFinancialInput_Update.UpdatedDateTime = DateTime.Now;

                            dbContext.SaveChanges();
                            status = true;

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                            return false;
                        }
                    }

                    #endregion

                    status = Add_PublicSectorAgencyFinancialInput_Archive(publicSectorAgencyFinancialInput_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_PublicSectorAgencyFinancialInput(PFRM_PublicSectorAgencyFinancialInput publicSectorAgencyFinancialInput)
        {
            try
            {
                dbContext.PFRM_PublicSectorAgencyFinancialInput.Add(publicSectorAgencyFinancialInput);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_PublicSectorAgencyFinancialInput_Archive(PFRM_PublicSectorAgencyFinancialInput_Archive publicSectorAgencyFinancialInput_Archive)
        {
            try
            {
                dbContext.PFRM_PublicSectorAgencyFinancialInput_Archive.Add(publicSectorAgencyFinancialInput_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_ProjectStatus(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, PFRM_ProjectStatusEntity projectStatusEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                PFRM_ProjectStatus_Archive projectStatus_Archive = new PFRM_ProjectStatus_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,
                    UserId = userId,

                    ProjectDesignStructure = projectStatusEntity.ProjectDesignStructure,
                    DetailedProjectFeasibilityReport = projectStatusEntity.DetailedProjectFeasibilityReport,
                    //StatusProjectClearances = projectStatusEntity.StatusProjectClearances,
                    //StatusFinancialclosure = projectStatusEntity.StatusFinancialclosure,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                PFRM_ProjectStatus projectStatus = new PFRM_ProjectStatus
                {
                    DetailsId = detailID,

                    ProjectDesignStructure = projectStatusEntity.ProjectDesignStructure,
                    DetailedProjectFeasibilityReport = projectStatusEntity.DetailedProjectFeasibilityReport,
                    //StatusProjectClearances = projectStatusEntity.StatusProjectClearances,
                    //StatusFinancialclosure = projectStatusEntity.StatusFinancialclosure,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (projectStatus != null && CheckIfAlreadyExists_ProjectStatus(detailID) == false)
                    {
                        try
                        {
                            status = Add_ProjectStatus(projectStatus);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            PFRM_ProjectStatus projectStatus_Update = dbContext.PFRM_ProjectStatus.Where(detail => detail.DetailsId == detailID).FirstOrDefault();

                            projectStatus_Update.ProjectDesignStructure = projectStatusEntity.ProjectDesignStructure;
                            projectStatus_Update.DetailedProjectFeasibilityReport = projectStatusEntity.DetailedProjectFeasibilityReport;
                            //projectStatus_Update.StatusProjectClearances = projectStatusEntity.StatusProjectClearances;
                            //projectStatus_Update.StatusFinancialclosure = projectStatusEntity.StatusFinancialclosure;

                            projectStatus_Update.UpdatedBy = userId;
                            projectStatus_Update.UpdatedDateTime = DateTime.Now;

                            dbContext.SaveChanges();
                            status = true;

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                            return false;
                        }
                    }

                    #endregion

                    status = Add_ProjectStatus_Archive(projectStatus_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_ProjectStatus(PFRM_ProjectStatus projectStatus)
        {
            try
            {
                dbContext.PFRM_ProjectStatus.Add(projectStatus);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_ProjectStatus_Archive(PFRM_ProjectStatus_Archive projectStatus_Archive)
        {
            try
            {
                dbContext.PFRM_ProjectStatus_Archive.Add(projectStatus_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_ProjectCostViablity(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, PFRM_ProjectCostViablityEntity projectCostViablityEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                PFRM_ProjectCostViablity_Archive projectCostViablity_Archive = new PFRM_ProjectCostViablity_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,
                    UserId = userId,

                    ProjectedDebtServiceCoverageRatio = projectCostViablityEntity.ProjectedDebtServiceCoverageRatio,
                    InternalRateReturn = projectCostViablityEntity.InternalRateReturn,
                    FirmnessProjectCost = projectCostViablityEntity.FirmnessProjectCost,
                    //CertaintyConstructionCost = projectCostViablityEntity.CertaintyConstructionCost,
                    SensitivityAnalysis = projectCostViablityEntity.SensitivityAnalysis,
                    ContingentLiability = projectCostViablityEntity.ContingentLiability,
                    //FundTransferMechansim = projectCostViablityEntity.FundTransferMechansim,
                    SecurityandGovernmentSupport = projectCostViablityEntity.SecurityandGovernmentSupport,
                    ForceMajeureRisk = projectCostViablityEntity.ForceMajeureRisk,
                    InterestRateHedging = projectCostViablityEntity.InterestRateHedging,
                    DebtEquityRatio = projectCostViablityEntity.DebtEquityRatio,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                PFRM_ProjectCostViablity projectCostViablity = new PFRM_ProjectCostViablity
                {
                    DetailsId = detailID,

                    ProjectedDebtServiceCoverageRatio = projectCostViablityEntity.ProjectedDebtServiceCoverageRatio,
                    InternalRateReturn = projectCostViablityEntity.InternalRateReturn,
                    FirmnessProjectCost = projectCostViablityEntity.FirmnessProjectCost,
                    //CertaintyConstructionCost = projectCostViablityEntity.CertaintyConstructionCost,
                    SensitivityAnalysis = projectCostViablityEntity.SensitivityAnalysis,
                    ContingentLiability = projectCostViablityEntity.ContingentLiability,
                    //FundTransferMechansim = projectCostViablityEntity.FundTransferMechansim,
                    SecurityandGovernmentSupport = projectCostViablityEntity.SecurityandGovernmentSupport,
                    ForceMajeureRisk = projectCostViablityEntity.ForceMajeureRisk,
                    InterestRateHedging = projectCostViablityEntity.InterestRateHedging,
                    DebtEquityRatio = projectCostViablityEntity.DebtEquityRatio,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (projectCostViablity != null && CheckIfAlreadyExists_ProjectCostViablity(detailID) == false)
                    {
                        try
                        {
                            status = Add_ProjectCostViablity(projectCostViablity);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            PFRM_ProjectCostViablity projectCostViablity_Update = dbContext.PFRM_ProjectCostViablity.Where(detail => detail.DetailsId == detailID).FirstOrDefault();

                            projectCostViablity_Update.ProjectedDebtServiceCoverageRatio = projectCostViablityEntity.ProjectedDebtServiceCoverageRatio;
                            projectCostViablity_Update.InternalRateReturn = projectCostViablityEntity.InternalRateReturn;
                            projectCostViablity_Update.FirmnessProjectCost = projectCostViablityEntity.FirmnessProjectCost;
                            //projectCostViablity_Update.CertaintyConstructionCost = projectCostViablityEntity.CertaintyConstructionCost;
                            projectCostViablity_Update.SensitivityAnalysis = projectCostViablityEntity.SensitivityAnalysis;
                            projectCostViablity_Update.ContingentLiability = projectCostViablityEntity.ContingentLiability;
                            //projectCostViablity_Update.FundTransferMechansim = projectCostViablityEntity.FundTransferMechansim;
                            projectCostViablity_Update.SecurityandGovernmentSupport = projectCostViablityEntity.SecurityandGovernmentSupport;
                            projectCostViablity_Update.ForceMajeureRisk = projectCostViablityEntity.ForceMajeureRisk;
                            projectCostViablity_Update.InterestRateHedging = projectCostViablityEntity.InterestRateHedging;
                            projectCostViablity_Update.DebtEquityRatio = projectCostViablityEntity.DebtEquityRatio;

                            projectCostViablity_Update.UpdatedBy = userId;
                            projectCostViablity_Update.UpdatedDateTime = DateTime.Now;

                            dbContext.SaveChanges();
                            status = true;

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                            return false;
                        }
                    }

                    #endregion

                    status = Add_ProjectCostViablity_Archive(projectCostViablity_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_ProjectCostViablity(PFRM_ProjectCostViablity projectCostViablity)
        {
            try
            {
                dbContext.PFRM_ProjectCostViablity.Add(projectCostViablity);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_ProjectCostViablity_Archive(PFRM_ProjectCostViablity_Archive projectCostViablity_Archive)
        {
            try
            {
                dbContext.PFRM_ProjectCostViablity_Archive.Add(projectCostViablity_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_OutputDetails(int userId, int roleId, int detailID, short logID, int detail_ArchiveID, DateTime CreatedDateTime, List<PFRM_OutputDetailsEntity> outputDetailsEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                if (outputDetailsEntity != null && userId != 0)
                {
                    List<PFRM_Output_Details> output_Details = new List<PFRM_Output_Details>();
                    List<PFRM_Output_Details_Archive> output_Details_Archive = new List<PFRM_Output_Details_Archive>();

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details.Add(new PFRM_Output_Details
                        {
                            DetailsId = detailID,
                            LineId = values.LineId,
                            Parameter_Name = values.Parameter_Name,//string.IsNullOrEmpty(values.Parameter_Name) ? values.First_Column_Name : values.Parameter_Name,
                            Rank = values.Rank,
                            Score = values.Score,
                            Comment = values.Comment,
                            CreatedDateTime = CreatedDateTime,
                        });
                    };

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details_Archive.Add(new PFRM_Output_Details_Archive
                        {
                            DetailsId = detailID,
                            LogId = logID,
                            Details_ArchiveId = detail_ArchiveID,
                            UserId = userId,
                            LineId = values.LineId,
                            Parameter_Name = values.Parameter_Name,
                            Rank = values.Rank,
                            Score = values.Score,
                            Comment = values.Comment,
                            CreatedBy = values.CreatedBy,
                            UpdatedBy = values.UpdatedBy,

                            CreatedDateTime = CreatedDateTime,
                            UpdatedDateTime = DateTime.Now,
                        });
                    };

                    if (output_Details != null)
                    {
                        if (CheckIfAlreadyExists_OutputDetails(detailID) == true)
                        {
                            Delete_OutputDetails(detailID);
                        }
                        status = Add_OutputDetails(output_Details);
                        status = Add_OutputDetails_Archive(output_Details_Archive);
                        dbContextTransaction.Commit();
                        status = true;
                    }
                }
            }

            return status;

        }

        public bool Add_OutputDetails(List<PFRM_Output_Details> output_Details)
        {
            try
            {
                dbContext.PFRM_Output_Details.AddRange(output_Details);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_OutputDetails_Archive(List<PFRM_Output_Details_Archive> output_Details_Archive)
        {
            try
            {
                dbContext.PFRM_Output_Details_Archive.AddRange(output_Details_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Get_OutputDetails_OpenXML(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            // Open the document for editing.
            using (DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadSheet = DocumentFormat.OpenXml.Packaging.SpreadsheetDocument.Open(OutputTemplateFilePath, true))
            {
                // Access the main Workbook part, which contains all references.
                DocumentFormat.OpenXml.Packaging.WorkbookPart workbookPart = spreadSheet.WorkbookPart;
                // get sheet by name
                DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbookPart.Workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == "Output NHB").FirstOrDefault();

                // get worksheetpart by sheet id
                DocumentFormat.OpenXml.Packaging.WorksheetPart worksheetPart = workbookPart.GetPartById(sheet.Id.Value) as DocumentFormat.OpenXml.Packaging.WorksheetPart;

                // The SheetData object will contain all the data.
                int? detailArchivedID = (from output in dbContext.PFRM_Output_Details_Archive
                                         join basicDetails in dbContext.NHB_Details_Archive on output.Details_ArchiveId equals basicDetails.Details_ArchiveId
                                         where basicDetails.CompanyId == companyId
                                         && DbFunctions.TruncateTime(output.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime)
                                         select output.Details_ArchiveId).OrderByDescending(data => data.Value).FirstOrDefault();

                //    PFRM_Output_Details_Archive data = dbContext.PFRM_Output_Details_Archive.Where(detail => detail.CompanyId == companyId
                //&& issuerinfo.PRDate == null).OrderByDescending(data => data.Details_ArchiveId).FirstOrDefault();

                if (detailArchivedID.HasValue)
                {
                    List<PFRM_OutputDetailsEntity> getOutputDetails = dbContext.PFRM_Output_Details_Archive
                       .Where(riskOutputs => riskOutputs.Details_ArchiveId == detailArchivedID.Value
                       )
                       .Select(Outputs => new PFRM_OutputDetailsEntity
                       {
                           Parameter_Name = Outputs.Parameter_Name,
                           Values = Outputs.Values,
                       }).ToList();

                    uint rowNo = 3;
                    for (int i = 0; i < getOutputDetails.Count; i++)
                    {
                        Cell cell = GetCell(worksheetPart.Worksheet, "K", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].Values);
                        rowNo++;
                    }
                    // Save the worksheet.
                    worksheetPart.Worksheet.Save();

                    // for recacluation of formula
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;
                }
            }
            return true;
        }

        private Cell GetCell(Worksheet worksheet, string columnName, uint rowIndex)
        {
            Row row = GetRow(worksheet, rowIndex);

            if (row == null) return null;

            var FirstRow = row.Elements<Cell>().Where(c => string.Compare
            (c.CellReference.Value, columnName +
            rowIndex, true) == 0).FirstOrDefault();

            if (FirstRow == null) return null;

            return FirstRow;
        }

        private Row GetRow(Worksheet worksheet, uint rowIndex)
        {
            Row row = worksheet.GetFirstChild<SheetData>().
            Elements<Row>().FirstOrDefault(r => r.RowIndex == rowIndex);
            if (row == null)
            {
                throw new ArgumentException(String.Format("No row with index {0} found in spreadsheet", rowIndex));
            }
            return row;
        }

        public bool Get_OutputDetails_OpenXML_old(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            bool status = false;
            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            try
            {
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                object misValue = System.Reflection.Missing.Value;
                xlApp.DisplayAlerts = false;
                xlApp.EditDirectlyInCell = true;
                xlApp.EnableEvents = true;

                int detailID = (from output in dbContext.HFC_Output_Details
                                join hfcBasicDetails in dbContext.NHB_Details on output.DetailsId equals hfcBasicDetails.DetailsId
                                where hfcBasicDetails.CompanyId == companyId
                                select output.DetailsId).FirstOrDefault();

                //select (int)issuers.BussinessGroupID).SingleOrDefault();
                //int detailID = dbContext.HFC_Output_Details.Where(detailId => detailId.CompanyId == companyId).Select(detailId => detailId.DetailsId).FirstOrDefault();

                if (detailID != 0)
                {
                    List<HFC_Output_Details> getOutputDetails = dbContext.HFC_Output_Details
                          .Where(riskOutputs => riskOutputs.DetailsId == detailID
                          //&& DbFunctions.TruncateTime(riskOutputs.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime))
                          )
                          .Select(Outputs => new HFC_Output_Details
                          {

                          }).ToList();//.OrderByDescending(riskOutputs => riskOutputs.UpdatedDateTime).Take(1).FirstOrDefault();

                    mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                    mWorkSheets = mWorkBook.Worksheets;
                    //Get the already exists sheet
                    mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(1);
                    if (getOutputDetails != null)
                    {
                        //mWSheet.Cells[2, 6] = ExtensionMethod.GetFormattedData(getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersWeight);
                        //mWSheet.Cells[2, 7] = getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersValue;
                        //mWSheet.Cells[2, 8] = getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersScore;
                        //mWSheet.Cells[3, 6] = ExtensionMethod.GetFormattedData(getOutputDetails.IndustryRiskCompetitionsWeight);
                        //mWSheet.Cells[3, 7] = getOutputDetails.IndustryRiskCompetitionsValue;
                        //mWSheet.Cells[3, 8] = getOutputDetails.IndustryRiskCompetitionsScore;

                    }
                    else
                    {
                        getOutputDetails = null;
                        status = false;
                    }

                    mWorkBook.Save();
                    mWorkBook.Close(1, null, null);
                    xlApp.Quit();
                    status = true;

                    mWSheet = null;
                    mWorkBook = null;
                    mWorkSheets = null;
                    xlApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return status;
        }

        public bool Get_OutputDetails_ExcelInterOP(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            bool status = false;
            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            try
            {
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                object misValue = System.Reflection.Missing.Value;
                xlApp.DisplayAlerts = false;
                xlApp.EditDirectlyInCell = true;
                xlApp.EnableEvents = true;

                int detailID = (from output in dbContext.HFC_Output_Details
                                join hfcBasicDetails in dbContext.NHB_Details on output.DetailsId equals hfcBasicDetails.DetailsId
                                where hfcBasicDetails.CompanyId == companyId
                                select output.DetailsId).FirstOrDefault();

                //select (int)issuers.BussinessGroupID).SingleOrDefault();
                //int detailID = dbContext.HFC_Output_Details.Where(detailId => detailId.CompanyId == companyId).Select(detailId => detailId.DetailsId).FirstOrDefault();

                if (detailID != 0)
                {
                    List<HFC_Output_Details> getOutputDetails = dbContext.HFC_Output_Details
                          .Where(riskOutputs => riskOutputs.DetailsId == detailID
                          //&& DbFunctions.TruncateTime(riskOutputs.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime))
                          )
                          .Select(Outputs => new HFC_Output_Details
                          {

                          }).ToList();//.OrderByDescending(riskOutputs => riskOutputs.UpdatedDateTime).Take(1).FirstOrDefault();

                    mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                    mWorkSheets = mWorkBook.Worksheets;
                    //Get the already exists sheet
                    mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(1);
                    if (getOutputDetails != null)
                    {
                        //mWSheet.Cells[2, 6] = ExtensionMethod.GetFormattedData(getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersWeight);
                        //mWSheet.Cells[2, 7] = getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersValue;
                        //mWSheet.Cells[2, 8] = getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersScore;
                        //mWSheet.Cells[3, 6] = ExtensionMethod.GetFormattedData(getOutputDetails.IndustryRiskCompetitionsWeight);
                        //mWSheet.Cells[3, 7] = getOutputDetails.IndustryRiskCompetitionsValue;
                        //mWSheet.Cells[3, 8] = getOutputDetails.IndustryRiskCompetitionsScore;

                    }
                    else
                    {
                        getOutputDetails = null;
                        status = false;
                    }

                    mWorkBook.Save();
                    mWorkBook.Close(1, null, null);
                    xlApp.Quit();
                    status = true;

                    mWSheet = null;
                    mWorkBook = null;
                    mWorkSheets = null;
                    xlApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return status;
        }

        public bool Delete_OutputDetails(int detailsID)
        {
            try
            {
                dbContext.PFRM_Output_Details.RemoveRange(dbContext.PFRM_Output_Details.Where(c => c.DetailsId == detailsID));
                //foreach (var ec in dbContext.HFC_Output_Details.Where(x => x.DetailsId == hfc_Output_Details[0].DetailsId))
                //{
                //    dbContext.HFC_Output_Details.Remove(ec);
                //}
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool CheckIfAlreadyExists_OutputDetails(int detailsId)
        {
            return dbContext.PFRM_Output_Details.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_CompanyDetails(int companyId)
        {
            return dbContext.NHB_Details.Any(company => company.CompanyId == companyId);
        }

        public bool CheckIfAlreadyExists_ConductProjectAccount(int detailsId)
        {
            return dbContext.PFRM_ConductProjectAccount.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_ConstructionRiskAssessment(int detailsId)
        {
            return dbContext.PFRM_ConstructionRiskAssessment.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_MarketRiskAssessment(int detailsId)
        {
            return dbContext.PFRM_MarketRiskAssessment.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_MicroFinanceInstitution(int detailsId)
        {
            return dbContext.PFRM_MicroFinanceInstitution.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_PrivateSectorAgencyFinancialInput(int detailsId)
        {
            return dbContext.PFRM_PrivateSectorAgencyFinancialInput.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_ProjectCostViablity(int detailsId)
        {
            return dbContext.PFRM_ProjectCostViablity.Any(asset => asset.DetailsId == detailsId);
        }
        public bool CheckIfAlreadyExists_ProjectStatus(int detailsId)
        {
            return dbContext.PFRM_ProjectStatus.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_PublicSectorAgencyFinancialInput(int detailsId)
        {
            return dbContext.PFRM_PublicSectorAgencyFinancialInput.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_SponsorRiskAssessment(int detailsId)
        {
            return dbContext.PFRM_SponsorRiskAssessment.Any(asset => asset.DetailsId == detailsId);
        }

        public List<SubjectiveParametersEntity> GetHeaderParametersList()
        {
            List<SubjectiveParametersEntity> objList = null;

            var result = (from T0 in dbContext.PFRM_Header_Definition_Map_SubHeader
                          join T1 in dbContext.PFRM_Header_Map_SubHeader
                          on T0.HeaderMapSubHeaderId equals T1.HeaderMapSubHeaderId
                          join T2 in dbContext.PFRM_SubHeader_Master
                          on T1.SubHeaderId equals T2.SubHeaderId
                          join T3 in dbContext.PFRM_Header_Master
                          on T1.HeaderId equals T3.HeaderId
                          select new SubjectiveParametersEntity
                          {
                              HeaderId = T0.HeaderMapSubHeaderId.HasValue ? T0.HeaderMapSubHeaderId.Value : 0,
                              HeaderName = T2.SubHeaderName,
                              Definitions = T0.Definitions,
                              value = T0.Value
                          });

            objList = result.ToList();

            return objList;
        }

        public bool Get_OutputDetailsFromFrontEnd_InterOp(int detailsID, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Basic Details List

            List<PFRM_BasicDetailsEntity> getBasicDetailsEntity = dbContext.NHB_Details
              .Where(a => a.DetailsId == detailsID
              )
              .Select(riskModelExcelEntity => new PFRM_BasicDetailsEntity
              {
                  CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                  ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                  SponsorBank = riskModelExcelEntity.SponsorBank,
                  ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
              }).ToList();

            #endregion


            List<PFRM_SponsorRiskAssessmentEntity> getSponsorRiskEntity = dbContext.PFRM_SponsorRiskAssessment
              .Where(a => a.DetailsId == detailsID
              )
              .Select(sponsorRiskAssessment => new PFRM_SponsorRiskAssessmentEntity
              {
                  EquityparticipationPromoters = sponsorRiskAssessment.EquityparticipationPromoters,
                  ProjectEquityTotalNetWorthPromoters = sponsorRiskAssessment.ProjectEquityTotalNetWorthPromoters,
                  //AbilityFundCostOverruns = sponsorRiskAssessment.AbilityFundCostOverruns,
                  //AbilityHandleProjectsHand = sponsorRiskAssessment.AbilityHandleProjectsHand,
                  //CompetenceSeniorManagementSector = sponsorRiskAssessment.CompetenceSeniorManagementSector,
                  CompetenceSeniorManagementProjectExecution = sponsorRiskAssessment.CompetenceSeniorManagementProjectExecution,
                  //ManagementIntegrity = sponsorRiskAssessment.ManagementIntegrity,
                  CreditTrackRecord = sponsorRiskAssessment.CreditTrackRecord,
                  //GeneralReputation = sponsorRiskAssessment.GeneralReputation,
                  //IntraPromoterConflicts = sponsorRiskAssessment.IntraPromoterConflicts,
                  //PastTrackRecordProjects = sponsorRiskAssessment.PastTrackRecordProjects,
                  //BankingHistory = sponsorRiskAssessment.BankingHistory,
                  //TransferOwnershipTrackRecord = sponsorRiskAssessment.TransferOwnershipTrackRecord,
                  //DisputeLitigationTrackRecordDeveloper = sponsorRiskAssessment.DisputeLitigationTrackRecordDeveloper,
                  //MarketingSalesPerformance = sponsorRiskAssessment.MarketingSalesPerformance,
                  //ClientileCustomerSatisfaction = sponsorRiskAssessment.ClientileCustomerSatisfaction,
              }).ToList();


            List<PFRM_ConstructionRiskAssessmentEntity> getConstructionRiskEntity = dbContext.PFRM_ConstructionRiskAssessment
              .Where(a => a.DetailsId == detailsID
              )
              .Select(constructionRiskAssessment => new PFRM_ConstructionRiskAssessmentEntity
              {
                  LandAvailabillity = constructionRiskAssessment.LandAvailabillity,
                  LabourAvailabillity = constructionRiskAssessment.LabourAvailabillity,
                  InfrastructureConnection = constructionRiskAssessment.InfrastructureConnection,
                  AvailabilityUtility = constructionRiskAssessment.AvailabilityUtility,
                  //LegalRisk = constructionRiskAssessment.LegalRisk,
                  PermitsLicenses = constructionRiskAssessment.PermitsLicenses,
              }).ToList();

            List<PFRM_MarketRiskAssessmentEntity> getMarketRiskEntity = dbContext.PFRM_MarketRiskAssessment
             .Where(a => a.DetailsId == detailsID
             )
             .Select(marketRiskAssessment => new PFRM_MarketRiskAssessmentEntity
             {
                 StateEconomy = marketRiskAssessment.StateEconomy,
                 RegulatoryIssuesFiscalPolicyDependence = marketRiskAssessment.RegulatoryIssuesFiscalPolicyDependence,
                 EnvironmentalImpact = marketRiskAssessment.EnvironmentalImpact,
                 //DemandSupplySituation = marketRiskAssessment.DemandSupplySituation,
                 OfftakePriceCompetitiveness = marketRiskAssessment.OfftakePriceCompetitiveness,
                 ExtentIntegratedProductOffering = marketRiskAssessment.ExtentIntegratedProductOffering,
             }).ToList();

            List<PFRM_ConductProjectAccountEntity> getConductProjectEntity = dbContext.PFRM_ConductProjectAccount
             .Where(a => a.DetailsId == detailsID
             )
             .Select(conductProjectAccount => new PFRM_ConductProjectAccountEntity
             {
                 ActualScheduleVersusProjectPlan = conductProjectAccount.ActualScheduleVersusProjectPlan,
                 PercentageProjectCompletion = conductProjectAccount.PercentageProjectCompletion,
                 Moratorium = conductProjectAccount.Moratorium,
             }).ToList();

            List<PFRM_ProjectCostViablityEntity> getProjectCostViabilityEntity = dbContext.PFRM_ProjectCostViablity
             .Where(a => a.DetailsId == detailsID
             )
             .Select(projectCostViablity => new PFRM_ProjectCostViablityEntity
             {
                 ProjectedDebtServiceCoverageRatio = projectCostViablity.ProjectedDebtServiceCoverageRatio,
                 InternalRateReturn = projectCostViablity.InternalRateReturn,
                 FirmnessProjectCost = projectCostViablity.FirmnessProjectCost,
                 //CertaintyConstructionCost = projectCostViablity.CertaintyConstructionCost,
                 SensitivityAnalysis = projectCostViablity.SensitivityAnalysis,
                 ContingentLiability = projectCostViablity.ContingentLiability,
                 //FundTransferMechansim = projectCostViablity.FundTransferMechansim,
                 SecurityandGovernmentSupport = projectCostViablity.SecurityandGovernmentSupport,

                 ForceMajeureRisk = projectCostViablity.ForceMajeureRisk,
                 InterestRateHedging = projectCostViablity.InterestRateHedging,
                 DebtEquityRatio = projectCostViablity.DebtEquityRatio,
             }).ToList();

            List<PFRM_ProjectStatusEntity> getProjectStatusEntity = dbContext.PFRM_ProjectStatus
           .Where(a => a.DetailsId == detailsID
           )
           .Select(projectStatus => new PFRM_ProjectStatusEntity
           {
               ProjectDesignStructure = projectStatus.ProjectDesignStructure,
               DetailedProjectFeasibilityReport = projectStatus.DetailedProjectFeasibilityReport,
               //StatusProjectClearances = projectStatus.StatusProjectClearances,
               //StatusFinancialclosure = projectStatus.StatusFinancialclosure,
           }).ToList();

            List<PFRM_MicroFinanceInstitutionEntity> getMicroFinanceEntity = dbContext.PFRM_MicroFinanceInstitution
           .Where(a => a.DetailsId == detailsID)
           .Select(getMicroFinance => new PFRM_MicroFinanceInstitutionEntity
           {
               CRARLastAccountingYearPer = getMicroFinance.CRARLastAccountingYear,
               PortfolioRiskGreaterNintyDaysPer = getMicroFinance.PortfolioRiskGreaterNintyDays,
               MicroReturnCapitalEmployedLastAccountingYearPer = getMicroFinance.ReturnCapitalEmployedLastAccountingYear,
               OperationalSelfSufficiency = getMicroFinance.OperationalSelfSufficiency,
               AveragePortfolioDeployedRsCrore = getMicroFinance.AveragePortfolioDeployedRsCrore,

           }).ToList();

            List<PFRM_PrivateSectorAgencyFinancialInputEntity> getPrivateSectorAgencyEntity = dbContext.PFRM_PrivateSectorAgencyFinancialInput
           .Where(a => a.DetailsId == detailsID
           )
           .Select(privateSectorAgencyFinancialInput => new PFRM_PrivateSectorAgencyFinancialInputEntity
           {
               NetWorthLastAccountingYear = privateSectorAgencyFinancialInput.NetWorthLastAccountingYear,
               ReturnCapitalEmployedLastAccountingyearPer = privateSectorAgencyFinancialInput.ReturnCapitalEmployedLastAccountingyear,
               DebtEBITDALastAccountingYear = privateSectorAgencyFinancialInput.DebtEBITDALastAccountingYear,
               InterestCoverageLastAccountingYear = privateSectorAgencyFinancialInput.InterestCoverageLastAccountingYear,
               CashInterestCoveragelastAccountingYear = privateSectorAgencyFinancialInput.CashInterestCoveragelastAccountingYear,
           }).ToList();

            List<PFRM_PublicSectorAgencyFinancialInputEntity> getPublicSectorAgencyEntity = dbContext.PFRM_PublicSectorAgencyFinancialInput
          .Where(a => a.DetailsId == detailsID
          )
          .Select(publicSectorAgencyFinancialInput => new PFRM_PublicSectorAgencyFinancialInputEntity
          {
              TaxRevenueCollectionEfficiencyPer = publicSectorAgencyFinancialInput.TaxRevenueCollectionEfficiency,
              AverageLCRLastThreeyears = publicSectorAgencyFinancialInput.AverageLCRLastThreeyears,
              LCRLastAccountingYear = publicSectorAgencyFinancialInput.LCRLastAccountingYear,
              SurplusGenerationLastAccountingYearPer = publicSectorAgencyFinancialInput.SurplusGenerationLastAccountingYear,
              AverageSurplusGenerationLastThreeYearsPer = publicSectorAgencyFinancialInput.AverageSurplusGenerationLastThreeYears,

          }).ToList();


            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            //Get the already exists sheet
            //mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(0);
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Template"];

            string value = "";
            uint rowIndex = 0;
            int columnIndex = 0;

            string columnName = "";
            object obj;
            //mWSheet.Cells[11, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate1_Liabilities;

            PFRM_BasicDetailsEntity pfrm_BasicDetailsEntity = new PFRM_BasicDetailsEntity();
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(pfrm_BasicDetailsEntity);
            properties = TypeDescriptor.GetProperties(pfrm_BasicDetailsEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getBasicDetailsEntity[0].GetType().GetProperty(property.Name).GetValue(getBasicDetailsEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }


            PFRM_SponsorRiskAssessmentEntity pfrmSponsorRiskAssessmentEntity = new PFRM_SponsorRiskAssessmentEntity();
            properties = TypeDescriptor.GetProperties(pfrmSponsorRiskAssessmentEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getSponsorRiskEntity[0].GetType().GetProperty(property.Name).GetValue(getSponsorRiskEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            PFRM_ConstructionRiskAssessmentEntity pfrmConstructionRiskAssessmentEntity = new PFRM_ConstructionRiskAssessmentEntity();
            properties = TypeDescriptor.GetProperties(pfrmConstructionRiskAssessmentEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getConstructionRiskEntity[0].GetType().GetProperty(property.Name).GetValue(getConstructionRiskEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            PFRM_ConductProjectAccountEntity pfrmConductProjectAccountEntity = new PFRM_ConductProjectAccountEntity();
            properties = TypeDescriptor.GetProperties(pfrmConductProjectAccountEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getConductProjectEntity[0].GetType().GetProperty(property.Name).GetValue(getConductProjectEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            PFRM_MarketRiskAssessmentEntity pfrmMarketRiskAssessmentEntity = new PFRM_MarketRiskAssessmentEntity();
            properties = TypeDescriptor.GetProperties(pfrmMarketRiskAssessmentEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getMarketRiskEntity[0].GetType().GetProperty(property.Name).GetValue(getMarketRiskEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            PFRM_ProjectCostViablityEntity pfrmProjectCostViablityEntity = new PFRM_ProjectCostViablityEntity();
            properties = TypeDescriptor.GetProperties(pfrmMarketRiskAssessmentEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getProjectCostViabilityEntity[0].GetType().GetProperty(property.Name).GetValue(getProjectCostViabilityEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            PFRM_ProjectStatusEntity pfrmProjectStatusEntity = new PFRM_ProjectStatusEntity();
            properties = TypeDescriptor.GetProperties(pfrmProjectStatusEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getProjectStatusEntity[0].GetType().GetProperty(property.Name).GetValue(getProjectStatusEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            PFRM_MicroFinanceInstitutionEntity pfrmMicroFinanceInstitutionEntity = new PFRM_MicroFinanceInstitutionEntity();
            properties = TypeDescriptor.GetProperties(pfrmMicroFinanceInstitutionEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getMicroFinanceEntity[0].GetType().GetProperty(property.Name).GetValue(getMicroFinanceEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            PFRM_PrivateSectorAgencyFinancialInputEntity pfrmPrivateSectorEntity = new PFRM_PrivateSectorAgencyFinancialInputEntity();
            properties = TypeDescriptor.GetProperties(pfrmPrivateSectorEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getPrivateSectorAgencyEntity[0].GetType().GetProperty(property.Name).GetValue(getPrivateSectorAgencyEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            PFRM_PublicSectorAgencyFinancialInputEntity pfrmPublicSectorEntity = new PFRM_PublicSectorAgencyFinancialInputEntity();
            properties = TypeDescriptor.GetProperties(pfrmPublicSectorEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getPublicSectorAgencyEntity[0].GetType().GetProperty(property.Name).GetValue(getPublicSectorAgencyEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            return true;
        }


        public bool ComputeOutputDetails(PFRM_BasicDetailsEntity riskModelExcelEntity, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            //Get the already exists sheet
            //mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(0);
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Template"];

            string value = "";
            uint rowIndex = 0;
            int columnIndex = 0;

            string columnName = "";
            object obj;

            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
            PFRM_BasicDetailsEntity basicDetails = riskModelExcelEntity;
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = basicDetails.GetType().GetProperty(property.Name).GetValue(basicDetails, null);
                        value = obj.ToString();
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            try
            {
                string PromoterName = riskModelExcelEntity.PromoterName;
                string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
                string ProjectTypeName = companyDAL.GetProjectTypeNameByID(riskModelExcelEntity.ProjectTypeId);
                try
                {
                    rowIndex = _helperDAL.GetExcelRowIndex("B2");
                    columnName = _helperDAL.GetExcelColumnName("B2");
                    columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                    mWSheet.Cells[rowIndex, columnIndex] = companyName;
                }
                catch { }
                try
                {
                    rowIndex = _helperDAL.GetExcelRowIndex("B4");
                    columnName = _helperDAL.GetExcelColumnName("B4");
                    columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                    mWSheet.Cells[rowIndex, columnIndex] = ProjectTypeName;
                }
                catch { }

            }
            catch { }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.PFRM_SponsorRiskAssessmentEntity);
            PFRM_SponsorRiskAssessmentEntity getSponsorRiskEntity = riskModelExcelEntity.PFRM_SponsorRiskAssessmentEntity;
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getSponsorRiskEntity.GetType().GetProperty(property.Name).GetValue(getSponsorRiskEntity, null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        //if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        //{
                        //    try
                        //    {
                        //        value = Convert.ToString(double.Parse(value) / 100);
                        //    }
                        //    catch
                        //    {

                        //    }
                        //    //value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        //}
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.PFRM_ConstructionRiskAssessmentEntity);
            PFRM_ConstructionRiskAssessmentEntity getConstructionRiskEntity = riskModelExcelEntity.PFRM_ConstructionRiskAssessmentEntity;

            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getConstructionRiskEntity.GetType().GetProperty(property.Name).GetValue(getConstructionRiskEntity, null);
                        value = obj.ToString();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            try
                            {
                                value = Convert.ToString(double.Parse(value) / 100);
                            }
                            catch
                            {

                            }
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.PFRM_ConductProjectAccountEntity);
            PFRM_ConductProjectAccountEntity getConductProjectEntity = riskModelExcelEntity.PFRM_ConductProjectAccountEntity;

            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getConductProjectEntity.GetType().GetProperty(property.Name).GetValue(getConductProjectEntity, null);
                        value = obj.ToString();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            try
                            {
                                value = Convert.ToString(double.Parse(value) / 100);
                            }
                            catch
                            {

                            }
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.PFRM_MarketRiskAssessmentEntity);
            PFRM_MarketRiskAssessmentEntity getMarketRiskEntity = riskModelExcelEntity.PFRM_MarketRiskAssessmentEntity;

            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getMarketRiskEntity.GetType().GetProperty(property.Name).GetValue(getMarketRiskEntity, null);
                        value = obj.ToString();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            try
                            {
                                value = Convert.ToString(double.Parse(value) / 100);
                            }
                            catch
                            {

                            }
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.PFRM_ProjectCostViablityEntity);
            PFRM_ProjectCostViablityEntity getProjectCostViabilityEntity = riskModelExcelEntity.PFRM_ProjectCostViablityEntity;

            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getProjectCostViabilityEntity.GetType().GetProperty(property.Name).GetValue(getProjectCostViabilityEntity, null);
                        value = obj.ToString();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            try
                            {
                                value = Convert.ToString(double.Parse(value) / 100);
                            }
                            catch
                            {

                            }
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.PFRM_ProjectStatusEntity);
            PFRM_ProjectStatusEntity getProjectStatusEntity = riskModelExcelEntity.PFRM_ProjectStatusEntity;

            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getProjectStatusEntity.GetType().GetProperty(property.Name).GetValue(getProjectStatusEntity, null);
                        value = obj.ToString();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            try
                            {
                                value = Convert.ToString(double.Parse(value) / 100);
                            }
                            catch
                            {

                            }
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.PFRM_MicroFinanceInstitutionEntity);
            PFRM_MicroFinanceInstitutionEntity getMicroFinanceEntity = riskModelExcelEntity.PFRM_MicroFinanceInstitutionEntity;

            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getMicroFinanceEntity.GetType().GetProperty(property.Name).GetValue(getMicroFinanceEntity, null);
                        value = obj.ToString();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            try
                            {
                                value = Convert.ToString(double.Parse(value) / 100);
                            }
                            catch
                            {

                            }
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.PFRM_PrivateSectorAgencyFinancialInputEntity);
            PFRM_PrivateSectorAgencyFinancialInputEntity getPrivateSectorAgencyEntity = riskModelExcelEntity.PFRM_PrivateSectorAgencyFinancialInputEntity;

            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getPrivateSectorAgencyEntity.GetType().GetProperty(property.Name).GetValue(getPrivateSectorAgencyEntity, null);
                        value = obj.ToString();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            try
                            {
                                value = Convert.ToString(double.Parse(value) / 100);
                            }
                            catch
                            {

                            }
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.PFRM_PublicSectorAgencyFinancialInputEntity);
            PFRM_PublicSectorAgencyFinancialInputEntity getPublicSectorAgencyEntity = riskModelExcelEntity.PFRM_PublicSectorAgencyFinancialInputEntity;

            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getPublicSectorAgencyEntity.GetType().GetProperty(property.Name).GetValue(getPublicSectorAgencyEntity, null);
                        value = obj.ToString();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            try
                            {
                                value = Convert.ToString(double.Parse(value) / 100);
                            }
                            catch
                            {

                            }
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            return true;
        }


        public bool Get_OutputDetails_InterOp_DetailsId(int detailsId, string companyName, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Key Financials List

            List<PFRM_OutputDetailsEntity> getOutputDetails = dbContext.PFRM_Output_Details
              .Where(a => a.DetailsId == detailsId
              )
              .Select(Outputs => new PFRM_OutputDetailsEntity
              {
                  Parameter_Name = Outputs.Parameter_Name,
                  Rank = Outputs.Rank,
                  Score = Outputs.Score,
              }).ToList();

            #endregion


            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Working"];

            uint rowIndex = 3;
            int columnIndex = 0;

            for (int i = 0; i < getOutputDetails.Count; i++)
            {
                columnIndex = _helperDAL.GetExcelColumnIndex("A");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].Parameter_Name;

                columnIndex = _helperDAL.GetExcelColumnIndex("B");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].Rank;

                columnIndex = _helperDAL.GetExcelColumnIndex("C");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].Score;

                rowIndex++;
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();


            return true;
        }

    }

}