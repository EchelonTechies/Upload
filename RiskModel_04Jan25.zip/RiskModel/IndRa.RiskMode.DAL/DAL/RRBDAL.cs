﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Text;
using IndRa.RiskModel.DAL.Entities;
using System.Reflection;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using IndRa.RiskModel.DAL.DataAccess;
using System.Data.Entity.Validation;
using IndRa.RiskModel.DAL.DAL;
using System.Data.Entity;
using IndRa.RiskModel.DAL.Helpers;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using IndRa.RiskModel.Helpers;
//using Microsoft.Office.Interop.Excel;

namespace IndRa.RiskModel.DAL
{
    public class RRBDAL
    {
        HelperDAL _helperDAL = null;
        IndRaDBcontext dbContext = new IndRaDBcontext();

        public RRBDAL()
        {
            _helperDAL = new HelperDAL();
        }

        public List<RRB_OutputDetailsEntity> GetOutputTemplateEntity()
        {
            List<RRB_OutputDetailsEntity> outputTemplate = new List<RRB_OutputDetailsEntity>();
            outputTemplate = dbContext.RRB_Output_Template.Where(a => a.InActive == null).OrderBy(a => a.Ranking).Select(output => new RRB_OutputDetailsEntity
            {
                TemplateID = output.TemplateID,
                Parameter1 = string.IsNullOrEmpty(output.Parameter1) ? string.Empty : output.Parameter1,
                Parameter1Per = string.IsNullOrEmpty(output.Parameter1Per) ? string.Empty : output.Parameter1Per,
                Parameter2 = string.IsNullOrEmpty(output.Parameter2) ? string.Empty : output.Parameter2,
                Parameter2Per = string.IsNullOrEmpty(output.Parameter2Per) ? string.Empty : output.Parameter2Per,
                Parameter3 = string.IsNullOrEmpty(output.Parameter3) ? string.Empty : output.Parameter3,
                Parameter3Per = string.Empty,
                UnderBaselIII_Score = string.Empty,
                UnderBaselIII_Value = string.Empty,
                UnderIND_Score = string.Empty,
                UnderIND_Value = string.Empty,
                Comments = string.Empty,
            }).ToList();
            return outputTemplate;
        }

        public RRB_BasicDetailsEntity GetBasicDetails(int detailsId)
        {
            RRB_BasicDetailsEntity basicDetails = new RRB_BasicDetailsEntity();
            RRB_KeyFinancialsEntity keyFinancials = new RRB_KeyFinancialsEntity();
            RRB_SubjectiveParametersEntity subjectiveParameters = new RRB_SubjectiveParametersEntity();
            List<RRB_OutputDetailsEntity> outputDetails = new List<RRB_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details.Where(data => data.DetailsId == detailsId).Select(x => new RRB_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = 0,
                FinYear = x.FinYear,
                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                DateOfInput = x.DateOfInput,
                //FinancialYearEndingDate = x.FinancialYearEndingDate,
                CurrencyUnits = x.CurrencyUnits,
                //ParentCompanyIsExist = x.ParentCompanyIsExist,
                ParentCompanyName = x.ParentCompanyName,
                ParentCompanyId = x.ParentCompanyId,
                ParentRating = x.ParentRating,
                SponsorBank = x.SponsorBank,
                ParentCompanyShareHoldingPer = x.ParentCompanyShareHoldingPer,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

                IsFinal = x.IsFinal.Value
            }).FirstOrDefault();

            keyFinancials = dbContext.RRB_KeyFinancials.Where(data => data.DetailsId == detailsId).Select(keyFinancialsEntity => new RRB_KeyFinancialsEntity
            {
                DetailsId = detailsId,
                PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                PeriodEndingDate3 = keyFinancialsEntity.PeriodEndingDate3,
                NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3,
                Currency1 = keyFinancialsEntity.Currency1,
                Currency2 = keyFinancialsEntity.Currency2,
                Currency3 = keyFinancialsEntity.Currency3,
                NetWorth1 = keyFinancialsEntity.NetWorth1,
                NetWorth2 = keyFinancialsEntity.NetWorth2,
                NetWorth3 = keyFinancialsEntity.NetWorth3,
                TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                TotalAssets3 = keyFinancialsEntity.TotalAssets3,
                TotalDeposits1 = keyFinancialsEntity.TotalDeposits1,
                TotalDeposits2 = keyFinancialsEntity.TotalDeposits2,
                TotalDeposits3 = keyFinancialsEntity.TotalDeposits3,
                TotalAdvances1 = keyFinancialsEntity.TotalAdvances1,
                TotalAdvances2 = keyFinancialsEntity.TotalAdvances2,
                TotalAdvances3 = keyFinancialsEntity.TotalAdvances3,
                InterestIncome1 = keyFinancialsEntity.InterestIncome1,
                InterestIncome2 = keyFinancialsEntity.InterestIncome2,
                InterestIncome3 = keyFinancialsEntity.InterestIncome3,
                NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1,
                NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2,
                NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3,
                InterestExpenses1 = keyFinancialsEntity.InterestExpenses1,
                InterestExpenses2 = keyFinancialsEntity.InterestExpenses2,
                InterestExpenses3 = keyFinancialsEntity.InterestExpenses3,
                EmployeeGAandSDExpensesExpenses1 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses1,
                EmployeeGAandSDExpensesExpenses2 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses2,
                EmployeeGAandSDExpensesExpenses3 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses3,
                PAT1 = keyFinancialsEntity.PAT1,
                PAT2 = keyFinancialsEntity.PAT2,
                PAT3 = keyFinancialsEntity.PAT3,
                LiquidAssets1 = keyFinancialsEntity.LiquidAssets1,
                LiquidAssets2 = keyFinancialsEntity.LiquidAssets2,
                LiquidAssets3 = keyFinancialsEntity.LiquidAssets3,
                ProvForNPAsandWriteoffs1 = keyFinancialsEntity.ProvForNPAsandWriteoffs1,
                ProvForNPAsandWriteoffs2 = keyFinancialsEntity.ProvForNPAsandWriteoffs2,
                ProvForNPAsandWriteoffs3 = keyFinancialsEntity.ProvForNPAsandWriteoffs3,
                CASAPer1 = keyFinancialsEntity.CASAPer1,
                CASAPer2 = keyFinancialsEntity.CASAPer2,
                CASAPer3 = keyFinancialsEntity.CASAPer3,
                //AdvancestoAgricultureSectorPer1 = keyFinancialsEntity.AdvancestoAgricultureSectorPer1,
                //AdvancestoAgricultureSectorPer2 = keyFinancialsEntity.AdvancestoAgricultureSectorPer2,
                //AdvancestoAgricultureSectorPer3 = keyFinancialsEntity.AdvancestoAgricultureSectorPer3,

                AdvancestoPrioritySectorPer1 = keyFinancialsEntity.AdvancestoPrioritySectorPer1,
                AdvancestoPrioritySectorPer2 = keyFinancialsEntity.AdvancestoPrioritySectorPer2,
                AdvancestoPrioritySectorPer3 = keyFinancialsEntity.AdvancestoPrioritySectorPer3,

                CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1,
                CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2,
                CostOfDepositsPer3 = keyFinancialsEntity.CostOfDepositsPer3,
                CRARPer1 = keyFinancialsEntity.CRARPer1,
                CRARPer2 = keyFinancialsEntity.CRARPer2,
                CRARPer3 = keyFinancialsEntity.CRARPer3,
                Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                Tier1Per3 = keyFinancialsEntity.Tier1Per3,
                NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                NetNPAPer3 = keyFinancialsEntity.NetNPAPer3,
                AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3,
                GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3,
                ContingentLiability1 = keyFinancialsEntity.ContingentLiability1,
                ContingentLiability2 = keyFinancialsEntity.ContingentLiability2,
                ContingentLiability3 = keyFinancialsEntity.ContingentLiability3,
                //ALMGapin6MonthsBucketPer1 = keyFinancialsEntity.ALMGapin6MonthsBucketPer1,
                //ALMGapin6MonthsBucketPer2 = keyFinancialsEntity.ALMGapin6MonthsBucketPer2,
                //ALMGapin6MonthsBucketPer3 = keyFinancialsEntity.ALMGapin6MonthsBucketPer3,
                BusinessPerEmployee1 = keyFinancialsEntity.BusinessPerEmployee1,
                BusinessPerEmployee2 = keyFinancialsEntity.BusinessPerEmployee2,
                BusinessPerEmployee3 = keyFinancialsEntity.BusinessPerEmployee3,
                SecuredAdvancesTotalAdvancesPer1 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer1,
                SecuredAdvancesTotalAdvancesPer2 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer2,
                SecuredAdvancesTotalAdvancesPer3 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer3,
                StateEconomicGrowthGSDPPer1 = keyFinancialsEntity.StateEconomicGrowthGSDPPer1,
                StateEconomicGrowthGSDPPer2 = keyFinancialsEntity.StateEconomicGrowthGSDPPer2,
                StateEconomicGrowthGSDPPer3 = keyFinancialsEntity.StateEconomicGrowthGSDPPer3,

            }).FirstOrDefault();

            subjectiveParameters = dbContext.RRB_SubjectiveParameters.Where(data => data.DetailsId == detailsId).Select(subjectiveParametersEntity => new RRB_SubjectiveParametersEntity
            {
                IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                RecentClimaticCondition = subjectiveParametersEntity.RecentClimaticCondition,
                AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS,
                ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                AdverseNews = subjectiveParametersEntity.AdverseNews,
                CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                NPASysGen = subjectiveParametersEntity.NPASysGen,
                NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

            }).FirstOrDefault();

            outputDetails = (from output in dbContext.RRB_Output_Details
                             join template in dbContext.RRB_Output_Template on output.TemplateId equals template.TemplateID
                             where output.DetailsId == detailsId

                             select new RRB_OutputDetailsEntity
                             {
                                 TemplateID = output.TemplateId,
                                 Parameter1 = string.IsNullOrEmpty(template.Parameter1) ? string.Empty : template.Parameter1,
                                 Parameter1Per = string.IsNullOrEmpty(template.Parameter1Per) ? string.Empty : template.Parameter1Per,
                                 Parameter2 = string.IsNullOrEmpty(template.Parameter2) ? string.Empty : template.Parameter2,
                                 Parameter2Per = string.IsNullOrEmpty(template.Parameter2Per) ? string.Empty : template.Parameter2Per,
                                 Parameter3Per = output.Parameter_Per,
                                 Parameter3 = output.Parameter_Name,
                                 UnderBaselIII_Score = string.IsNullOrEmpty(output.UnderBaselIII_Score) ? string.Empty : output.UnderBaselIII_Score,
                                 UnderBaselIII_Value = string.IsNullOrEmpty(output.UnderBaselIII_Value) ? string.Empty : output.UnderBaselIII_Value,
                                 UnderIND_Score = string.IsNullOrEmpty(output.UnderIND_Score) ? string.Empty : output.UnderIND_Score,
                                 UnderIND_Value = string.IsNullOrEmpty(output.UnderIND_Value) ? string.Empty : output.UnderIND_Value,
                                 Comments = string.IsNullOrEmpty(output.Comments) ? string.Empty : output.Comments,
                             }).ToList();


            basicDetails.RRB_KeyFinancialsEntity = keyFinancials;
            basicDetails.RRB_SubjectiveParametersEntity = subjectiveParameters;
            basicDetails.RRB_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public RRB_BasicDetailsEntity GetBasicDetails_Archive(int detailsId,short logId)
        {
            RRB_BasicDetailsEntity basicDetails = new RRB_BasicDetailsEntity();
            RRB_KeyFinancialsEntity keyFinancials = new RRB_KeyFinancialsEntity();
            RRB_SubjectiveParametersEntity subjectiveParameters = new RRB_SubjectiveParametersEntity();
            List<RRB_OutputDetailsEntity> outputDetails = new List<RRB_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(x => new RRB_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = logId,
                FinYear = x.FinYear,
                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                DateOfInput = x.DateOfInput,
                //FinancialYearEndingDate = x.FinancialYearEndingDate,
                CurrencyUnits = x.CurrencyUnits,
                //ParentCompanyIsExist = x.ParentCompanyIsExist,
                ParentCompanyName = x.ParentCompanyName,
                ParentCompanyId = x.ParentCompanyId,
                ParentRating = x.ParentRating,
                SponsorBank = x.SponsorBank,
                ParentCompanyShareHoldingPer = x.ParentCompanyShareHoldingPer,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

                IsFinal = x.IsFinal.Value
            }).FirstOrDefault();

            keyFinancials = dbContext.RRB_KeyFinancials_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(keyFinancialsEntity => new RRB_KeyFinancialsEntity
            {
                DetailsId = detailsId,
                PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                PeriodEndingDate3 = keyFinancialsEntity.PeriodEndingDate3,
                NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3,
                Currency1 = keyFinancialsEntity.Currency1,
                Currency2 = keyFinancialsEntity.Currency2,
                Currency3 = keyFinancialsEntity.Currency3,
                NetWorth1 = keyFinancialsEntity.NetWorth1,
                NetWorth2 = keyFinancialsEntity.NetWorth2,
                NetWorth3 = keyFinancialsEntity.NetWorth3,
                TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                TotalAssets3 = keyFinancialsEntity.TotalAssets3,
                TotalDeposits1 = keyFinancialsEntity.TotalDeposits1,
                TotalDeposits2 = keyFinancialsEntity.TotalDeposits2,
                TotalDeposits3 = keyFinancialsEntity.TotalDeposits3,
                TotalAdvances1 = keyFinancialsEntity.TotalAdvances1,
                TotalAdvances2 = keyFinancialsEntity.TotalAdvances2,
                TotalAdvances3 = keyFinancialsEntity.TotalAdvances3,
                InterestIncome1 = keyFinancialsEntity.InterestIncome1,
                InterestIncome2 = keyFinancialsEntity.InterestIncome2,
                InterestIncome3 = keyFinancialsEntity.InterestIncome3,
                NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1,
                NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2,
                NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3,
                InterestExpenses1 = keyFinancialsEntity.InterestExpenses1,
                InterestExpenses2 = keyFinancialsEntity.InterestExpenses2,
                InterestExpenses3 = keyFinancialsEntity.InterestExpenses3,
                EmployeeGAandSDExpensesExpenses1 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses1,
                EmployeeGAandSDExpensesExpenses2 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses2,
                EmployeeGAandSDExpensesExpenses3 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses3,
                PAT1 = keyFinancialsEntity.PAT1,
                PAT2 = keyFinancialsEntity.PAT2,
                PAT3 = keyFinancialsEntity.PAT3,
                LiquidAssets1 = keyFinancialsEntity.LiquidAssets1,
                LiquidAssets2 = keyFinancialsEntity.LiquidAssets2,
                LiquidAssets3 = keyFinancialsEntity.LiquidAssets3,
                ProvForNPAsandWriteoffs1 = keyFinancialsEntity.ProvForNPAsandWriteoffs1,
                ProvForNPAsandWriteoffs2 = keyFinancialsEntity.ProvForNPAsandWriteoffs2,
                ProvForNPAsandWriteoffs3 = keyFinancialsEntity.ProvForNPAsandWriteoffs3,
                CASAPer1 = keyFinancialsEntity.CASAPer1,
                CASAPer2 = keyFinancialsEntity.CASAPer2,
                CASAPer3 = keyFinancialsEntity.CASAPer3,
                //AdvancestoAgricultureSectorPer1 = keyFinancialsEntity.AdvancestoAgricultureSectorPer1,
                //AdvancestoAgricultureSectorPer2 = keyFinancialsEntity.AdvancestoAgricultureSectorPer2,
                //AdvancestoAgricultureSectorPer3 = keyFinancialsEntity.AdvancestoAgricultureSectorPer3,

                AdvancestoPrioritySectorPer1 = keyFinancialsEntity.AdvancestoPrioritySectorPer1,
                AdvancestoPrioritySectorPer2 = keyFinancialsEntity.AdvancestoPrioritySectorPer2,
                AdvancestoPrioritySectorPer3 = keyFinancialsEntity.AdvancestoPrioritySectorPer3,

                CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1,
                CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2,
                CostOfDepositsPer3 = keyFinancialsEntity.CostOfDepositsPer3,
                CRARPer1 = keyFinancialsEntity.CRARPer1,
                CRARPer2 = keyFinancialsEntity.CRARPer2,
                CRARPer3 = keyFinancialsEntity.CRARPer3,
                Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                Tier1Per3 = keyFinancialsEntity.Tier1Per3,
                NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                NetNPAPer3 = keyFinancialsEntity.NetNPAPer3,
                AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3,
                GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3,
                ContingentLiability1 = keyFinancialsEntity.ContingentLiability1,
                ContingentLiability2 = keyFinancialsEntity.ContingentLiability2,
                ContingentLiability3 = keyFinancialsEntity.ContingentLiability3,
                //ALMGapin6MonthsBucketPer1 = keyFinancialsEntity.ALMGapin6MonthsBucketPer1,
                //ALMGapin6MonthsBucketPer2 = keyFinancialsEntity.ALMGapin6MonthsBucketPer2,
                //ALMGapin6MonthsBucketPer3 = keyFinancialsEntity.ALMGapin6MonthsBucketPer3,
                BusinessPerEmployee1 = keyFinancialsEntity.BusinessPerEmployee1,
                BusinessPerEmployee2 = keyFinancialsEntity.BusinessPerEmployee2,
                BusinessPerEmployee3 = keyFinancialsEntity.BusinessPerEmployee3,
                SecuredAdvancesTotalAdvancesPer1 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer1,
                SecuredAdvancesTotalAdvancesPer2 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer2,
                SecuredAdvancesTotalAdvancesPer3 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer3,
                StateEconomicGrowthGSDPPer1 = keyFinancialsEntity.StateEconomicGrowthGSDPPer1,
                StateEconomicGrowthGSDPPer2 = keyFinancialsEntity.StateEconomicGrowthGSDPPer2,
                StateEconomicGrowthGSDPPer3 = keyFinancialsEntity.StateEconomicGrowthGSDPPer3,

            }).FirstOrDefault();

            subjectiveParameters = dbContext.RRB_SubjectiveParameters_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(subjectiveParametersEntity => new RRB_SubjectiveParametersEntity
            {
                IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                RecentClimaticCondition = subjectiveParametersEntity.RecentClimaticCondition,
                AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS,
                ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                AdverseNews = subjectiveParametersEntity.AdverseNews,
                CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                NPASysGen = subjectiveParametersEntity.NPASysGen,
                NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

            }).FirstOrDefault();

            outputDetails = (from output in dbContext.RRB_Output_Details_Archive
                             join template in dbContext.RRB_Output_Template on output.TemplateId equals template.TemplateID
                             where output.DetailsId == detailsId && output.LogId == logId

                             select new RRB_OutputDetailsEntity
                             {
                                 TemplateID = output.TemplateId,
                                 Parameter1 = string.IsNullOrEmpty(template.Parameter1) ? string.Empty : template.Parameter1,
                                 Parameter1Per = string.IsNullOrEmpty(template.Parameter1Per) ? string.Empty : template.Parameter1Per,
                                 Parameter2 = string.IsNullOrEmpty(template.Parameter2) ? string.Empty : template.Parameter2,
                                 Parameter2Per = string.IsNullOrEmpty(template.Parameter2Per) ? string.Empty : template.Parameter2Per,
                                 Parameter3Per = output.Parameter_Per,
                                 Parameter3 = output.Parameter_Name,
                                 UnderBaselIII_Score = string.IsNullOrEmpty(output.UnderBaselIII_Score) ? string.Empty : output.UnderBaselIII_Score,
                                 UnderBaselIII_Value = string.IsNullOrEmpty(output.UnderBaselIII_Value) ? string.Empty : output.UnderBaselIII_Value,
                                 UnderIND_Score = string.IsNullOrEmpty(output.UnderIND_Score) ? string.Empty : output.UnderIND_Score,
                                 UnderIND_Value = string.IsNullOrEmpty(output.UnderIND_Value) ? string.Empty : output.UnderIND_Value,
                                 Comments = string.IsNullOrEmpty(output.Comments) ? string.Empty : output.Comments,
                             }).ToList();


            basicDetails.RRB_KeyFinancialsEntity = keyFinancials;
            basicDetails.RRB_SubjectiveParametersEntity = subjectiveParameters;
            basicDetails.RRB_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public RRB_BasicDetailsEntity ImportCompanyDetailsFromExcel(string filePath, string fileName, string workSheet, int userId)
        {
            RRB_BasicDetailsEntity basicDetails = new RRB_BasicDetailsEntity();
            RRB_KeyFinancialsEntity keyFinancials = new RRB_KeyFinancialsEntity();
            RRB_SubjectiveParametersEntity subjectiveParameters = new RRB_SubjectiveParametersEntity();
            string value = "";
            DataTable dtExcel = null;
            DataTable dtTranspose = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);
            dtTranspose = _helperDAL.GenerateTransposedTable(dtExcel);

            if (dtTranspose.Rows.Count > 0)
            {
                // get values for Basic Details
                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(basicDetails);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            value = dtTranspose.Rows[0][property.DisplayName].ToString();

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }
                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(basicDetails, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for Key financials
                properties = TypeDescriptor.GetProperties(keyFinancials);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(keyFinancials, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for Subjective Parameters
                properties = TypeDescriptor.GetProperties(subjectiveParameters);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            value = dtTranspose.Rows[2][property.DisplayName].ToString();

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(subjectiveParameters, safeValue);
                        }
                    }
                    catch { }

                }
                basicDetails.RRB_KeyFinancialsEntity = keyFinancials;
                basicDetails.RRB_SubjectiveParametersEntity = subjectiveParameters;
                CompanyDAL companyDAL = new CompanyDAL();
                int companyID = companyDAL.GetCompanyIDByCompanyName(basicDetails.CompanyName, userId);
                basicDetails.CompanyId = companyID;
                CommonDAL commonDAL = new CommonDAL();
                string finYear = commonDAL.GetFinYearBasedOnDate(DateTime.Now);
                basicDetails.FinYear = finYear;
                //if (basicDetails.DateOfInput.HasValue)
                //{
                //    DateTime dateOfInput = basicDetails.DateOfInput.Value;
                //    string finYear = commonDAL.GetFinYearBasedOnDate(basicDetails.DateOfInput.Value);
                //    basicDetails.FinYear = finYear;
                //}
            }

            return basicDetails;

        }

        public bool ComputeOutputDetails(RRB_BasicDetailsEntity riskModelExcelEntity, string OutputTemplateFilePath)
        {
            CompanyDAL companyDAL = new CompanyDAL();
            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            try
            {
                mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                mWorkSheets = mWorkBook.Worksheets;
                mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Input Sheet"];

                string value = "";
                uint rowIndex = 0;
                int columnIndex = 0;

                string columnName = "";
                object obj;

                // Basic detail fields update - Company Name
                try
                {
                    string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);
                    rowIndex = _helperDAL.GetExcelRowIndex("B4");
                    columnName = _helperDAL.GetExcelColumnName("B4");
                    columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                    mWSheet.Cells[rowIndex, columnIndex] = companyName;

                    rowIndex = _helperDAL.GetExcelRowIndex("B1");
                    columnName = _helperDAL.GetExcelColumnName("B1");
                    columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                    mWSheet.Cells[rowIndex, columnIndex] = riskModelExcelEntity.DateOfInput.Value.Date;

                }
                catch { }

                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
                properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = riskModelExcelEntity.GetType().GetProperty(property.Name).GetValue(riskModelExcelEntity, null);
                            value = obj.ToString();

                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                try
                                {
                                    value = Convert.ToString(double.Parse(value) / 100);
                                    //value = (value == string.Empty || value.ToUpper().Trim() == "NA") ? "0" : Convert.ToString(double.Parse(value) / 100);
                                }
                                catch
                                {

                                }
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                properties = TypeDescriptor.GetProperties(riskModelExcelEntity.RRB_KeyFinancialsEntity);
                RRB_KeyFinancialsEntity getKeyFinancialsEntity = riskModelExcelEntity.RRB_KeyFinancialsEntity;
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = getKeyFinancialsEntity.GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity, null);
                            value = obj.ToString();
                            var type = getKeyFinancialsEntity.GetType().GetProperty(property.Name).ToString();
                            if (type.ToLower().Contains("system.datetime"))
                            {
                                try
                                {
                                    DateTime dt = Convert.ToDateTime(value.ToString());
                                    mWSheet.Cells[rowIndex, columnIndex] = dt.ToString("dd-MMM-yyyy");
                                }
                                catch { }
                            }
                            else
                            {
                                string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                                if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                                {
                                    try
                                    {
                                        value = Convert.ToString(double.Parse(value) / 100);
                                    }
                                    catch
                                    {

                                    }
                                    //value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                                }
                                mWSheet.Cells[rowIndex, columnIndex] = value;
                            }
                        }
                        catch { }
                    }
                }

                properties = TypeDescriptor.GetProperties(riskModelExcelEntity.RRB_SubjectiveParametersEntity);
                RRB_SubjectiveParametersEntity getSubjectiveParametersEntity = riskModelExcelEntity.RRB_SubjectiveParametersEntity;

                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = getSubjectiveParametersEntity.GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity, null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                mWorkBook.Save();
                mWorkBook.Close(1, null, null);
                xlApp.Quit();
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                mWSheet = null;
                mWorkBook = null;
                mWorkSheets = null;
                xlApp = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return true;
        }

        public bool Get_OutputDetailsFromFrontEnd_InterOp(int detailsID, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Basic Details List

            List<RRB_BasicDetailsEntity> getBasicDetailsEntity = dbContext.NHB_Details
              .Where(a => a.DetailsId == detailsID
              )
              .Select(riskModelExcelEntity => new RRB_BasicDetailsEntity
              {
                  CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                  ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                  SponsorBank = riskModelExcelEntity.SponsorBank,
                  ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
              }).ToList();

            #endregion

            #region Key Financials List

            List<RRB_KeyFinancialsEntity> getKeyFinancialsEntity = dbContext.RRB_KeyFinancials
              .Where(a => a.DetailsId == detailsID
              )
              .Select(keyFinancialsEntity => new RRB_KeyFinancialsEntity
              {
                  PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                  PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                  PeriodEndingDate3 = keyFinancialsEntity.PeriodEndingDate3,
                  NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                  NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                  NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3,
                  Currency1 = keyFinancialsEntity.Currency1,
                  Currency2 = keyFinancialsEntity.Currency2,
                  Currency3 = keyFinancialsEntity.Currency3,
                  NetWorth1 = keyFinancialsEntity.NetWorth1,
                  NetWorth2 = keyFinancialsEntity.NetWorth2,
                  NetWorth3 = keyFinancialsEntity.NetWorth3,
                  TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                  TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                  TotalAssets3 = keyFinancialsEntity.TotalAssets3,
                  TotalDeposits1 = keyFinancialsEntity.TotalDeposits1,
                  TotalDeposits2 = keyFinancialsEntity.TotalDeposits2,
                  TotalDeposits3 = keyFinancialsEntity.TotalDeposits3,
                  TotalAdvances1 = keyFinancialsEntity.TotalAdvances1,
                  TotalAdvances2 = keyFinancialsEntity.TotalAdvances2,
                  TotalAdvances3 = keyFinancialsEntity.TotalAdvances3,
                  InterestIncome1 = keyFinancialsEntity.InterestIncome1,
                  InterestIncome2 = keyFinancialsEntity.InterestIncome2,
                  InterestIncome3 = keyFinancialsEntity.InterestIncome3,
                  NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1,
                  NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2,
                  NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3,
                  InterestExpenses1 = keyFinancialsEntity.InterestExpenses1,
                  InterestExpenses2 = keyFinancialsEntity.InterestExpenses2,
                  InterestExpenses3 = keyFinancialsEntity.InterestExpenses3,
                  EmployeeGAandSDExpensesExpenses1 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses1,
                  EmployeeGAandSDExpensesExpenses2 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses2,
                  EmployeeGAandSDExpensesExpenses3 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses3,
                  PAT1 = keyFinancialsEntity.PAT1,
                  PAT2 = keyFinancialsEntity.PAT2,
                  PAT3 = keyFinancialsEntity.PAT3,
                  LiquidAssets1 = keyFinancialsEntity.LiquidAssets1,
                  LiquidAssets2 = keyFinancialsEntity.LiquidAssets2,
                  LiquidAssets3 = keyFinancialsEntity.LiquidAssets3,
                  ProvForNPAsandWriteoffs1 = keyFinancialsEntity.ProvForNPAsandWriteoffs1,
                  ProvForNPAsandWriteoffs2 = keyFinancialsEntity.ProvForNPAsandWriteoffs2,
                  ProvForNPAsandWriteoffs3 = keyFinancialsEntity.ProvForNPAsandWriteoffs3,
                  CASAPer1 = keyFinancialsEntity.CASAPer1,
                  CASAPer2 = keyFinancialsEntity.CASAPer2,
                  CASAPer3 = keyFinancialsEntity.CASAPer3,
                  //AdvancestoAgricultureSectorPer1 = keyFinancialsEntity.AdvancestoAgricultureSectorPer1,
                  //AdvancestoAgricultureSectorPer2 = keyFinancialsEntity.AdvancestoAgricultureSectorPer2,
                  //AdvancestoAgricultureSectorPer3 = keyFinancialsEntity.AdvancestoAgricultureSectorPer3,

                  AdvancestoPrioritySectorPer1 = keyFinancialsEntity.AdvancestoPrioritySectorPer1,
                  AdvancestoPrioritySectorPer2 = keyFinancialsEntity.AdvancestoPrioritySectorPer2,
                  AdvancestoPrioritySectorPer3 = keyFinancialsEntity.AdvancestoPrioritySectorPer3,

                  CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1,
                  CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2,
                  CostOfDepositsPer3 = keyFinancialsEntity.CostOfDepositsPer3,
                  CRARPer1 = keyFinancialsEntity.CRARPer1,
                  CRARPer2 = keyFinancialsEntity.CRARPer2,
                  CRARPer3 = keyFinancialsEntity.CRARPer3,
                  Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                  Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                  Tier1Per3 = keyFinancialsEntity.Tier1Per3,
                  NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                  NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                  NetNPAPer3 = keyFinancialsEntity.NetNPAPer3,
                  AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                  AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                  AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3,
                  GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                  GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                  GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3,
                  ContingentLiability1 = keyFinancialsEntity.ContingentLiability1,
                  ContingentLiability2 = keyFinancialsEntity.ContingentLiability2,
                  ContingentLiability3 = keyFinancialsEntity.ContingentLiability3,
                  //ALMGapin6MonthsBucketPer1 = keyFinancialsEntity.ALMGapin6MonthsBucketPer1,
                  //ALMGapin6MonthsBucketPer2 = keyFinancialsEntity.ALMGapin6MonthsBucketPer2,
                  //ALMGapin6MonthsBucketPer3 = keyFinancialsEntity.ALMGapin6MonthsBucketPer3,
                  BusinessPerEmployee1 = keyFinancialsEntity.BusinessPerEmployee1,
                  BusinessPerEmployee2 = keyFinancialsEntity.BusinessPerEmployee2,
                  BusinessPerEmployee3 = keyFinancialsEntity.BusinessPerEmployee3,
                  SecuredAdvancesTotalAdvancesPer1 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer1,
                  SecuredAdvancesTotalAdvancesPer2 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer2,
                  SecuredAdvancesTotalAdvancesPer3 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer3,
                  StateEconomicGrowthGSDPPer1 = keyFinancialsEntity.StateEconomicGrowthGSDPPer1,
                  StateEconomicGrowthGSDPPer2 = keyFinancialsEntity.StateEconomicGrowthGSDPPer2,
                  StateEconomicGrowthGSDPPer3 = keyFinancialsEntity.StateEconomicGrowthGSDPPer3,

              }).ToList();

            #endregion

            #region Subjective Parameters List

            List<RRB_SubjectiveParametersEntity> getSubjectiveParametersEntity = dbContext.RRB_SubjectiveParameters
              .Where(a => a.DetailsId == detailsID
              )
              .Select(subjectiveParametersEntity => new RRB_SubjectiveParametersEntity
              {
                  IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                  RecentClimaticCondition = subjectiveParametersEntity.RecentClimaticCondition,
                  AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS,
                  ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                  //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                  AdverseNews = subjectiveParametersEntity.AdverseNews,
                  CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                  AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                  AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                  NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                  NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                  LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                  CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                  NPASysGen = subjectiveParametersEntity.NPASysGen,
                  NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                  CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                  NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                  SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                  QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                  DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,
              }).ToList();

            #endregion


            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            //Get the already exists sheet
            //mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(2);
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Input Sheet"];

            string value = "";
            uint rowIndex = 0;
            int columnIndex = 0;

            string columnName = "";
            object obj;
            //mWSheet.Cells[11, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate1_Liabilities;

            RRB_BasicDetailsEntity RRB_BasicDetailsEntity = new RRB_BasicDetailsEntity();
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(RRB_BasicDetailsEntity);
            properties = TypeDescriptor.GetProperties(RRB_BasicDetailsEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getBasicDetailsEntity[0].GetType().GetProperty(property.Name).GetValue(getBasicDetailsEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }


            RRB_KeyFinancialsEntity RRB_KeyFinancialsEntity = new RRB_KeyFinancialsEntity();
            properties = TypeDescriptor.GetProperties(RRB_KeyFinancialsEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getKeyFinancialsEntity[0].GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            RRB_SubjectiveParametersEntity RRB_SubjectiveParametersEntity = new RRB_SubjectiveParametersEntity();
            properties = TypeDescriptor.GetProperties(RRB_SubjectiveParametersEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getSubjectiveParametersEntity[0].GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }


            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            return true;
        }

        public List<RRB_OutputDetailsEntity> GetOutputFromExcel(string filePath, string fileName, string workSheet, int userId)
        {
            List<RRB_OutputDetailsEntity> outputDetailsEntity = new List<RRB_OutputDetailsEntity>();
            DataTable dtExcel = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);

            string paramterName = "";

            if (dtExcel.Rows.Count > 0)
            {
                short row = 0;
                string underBaselIIIColumnName_Value = "Under Basel III";
                string underBaselIIIColumnName_Score = "";
                string UnderINDAS109ColumnName_Value = "Under IND AS 109";
                string UnderINDAS109ColumnName_Score = "";

                for (int col = 0; col < dtExcel.Columns.Count; col++)
                {
                    if (dtExcel.Columns[col].Caption == underBaselIIIColumnName_Value)
                    {
                        underBaselIIIColumnName_Score = dtExcel.Columns[col + 1].Caption;
                        continue;
                    }
                    else if (dtExcel.Columns[col].Caption == UnderINDAS109ColumnName_Value)
                    {
                        UnderINDAS109ColumnName_Score = dtExcel.Columns[col + 1].Caption;
                    }
                }
                for (int i = 1; i < dtExcel.Rows.Count; i++)
                {
                    RRB_OutputDetailsEntity newRow = new RRB_OutputDetailsEntity();
                    newRow.TemplateID = row;
                    paramterName = dtExcel.Rows[i]["F7"].ToString();
                    if (paramterName != string.Empty)
                    {
                    }
                    else
                    {
                        paramterName = dtExcel.Rows[i][0].ToString();
                    }
                    if (paramterName == string.Empty)
                    {
                        continue;
                    }
                    if (paramterName == "Rating / Probability of Default")
                    {
                        break;
                    }
                    newRow.Parameter1 = paramterName;
                    newRow.Parameter3Per = dtExcel.Rows[i]["F9"].ToString();
                    newRow.UnderBaselIII_Value = dtExcel.Rows[i][underBaselIIIColumnName_Value].ToString();
                    newRow.UnderBaselIII_Score = dtExcel.Rows[i][underBaselIIIColumnName_Score].ToString();

                    newRow.UnderIND_Value = dtExcel.Rows[i][UnderINDAS109ColumnName_Value].ToString();
                    newRow.UnderIND_Score = dtExcel.Rows[i][UnderINDAS109ColumnName_Score].ToString();

                    outputDetailsEntity.Add(newRow);
                    row++;
                }
            }

            return outputDetailsEntity;

        }

        public int SaveCompanyBasicDetailsAsDraft(int userId, int roleId, RRB_BasicDetailsEntity riskModelExcelEntity, out int basicDetails_ArchiveId, out short logID)
        {
            int detailsId = 0;
            basicDetails_ArchiveId = 0; 
            CompanyDAL companyDAL = new CompanyDAL();
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                bool isRecordExist = companyDAL.CheckIfAlreadyExists_CompanyDetails(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                if (isRecordExist == true && riskModelExcelEntity.DetailsId == 0)
                {
                    detailsId = companyDAL.GetCompanyBasicDetailsID(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                    riskModelExcelEntity.DetailsId = detailsId;
                }
                //DateTime? approvedDate = null;
                //DateTime? reviewDate = null;
                //approvedDate = companyDAL.GetDetailsApprovedDate(riskModelExcelEntity.DetailsId);
                //reviewDate = companyDAL.GetDetailsReviewedDate(riskModelExcelEntity.DetailsId);

                if (riskModelExcelEntity.ButtonValue == ButtonValue.SubmitForApporval.ToString()) //"SubmitForApporval"
                {
                    riskModelExcelEntity.SubmitForApproval = true;
                    riskModelExcelEntity.SubmitForApprovalDate = DateTime.Now;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                {
                    riskModelExcelEntity.ApprovedDate = DateTime.Now;
                    riskModelExcelEntity.ReviewedDate = null;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ReviewDetails.ToString())
                {
                    riskModelExcelEntity.ReviewedDate = DateTime.Now;
                    riskModelExcelEntity.ApprovedDate = null;
                }
                logID = companyDAL.GetNHBLogId(riskModelExcelEntity.DetailsId);

                NHB_Details_Archive nHB_Details_Archive = new NHB_Details_Archive
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = Convert.ToDateTime(riskModelExcelEntity.DateOfInput),
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    SponsorBank = riskModelExcelEntity.SponsorBank,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                    IsDraft = true
                };

                NHB_Details nHB_Details = new NHB_Details
                {
                    UserId = userId,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = Convert.ToDateTime(riskModelExcelEntity.DateOfInput),
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    SponsorBank = riskModelExcelEntity.SponsorBank,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                };

                NHB_Details_Final nHB_Details_Final = new NHB_Details_Final
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = Convert.ToDateTime(riskModelExcelEntity.DateOfInput),
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    SponsorBank = riskModelExcelEntity.SponsorBank,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                };

                if (userId != 0)
                {
                    #region Add Data

                    if (nHB_Details != null && companyDAL.CheckIfAlreadyExists_CompanyDetails(nHB_Details.CompanyId, nHB_Details.FinYear) == false)
                    {
                        try
                        {
                            detailsId = (int)companyDAL.AddCompanyDetails(nHB_Details);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }

                    }

                    #endregion

                    #region Update Data

                    else
                    {
                        try
                        {
                            NHB_Details details = dbContext.NHB_Details.Where(detail => detail.DetailsId == nHB_Details.DetailsId).FirstOrDefault();
                            if (details != null)
                            {
                                details.UserId = nHB_Details.UserId;
                                details.CompanyId = nHB_Details.CompanyId;
                                details.DateOfInput = nHB_Details.DateOfInput;
                                details.CurrencyUnits = nHB_Details.CurrencyUnits;
                                details.ParentCompanyId = nHB_Details.ParentCompanyId;
                                details.SponsorBank = nHB_Details.SponsorBank;
                                details.ParentCompanyName = nHB_Details.ParentCompanyName;
                                details.UpdatedBy = nHB_Details.UpdatedBy;
                                details.UpdatedDateTime = nHB_Details.UpdatedDateTime; 
                                details.Comments = riskModelExcelEntity.Comments;
                                details.FinalRating = riskModelExcelEntity.FinalRating;
                                details.PD = riskModelExcelEntity.PD;
                                details.SubmitForApproval = nHB_Details.SubmitForApproval;
                                details.SubmitForApprovalDate = nHB_Details.SubmitForApprovalDate;
                                details.ApprovedDate = nHB_Details.ApprovedDate;
                                details.ReviewedDate = nHB_Details.ReviewedDate;

                                details.IsFinal = nHB_Details.IsFinal;
                                dbContext.SaveChanges();
                                detailsId = details.DetailsId;
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return -1;
                            }
                        }
                        catch (Exception exception)
                        {
                            throw exception;
                        }
                    }

                    #endregion

                    #region Final Data Add

                    if (nHB_Details.IsFinal == true)
                    {
                        try
                        {
                            companyDAL.AddCompanyDetails_Final(nHB_Details_Final);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    if (isRecordExist == false)
                    {
                        nHB_Details_Archive.UpdatedBy = null;
                        nHB_Details_Archive.UpdatedDateTime = null;
                    }
                    else
                    {
                        nHB_Details_Archive.CreatedBy = null;
                        nHB_Details_Archive.CreatedDateTime = null;
                    }
                    nHB_Details_Archive.DetailsId = detailsId;
                    basicDetails_ArchiveId = (int)companyDAL.AddCompanyDetails_Archive(nHB_Details_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return detailsId;

        }


        public bool SaveAsDraft_KeyFinancial(int userId, int roleId, int detailID,short logID, DateTime CreatedDateTime, RRB_KeyFinancialsEntity keyFinancialsEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                RRB_KeyFinancials_Archive KeyFinancials_Archive = new RRB_KeyFinancials_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,

                    UserId = userId,
                    PeriodEndingDate1 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate1.ToString()),
                    PeriodEndingDate2 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate2.ToString()),
                    PeriodEndingDate3 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate3.ToString()),
                    NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                    NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                    NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3,
                    Currency1 = keyFinancialsEntity.Currency1,
                    Currency2 = keyFinancialsEntity.Currency2,
                    Currency3 = keyFinancialsEntity.Currency3,
                    NetWorth1 = keyFinancialsEntity.NetWorth1,
                    NetWorth2 = keyFinancialsEntity.NetWorth2,
                    NetWorth3 = keyFinancialsEntity.NetWorth3,
                    TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                    TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                    TotalAssets3 = keyFinancialsEntity.TotalAssets3,
                    TotalDeposits1 = keyFinancialsEntity.TotalDeposits1,
                    TotalDeposits2 = keyFinancialsEntity.TotalDeposits2,
                    TotalDeposits3 = keyFinancialsEntity.TotalDeposits3,
                    TotalAdvances1 = keyFinancialsEntity.TotalAdvances1,
                    TotalAdvances2 = keyFinancialsEntity.TotalAdvances2,
                    TotalAdvances3 = keyFinancialsEntity.TotalAdvances3,
                    InterestIncome1 = keyFinancialsEntity.InterestIncome1,
                    InterestIncome2 = keyFinancialsEntity.InterestIncome2,
                    InterestIncome3 = keyFinancialsEntity.InterestIncome3,
                    NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1,
                    NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2,
                    NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3,
                    InterestExpenses1 = keyFinancialsEntity.InterestExpenses1,
                    InterestExpenses2 = keyFinancialsEntity.InterestExpenses2,
                    InterestExpenses3 = keyFinancialsEntity.InterestExpenses3,
                    EmployeeGAandSDExpensesExpenses1 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses1,
                    EmployeeGAandSDExpensesExpenses2 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses2,
                    EmployeeGAandSDExpensesExpenses3 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses3,
                    PAT1 = keyFinancialsEntity.PAT1,
                    PAT2 = keyFinancialsEntity.PAT2,
                    PAT3 = keyFinancialsEntity.PAT3,
                    LiquidAssets1 = keyFinancialsEntity.LiquidAssets1,
                    LiquidAssets2 = keyFinancialsEntity.LiquidAssets2,
                    LiquidAssets3 = keyFinancialsEntity.LiquidAssets3,
                    ProvForNPAsandWriteoffs1 = keyFinancialsEntity.ProvForNPAsandWriteoffs1,
                    ProvForNPAsandWriteoffs2 = keyFinancialsEntity.ProvForNPAsandWriteoffs2,
                    ProvForNPAsandWriteoffs3 = keyFinancialsEntity.ProvForNPAsandWriteoffs3,
                    CASAPer1 = keyFinancialsEntity.CASAPer1,
                    CASAPer2 = keyFinancialsEntity.CASAPer2,
                    CASAPer3 = keyFinancialsEntity.CASAPer3,
                    //AdvancestoAgricultureSectorPer1 = keyFinancialsEntity.AdvancestoAgricultureSectorPer1,
                    //AdvancestoAgricultureSectorPer2 = keyFinancialsEntity.AdvancestoAgricultureSectorPer2,
                    //AdvancestoAgricultureSectorPer3 = keyFinancialsEntity.AdvancestoAgricultureSectorPer3,
                    AdvancestoPrioritySectorPer1 = keyFinancialsEntity.AdvancestoPrioritySectorPer1,
                    AdvancestoPrioritySectorPer2 = keyFinancialsEntity.AdvancestoPrioritySectorPer2,
                    AdvancestoPrioritySectorPer3 = keyFinancialsEntity.AdvancestoPrioritySectorPer3,

                    CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1,
                    CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2,
                    CostOfDepositsPer3 = keyFinancialsEntity.CostOfDepositsPer3,
                    CRARPer1 = keyFinancialsEntity.CRARPer1,
                    CRARPer2 = keyFinancialsEntity.CRARPer2,
                    CRARPer3 = keyFinancialsEntity.CRARPer3,
                    Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                    Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                    Tier1Per3 = keyFinancialsEntity.Tier1Per3,
                    NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                    NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                    NetNPAPer3 = keyFinancialsEntity.NetNPAPer3,
                    AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                    AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                    AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3,
                    GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                    GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                    GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3,
                    ContingentLiability1 = keyFinancialsEntity.ContingentLiability1,
                    ContingentLiability2 = keyFinancialsEntity.ContingentLiability2,
                    ContingentLiability3 = keyFinancialsEntity.ContingentLiability3,
                    //ALMGapin6MonthsBucketPer1 = keyFinancialsEntity.ALMGapin6MonthsBucketPer1,
                    //ALMGapin6MonthsBucketPer2 = keyFinancialsEntity.ALMGapin6MonthsBucketPer2,
                    //ALMGapin6MonthsBucketPer3 = keyFinancialsEntity.ALMGapin6MonthsBucketPer3,
                    BusinessPerEmployee1 = keyFinancialsEntity.BusinessPerEmployee1,
                    BusinessPerEmployee2 = keyFinancialsEntity.BusinessPerEmployee2,
                    BusinessPerEmployee3 = keyFinancialsEntity.BusinessPerEmployee3,
                    SecuredAdvancesTotalAdvancesPer1 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer1,
                    SecuredAdvancesTotalAdvancesPer2 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer2,
                    SecuredAdvancesTotalAdvancesPer3 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer3,
                    StateEconomicGrowthGSDPPer1 = keyFinancialsEntity.StateEconomicGrowthGSDPPer1,
                    StateEconomicGrowthGSDPPer2 = keyFinancialsEntity.StateEconomicGrowthGSDPPer2,
                    StateEconomicGrowthGSDPPer3 = keyFinancialsEntity.StateEconomicGrowthGSDPPer3,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                RRB_KeyFinancials KeyFinancials = new RRB_KeyFinancials
                {
                    DetailsId = detailID,

                    PeriodEndingDate1 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate1),
                    PeriodEndingDate2 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate2),
                    PeriodEndingDate3 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate3),
                    NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                    NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                    NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3,
                    Currency1 = keyFinancialsEntity.Currency1,
                    Currency2 = keyFinancialsEntity.Currency2,
                    Currency3 = keyFinancialsEntity.Currency3,
                    NetWorth1 = keyFinancialsEntity.NetWorth1,
                    NetWorth2 = keyFinancialsEntity.NetWorth2,
                    NetWorth3 = keyFinancialsEntity.NetWorth3,
                    TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                    TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                    TotalAssets3 = keyFinancialsEntity.TotalAssets3,
                    TotalDeposits1 = keyFinancialsEntity.TotalDeposits1,
                    TotalDeposits2 = keyFinancialsEntity.TotalDeposits2,
                    TotalDeposits3 = keyFinancialsEntity.TotalDeposits3,
                    TotalAdvances1 = keyFinancialsEntity.TotalAdvances1,
                    TotalAdvances2 = keyFinancialsEntity.TotalAdvances2,
                    TotalAdvances3 = keyFinancialsEntity.TotalAdvances3,
                    InterestIncome1 = keyFinancialsEntity.InterestIncome1,
                    InterestIncome2 = keyFinancialsEntity.InterestIncome2,
                    InterestIncome3 = keyFinancialsEntity.InterestIncome3,
                    NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1,
                    NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2,
                    NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3,
                    InterestExpenses1 = keyFinancialsEntity.InterestExpenses1,
                    InterestExpenses2 = keyFinancialsEntity.InterestExpenses2,
                    InterestExpenses3 = keyFinancialsEntity.InterestExpenses3,
                    EmployeeGAandSDExpensesExpenses1 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses1,
                    EmployeeGAandSDExpensesExpenses2 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses2,
                    EmployeeGAandSDExpensesExpenses3 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses3,
                    PAT1 = keyFinancialsEntity.PAT1,
                    PAT2 = keyFinancialsEntity.PAT2,
                    PAT3 = keyFinancialsEntity.PAT3,
                    LiquidAssets1 = keyFinancialsEntity.LiquidAssets1,
                    LiquidAssets2 = keyFinancialsEntity.LiquidAssets2,
                    LiquidAssets3 = keyFinancialsEntity.LiquidAssets3,
                    ProvForNPAsandWriteoffs1 = keyFinancialsEntity.ProvForNPAsandWriteoffs1,
                    ProvForNPAsandWriteoffs2 = keyFinancialsEntity.ProvForNPAsandWriteoffs2,
                    ProvForNPAsandWriteoffs3 = keyFinancialsEntity.ProvForNPAsandWriteoffs3,
                    CASAPer1 = keyFinancialsEntity.CASAPer1,
                    CASAPer2 = keyFinancialsEntity.CASAPer2,
                    CASAPer3 = keyFinancialsEntity.CASAPer3,
                    //AdvancestoAgricultureSectorPer1 = keyFinancialsEntity.AdvancestoAgricultureSectorPer1,
                    //AdvancestoAgricultureSectorPer2 = keyFinancialsEntity.AdvancestoAgricultureSectorPer2,
                    //AdvancestoAgricultureSectorPer3 = keyFinancialsEntity.AdvancestoAgricultureSectorPer3,

                    AdvancestoPrioritySectorPer1 = keyFinancialsEntity.AdvancestoPrioritySectorPer1,
                    AdvancestoPrioritySectorPer2 = keyFinancialsEntity.AdvancestoPrioritySectorPer2,
                    AdvancestoPrioritySectorPer3 = keyFinancialsEntity.AdvancestoPrioritySectorPer3,

                    CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1,
                    CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2,
                    CostOfDepositsPer3 = keyFinancialsEntity.CostOfDepositsPer3,
                    CRARPer1 = keyFinancialsEntity.CRARPer1,
                    CRARPer2 = keyFinancialsEntity.CRARPer2,
                    CRARPer3 = keyFinancialsEntity.CRARPer3,
                    Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                    Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                    Tier1Per3 = keyFinancialsEntity.Tier1Per3,
                    NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                    NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                    NetNPAPer3 = keyFinancialsEntity.NetNPAPer3,
                    AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                    AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                    AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3,
                    GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                    GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                    GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3,
                    ContingentLiability1 = keyFinancialsEntity.ContingentLiability1,
                    ContingentLiability2 = keyFinancialsEntity.ContingentLiability2,
                    ContingentLiability3 = keyFinancialsEntity.ContingentLiability3,
                    //ALMGapin6MonthsBucketPer1 = keyFinancialsEntity.ALMGapin6MonthsBucketPer1,
                    //ALMGapin6MonthsBucketPer2 = keyFinancialsEntity.ALMGapin6MonthsBucketPer2,
                    //ALMGapin6MonthsBucketPer3 = keyFinancialsEntity.ALMGapin6MonthsBucketPer3,
                    BusinessPerEmployee1 = keyFinancialsEntity.BusinessPerEmployee1,
                    BusinessPerEmployee2 = keyFinancialsEntity.BusinessPerEmployee2,
                    BusinessPerEmployee3 = keyFinancialsEntity.BusinessPerEmployee3,
                    SecuredAdvancesTotalAdvancesPer1 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer1,
                    SecuredAdvancesTotalAdvancesPer2 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer2,
                    SecuredAdvancesTotalAdvancesPer3 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer3,
                    StateEconomicGrowthGSDPPer1 = keyFinancialsEntity.StateEconomicGrowthGSDPPer1,
                    StateEconomicGrowthGSDPPer2 = keyFinancialsEntity.StateEconomicGrowthGSDPPer2,
                    StateEconomicGrowthGSDPPer3 = keyFinancialsEntity.StateEconomicGrowthGSDPPer3,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (KeyFinancials != null && CheckIfAlreadyExists_KeyFinancial(detailID) == false)
                    {
                        try
                        {
                            status = Add_KeyFinancial(KeyFinancials);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            RRB_KeyFinancials keyFinancials_Update = dbContext.RRB_KeyFinancials.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            keyFinancials_Update.PeriodEndingDate1 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate1);
                            keyFinancials_Update.PeriodEndingDate2 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate2);
                            keyFinancials_Update.PeriodEndingDate3 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate3);
                            keyFinancials_Update.NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1;
                            keyFinancials_Update.NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2;
                            keyFinancials_Update.NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3;
                            keyFinancials_Update.Currency1 = keyFinancialsEntity.Currency1;
                            keyFinancials_Update.Currency2 = keyFinancialsEntity.Currency2;
                            keyFinancials_Update.Currency3 = keyFinancialsEntity.Currency3;
                            keyFinancials_Update.NetWorth1 = keyFinancialsEntity.NetWorth1;
                            keyFinancials_Update.NetWorth2 = keyFinancialsEntity.NetWorth2;
                            keyFinancials_Update.NetWorth3 = keyFinancialsEntity.NetWorth3;
                            keyFinancials_Update.TotalAssets1 = keyFinancialsEntity.TotalAssets1;
                            keyFinancials_Update.TotalAssets2 = keyFinancialsEntity.TotalAssets2;
                            keyFinancials_Update.TotalAssets3 = keyFinancialsEntity.TotalAssets3;
                            keyFinancials_Update.TotalDeposits1 = keyFinancialsEntity.TotalDeposits1;
                            keyFinancials_Update.TotalDeposits2 = keyFinancialsEntity.TotalDeposits2;
                            keyFinancials_Update.TotalDeposits3 = keyFinancialsEntity.TotalDeposits3;
                            keyFinancials_Update.TotalAdvances1 = keyFinancialsEntity.TotalAdvances1;
                            keyFinancials_Update.TotalAdvances2 = keyFinancialsEntity.TotalAdvances2;
                            keyFinancials_Update.TotalAdvances3 = keyFinancialsEntity.TotalAdvances3;
                            keyFinancials_Update.InterestIncome1 = keyFinancialsEntity.InterestIncome1;
                            keyFinancials_Update.InterestIncome2 = keyFinancialsEntity.InterestIncome2;
                            keyFinancials_Update.InterestIncome3 = keyFinancialsEntity.InterestIncome3;
                            keyFinancials_Update.NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1;
                            keyFinancials_Update.NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2;
                            keyFinancials_Update.NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3;
                            keyFinancials_Update.InterestExpenses1 = keyFinancialsEntity.InterestExpenses1;
                            keyFinancials_Update.InterestExpenses2 = keyFinancialsEntity.InterestExpenses2;
                            keyFinancials_Update.InterestExpenses3 = keyFinancialsEntity.InterestExpenses3;
                            keyFinancials_Update.EmployeeGAandSDExpensesExpenses1 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses1;
                            keyFinancials_Update.EmployeeGAandSDExpensesExpenses2 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses2;
                            keyFinancials_Update.EmployeeGAandSDExpensesExpenses3 = keyFinancialsEntity.EmployeeGAandSDExpensesExpenses3;
                            keyFinancials_Update.PAT1 = keyFinancialsEntity.PAT1;
                            keyFinancials_Update.PAT2 = keyFinancialsEntity.PAT2;
                            keyFinancials_Update.PAT3 = keyFinancialsEntity.PAT3;
                            keyFinancials_Update.LiquidAssets1 = keyFinancialsEntity.LiquidAssets1;
                            keyFinancials_Update.LiquidAssets2 = keyFinancialsEntity.LiquidAssets2;
                            keyFinancials_Update.LiquidAssets3 = keyFinancialsEntity.LiquidAssets3;
                            keyFinancials_Update.ProvForNPAsandWriteoffs1 = keyFinancialsEntity.ProvForNPAsandWriteoffs1;
                            keyFinancials_Update.ProvForNPAsandWriteoffs2 = keyFinancialsEntity.ProvForNPAsandWriteoffs2;
                            keyFinancials_Update.ProvForNPAsandWriteoffs3 = keyFinancialsEntity.ProvForNPAsandWriteoffs3;
                            keyFinancials_Update.CASAPer1 = keyFinancialsEntity.CASAPer1;
                            keyFinancials_Update.CASAPer2 = keyFinancialsEntity.CASAPer2;
                            keyFinancials_Update.CASAPer3 = keyFinancialsEntity.CASAPer3;
                            //keyFinancials_Update.AdvancestoAgricultureSectorPer1 = keyFinancialsEntity.AdvancestoAgricultureSectorPer1;
                            //keyFinancials_Update.AdvancestoAgricultureSectorPer2 = keyFinancialsEntity.AdvancestoAgricultureSectorPer2;
                            //keyFinancials_Update.AdvancestoAgricultureSectorPer3 = keyFinancialsEntity.AdvancestoAgricultureSectorPer3;

                            keyFinancials_Update.AdvancestoPrioritySectorPer1 = keyFinancialsEntity.AdvancestoPrioritySectorPer1;
                            keyFinancials_Update.AdvancestoPrioritySectorPer2 = keyFinancialsEntity.AdvancestoPrioritySectorPer2;
                            keyFinancials_Update.AdvancestoPrioritySectorPer3 = keyFinancialsEntity.AdvancestoPrioritySectorPer3;

                            keyFinancials_Update.CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1;
                            keyFinancials_Update.CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2;
                            keyFinancials_Update.CostOfDepositsPer3 = keyFinancialsEntity.CostOfDepositsPer3;
                            keyFinancials_Update.CRARPer1 = keyFinancialsEntity.CRARPer1;
                            keyFinancials_Update.CRARPer2 = keyFinancialsEntity.CRARPer2;
                            keyFinancials_Update.CRARPer3 = keyFinancialsEntity.CRARPer3;
                            keyFinancials_Update.Tier1Per1 = keyFinancialsEntity.Tier1Per1;
                            keyFinancials_Update.Tier1Per2 = keyFinancialsEntity.Tier1Per2;
                            keyFinancials_Update.Tier1Per3 = keyFinancialsEntity.Tier1Per3;
                            keyFinancials_Update.NetNPAPer1 = keyFinancialsEntity.NetNPAPer1;
                            keyFinancials_Update.NetNPAPer2 = keyFinancialsEntity.NetNPAPer2;
                            keyFinancials_Update.NetNPAPer3 = keyFinancialsEntity.NetNPAPer3;
                            keyFinancials_Update.AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1;
                            keyFinancials_Update.AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2;
                            keyFinancials_Update.AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3;
                            keyFinancials_Update.GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1;
                            keyFinancials_Update.GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2;
                            keyFinancials_Update.GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3;
                            keyFinancials_Update.ContingentLiability1 = keyFinancialsEntity.ContingentLiability1;
                            keyFinancials_Update.ContingentLiability2 = keyFinancialsEntity.ContingentLiability2;
                            keyFinancials_Update.ContingentLiability3 = keyFinancialsEntity.ContingentLiability3;
                            //keyFinancials_Update.ALMGapin6MonthsBucketPer1 = keyFinancialsEntity.ALMGapin6MonthsBucketPer1;
                            //keyFinancials_Update.ALMGapin6MonthsBucketPer2 = keyFinancialsEntity.ALMGapin6MonthsBucketPer2;
                            //keyFinancials_Update.ALMGapin6MonthsBucketPer3 = keyFinancialsEntity.ALMGapin6MonthsBucketPer3;
                            keyFinancials_Update.BusinessPerEmployee1 = keyFinancialsEntity.BusinessPerEmployee1;
                            keyFinancials_Update.BusinessPerEmployee2 = keyFinancialsEntity.BusinessPerEmployee2;
                            keyFinancials_Update.BusinessPerEmployee3 = keyFinancialsEntity.BusinessPerEmployee3;
                            keyFinancials_Update.SecuredAdvancesTotalAdvancesPer1 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer1;
                            keyFinancials_Update.SecuredAdvancesTotalAdvancesPer2 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer2;
                            keyFinancials_Update.SecuredAdvancesTotalAdvancesPer3 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer3;
                            keyFinancials_Update.StateEconomicGrowthGSDPPer1 = keyFinancialsEntity.StateEconomicGrowthGSDPPer1;
                            keyFinancials_Update.StateEconomicGrowthGSDPPer2 = keyFinancialsEntity.StateEconomicGrowthGSDPPer2;
                            keyFinancials_Update.StateEconomicGrowthGSDPPer3 = keyFinancialsEntity.StateEconomicGrowthGSDPPer3;
                            keyFinancials_Update.UpdatedBy = userId;
                            keyFinancials_Update.UpdatedDateTime = DateTime.Now;
                            dbContext.SaveChanges();
                            status = true;

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                            return false;
                        }
                    }

                    #endregion

                    status = Add_KeyFinancial_Archive(KeyFinancials_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_KeyFinancial(RRB_KeyFinancials KeyFinancials)
        {
            try
            {
                dbContext.RRB_KeyFinancials.Add(KeyFinancials);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_KeyFinancial_Archive(RRB_KeyFinancials_Archive KeyFinancials_Archive)
        {
            try
            {
                dbContext.RRB_KeyFinancials_Archive.Add(KeyFinancials_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_SubjectiveParameters(int userId, int roleId, int detailID, short logID,DateTime CreatedDateTime, RRB_SubjectiveParametersEntity subjectiveParametersEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                RRB_SubjectiveParameters_Archive subjectiveParameters_Archive = new RRB_SubjectiveParameters_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,

                    UserId = userId,
                    IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                    RecentClimaticCondition = subjectiveParametersEntity.RecentClimaticCondition,
                    AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS,
                    ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                    //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                    AdverseNews = subjectiveParametersEntity.AdverseNews,

                    CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                    AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                    AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                    NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                    NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                    LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                    CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                    NPASysGen = subjectiveParametersEntity.NPASysGen,
                    NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                    CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                    NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                    SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                    QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                    DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                };

                RRB_SubjectiveParameters subjectiveParameters = new RRB_SubjectiveParameters
                {
                    DetailsId = detailID,
                    IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                    RecentClimaticCondition = subjectiveParametersEntity.RecentClimaticCondition,
                    AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS,
                    ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                    //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                    AdverseNews = subjectiveParametersEntity.AdverseNews,

                    CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                    AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                    AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                    NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                    NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                    LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                    CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                    NPASysGen = subjectiveParametersEntity.NPASysGen,
                    NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                    CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                    NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                    SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                    QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                    DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                };

                if (userId != 0)
                {
                    #region Add Data 
                    if (subjectiveParameters != null && CheckIfAlreadyExists_SubjectiveParameters(detailID) == false)
                    {
                        try
                        {
                            status = Add_SubjectiveParameter(subjectiveParameters);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }


                    #endregion

                    #region Update Existing Data

                    else
                    {

                        try
                        {
                            RRB_SubjectiveParameters subjectiveParameters_Update = dbContext.RRB_SubjectiveParameters.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (subjectiveParameters_Update != null)
                            {
                                subjectiveParameters_Update.IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore;

                                subjectiveParameters_Update.RecentClimaticCondition = subjectiveParametersEntity.RecentClimaticCondition;
                                subjectiveParameters_Update.AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS;
                                subjectiveParameters_Update.ManagementQuality = subjectiveParametersEntity.ManagementQuality;
                                //subjectiveParameters_Update.UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards;
                                subjectiveParameters_Update.AdverseNews = subjectiveParametersEntity.AdverseNews;

                                subjectiveParameters_Update.CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility;
                                subjectiveParameters_Update.AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime;
                                subjectiveParameters_Update.AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems;
                                subjectiveParameters_Update.NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm;
                                subjectiveParameters_Update.NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm;
                                subjectiveParameters_Update.LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran;
                                subjectiveParameters_Update.CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData;
                                subjectiveParameters_Update.NPASysGen = subjectiveParametersEntity.NPASysGen;
                                subjectiveParameters_Update.NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting;
                                subjectiveParameters_Update.CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement;
                                subjectiveParameters_Update.NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess;
                                subjectiveParameters_Update.SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort;
                                subjectiveParameters_Update.QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor;
                                subjectiveParameters_Update.DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders;

                                subjectiveParameters_Update.UpdatedBy = subjectiveParametersEntity.UpdatedBy;
                                subjectiveParameters_Update.UpdatedDateTime = subjectiveParametersEntity.UpdatedDateTime;
                                dbContext.SaveChanges();
                                status = true;
                            }
                            else
                            {
                                status = false;
                                dbContextTransaction.Rollback();
                            }

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            status = false;
                        }

                    }
                    #endregion

                    status = Add_SubjectiveParameter_Archive(subjectiveParameters_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
            }

            return status;

        }

        public bool Add_SubjectiveParameter(RRB_SubjectiveParameters subjectiveParameters)
        {
            try
            {
                dbContext.RRB_SubjectiveParameters.Add(subjectiveParameters);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_SubjectiveParameter_Archive(RRB_SubjectiveParameters_Archive subjectiveParameters_Archive)
        {
            try
            {
                dbContext.RRB_SubjectiveParameters_Archive.Add(subjectiveParameters_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_OutputDetails(int userId, int roleId, int detailID, short logID,int detail_ArchiveID, DateTime CreatedDateTime, List<RRB_OutputDetailsEntity> outputDetailsEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                if (outputDetailsEntity != null && userId != 0)
                {
                    List<RRB_Output_Details> output_Details = new List<RRB_Output_Details>();
                    List<RRB_Output_Details_Archive> output_Details_Archive = new List<RRB_Output_Details_Archive>();

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details.Add(new RRB_Output_Details
                        {
                            DetailsId = detailID,
                            TemplateId = values.TemplateID,
                            Parameter_Per = values.Parameter3Per,
                            Parameter_Name = string.IsNullOrEmpty(values.Parameter3) ? values.Parameter1 : values.Parameter3,
                            UnderBaselIII_Score = values.UnderBaselIII_Score,
                            UnderBaselIII_Value = values.UnderBaselIII_Value,
                            UnderIND_Score = values.UnderIND_Score,
                            UnderIND_Value = values.UnderIND_Value,
                            Comments = values.Comments,
                            CreatedDateTime = CreatedDateTime,
                        });
                    };

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details_Archive.Add(new RRB_Output_Details_Archive
                        {
                            DetailsId = detailID,
                            LogId = logID,

                            Details_ArchiveId = detail_ArchiveID,
                            UserId = userId,
                            TemplateId = values.TemplateID,
                            Parameter_Per = values.Parameter3Per,
                            Parameter_Name = string.IsNullOrEmpty(values.Parameter3) ? values.Parameter1 : values.Parameter3,
                            UnderBaselIII_Score = values.UnderBaselIII_Score,
                            UnderBaselIII_Value = values.UnderBaselIII_Value,
                            UnderIND_Score = values.UnderIND_Score,
                            UnderIND_Value = values.UnderIND_Value,
                            Comments = values.Comments,

                            CreatedBy = values.CreatedBy,
                            UpdatedBy = values.UpdatedBy,

                            CreatedDateTime = CreatedDateTime,
                            UpdatedDateTime = DateTime.Now,
                        });
                    };

                    if (output_Details != null)
                    {
                        if (CheckIfAlreadyExists_OutputDetails(detailID) == true)
                        {
                            Delete_OutputDetails(detailID);
                        }
                        status = Add_OutputDetails(output_Details);
                        status = Add_OutputDetails_Archive(output_Details_Archive);
                        dbContextTransaction.Commit();
                        status = true;
                    }
                }
            }

            return status;

        }

        public bool Add_OutputDetails(List<RRB_Output_Details> output_Details)
        {
            try
            {
                dbContext.RRB_Output_Details.AddRange(output_Details);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_OutputDetails_Archive(List<RRB_Output_Details_Archive> output_Details_Archive)
        {
            try
            {
                dbContext.RRB_Output_Details_Archive.AddRange(output_Details_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Get_OutputDetails_OpenXML(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            // Open the document for editing.
            using (DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadSheet = DocumentFormat.OpenXml.Packaging.SpreadsheetDocument.Open(OutputTemplateFilePath, true))
            {
                // Access the main Workbook part, which contains all references.
                DocumentFormat.OpenXml.Packaging.WorkbookPart workbookPart = spreadSheet.WorkbookPart;
                // get sheet by name
                DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbookPart.Workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == "Output NHB").FirstOrDefault();

                // get worksheetpart by sheet id
                DocumentFormat.OpenXml.Packaging.WorksheetPart worksheetPart = workbookPart.GetPartById(sheet.Id.Value) as DocumentFormat.OpenXml.Packaging.WorksheetPart;

                // The SheetData object will contain all the data.
                int? detailArchivedID = (from output in dbContext.RRB_Output_Details_Archive
                                         join basicDetails in dbContext.NHB_Details_Archive on output.Details_ArchiveId equals basicDetails.Details_ArchiveId
                                         where basicDetails.CompanyId == companyId
                                         && DbFunctions.TruncateTime(output.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime)
                                         select output.Details_ArchiveId).OrderByDescending(data => data).FirstOrDefault();

                //    RRB_Output_Details_Archive data = dbContext.RRB_Output_Details_Archive.Where(detail => detail.CompanyId == companyId
                //&& issuerinfo.PRDate == null).OrderByDescending(data => data.Details_ArchiveId).FirstOrDefault();

                if (detailArchivedID > 0)
                {
                    List<RRB_OutputDetailsEntity> getOutputDetails = dbContext.RRB_Output_Details_Archive
                       .Where(riskOutputs => riskOutputs.Details_ArchiveId == detailArchivedID.Value
                       )
                       .Select(Outputs => new RRB_OutputDetailsEntity
                       {
                           Parameter3 = Outputs.Parameter_Name,
                           UnderIND_Score = Outputs.UnderIND_Score,
                           UnderIND_Value = Outputs.UnderIND_Value,
                           UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                           UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
                       }).ToList();

                    uint rowNo = 3;
                    for (int i = 0; i < getOutputDetails.Count; i++)
                    {
                        Cell cell = GetCell(worksheetPart.Worksheet, "K", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Score);
                        cell = GetCell(worksheetPart.Worksheet, "L", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Value);
                        cell = GetCell(worksheetPart.Worksheet, "N", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Score);
                        cell = GetCell(worksheetPart.Worksheet, "O", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Value);
                        rowNo++;
                    }
                    // Save the worksheet.
                    worksheetPart.Worksheet.Save();

                    // for recacluation of formula
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;
                }
            }
            return true;
        }

        private Cell GetCell(Worksheet worksheet, string columnName, uint rowIndex)
        {
            Row row = GetRow(worksheet, rowIndex);

            if (row == null) return null;

            var FirstRow = row.Elements<Cell>().Where(c => string.Compare
            (c.CellReference.Value, columnName +
            rowIndex, true) == 0).FirstOrDefault();

            if (FirstRow == null) return null;

            return FirstRow;
        }

        private Row GetRow(Worksheet worksheet, uint rowIndex)
        {
            Row row = worksheet.GetFirstChild<SheetData>().
            Elements<Row>().FirstOrDefault(r => r.RowIndex == rowIndex);
            if (row == null)
            {
                throw new ArgumentException(String.Format("No row with index {0} found in spreadsheet", rowIndex));
            }
            return row;
        }

        public bool Get_OutputDetails_ExcelInterOP(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            bool status = false;
            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            try
            {
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                object misValue = System.Reflection.Missing.Value;
                xlApp.DisplayAlerts = false;
                xlApp.EditDirectlyInCell = true;
                xlApp.EnableEvents = true;

                int detailID = (from output in dbContext.RRB_Output_Details
                                join RRBBasicDetails in dbContext.NHB_Details on output.DetailsId equals RRBBasicDetails.DetailsId
                                where RRBBasicDetails.CompanyId == companyId
                                select output.DetailsId).FirstOrDefault();

                //select (int)issuers.BussinessGroupID).SingleOrDefault();
                //int detailID = dbContext.RRB_Output_Details.Where(detailId => detailId.CompanyId == companyId).Select(detailId => detailId.DetailsId).FirstOrDefault();

                if (detailID != 0)
                {
                    List<RRB_Output_Details> getOutputDetails = dbContext.RRB_Output_Details
                          .Where(riskOutputs => riskOutputs.DetailsId == detailID
                          //&& DbFunctions.TruncateTime(riskOutputs.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime))
                          )
                          .Select(Outputs => new RRB_Output_Details
                          {

                          }).ToList();//.OrderByDescending(riskOutputs => riskOutputs.UpdatedDateTime).Take(1).FirstOrDefault();

                    mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                    mWorkSheets = mWorkBook.Worksheets;
                    //Get the already exists sheet
                    mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(1);
                    if (getOutputDetails != null)
                    {
                        //mWSheet.Cells[2, 6] = ExtensionMethod.GetFormattedData(getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersWeight);
                        //mWSheet.Cells[2, 7] = getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersValue;
                        //mWSheet.Cells[2, 8] = getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersScore;
                        //mWSheet.Cells[3, 6] = ExtensionMethod.GetFormattedData(getOutputDetails.IndustryRiskCompetitionsWeight);
                        //mWSheet.Cells[3, 7] = getOutputDetails.IndustryRiskCompetitionsValue;
                        //mWSheet.Cells[3, 8] = getOutputDetails.IndustryRiskCompetitionsScore;

                    }
                    else
                    {
                        getOutputDetails = null;
                        status = false;
                    }

                    mWorkBook.Save();
                    mWorkBook.Close(1, null, null);
                    xlApp.Quit();
                    status = true;

                    mWSheet = null;
                    mWorkBook = null;
                    mWorkSheets = null;
                    xlApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return status;
        }

        public bool Delete_OutputDetails(int detailsID)
        {
            try
            {
                dbContext.RRB_Output_Details.RemoveRange(dbContext.RRB_Output_Details.Where(c => c.DetailsId == detailsID));
                //foreach (var ec in dbContext.RRB_Output_Details.Where(x => x.DetailsId == RRB_Output_Details[0].DetailsId))
                //{
                //    dbContext.RRB_Output_Details.Remove(ec);
                //}
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool CheckIfAlreadyExists_KeyFinancial(int detailsId)
        {
            return dbContext.RRB_KeyFinancials.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_SubjectiveParameters(int detailsId)
        {
            return dbContext.RRB_SubjectiveParameters.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_OutputDetails(int detailsId)
        {
            return dbContext.RRB_Output_Details.Any(asset => asset.DetailsId == detailsId);
        }

       

        public bool Get_OutputDetails_InterOp_DetailsId(int detailsId, string companyName, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Key Financials List

            List<HFC_OutputDetailsEntity> getOutputDetails = dbContext.RRB_Output_Details
              .Where(a => a.DetailsId == detailsId
              )
              .Select(Outputs => new HFC_OutputDetailsEntity
              {
                  Parameter3Per = Outputs.Parameter_Per,
                  Parameter3 = Outputs.Parameter_Name,
                  UnderIND_Score = Outputs.UnderIND_Score,
                  UnderIND_Value = Outputs.UnderIND_Value,
                  UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                  UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
              }).ToList();

            #endregion

            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Output NHB"];

            uint rowIndex = 2;
            int columnIndex = 0;
            columnIndex = _helperDAL.GetExcelColumnIndex("B");
            mWSheet.Cells[rowIndex, columnIndex] = companyName;

            rowIndex = 3;
            columnIndex = 0;

            for (int i = 0; i < getOutputDetails.Count; i++)
            {
                columnIndex = _helperDAL.GetExcelColumnIndex("K");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("L");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Score;

                columnIndex = _helperDAL.GetExcelColumnIndex("N");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("O");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Score;
                rowIndex++;
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();

            return true;
        }

        public bool DownloadOutputDetails(RRB_BasicDetailsEntity riskModelExcelEntity, string companyName, string OutputTemplateFilePath)
        {
            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Output NHB"];

            uint rowIndex = 2;
            int columnIndex = 0;
            columnIndex = _helperDAL.GetExcelColumnIndex("B");
            mWSheet.Cells[rowIndex, columnIndex] = companyName;

            rowIndex = 3;
            columnIndex = 0;
            List<RRB_OutputDetailsEntity> getOutputDetails = riskModelExcelEntity.RRB_OutputDetailsEntity;
            for (int i = 0; i < getOutputDetails.Count; i++)
            {
                columnIndex = _helperDAL.GetExcelColumnIndex("K");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("L");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Score;

                columnIndex = _helperDAL.GetExcelColumnIndex("N");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("O");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Score;
                rowIndex++;
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();

            return true;
        }

    }

}