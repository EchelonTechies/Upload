﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Text;
using IndRa.RiskModel.DAL.Entities;
using System.Reflection;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using IndRa.RiskModel.DAL.DataAccess;
using System.Data.Entity.Validation;
using IndRa.RiskModel.DAL.DAL;
using System.Data.Entity;
using IndRa.RiskModel.DAL.Helpers;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Data.Entity.SqlServer;
using IndRa.RiskModel.Helpers;
//using Microsoft.Office.Interop.Excel;

namespace IndRa.RiskModel.DAL
{
    public class HFCNewDAL
    {
        HelperDAL _helperDAL = null;
        IndRaDBcontext dbContext = new IndRaDBcontext();

        public HFCNewDAL()
        {
            _helperDAL = new HelperDAL();
        }

        public List<HFCNew_OutputDetailsEntity> GetOutputTemplateEntity()
        {
            List<HFCNew_OutputDetailsEntity> outputTemplate = new List<HFCNew_OutputDetailsEntity>();
            outputTemplate = dbContext.HFCNew_Output_Template.Where(a => a.InActive == null).OrderBy(a => a.Ranking).Select(output => new HFCNew_OutputDetailsEntity
            {
                TemplateID = output.TemplateID,
                Parameter1 = string.IsNullOrEmpty(output.Parameter1) ? string.Empty : output.Parameter1,
                Parameter1Per = string.IsNullOrEmpty(output.Parameter1Per) ? string.Empty : output.Parameter1Per,
                Parameter2 = string.IsNullOrEmpty(output.Parameter2) ? string.Empty : output.Parameter2,
                Parameter2Per = string.IsNullOrEmpty(output.Parameter2Per) ? string.Empty : output.Parameter2Per,
                Parameter3 = string.IsNullOrEmpty(output.Parameter3) ? string.Empty : output.Parameter3,
                Parameter3Per = string.Empty,
                UnderBaselIII_Score = string.Empty,
                UnderBaselIII_Value = string.Empty,
                UnderIND_Score = string.Empty,
                UnderIND_Value = string.Empty,
                Comments = string.Empty,
            }).ToList();
            return outputTemplate;
        }


        public HFCNew_BasicDetailsEntity GetBasicDetails(int detailsId)
        {
            HFCNew_BasicDetailsEntity basicDetails = new HFCNew_BasicDetailsEntity();
            HFCNew_KeyFinancialsEntity keyFinancials = new HFCNew_KeyFinancialsEntity();
            HFCNew_SubjectiveParametersEntity subjectiveParameters = new HFCNew_SubjectiveParametersEntity();
            List<HFCNew_OutputDetailsEntity> outputDetails = new List<HFCNew_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details.Where(data => data.DetailsId == detailsId).Select(x => new HFCNew_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = 0,
                FinYear = x.FinYear,
                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                DateOfInput = x.DateOfInput,
                //FinancialYearEndingDate = x.FinancialYearEndingDate,
                CurrencyUnits = x.CurrencyUnits,
                //ParentCompanyIsExist = x.ParentCompanyIsExist,
                ParentCompanyName = x.ParentCompanyName,
                ParentRating = x.ParentRating,
                ParentCompanyShareHoldingPer = x.ParentCompanyShareHoldingPer,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

                IsFinal = x.IsFinal.Value
            }).FirstOrDefault();

            keyFinancials = dbContext.HFCNew_KeyFinancials.Where(data => data.DetailsId == detailsId).Select(keyFinancialsEntity => new HFCNew_KeyFinancialsEntity
            {
                DetailsId = detailsId,
                PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                Currency1 = keyFinancialsEntity.Currency1,
                Currency2 = keyFinancialsEntity.Currency2,
                NetWorth1 = keyFinancialsEntity.NetWorth1,
                NetWorth2 = keyFinancialsEntity.NetWorth2,
                TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                //UnencumberedLiquidAssetsPer1 = keyFinancialsEntity.UnencumberedLiquidAssetsPer1,
                //UnencumberedLiquidAssetsPer2 = keyFinancialsEntity.UnencumberedLiquidAssetsPer2,
                ReturnonEquityPer1 = keyFinancialsEntity.ReturnonEquityPer1,
                ReturnonEquityPer2 = keyFinancialsEntity.ReturnonEquityPer2,
                ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                //ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                //ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                NetInterestMarginPer1 = keyFinancialsEntity.NetInterestMarginPer1,
                NetInterestMarginPer2 = keyFinancialsEntity.NetInterestMarginPer2,
                CRARPer1 = keyFinancialsEntity.CRARPer1,
                CRARPer2 = keyFinancialsEntity.CRARPer2,
                Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                TotalNoOfBranches1 = keyFinancialsEntity.TotalNoOfBranches1,
                TotalNoOfBranches2 = keyFinancialsEntity.TotalNoOfBranches2,
                GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                //IndividualHousingLoanTotalAdvancesPer1 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer1,
                //IndividualHousingLoanTotalAdvancesPer2 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer2,
                LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                //AssetGrowthHousingLoansPer1 = keyFinancialsEntity.AssetGrowthHousingLoansPer1,
                //AssetGrowthHousingLoansPer2 = keyFinancialsEntity.AssetGrowthHousingLoansPer2,
                BusinessINRmnemployee1 = keyFinancialsEntity.BusinessINRmnemployee1,
                BusinessINRmnemployee2 = keyFinancialsEntity.BusinessINRmnemployee2,
                PresenceinStatesUT1 = keyFinancialsEntity.PresenceinStatesUT1,
                PresenceinStatesUT2 = keyFinancialsEntity.PresenceinStatesUT2,
                YearsPassedSinceCommencementofHFC1 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC1,
                YearsPassedSinceCommencementofHFC2 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC2,
                GrowthinAdvancesPer1 = keyFinancialsEntity.GrowthinAdvancesPer1,
                GrowthinAdvancesPer2 = keyFinancialsEntity.GrowthinAdvancesPer2,
                Gearing1 = keyFinancialsEntity.GearingPer1,
                Gearing2 = keyFinancialsEntity.GearingPer2,
                //Leverage1 = keyFinancialsEntity.Leverage1,
                //Leverage2 = keyFinancialsEntity.Leverage2,


                PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1,
                PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2,
                PBCtowardsHousingFinanceAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer1,
                PBCtowardsHousingFinanceAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer2,



            }).FirstOrDefault();

            subjectiveParameters = dbContext.HFCNew_SubjectiveParameters.Where(data => data.DetailsId == detailsId).Select(subjectiveParametersEntity => new HFCNew_SubjectiveParametersEntity
            {
                //PropensityToSupportInstitution = subjectiveParametersEntity.PropensityToSupportInstitution,
                IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                BusinessModel = subjectiveParametersEntity.BusinessModel,
                ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                AdverseNews = subjectiveParametersEntity.AdverseNews,
                //ProspectOfKeyMarkets = subjectiveParametersEntity.ProspectOfKeyMarkets,
                GeographicalDiversification = subjectiveParametersEntity.GeographicalDiversification,
                DiversityOfResources = subjectiveParametersEntity.DiversityOfResources,
                //AccessToFunds = subjectiveParametersEntity.AccessToFunds,
                CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                //LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                NPASysGen = subjectiveParametersEntity.NPASysGen,
                NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

                ExternalRating = subjectiveParametersEntity.ExternalRating,
                CollateralCoverageRatio = subjectiveParametersEntity.CollateralCoverageRatio,
                RelatedPartyTranscations = subjectiveParametersEntity.RelatedPartyTranscations,
                GapsinSLSWithinRegulatoryLimits = subjectiveParametersEntity.GapsinSLSWithinRegulatoryLimits,


            }).FirstOrDefault();

            outputDetails = (from output in dbContext.HFCNew_Output_Details
                             join template in dbContext.HFCNew_Output_Template on output.TemplateId equals template.TemplateID
                             where output.DetailsId == detailsId

                             select new HFCNew_OutputDetailsEntity
                             {
                                 TemplateID = output.TemplateId,
                                 Parameter1 = string.IsNullOrEmpty(template.Parameter1) ? string.Empty : template.Parameter1,
                                 Parameter1Per = string.IsNullOrEmpty(template.Parameter1Per) ? string.Empty : template.Parameter1Per,
                                 Parameter2 = string.IsNullOrEmpty(template.Parameter2) ? string.Empty : template.Parameter2,
                                 Parameter2Per = string.IsNullOrEmpty(template.Parameter2Per) ? string.Empty : template.Parameter2Per,
                                 Parameter3Per = output.Parameter_Per,
                                 Parameter3 = output.Parameter_Name,
                                 UnderBaselIII_Score = string.IsNullOrEmpty(output.UnderBaselIII_Score) ? string.Empty : output.UnderBaselIII_Score,
                                 UnderBaselIII_Value = string.IsNullOrEmpty(output.UnderBaselIII_Value) ? string.Empty : output.UnderBaselIII_Value,
                                 UnderIND_Score = string.IsNullOrEmpty(output.UnderIND_Score) ? string.Empty : output.UnderIND_Score,
                                 UnderIND_Value = string.IsNullOrEmpty(output.UnderIND_Value) ? string.Empty : output.UnderIND_Value,
                                 Comments = string.IsNullOrEmpty(output.Comments) ? string.Empty : output.Comments,
                             }).ToList();

            basicDetails.HFCNew_KeyFinancialsEntity = keyFinancials;
            basicDetails.HFCNew_SubjectiveParametersEntity = subjectiveParameters;
            basicDetails.HFCNew_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public HFCNew_BasicDetailsEntity GetBasicDetails_Archive(int detailsId, short logId)
        {
            HFCNew_BasicDetailsEntity basicDetails = new HFCNew_BasicDetailsEntity();
            HFCNew_KeyFinancialsEntity keyFinancials = new HFCNew_KeyFinancialsEntity();
            HFCNew_SubjectiveParametersEntity subjectiveParameters = new HFCNew_SubjectiveParametersEntity();
            List<HFCNew_OutputDetailsEntity> outputDetails = new List<HFCNew_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(x => new HFCNew_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = logId,
                FinYear = x.FinYear,
                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                DateOfInput = x.DateOfInput,
                //FinancialYearEndingDate = x.FinancialYearEndingDate,
                CurrencyUnits = x.CurrencyUnits,
                //ParentCompanyIsExist = x.ParentCompanyIsExist,
                ParentCompanyName = x.ParentCompanyName,
                ParentRating = x.ParentRating,
                ParentCompanyShareHoldingPer = x.ParentCompanyShareHoldingPer,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

                IsFinal = x.IsFinal.Value
            }).FirstOrDefault();

            keyFinancials = dbContext.HFCNew_KeyFinancials_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(keyFinancialsEntity => new HFCNew_KeyFinancialsEntity
            {
                DetailsId = detailsId,
                PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                Currency1 = keyFinancialsEntity.Currency1,
                Currency2 = keyFinancialsEntity.Currency2,
                NetWorth1 = keyFinancialsEntity.NetWorth1,
                NetWorth2 = keyFinancialsEntity.NetWorth2,
                TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                //UnencumberedLiquidAssetsPer1 = keyFinancialsEntity.UnencumberedLiquidAssetsPer1,
                //UnencumberedLiquidAssetsPer2 = keyFinancialsEntity.UnencumberedLiquidAssetsPer2,
                ReturnonEquityPer1 = keyFinancialsEntity.ReturnonEquityPer1,
                ReturnonEquityPer2 = keyFinancialsEntity.ReturnonEquityPer2,
                ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                //ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                //ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                NetInterestMarginPer1 = keyFinancialsEntity.NetInterestMarginPer1,
                NetInterestMarginPer2 = keyFinancialsEntity.NetInterestMarginPer2,
                CRARPer1 = keyFinancialsEntity.CRARPer1,
                CRARPer2 = keyFinancialsEntity.CRARPer2,
                Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                TotalNoOfBranches1 = keyFinancialsEntity.TotalNoOfBranches1,
                TotalNoOfBranches2 = keyFinancialsEntity.TotalNoOfBranches2,
                GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                //IndividualHousingLoanTotalAdvancesPer1 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer1,
                //IndividualHousingLoanTotalAdvancesPer2 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer2,
                LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                //AssetGrowthHousingLoansPer1 = keyFinancialsEntity.AssetGrowthHousingLoansPer1,
                //AssetGrowthHousingLoansPer2 = keyFinancialsEntity.AssetGrowthHousingLoansPer2,
                BusinessINRmnemployee1 = keyFinancialsEntity.BusinessINRmnemployee1,
                BusinessINRmnemployee2 = keyFinancialsEntity.BusinessINRmnemployee2,
                PresenceinStatesUT1 = keyFinancialsEntity.PresenceinStatesUT1,
                PresenceinStatesUT2 = keyFinancialsEntity.PresenceinStatesUT2,
                YearsPassedSinceCommencementofHFC1 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC1,
                YearsPassedSinceCommencementofHFC2 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC2,
                GrowthinAdvancesPer1 = keyFinancialsEntity.GrowthinAdvancesPer1,
                GrowthinAdvancesPer2 = keyFinancialsEntity.GrowthinAdvancesPer2,
                Gearing1 = keyFinancialsEntity.GearingPer1,
                Gearing2 = keyFinancialsEntity.GearingPer2,
                //Leverage1 = keyFinancialsEntity.Leverage1,
                //Leverage2 = keyFinancialsEntity.Leverage2,


                PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1,
                PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2,
                PBCtowardsHousingFinanceAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer1,
                PBCtowardsHousingFinanceAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer2,


            }).FirstOrDefault();

            subjectiveParameters = dbContext.HFCNew_SubjectiveParameters_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(subjectiveParametersEntity => new HFCNew_SubjectiveParametersEntity
            {
                //PropensityToSupportInstitution = subjectiveParametersEntity.PropensityToSupportInstitution,
                IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                BusinessModel = subjectiveParametersEntity.BusinessModel,
                ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                AdverseNews = subjectiveParametersEntity.AdverseNews,
                //ProspectOfKeyMarkets = subjectiveParametersEntity.ProspectOfKeyMarkets,
                GeographicalDiversification = subjectiveParametersEntity.GeographicalDiversification,
                DiversityOfResources = subjectiveParametersEntity.DiversityOfResources,
                //AccessToFunds = subjectiveParametersEntity.AccessToFunds,
                CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                //LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                NPASysGen = subjectiveParametersEntity.NPASysGen,
                NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

                ExternalRating = subjectiveParametersEntity.ExternalRating,
                CollateralCoverageRatio = subjectiveParametersEntity.CollateralCoverageRatio,
                RelatedPartyTranscations = subjectiveParametersEntity.RelatedPartyTranscations,
                GapsinSLSWithinRegulatoryLimits = subjectiveParametersEntity.GapsinSLSWithinRegulatoryLimits,

            }).FirstOrDefault();

            outputDetails = (from output in dbContext.HFCNew_Output_Details_Archive
                             join template in dbContext.HFCNew_Output_Template on output.TemplateId equals template.TemplateID
                             where output.DetailsId == detailsId && output.LogId == logId

                             select new HFCNew_OutputDetailsEntity
                             {
                                 TemplateID = output.TemplateId,
                                 Parameter1 = string.IsNullOrEmpty(template.Parameter1) ? string.Empty : template.Parameter1,
                                 Parameter1Per = string.IsNullOrEmpty(template.Parameter1Per) ? string.Empty : template.Parameter1Per,
                                 Parameter2 = string.IsNullOrEmpty(template.Parameter2) ? string.Empty : template.Parameter2,
                                 Parameter2Per = string.IsNullOrEmpty(template.Parameter2Per) ? string.Empty : template.Parameter2Per,
                                 Parameter3Per = output.Parameter_Per,
                                 Parameter3 = output.Parameter_Name,
                                 UnderBaselIII_Score = string.IsNullOrEmpty(output.UnderBaselIII_Score) ? string.Empty : output.UnderBaselIII_Score,
                                 UnderBaselIII_Value = string.IsNullOrEmpty(output.UnderBaselIII_Value) ? string.Empty : output.UnderBaselIII_Value,
                                 UnderIND_Score = string.IsNullOrEmpty(output.UnderIND_Score) ? string.Empty : output.UnderIND_Score,
                                 UnderIND_Value = string.IsNullOrEmpty(output.UnderIND_Value) ? string.Empty : output.UnderIND_Value,
                                 Comments = string.IsNullOrEmpty(output.Comments) ? string.Empty : output.Comments,
                             }).ToList();

            basicDetails.HFCNew_KeyFinancialsEntity = keyFinancials;
            basicDetails.HFCNew_SubjectiveParametersEntity = subjectiveParameters;
            basicDetails.HFCNew_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public HFCNew_BasicDetailsEntity ImportCompanyDetailsFromExcel(string filePath, string fileName, string workSheet, int userId)
        {

            HFCNew_BasicDetailsEntity hfcNewBasicDetails = new HFCNew_BasicDetailsEntity();
            HFCNew_KeyFinancialsEntity hfcNewKeyFinancials = new HFCNew_KeyFinancialsEntity();
            HFCNew_SubjectiveParametersEntity hfcNewSubjectiveParameters = new HFCNew_SubjectiveParametersEntity();
            string value = "";
            DataTable dtExcel = null;
            DataTable dtTranspose = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);
            dtTranspose = _helperDAL.GenerateTransposedTable(dtExcel);

            if (dtTranspose.Rows.Count > 0)
            {
                // get values for HFCNew Basic Details
                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(hfcNewBasicDetails);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            value = dtTranspose.Rows[0][property.DisplayName].ToString();

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(hfcNewBasicDetails, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for HFCNew Key financials
                properties = TypeDescriptor.GetProperties(hfcNewKeyFinancials);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(hfcNewKeyFinancials, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for HFCNew Subjective Parameters
                properties = TypeDescriptor.GetProperties(hfcNewSubjectiveParameters);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            value = dtTranspose.Rows[1][property.DisplayName].ToString();

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(hfcNewSubjectiveParameters, safeValue);
                        }
                    }
                    catch { }

                }
                hfcNewBasicDetails.HFCNew_KeyFinancialsEntity = hfcNewKeyFinancials;
                hfcNewBasicDetails.HFCNew_SubjectiveParametersEntity = hfcNewSubjectiveParameters;
                CompanyDAL companyDAL = new CompanyDAL();
                int companyID = companyDAL.GetCompanyIDByCompanyName(hfcNewBasicDetails.CompanyName, userId);
                hfcNewBasicDetails.CompanyId = companyID;
                //int detailID = companyDAL.GetDetailIDByCompanyID(companyID);
                //hfcNewBasicDetails.DetailsId = detailID;
                CommonDAL commonDAL = new CommonDAL();
                string finYear = commonDAL.GetFinYearBasedOnDate(DateTime.Now);
                hfcNewBasicDetails.FinYear = finYear;
                //if (hfcNewBasicDetails.DateOfInput.HasValue)
                //{
                //    DateTime dateOfInput = hfcNewBasicDetails.DateOfInput.Value;
                //    string finYear = commonDAL.GetFinYearBasedOnDate(hfcNewBasicDetails.DateOfInput.Value);
                //    hfcNewBasicDetails.FinYear = finYear;
                //}
            }

            return hfcNewBasicDetails;

        }

        public List<HFCNew_OutputDetailsEntity> GetOutputFromExcel(string filePath, string fileName, string workSheet, int userId)
        {
            List<HFCNew_OutputDetailsEntity> outputDetailsEntity = new List<HFCNew_OutputDetailsEntity>();
            DataTable dtExcel = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);
            string a = "";
            //dtExcel= _helperDAL.ReadExcelFile(filePath,fileName,workSheet,out a);
            string paramterName = "";

            if (dtExcel.Rows.Count > 0)
            {
                short row = 0;
                string underBaselIIIColumnName_Value = "Under Basel III";
                string underBaselIIIColumnName_Score = "";
                string UnderINDAS109ColumnName_Value = "Under IND AS 109";
                string UnderINDAS109ColumnName_Score = "";

                for (int col = 0; col < dtExcel.Columns.Count; col++)
                {
                    if (dtExcel.Columns[col].Caption == underBaselIIIColumnName_Value)
                    {
                        underBaselIIIColumnName_Score = dtExcel.Columns[col + 1].Caption;
                        continue;
                    }
                    else if (dtExcel.Columns[col].Caption == UnderINDAS109ColumnName_Value)
                    {
                        UnderINDAS109ColumnName_Score = dtExcel.Columns[col + 1].Caption;
                    }
                }
                for (int i = 1; i < dtExcel.Rows.Count; i++)
                {
                    HFCNew_OutputDetailsEntity newRow = new HFCNew_OutputDetailsEntity();
                    newRow.TemplateID = row;
                    paramterName = dtExcel.Rows[i]["F7"].ToString();
                    if (paramterName != string.Empty)
                    {
                    }
                    else
                    {
                        paramterName = dtExcel.Rows[i][0].ToString();
                    }
                    if (paramterName == string.Empty)
                    {
                        continue;
                    }
                    if (paramterName == "Rating / Probability of Default")
                    {
                        break;
                    }
                    newRow.Parameter1 = paramterName;
                    newRow.Parameter3Per = dtExcel.Rows[i]["F9"].ToString();
                    newRow.UnderBaselIII_Value = dtExcel.Rows[i][underBaselIIIColumnName_Value].ToString();
                    newRow.UnderBaselIII_Score = dtExcel.Rows[i][underBaselIIIColumnName_Score].ToString();

                    newRow.UnderIND_Value = dtExcel.Rows[i][UnderINDAS109ColumnName_Value].ToString();
                    newRow.UnderIND_Score = dtExcel.Rows[i][UnderINDAS109ColumnName_Score].ToString();

                    outputDetailsEntity.Add(newRow);
                    row++;
                }
            }

            return outputDetailsEntity;

        }

        public int SaveCompanyBasicDetailsAsDraft(int userId, int roleId, HFCNew_BasicDetailsEntity riskModelExcelEntity, out int basicDetails_ArchiveId, out short logID)
        {
            int detailsId = 0;
            basicDetails_ArchiveId = 0;

            CompanyDAL companyDAL = new CompanyDAL();

            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                bool isRecordExist = companyDAL.CheckIfAlreadyExists_CompanyDetails(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                if (isRecordExist == true && riskModelExcelEntity.DetailsId == 0)
                {
                    detailsId = companyDAL.GetCompanyBasicDetailsID(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                    riskModelExcelEntity.DetailsId = detailsId;
                }
                if (riskModelExcelEntity.ButtonValue == ButtonValue.SubmitForApporval.ToString()) //"SubmitForApporval"
                {
                    riskModelExcelEntity.SubmitForApproval = true;
                    riskModelExcelEntity.SubmitForApprovalDate = DateTime.Now;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                {
                    riskModelExcelEntity.ApprovedDate = DateTime.Now;
                    riskModelExcelEntity.ReviewedDate = null;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ReviewDetails.ToString())
                {
                    riskModelExcelEntity.ReviewedDate = DateTime.Now;
                    riskModelExcelEntity.ApprovedDate = null;
                }
                logID = companyDAL.GetNHBLogId(riskModelExcelEntity.DetailsId);

                NHB_Details_Archive nHB_Details_Archive = new NHB_Details_Archive
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = Convert.ToDateTime(riskModelExcelEntity.DateOfInput),
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                    IsDraft = true
                };

                NHB_Details nHB_Details = new NHB_Details
                {
                    UserId = userId,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = Convert.ToDateTime(riskModelExcelEntity.DateOfInput),
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false
                };

                NHB_Details_Final nHB_Details_Final = new NHB_Details_Final
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = Convert.ToDateTime(riskModelExcelEntity.DateOfInput),
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false
                };

                if (userId != 0)
                {
                    #region Add Data

                    if (nHB_Details != null && companyDAL.CheckIfAlreadyExists_CompanyDetails(nHB_Details.CompanyId, nHB_Details.FinYear) == false)
                    {
                        try
                        {
                            detailsId = (int)companyDAL.AddCompanyDetails(nHB_Details);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }

                    }

                    #endregion

                    #region Update Data

                    else
                    {
                        try
                        {
                            NHB_Details details = dbContext.NHB_Details.Where(detail => detail.DetailsId == nHB_Details.DetailsId).FirstOrDefault();
                            if (details != null)
                            {
                                details.UserId = nHB_Details.UserId;
                                details.CompanyId = nHB_Details.CompanyId;
                                details.DateOfInput = nHB_Details.DateOfInput;
                                details.CurrencyUnits = nHB_Details.CurrencyUnits;
                                details.ParentCompanyName = nHB_Details.ParentCompanyName;
                                details.UpdatedBy = nHB_Details.UpdatedBy;
                                details.UpdatedDateTime = nHB_Details.UpdatedDateTime;
                                details.Comments = riskModelExcelEntity.Comments;
                                details.FinalRating = riskModelExcelEntity.FinalRating;
                                details.PD = riskModelExcelEntity.PD;
                                details.SubmitForApproval = nHB_Details.SubmitForApproval;
                                details.SubmitForApprovalDate = nHB_Details.SubmitForApprovalDate;
                                details.ApprovedDate = nHB_Details.ApprovedDate;
                                details.ReviewedDate = nHB_Details.ReviewedDate;

                                details.IsFinal = nHB_Details.IsFinal;
                                dbContext.SaveChanges();
                                detailsId = details.DetailsId;
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return -1;
                            }
                        }
                        catch (Exception exception)
                        {
                            throw exception;
                        }
                    }

                    #endregion

                    #region Final Data Add

                    if (nHB_Details.IsFinal == true)
                    {
                        try
                        {
                            companyDAL.AddCompanyDetails_Final(nHB_Details_Final);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    nHB_Details_Archive.DetailsId = detailsId;
                    if (isRecordExist == false)
                    {
                        nHB_Details_Archive.UpdatedBy = null;
                        nHB_Details_Archive.UpdatedDateTime = null;
                    }
                    else
                    {
                        nHB_Details_Archive.CreatedBy = null;
                        nHB_Details_Archive.CreatedDateTime = null;
                    }
                    basicDetails_ArchiveId = (int)companyDAL.AddCompanyDetails_Archive(nHB_Details_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return detailsId;

        }

        public bool SaveAsDraft_KeyFinancial(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, HFCNew_KeyFinancialsEntity keyFinancialsEntity)
        {
            bool status = false;

            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                HFCNew_KeyFinancials_Archive KeyFinancials_Archive = new HFCNew_KeyFinancials_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,

                    UserId = userId,
                    PeriodEndingDate1 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate1),
                    PeriodEndingDate2 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate2),
                    NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                    NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                    Currency1 = keyFinancialsEntity.Currency1,
                    Currency2 = keyFinancialsEntity.Currency2,
                    NetWorth1 = keyFinancialsEntity.NetWorth1,
                    NetWorth2 = keyFinancialsEntity.NetWorth2,
                    TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                    TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                    //UnencumberedLiquidAssetsPer1 = keyFinancialsEntity.UnencumberedLiquidAssetsPer1,
                    //UnencumberedLiquidAssetsPer2 = keyFinancialsEntity.UnencumberedLiquidAssetsPer2,

                    ReturnonEquityPer1 = keyFinancialsEntity.ReturnonEquityPer1,
                    ReturnonEquityPer2 = keyFinancialsEntity.ReturnonEquityPer2,

                    ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                    ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                    //ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                    //ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                    CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                    CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                    NetInterestMarginPer1 = keyFinancialsEntity.NetInterestMarginPer1,
                    NetInterestMarginPer2 = keyFinancialsEntity.NetInterestMarginPer2,
                    CRARPer1 = keyFinancialsEntity.CRARPer1,
                    CRARPer2 = keyFinancialsEntity.CRARPer2,
                    Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                    Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                    NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                    NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                    TotalNoOfBranches1 = keyFinancialsEntity.TotalNoOfBranches1,
                    TotalNoOfBranches2 = keyFinancialsEntity.TotalNoOfBranches2,
                    GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                    GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                    AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                    AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                    TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                    TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                    TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                    TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                    //IndividualHousingLoanTotalAdvancesPer1 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer1,
                    //IndividualHousingLoanTotalAdvancesPer2 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer2,
                    LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                    LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                    CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                    CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                    CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                    CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                    PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                    PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                    //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                    //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                    Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                    Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                    //AssetGrowthHousingLoansPer1 = keyFinancialsEntity.AssetGrowthHousingLoansPer1,
                    //AssetGrowthHousingLoansPer2 = keyFinancialsEntity.AssetGrowthHousingLoansPer2,
                    BusinessINRmnemployee1 = keyFinancialsEntity.BusinessINRmnemployee1,
                    BusinessINRmnemployee2 = keyFinancialsEntity.BusinessINRmnemployee2,
                    PresenceinStatesUT1 = keyFinancialsEntity.PresenceinStatesUT1,
                    PresenceinStatesUT2 = keyFinancialsEntity.PresenceinStatesUT2,
                    YearsPassedSinceCommencementofHFC1 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC1,
                    YearsPassedSinceCommencementofHFC2 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC2,
                    GrowthinAdvancesPer1 = keyFinancialsEntity.GrowthinAdvancesPer1,
                    GrowthinAdvancesPer2 = keyFinancialsEntity.GrowthinAdvancesPer2,
                    GearingPer1 = keyFinancialsEntity.Gearing1,
                    GearingPer2 = keyFinancialsEntity.Gearing2,
                    //Leverage1 = keyFinancialsEntity.Leverage1,
                    //Leverage2 = keyFinancialsEntity.Leverage2,


                    PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1,
                    PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2,
                    PBCtowardsHousingFinanceAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer1,
                    PBCtowardsHousingFinanceAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer2,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                HFCNew_KeyFinancials keyFinancials = new HFCNew_KeyFinancials
                {
                    DetailsId = detailID,
                    PeriodEndingDate1 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate1),
                    PeriodEndingDate2 = Convert.ToDateTime(keyFinancialsEntity.PeriodEndingDate2),
                    NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                    NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                    Currency1 = keyFinancialsEntity.Currency1,
                    Currency2 = keyFinancialsEntity.Currency2,
                    NetWorth1 = keyFinancialsEntity.NetWorth1,
                    NetWorth2 = keyFinancialsEntity.NetWorth2,
                    TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                    TotalAssets2 = keyFinancialsEntity.TotalAssets2,

                    //UnencumberedLiquidAssetsPer1 = keyFinancialsEntity.UnencumberedLiquidAssetsPer1,
                    //UnencumberedLiquidAssetsPer2 = keyFinancialsEntity.UnencumberedLiquidAssetsPer2,


                    ReturnonEquityPer1 = keyFinancialsEntity.ReturnonEquityPer1,
                    ReturnonEquityPer2 = keyFinancialsEntity.ReturnonEquityPer2,

                    ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                    ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                    //ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                    //ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                    CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                    CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                    NetInterestMarginPer1 = keyFinancialsEntity.NetInterestMarginPer1,
                    NetInterestMarginPer2 = keyFinancialsEntity.NetInterestMarginPer2,
                    CRARPer1 = keyFinancialsEntity.CRARPer1,
                    CRARPer2 = keyFinancialsEntity.CRARPer2,
                    Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                    Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                    NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                    NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                    TotalNoOfBranches1 = keyFinancialsEntity.TotalNoOfBranches1,
                    TotalNoOfBranches2 = keyFinancialsEntity.TotalNoOfBranches2,
                    GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                    GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                    AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                    AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                    TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                    TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                    TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                    TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                    //IndividualHousingLoanTotalAdvancesPer1 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer1,
                    //IndividualHousingLoanTotalAdvancesPer2 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer2,
                    LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                    LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                    CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                    CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                    CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                    CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                    PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                    PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                    //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                    //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                    Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                    Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                    //AssetGrowthHousingLoansPer1 = keyFinancialsEntity.AssetGrowthHousingLoansPer1,
                    //AssetGrowthHousingLoansPer2 = keyFinancialsEntity.AssetGrowthHousingLoansPer2,
                    BusinessINRmnemployee1 = keyFinancialsEntity.BusinessINRmnemployee1,
                    BusinessINRmnemployee2 = keyFinancialsEntity.BusinessINRmnemployee2,
                    PresenceinStatesUT1 = keyFinancialsEntity.PresenceinStatesUT1,
                    PresenceinStatesUT2 = keyFinancialsEntity.PresenceinStatesUT2,
                    YearsPassedSinceCommencementofHFC1 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC1,
                    YearsPassedSinceCommencementofHFC2 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC2,
                    GrowthinAdvancesPer1 = keyFinancialsEntity.GrowthinAdvancesPer1,
                    GrowthinAdvancesPer2 = keyFinancialsEntity.GrowthinAdvancesPer2,
                    GearingPer1 = keyFinancialsEntity.Gearing1,
                    GearingPer2 = keyFinancialsEntity.Gearing2,
                    //Leverage1 = keyFinancialsEntity.Leverage1,
                    //Leverage2 = keyFinancialsEntity.Leverage2,


                    PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1,
                    PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2,
                    PBCtowardsHousingFinanceAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer1,
                    PBCtowardsHousingFinanceAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer2,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region  Add Data

                    if (keyFinancials != null && CheckIfAlreadyExists_KeyFinancial(detailID) == false)
                    {
                        try
                        {
                            status = Add_KeyFinancial(keyFinancials);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            HFCNew_KeyFinancials keyFinancials_Update = dbContext.HFCNew_KeyFinancials.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (keyFinancials_Update != null)
                            {
                                keyFinancials_Update.PeriodEndingDate1 = keyFinancials.PeriodEndingDate1;
                                keyFinancials_Update.PeriodEndingDate2 = keyFinancials.PeriodEndingDate2;
                                keyFinancials_Update.NoofMonthsPeriod1 = keyFinancials.NoofMonthsPeriod1;
                                keyFinancials_Update.NoofMonthsPeriod2 = keyFinancials.NoofMonthsPeriod2;
                                keyFinancials_Update.Currency1 = keyFinancials.Currency1;
                                keyFinancials_Update.Currency2 = keyFinancials.Currency2;
                                keyFinancials_Update.NetWorth1 = keyFinancials.NetWorth1;
                                keyFinancials_Update.NetWorth2 = keyFinancials.NetWorth2;
                                keyFinancials_Update.TotalAssets1 = keyFinancials.TotalAssets1;
                                keyFinancials_Update.TotalAssets2 = keyFinancials.TotalAssets2;
                                keyFinancials_Update.ReturnonEquityPer1 = keyFinancials.ReturnonEquityPer1;
                                keyFinancials_Update.ReturnonEquityPer2 = keyFinancials.ReturnonEquityPer2;
                                keyFinancials_Update.ReturnOnAssetsPer1 = keyFinancials.ReturnOnAssetsPer1;
                                keyFinancials_Update.ReturnOnAssetsPer2 = keyFinancials.ReturnOnAssetsPer2;
                                keyFinancials_Update.UnencumberedLiquidAssetsPer1 = keyFinancials.UnencumberedLiquidAssetsPer1;
                                keyFinancials_Update.UnencumberedLiquidAssetsPer2 = keyFinancials.UnencumberedLiquidAssetsPer2;

                                keyFinancials_Update.ReturnOnNetWorthPer1 = keyFinancials.ReturnOnNetWorthPer1;
                                keyFinancials_Update.ReturnOnNetWorthPer2 = keyFinancials.ReturnOnNetWorthPer2;
                                keyFinancials_Update.CostOfFundsPer1 = keyFinancials.CostOfFundsPer1;
                                keyFinancials_Update.CostOfFundsPer2 = keyFinancials.CostOfFundsPer2;
                                keyFinancials_Update.NetInterestMarginPer1 = keyFinancials.NetInterestMarginPer1;
                                keyFinancials_Update.NetInterestMarginPer2 = keyFinancials.NetInterestMarginPer2;
                                keyFinancials_Update.CRARPer1 = keyFinancials.CRARPer1;
                                keyFinancials_Update.CRARPer2 = keyFinancials.CRARPer2;
                                keyFinancials_Update.Tier1Per1 = keyFinancials.Tier1Per1;
                                keyFinancials_Update.Tier1Per2 = keyFinancials.Tier1Per2;
                                keyFinancials_Update.NetNPAPer1 = keyFinancials.NetNPAPer1;
                                keyFinancials_Update.NetNPAPer2 = keyFinancials.NetNPAPer2;
                                keyFinancials_Update.TotalNoOfBranches1 = keyFinancials.TotalNoOfBranches1;
                                keyFinancials_Update.TotalNoOfBranches2 = keyFinancials.TotalNoOfBranches2;
                                keyFinancials_Update.GrossNPAPer1 = keyFinancials.GrossNPAPer1;
                                keyFinancials_Update.GrossNPAPer2 = keyFinancials.GrossNPAPer2;
                                keyFinancials_Update.AdditioninNPAsAdvancesPer1 = keyFinancials.AdditioninNPAsAdvancesPer1;
                                keyFinancials_Update.AdditioninNPAsAdvancesPer2 = keyFinancials.AdditioninNPAsAdvancesPer2;
                                keyFinancials_Update.TangibleNWNetNPA1 = keyFinancials.TangibleNWNetNPA1;
                                keyFinancials_Update.TangibleNWNetNPA2 = keyFinancials.TangibleNWNetNPA2;
                                keyFinancials_Update.TotalContLiabilityTotalAssetsPer1 = keyFinancials.TotalContLiabilityTotalAssetsPer1;
                                keyFinancials_Update.TotalContLiabilityTotalAssetsPer2 = keyFinancials.TotalContLiabilityTotalAssetsPer2;
                                keyFinancials_Update.IndividualHousingLoanTotalAdvancesPer1 = keyFinancials.IndividualHousingLoanTotalAdvancesPer1;
                                keyFinancials_Update.IndividualHousingLoanTotalAdvancesPer2 = keyFinancials.IndividualHousingLoanTotalAdvancesPer2;
                                keyFinancials_Update.LiquidityCoverageRatioPer1 = keyFinancials.LiquidityCoverageRatioPer1;
                                keyFinancials_Update.LiquidityCoverageRatioPer2 = keyFinancials.LiquidityCoverageRatioPer2;
                                keyFinancials_Update.CosttoIncomePer1 = keyFinancials.CosttoIncomePer1;
                                keyFinancials_Update.CosttoIncomePer2 = keyFinancials.CosttoIncomePer2;
                                keyFinancials_Update.CreditCostPer1 = keyFinancials.CreditCostPer1;
                                keyFinancials_Update.CreditCostPer2 = keyFinancials.CreditCostPer2;
                                keyFinancials_Update.PPOPCreditCost1 = keyFinancials.PPOPCreditCost1;
                                keyFinancials_Update.PPOPCreditCost2 = keyFinancials.PPOPCreditCost2;
                                keyFinancials_Update.ALMGapin6monthsbucketPer1 = keyFinancials.ALMGapin6monthsbucketPer1;
                                keyFinancials_Update.ALMGapin6monthsbucketPer2 = keyFinancials.ALMGapin6monthsbucketPer2;
                                keyFinancials_Update.Top20ConcentrationPer1 = keyFinancials.Top20ConcentrationPer1;
                                keyFinancials_Update.Top20ConcentrationPer2 = keyFinancials.Top20ConcentrationPer2;
                                keyFinancials_Update.AssetGrowthHousingLoansPer1 = keyFinancials.AssetGrowthHousingLoansPer1;
                                keyFinancials_Update.AssetGrowthHousingLoansPer2 = keyFinancials.AssetGrowthHousingLoansPer2;
                                keyFinancials_Update.BusinessINRmnemployee1 = keyFinancials.BusinessINRmnemployee1;
                                keyFinancials_Update.BusinessINRmnemployee2 = keyFinancials.BusinessINRmnemployee2;
                                keyFinancials_Update.PresenceinStatesUT1 = keyFinancials.PresenceinStatesUT1;
                                keyFinancials_Update.PresenceinStatesUT2 = keyFinancials.PresenceinStatesUT2;
                                keyFinancials_Update.YearsPassedSinceCommencementofHFC1 = keyFinancials.YearsPassedSinceCommencementofHFC1;
                                keyFinancials_Update.YearsPassedSinceCommencementofHFC2 = keyFinancials.YearsPassedSinceCommencementofHFC2;
                                keyFinancials_Update.GrowthinAdvancesPer1 = keyFinancials.GrowthinAdvancesPer1;
                                keyFinancials_Update.GrowthinAdvancesPer2 = keyFinancials.GrowthinAdvancesPer2;
                                keyFinancials_Update.GearingPer1 = keyFinancials.GearingPer1;
                                keyFinancials_Update.GearingPer2 = keyFinancials.GearingPer2;
                                keyFinancials_Update.Leverage1 = keyFinancials.Leverage1;
                                keyFinancials_Update.Leverage2 = keyFinancials.Leverage2;

                                keyFinancials_Update.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1 = keyFinancials.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1;
                                keyFinancials_Update.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2 = keyFinancials.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2;
                                keyFinancials_Update.PBCtowardsHousingFinanceAsofTotalAssetsPer1 = keyFinancials.PBCtowardsHousingFinanceAsofTotalAssetsPer1;
                                keyFinancials_Update.PBCtowardsHousingFinanceAsofTotalAssetsPer2 = keyFinancials.PBCtowardsHousingFinanceAsofTotalAssetsPer2;


                                keyFinancials_Update.UpdatedBy = keyFinancials.UpdatedBy;
                                keyFinancials_Update.UpdatedDateTime = keyFinancials.UpdatedDateTime;
                                dbContext.SaveChanges();
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return false;
                            }
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            return false;
                        }
                    }

                    #endregion

                    status = Add_KeyFinancial_Archive(KeyFinancials_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return true;

        }

        public bool Add_KeyFinancial(HFCNew_KeyFinancials hfcNew_KeyFinancials)
        {
            try
            {
                dbContext.HFCNew_KeyFinancials.Add(hfcNew_KeyFinancials);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_KeyFinancial_Archive(HFCNew_KeyFinancials_Archive hfcNew_KeyFinancials_Archive)
        {
            try
            {
                dbContext.HFCNew_KeyFinancials_Archive.Add(hfcNew_KeyFinancials_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_SubjectiveParameters(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, HFCNew_SubjectiveParametersEntity subjectiveParametersEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                HFCNew_SubjectiveParameters_Archive subjectiveParameters_Archive = new HFCNew_SubjectiveParameters_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,

                    UserId = userId,
                    //PropensityToSupportInstitution = subjectiveParametersEntity.PropensityToSupportInstitution,
                    IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                    BusinessModel = subjectiveParametersEntity.BusinessModel,
                    ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                    //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                    AdverseNews = subjectiveParametersEntity.AdverseNews,
                    //ProspectOfKeyMarkets = subjectiveParametersEntity.ProspectOfKeyMarkets,
                    GeographicalDiversification = subjectiveParametersEntity.GeographicalDiversification,
                    DiversityOfResources = subjectiveParametersEntity.DiversityOfResources,
                    //AccessToFunds = subjectiveParametersEntity.AccessToFunds,
                    CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                    AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                    AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                    NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                    //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                    NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                    //LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                    CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                    NPASysGen = subjectiveParametersEntity.NPASysGen,
                    NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                    CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                    NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                    SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                    QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                    DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,
                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,

                    ExternalRating = subjectiveParametersEntity.ExternalRating,
                    CollateralCoverageRatio = subjectiveParametersEntity.CollateralCoverageRatio,
                    RelatedPartyTranscations = subjectiveParametersEntity.RelatedPartyTranscations,
                    GapsinSLSWithinRegulatoryLimits = subjectiveParametersEntity.GapsinSLSWithinRegulatoryLimits,

                    //IsFinal = false,
                };

                HFCNew_SubjectiveParameters subjectiveParameters = new HFCNew_SubjectiveParameters
                {
                    DetailsId = detailID,
                    //PropensityToSupportInstitution = subjectiveParametersEntity.PropensityToSupportInstitution,
                    IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                    BusinessModel = subjectiveParametersEntity.BusinessModel,
                    ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                    //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                    AdverseNews = subjectiveParametersEntity.AdverseNews,
                    //ProspectOfKeyMarkets = subjectiveParametersEntity.ProspectOfKeyMarkets,
                    GeographicalDiversification = subjectiveParametersEntity.GeographicalDiversification,
                    DiversityOfResources = subjectiveParametersEntity.DiversityOfResources,
                    //AccessToFunds = subjectiveParametersEntity.AccessToFunds,
                    CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                    AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                    AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                    NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                    //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                    NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                    //LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                    CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                    NPASysGen = subjectiveParametersEntity.NPASysGen,
                    NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                    CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                    NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                    SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                    QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                    DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

                    ExternalRating = subjectiveParametersEntity.ExternalRating,
                    CollateralCoverageRatio = subjectiveParametersEntity.CollateralCoverageRatio,
                    RelatedPartyTranscations = subjectiveParametersEntity.RelatedPartyTranscations,
                    GapsinSLSWithinRegulatoryLimits = subjectiveParametersEntity.GapsinSLSWithinRegulatoryLimits,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region  Add Data


                    if (subjectiveParameters != null && CheckIfAlreadyExists_SubjectiveParameters(detailID) == false)
                    {
                        try
                        {
                            status = Add_HFCNewSubjectiveParameter(subjectiveParameters);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            HFCNew_SubjectiveParameters hfcNew_SubjectiveParameters_Update = dbContext.HFCNew_SubjectiveParameters.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (hfcNew_SubjectiveParameters_Update != null)
                            {
                                hfcNew_SubjectiveParameters_Update.PropensityToSupportInstitution = subjectiveParameters.PropensityToSupportInstitution;
                                hfcNew_SubjectiveParameters_Update.IndustryRiskScore = subjectiveParameters.IndustryRiskScore;
                                hfcNew_SubjectiveParameters_Update.BusinessModel = subjectiveParameters.BusinessModel;
                                hfcNew_SubjectiveParameters_Update.ManagementQuality = subjectiveParameters.ManagementQuality;
                                hfcNew_SubjectiveParameters_Update.UnderwritingStandards = subjectiveParameters.UnderwritingStandards;
                                hfcNew_SubjectiveParameters_Update.AdverseNews = subjectiveParameters.AdverseNews;
                                //hfcNew_SubjectiveParameters_Update.ProspectOfKeyMarkets = subjectiveParameters.ProspectOfKeyMarkets;
                                hfcNew_SubjectiveParameters_Update.GeographicalDiversification = subjectiveParameters.GeographicalDiversification;
                                hfcNew_SubjectiveParameters_Update.DiversityOfResources = subjectiveParameters.DiversityOfResources;
                                //hfcNew_SubjectiveParameters_Update.AccessToFunds = subjectiveParameters.AccessToFunds;

                                hfcNew_SubjectiveParameters_Update.CompanySpendsCorporateSocialResponsibility = subjectiveParameters.CompanySpendsCorporateSocialResponsibility;
                                hfcNew_SubjectiveParameters_Update.AuditCommitteeHeldOnTime = subjectiveParameters.AuditCommitteeHeldOnTime;
                                hfcNew_SubjectiveParameters_Update.AuditCommitteeDiscuAllCalendarItems = subjectiveParameters.AuditCommitteeDiscuAllCalendarItems;
                                hfcNew_SubjectiveParameters_Update.NoChangeAuditorsBeforeTerm = subjectiveParameters.NoChangeAuditorsBeforeTerm;
                                //hfcNew_SubjectiveParameters_Update.AuditCondByRepAuditFirms = subjectiveParameters.AuditCondByRepAuditFirms;
                                hfcNew_SubjectiveParameters_Update.NoIndKeyManResignBeforeTerm = subjectiveParameters.NoIndKeyManResignBeforeTerm;
                                hfcNew_SubjectiveParameters_Update.LessThanOnePerTotTran = subjectiveParameters.LessThanOnePerTotTran;
                                hfcNew_SubjectiveParameters_Update.CentDBCapturesAllData = subjectiveParameters.CentDBCapturesAllData;
                                hfcNew_SubjectiveParameters_Update.NPASysGen = subjectiveParameters.NPASysGen;
                                hfcNew_SubjectiveParameters_Update.NoDelayInReporting = subjectiveParameters.NoDelayInReporting;
                                hfcNew_SubjectiveParameters_Update.CompAndIndManagement = subjectiveParameters.CompAndIndManagement;
                                hfcNew_SubjectiveParameters_Update.NoDivBetRegAssess = subjectiveParameters.NoDivBetRegAssess;
                                hfcNew_SubjectiveParameters_Update.SMA1And2UnderLoanPort = subjectiveParameters.SMA1And2UnderLoanPort;
                                hfcNew_SubjectiveParameters_Update.QualifiedOpinionByAuditor = subjectiveParameters.QualifiedOpinionByAuditor;
                                hfcNew_SubjectiveParameters_Update.DefaultWithOtherLenders = subjectiveParameters.DefaultWithOtherLenders;


                                hfcNew_SubjectiveParameters_Update.ExternalRating = subjectiveParameters.ExternalRating;
                                hfcNew_SubjectiveParameters_Update.CollateralCoverageRatio = subjectiveParameters.CollateralCoverageRatio;
                                hfcNew_SubjectiveParameters_Update.RelatedPartyTranscations = subjectiveParameters.RelatedPartyTranscations;
                                hfcNew_SubjectiveParameters_Update.GapsinSLSWithinRegulatoryLimits = subjectiveParameters.GapsinSLSWithinRegulatoryLimits;

                                hfcNew_SubjectiveParameters_Update.UpdatedBy = subjectiveParameters.UpdatedBy;
                                hfcNew_SubjectiveParameters_Update.UpdatedDateTime = subjectiveParameters.UpdatedDateTime;

                                dbContext.SaveChanges();
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return false;
                            }
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            return false;
                        }
                    }

                    #endregion

                    status = Add_HFCNewSubjectiveParameter_Archive(subjectiveParameters_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return true;

        }

        public bool Add_HFCNewSubjectiveParameter(HFCNew_SubjectiveParameters hfcNew_SubjectiveParameters)
        {
            try
            {
                dbContext.HFCNew_SubjectiveParameters.Add(hfcNew_SubjectiveParameters);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_HFCNewSubjectiveParameter_Archive(HFCNew_SubjectiveParameters_Archive hfcNew_SubjectiveParameters_Archive)
        {
            try
            {
                dbContext.HFCNew_SubjectiveParameters_Archive.Add(hfcNew_SubjectiveParameters_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_OutputDetails(int userId, int roleId, int detailID, short logID, int detail_ArchiveID, DateTime CreatedDateTime, List<HFCNew_OutputDetailsEntity> outputDetailsEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                if (outputDetailsEntity != null && userId != 0)
                {
                    List<HFCNew_Output_Details> output_Details = new List<HFCNew_Output_Details>();
                    List<HFCNew_Output_Details_Archive> output_Details_Archive = new List<HFCNew_Output_Details_Archive>();

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details.Add(new HFCNew_Output_Details
                        {

                            DetailsId = detailID,
                            TemplateId = values.TemplateID,
                            Parameter_Per = values.Parameter3Per,
                            Parameter_Name = string.IsNullOrEmpty(values.Parameter3) ? values.Parameter1 : values.Parameter3,

                            UnderBaselIII_Score = values.UnderBaselIII_Score,
                            UnderBaselIII_Value = values.UnderBaselIII_Value,
                            UnderIND_Score = values.UnderIND_Score,
                            UnderIND_Value = values.UnderIND_Value,
                            Comments = values.Comments,

                            CreatedDateTime = DateTime.Now,
                        });
                    };

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details_Archive.Add(new HFCNew_Output_Details_Archive
                        {
                            DetailsId = detailID,
                            LogId = logID,

                            Details_ArchiveId = detail_ArchiveID,
                            UserId = userId,
                            TemplateId = values.TemplateID,
                            Parameter_Per = values.Parameter3Per,
                            Parameter_Name = string.IsNullOrEmpty(values.Parameter3) ? values.Parameter1 : values.Parameter3,

                            UnderBaselIII_Score = values.UnderBaselIII_Score,
                            UnderBaselIII_Value = values.UnderBaselIII_Value,

                            UnderIND_Score = values.UnderIND_Score,
                            UnderIND_Value = values.UnderIND_Value,
                            Comments = values.Comments,
                            CreatedDateTime = DateTime.Now,
                            UpdatedDateTime = CreatedDateTime,
                        });
                    };

                    if (output_Details != null)
                    {
                        if (CheckIfAlreadyExists_OutputDetails(detailID) == true)
                        {
                            Delete_OutputDetails(detailID);
                        }
                        status = Add_OutputDetails(output_Details);
                        status = Add_OutputDetails_Archive(output_Details_Archive);

                        dbContextTransaction.Commit();
                        status = true;
                    }
                }
            }

            return status;

        }

        public bool Delete_OutputDetails(int detailsID)
        {
            try
            {
                dbContext.HFCNew_Output_Details.RemoveRange(dbContext.HFCNew_Output_Details.Where(c => c.DetailsId == detailsID));
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_OutputDetails(List<HFCNew_Output_Details> output_Details)
        {
            try
            {
                dbContext.HFCNew_Output_Details.AddRange(output_Details);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_OutputDetails_Archive(List<HFCNew_Output_Details_Archive> output_Details_Archive)
        {
            try
            {
                dbContext.HFCNew_Output_Details_Archive.AddRange(output_Details_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Get_OutputDetailsFromFrontEnd_InterOp(int detailsID, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Key Financials List

            List<HFCNew_KeyFinancialsEntity> getKeyFinancialsEntity = dbContext.HFCNew_KeyFinancials
              .Where(a => a.DetailsId == detailsID
              )
              .Select(keyFinancialsEntity => new HFCNew_KeyFinancialsEntity
              {
                  //PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1.Value.ToString("dd-MMM-yyyy"),
                  //PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2.Value.ToString("dd-MMM-yyyy"),
                  PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1.Value,
                  PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2.Value,
                  NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                  NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                  Currency1 = keyFinancialsEntity.Currency1,
                  Currency2 = keyFinancialsEntity.Currency2,
                  NetWorth1 = keyFinancialsEntity.NetWorth1,
                  NetWorth2 = keyFinancialsEntity.NetWorth2,
                  TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                  TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                  //UnencumberedLiquidAssetsPer1 = keyFinancialsEntity.UnencumberedLiquidAssetsPer1,
                  //UnencumberedLiquidAssetsPer2 = keyFinancialsEntity.UnencumberedLiquidAssetsPer2,
                  ReturnonEquityPer1 = keyFinancialsEntity.ReturnonEquityPer1,
                  ReturnonEquityPer2 = keyFinancialsEntity.ReturnonEquityPer2,

                  ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                  ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                  //ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                  //ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                  CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                  CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                  NetInterestMarginPer1 = keyFinancialsEntity.NetInterestMarginPer1,
                  NetInterestMarginPer2 = keyFinancialsEntity.NetInterestMarginPer2,
                  CRARPer1 = keyFinancialsEntity.CRARPer1,
                  CRARPer2 = keyFinancialsEntity.CRARPer2,
                  Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                  Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                  NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                  NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                  TotalNoOfBranches1 = keyFinancialsEntity.TotalNoOfBranches1,
                  TotalNoOfBranches2 = keyFinancialsEntity.TotalNoOfBranches2,
                  GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                  GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                  AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                  AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                  TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                  TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                  TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                  TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                  //IndividualHousingLoanTotalAdvancesPer1 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer1,
                  //IndividualHousingLoanTotalAdvancesPer2 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer2,
                  LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                  LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                  CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                  CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                  CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                  CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                  PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                  PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                  //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                  //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                  Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                  Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                  //AssetGrowthHousingLoansPer1 = keyFinancialsEntity.AssetGrowthHousingLoansPer1,
                  //AssetGrowthHousingLoansPer2 = keyFinancialsEntity.AssetGrowthHousingLoansPer2,
                  BusinessINRmnemployee1 = keyFinancialsEntity.BusinessINRmnemployee1,
                  BusinessINRmnemployee2 = keyFinancialsEntity.BusinessINRmnemployee2,
                  PresenceinStatesUT1 = keyFinancialsEntity.PresenceinStatesUT1,
                  PresenceinStatesUT2 = keyFinancialsEntity.PresenceinStatesUT2,
                  YearsPassedSinceCommencementofHFC1 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC1,
                  YearsPassedSinceCommencementofHFC2 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC2,
                  GrowthinAdvancesPer1 = keyFinancialsEntity.GrowthinAdvancesPer1,
                  GrowthinAdvancesPer2 = keyFinancialsEntity.GrowthinAdvancesPer2,
                  Gearing1 = keyFinancialsEntity.GearingPer1,
                  Gearing2 = keyFinancialsEntity.GearingPer2,
                  //Leverage1 = keyFinancialsEntity.Leverage1,
                  //Leverage2 = keyFinancialsEntity.Leverage2,

                  PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1,
                  PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2,
                  PBCtowardsHousingFinanceAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer1,
                  PBCtowardsHousingFinanceAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer2,

              }).ToList();

            #endregion

            #region Subjective Parameters List

            List<HFCNew_SubjectiveParametersEntity> getSubjectiveParametersEntity = dbContext.HFCNew_SubjectiveParameters
              .Where(a => a.DetailsId == detailsID
              )
              .Select(subjectiveParametersEntity => new HFCNew_SubjectiveParametersEntity
              {
                  //PropensityToSupportInstitution = subjectiveParametersEntity.PropensityToSupportInstitution,
                  IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                  BusinessModel = subjectiveParametersEntity.BusinessModel,
                  ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                  //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                  AdverseNews = subjectiveParametersEntity.AdverseNews,
                  //ProspectOfKeyMarkets = subjectiveParametersEntity.ProspectOfKeyMarkets,
                  GeographicalDiversification = subjectiveParametersEntity.GeographicalDiversification,
                  DiversityOfResources = subjectiveParametersEntity.DiversityOfResources,
                  //AccessToFunds = subjectiveParametersEntity.AccessToFunds,

                  ExternalRating = subjectiveParametersEntity.ExternalRating,
                  CollateralCoverageRatio = subjectiveParametersEntity.CollateralCoverageRatio,
                  RelatedPartyTranscations = subjectiveParametersEntity.RelatedPartyTranscations,
                  GapsinSLSWithinRegulatoryLimits = subjectiveParametersEntity.GapsinSLSWithinRegulatoryLimits,

              }).ToList();

            #endregion


            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            //Get the already exists sheet
            //mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(2);
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Input Sheet"];

            string value = "";
            uint rowIndex = 0;
            int columnIndex = 0;

            string columnName = "";
            object obj;
            //mWSheet.Cells[11, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate1_Liabilities;
            HFCNew_KeyFinancialsEntity hfcNew_KeyFinancialsEntity = new HFCNew_KeyFinancialsEntity();
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(hfcNew_KeyFinancialsEntity);
            properties = TypeDescriptor.GetProperties(hfcNew_KeyFinancialsEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {

                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getKeyFinancialsEntity[0].GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            HFCNew_SubjectiveParametersEntity hfcNew_SubjectiveParametersEntity = new HFCNew_SubjectiveParametersEntity();
            properties = TypeDescriptor.GetProperties(hfcNew_SubjectiveParametersEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getSubjectiveParametersEntity[0].GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }


            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();

            return true;
        }

        public bool Get_OutputDetailsFromFrontEnd_OpenXML(int detailsID, string OutputTemplateFilePath)
        {
            // Open the document for editing.
            using (DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadSheet = DocumentFormat.OpenXml.Packaging.SpreadsheetDocument.Open(OutputTemplateFilePath, true))
            {
                // Access the main Workbook part, which contains all references.
                DocumentFormat.OpenXml.Packaging.WorkbookPart workbookPart = spreadSheet.WorkbookPart;
                // get sheet by name
                DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbookPart.Workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == "Data Input Sheet").FirstOrDefault();

                // get worksheetpart by sheet id
                DocumentFormat.OpenXml.Packaging.WorksheetPart worksheetPart = workbookPart.GetPartById(sheet.Id.Value) as DocumentFormat.OpenXml.Packaging.WorksheetPart;
                CompanyDAL companyDAL = new CompanyDAL();

                List<HFCNew_KeyFinancialsEntity> getKeyFinancialsEntity = dbContext.HFCNew_KeyFinancials
                  .Where(a => a.DetailsId == detailsID
                  )
                  .Select(keyFinancialsEntity => new HFCNew_KeyFinancialsEntity
                  {
                      PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1.Value,
                      PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2.Value,
                      NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                      NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                      Currency1 = keyFinancialsEntity.Currency1,
                      Currency2 = keyFinancialsEntity.Currency2,
                      NetWorth1 = keyFinancialsEntity.NetWorth1,
                      NetWorth2 = keyFinancialsEntity.NetWorth2,
                      TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                      TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                      //UnencumberedLiquidAssetsPer1 = keyFinancialsEntity.UnencumberedLiquidAssetsPer1,
                      //UnencumberedLiquidAssetsPer2 = keyFinancialsEntity.UnencumberedLiquidAssetsPer2,
                      ReturnonEquityPer1 = keyFinancialsEntity.ReturnonEquityPer1,
                      ReturnonEquityPer2 = keyFinancialsEntity.ReturnonEquityPer2,

                      ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                      ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                      //ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                      //ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                      CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                      CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                      NetInterestMarginPer1 = keyFinancialsEntity.NetInterestMarginPer1,
                      NetInterestMarginPer2 = keyFinancialsEntity.NetInterestMarginPer2,
                      CRARPer1 = keyFinancialsEntity.CRARPer1,
                      CRARPer2 = keyFinancialsEntity.CRARPer2,
                      Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                      Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                      NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                      NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                      TotalNoOfBranches1 = keyFinancialsEntity.TotalNoOfBranches1,
                      TotalNoOfBranches2 = keyFinancialsEntity.TotalNoOfBranches2,
                      GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                      GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                      AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                      AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                      TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                      TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                      TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                      TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                      //IndividualHousingLoanTotalAdvancesPer1 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer1,
                      //IndividualHousingLoanTotalAdvancesPer2 = keyFinancialsEntity.IndividualHousingLoanTotalAdvancesPer2,
                      LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                      LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                      CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                      CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                      CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                      CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                      PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                      PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                      //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                      //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                      Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                      Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                      //AssetGrowthHousingLoansPer1 = keyFinancialsEntity.AssetGrowthHousingLoansPer1,
                      //AssetGrowthHousingLoansPer2 = keyFinancialsEntity.AssetGrowthHousingLoansPer2,
                      BusinessINRmnemployee1 = keyFinancialsEntity.BusinessINRmnemployee1,
                      BusinessINRmnemployee2 = keyFinancialsEntity.BusinessINRmnemployee2,
                      PresenceinStatesUT1 = keyFinancialsEntity.PresenceinStatesUT1,
                      PresenceinStatesUT2 = keyFinancialsEntity.PresenceinStatesUT2,
                      YearsPassedSinceCommencementofHFC1 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC1,
                      YearsPassedSinceCommencementofHFC2 = keyFinancialsEntity.YearsPassedSinceCommencementofHFC2,
                      GrowthinAdvancesPer1 = keyFinancialsEntity.GrowthinAdvancesPer1,
                      GrowthinAdvancesPer2 = keyFinancialsEntity.GrowthinAdvancesPer2,
                      Gearing1 = keyFinancialsEntity.GearingPer1,
                      Gearing2 = keyFinancialsEntity.GearingPer2,
                      //Leverage1 = keyFinancialsEntity.Leverage1,
                      //Leverage2 = keyFinancialsEntity.Leverage2

                      PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1,
                      PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2,
                      PBCtowardsHousingFinanceAsofTotalAssetsPer1 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer1,
                      PBCtowardsHousingFinanceAsofTotalAssetsPer2 = keyFinancialsEntity.PBCtowardsHousingFinanceAsofTotalAssetsPer2,

                  }).ToList();


                List<HFCNew_SubjectiveParametersEntity> getSubjectiveParametersEntity = dbContext.HFCNew_SubjectiveParameters
                  .Where(a => a.DetailsId == detailsID
                  )
                  .Select(subjectiveParametersEntity => new HFCNew_SubjectiveParametersEntity
                  {
                      //PropensityToSupportInstitution = subjectiveParametersEntity.PropensityToSupportInstitution,
                      IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                      BusinessModel = subjectiveParametersEntity.BusinessModel,
                      ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                      //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                      AdverseNews = subjectiveParametersEntity.AdverseNews,
                      //ProspectOfKeyMarkets = subjectiveParametersEntity.ProspectOfKeyMarkets,
                      GeographicalDiversification = subjectiveParametersEntity.GeographicalDiversification,
                      DiversityOfResources = subjectiveParametersEntity.DiversityOfResources,
                      //AccessToFunds = subjectiveParametersEntity.AccessToFunds,
                      CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                      AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                      AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                      NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                      //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                      NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                      //LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                      CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                      NPASysGen = subjectiveParametersEntity.NPASysGen,
                      NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                      CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                      NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                      SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                      QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                      DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

                      ExternalRating = subjectiveParametersEntity.ExternalRating,
                      CollateralCoverageRatio = subjectiveParametersEntity.CollateralCoverageRatio,
                      RelatedPartyTranscations = subjectiveParametersEntity.RelatedPartyTranscations,
                      GapsinSLSWithinRegulatoryLimits = subjectiveParametersEntity.GapsinSLSWithinRegulatoryLimits,

                  }).ToList();

                Cell cell = null;
                uint rowIndex = 0;
                string columnName = "";
                object obj = "";
                string value = "";

                HFCNew_KeyFinancialsEntity hfcNew_KeyFinancialsEntity = new HFCNew_KeyFinancialsEntity();
                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(hfcNew_KeyFinancialsEntity);
                properties = TypeDescriptor.GetProperties(hfcNew_KeyFinancialsEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);

                            if (rowIndex == 0)
                            {
                                continue;
                            }

                            cell = GetCell(worksheetPart.Worksheet, columnName, rowIndex);
                            obj = getKeyFinancialsEntity[0].GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity[0], null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                            }
                            cell.CellValue = new CellValue(value.ToString());
                            //cell.DataType = CellValues.InlineString;
                            //cell.InlineString = new InlineString() { Text = new Text(value) };
                        }
                        catch { }
                    }
                }

                HFCNew_SubjectiveParametersEntity hfcNew_SubjectiveParametersEntity = new HFCNew_SubjectiveParametersEntity();
                properties = TypeDescriptor.GetProperties(hfcNew_SubjectiveParametersEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);

                            if (rowIndex == 0)
                            {
                                continue;
                            }

                            cell = GetCell(worksheetPart.Worksheet, columnName, rowIndex);
                            obj = getSubjectiveParametersEntity[0].GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity[0], null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                            }
                            cell.CellValue = new CellValue(value.ToString());
                            //   cell.DataType = CellValues.InlineString;
                            //cell.InlineString = new InlineString() { Text = new Text(value) };
                        }
                        catch { }
                    }
                }

                spreadSheet.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                spreadSheet.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;

                // Save the worksheet.
                worksheetPart.Worksheet.Save();
                workbookPart.Workbook.Save();
                // for recacluation of formula

                spreadSheet.Close();
                //Process[] excelProcesses = Process.GetProcessesByName("excel");
                //foreach (Process p in excelProcesses)
                //{
                //    if (string.IsNullOrEmpty(p.MainWindowTitle)) // use MainWindowTitle to distinguish this excel process with other excel processes 
                //    {
                //        p.Kill();
                //    }
                //}
            }
            return true;
        }

        public bool Get_OutputDetails_OpenXML_DetailsId_old(int detailsId, string companyName, string OutputTemplateFilePath)
        {
            // Open the document for editing.
            using (DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadSheet = DocumentFormat.OpenXml.Packaging.SpreadsheetDocument.Open(OutputTemplateFilePath, true))
            {
                // Access the main Workbook part, which contains all references.
                DocumentFormat.OpenXml.Packaging.WorkbookPart workbookPart = spreadSheet.WorkbookPart;
                // get sheet by name
                DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbookPart.Workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == "Output NHB").FirstOrDefault();

                // get worksheetpart by sheet id
                DocumentFormat.OpenXml.Packaging.WorksheetPart worksheetPart = workbookPart.GetPartById(sheet.Id.Value) as DocumentFormat.OpenXml.Packaging.WorksheetPart;
                List<HFCNew_OutputDetailsEntity> getOutputDetails = dbContext.HFCNew_Output_Details
                  .Where(riskOutputs => riskOutputs.DetailsId == detailsId
                  )
                  .Select(Outputs => new HFCNew_OutputDetailsEntity
                  {
                      Parameter3 = Outputs.Parameter_Name,

                      UnderIND_Score = Outputs.UnderIND_Score,
                      UnderIND_Value = Outputs.UnderIND_Value,
                      UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                      UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
                  }).ToList();

                uint rowNo = 3;
                Cell cell = GetCell(worksheetPart.Worksheet, "G", 2);
                cell.CellValue = new CellValue(companyName);

                for (int i = 0; i < getOutputDetails.Count; i++)
                {
                    cell = GetCell(worksheetPart.Worksheet, "J", rowNo);
                    cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Score);
                    cell = GetCell(worksheetPart.Worksheet, "K", rowNo);
                    cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Value);
                    cell = GetCell(worksheetPart.Worksheet, "M", rowNo);
                    cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Score);
                    cell = GetCell(worksheetPart.Worksheet, "N", rowNo);
                    cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Value);
                    rowNo++;
                    //cell.DataType = new EnumValue<CellValues>(CellValues.Number);
                }
                // Save the worksheet.
                worksheetPart.Worksheet.Save();

                // for recacluation of formula
                spreadSheet.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                spreadSheet.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;
                // Regulatory Environment

            }
            return true;
        }

        public bool Get_OutputDetails_InterOp_DetailsId(int detailsId, string companyName, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Key Financials List

            List<HFCNew_OutputDetailsEntity> getOutputDetails = dbContext.HFCNew_Output_Details
              .Where(a => a.DetailsId == detailsId
              )
              .Select(Outputs => new HFCNew_OutputDetailsEntity
              {
                  Parameter3Per = Outputs.Parameter_Per,
                  Parameter3 = Outputs.Parameter_Name,
                  UnderIND_Score = Outputs.UnderIND_Score,
                  UnderIND_Value = Outputs.UnderIND_Value,
                  UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                  UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
              }).ToList();

            #endregion


            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Output NHB"];


            uint rowIndex = 2;
            int columnIndex = 0;
            columnIndex = _helperDAL.GetExcelColumnIndex("G");
            mWSheet.Cells[rowIndex, columnIndex] = companyName;
            rowIndex = 3;

            for (int i = 0; i < getOutputDetails.Count; i++)
            {
                columnIndex = _helperDAL.GetExcelColumnIndex("J");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("K");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Score;

                columnIndex = _helperDAL.GetExcelColumnIndex("M");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("N");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Score;
                rowIndex++;
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();


            return true;
        }


        public bool Get_OutputDetails_OpenXML(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            // Open the document for editing.
            using (DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadSheet = DocumentFormat.OpenXml.Packaging.SpreadsheetDocument.Open(OutputTemplateFilePath, true))
            {
                // Access the main Workbook part, which contains all references.
                DocumentFormat.OpenXml.Packaging.WorkbookPart workbookPart = spreadSheet.WorkbookPart;
                // get sheet by name
                DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbookPart.Workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == "Output NHB").FirstOrDefault();

                // get worksheetpart by sheet id
                DocumentFormat.OpenXml.Packaging.WorksheetPart worksheetPart = workbookPart.GetPartById(sheet.Id.Value) as DocumentFormat.OpenXml.Packaging.WorksheetPart;
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByID(companyId);

                // The SheetData object will contain all the data.
                int detailArchivedID = (from output in dbContext.HFCNew_Output_Details_Archive
                                        join basicDetails in dbContext.NHB_Details_Archive on output.Details_ArchiveId equals basicDetails.Details_ArchiveId
                                        where basicDetails.CompanyId == companyId
                                        && DbFunctions.TruncateTime(output.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime)
                                        select output.Details_ArchiveId).OrderByDescending(data => data).FirstOrDefault();
                if (detailArchivedID > 0)
                {
                    List<HFCNew_OutputDetailsEntity> getOutputDetails = dbContext.HFCNew_Output_Details_Archive
                      .Where(riskOutputs => riskOutputs.Details_ArchiveId == detailArchivedID
                      )
                      .Select(Outputs => new HFCNew_OutputDetailsEntity
                      {
                          Parameter3 = Outputs.Parameter_Name,

                          UnderIND_Score = Outputs.UnderIND_Score,
                          UnderIND_Value = Outputs.UnderIND_Value,
                          UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                          UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
                      }).ToList();

                    uint rowNo = 3;
                    Cell cell = GetCell(worksheetPart.Worksheet, "G", 2);
                    cell.CellValue = new CellValue(companyName);

                    for (int i = 0; i < getOutputDetails.Count; i++)
                    {
                        cell = GetCell(worksheetPart.Worksheet, "J", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Score);
                        cell = GetCell(worksheetPart.Worksheet, "K", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Value);
                        cell = GetCell(worksheetPart.Worksheet, "M", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Score);
                        cell = GetCell(worksheetPart.Worksheet, "N", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Value);
                        rowNo++;
                        //cell.DataType = new EnumValue<CellValues>(CellValues.Number);
                    }
                    // Save the worksheet.
                    worksheetPart.Worksheet.Save();

                    // for recacluation of formula
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;


                }


                // Regulatory Environment

            }
            return true;
        }

        private Cell GetCell(Worksheet worksheet, string columnName, uint rowIndex)
        {
            Row row = GetRow(worksheet, rowIndex);
            if (row == null) return null;

            var FirstRow = row.Elements<Cell>().Where(c => string.Compare
            (c.CellReference.Value, columnName +
            rowIndex, true) == 0).FirstOrDefault();

            if (FirstRow == null) return null;

            return FirstRow;
        }

        private Row GetRow(Worksheet worksheet, uint rowIndex)
        {
            Row row = worksheet.GetFirstChild<SheetData>().
            Elements<Row>().FirstOrDefault(r => r.RowIndex == rowIndex);
            if (row == null)
            {
                throw new ArgumentException(String.Format("No row with index {0} found in spreadsheet", rowIndex));
            }
            return row;
        }

        private uint GetRowIndex(Worksheet worksheet, string excelRowText)
        {
            try
            {
                Row row = worksheet.GetFirstChild<SheetData>().
                Elements<Row>().FirstOrDefault(r => r.InnerText.Contains(excelRowText));

                row = worksheet.GetFirstChild<SheetData>().
                Elements<Row>().FirstOrDefault(r => r.RowIndex == 8);
                return row.RowIndex;
            }
            catch { return 0; }
        }



        public bool Get_HFCNewOutputDetails_OpenXML_old(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            bool status = false;
            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            try
            {
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                object misValue = System.Reflection.Missing.Value;
                xlApp.DisplayAlerts = false;
                xlApp.EditDirectlyInCell = true;
                xlApp.EnableEvents = true;

                int detailID = (from output in dbContext.HFCNew_Output_Details
                                join hfcNewBasicDetails in dbContext.NHB_Details on output.DetailsId equals hfcNewBasicDetails.DetailsId
                                where hfcNewBasicDetails.CompanyId == companyId
                                select output.DetailsId).FirstOrDefault();

                //select (int)issuers.BussinessGroupID).SingleOrDefault();
                //int detailID = dbContext.HFCNew_Output_Details.Where(detailId => detailId.CompanyId == companyId).Select(detailId => detailId.DetailsId).FirstOrDefault();

                if (detailID != 0)
                {
                    List<HFCNew_Output_Details> getOutputDetails = dbContext.HFCNew_Output_Details
                          .Where(riskOutputs => riskOutputs.DetailsId == detailID
                          //&& DbFunctions.TruncateTime(riskOutputs.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime))
                          )
                          .Select(Outputs => new HFCNew_Output_Details
                          {

                          }).ToList();//.OrderByDescending(riskOutputs => riskOutputs.UpdatedDateTime).Take(1).FirstOrDefault();

                    mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                    mWorkSheets = mWorkBook.Worksheets;
                    //Get the already exists sheet
                    mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(1);
                    if (getOutputDetails != null)
                    {
                        //mWSheet.Cells[2, 6] = ExtensionMethod.GetFormattedData(getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersWeight);
                        //mWSheet.Cells[2, 7] = getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersValue;
                        //mWSheet.Cells[2, 8] = getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersScore;
                        //mWSheet.Cells[3, 6] = ExtensionMethod.GetFormattedData(getOutputDetails.IndustryRiskCompetitionsWeight);
                        //mWSheet.Cells[3, 7] = getOutputDetails.IndustryRiskCompetitionsValue;
                        //mWSheet.Cells[3, 8] = getOutputDetails.IndustryRiskCompetitionsScore;

                    }
                    else
                    {
                        getOutputDetails = null;
                        status = false;
                    }

                    mWorkBook.Save();
                    mWorkBook.Close(1, null, null);
                    xlApp.Quit();
                    status = true;

                    mWSheet = null;
                    mWorkBook = null;
                    mWorkSheets = null;
                    xlApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return status;
        }

        public bool Get_HFCNewOutputDetails_ExcelInterOP(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            bool status = false;
            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            try
            {
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                object misValue = System.Reflection.Missing.Value;
                xlApp.DisplayAlerts = false;
                xlApp.EditDirectlyInCell = true;
                xlApp.EnableEvents = true;

                int detailID = (from output in dbContext.HFCNew_Output_Details
                                join hfcNewBasicDetails in dbContext.NHB_Details on output.DetailsId equals hfcNewBasicDetails.DetailsId
                                where hfcNewBasicDetails.CompanyId == companyId
                                select output.DetailsId).FirstOrDefault();

                //select (int)issuers.BussinessGroupID).SingleOrDefault();
                //int detailID = dbContext.HFCNew_Output_Details.Where(detailId => detailId.CompanyId == companyId).Select(detailId => detailId.DetailsId).FirstOrDefault();

                if (detailID != 0)
                {
                    List<HFCNew_Output_Details> getOutputDetails = dbContext.HFCNew_Output_Details
                          .Where(riskOutputs => riskOutputs.DetailsId == detailID
                          //&& DbFunctions.TruncateTime(riskOutputs.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime))
                          )
                          .Select(Outputs => new HFCNew_Output_Details
                          {

                          }).ToList();//.OrderByDescending(riskOutputs => riskOutputs.UpdatedDateTime).Take(1).FirstOrDefault();

                    mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                    mWorkSheets = mWorkBook.Worksheets;
                    //Get the already exists sheet
                    mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(1);
                    if (getOutputDetails != null)
                    {
                        //mWSheet.Cells[2, 6] = ExtensionMethod.GetFormattedData(getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersWeight);
                        //mWSheet.Cells[2, 7] = getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersValue;
                        //mWSheet.Cells[2, 8] = getOutputDetails.IndustryRiskFinancialPerformanceOfPlayersScore;
                        //mWSheet.Cells[3, 6] = ExtensionMethod.GetFormattedData(getOutputDetails.IndustryRiskCompetitionsWeight);
                        //mWSheet.Cells[3, 7] = getOutputDetails.IndustryRiskCompetitionsValue;
                        //mWSheet.Cells[3, 8] = getOutputDetails.IndustryRiskCompetitionsScore;

                    }
                    else
                    {
                        getOutputDetails = null;
                        status = false;
                    }

                    mWorkBook.Save();
                    mWorkBook.Close(1, null, null);
                    xlApp.Quit();
                    status = true;

                    mWSheet = null;
                    mWorkBook = null;
                    mWorkSheets = null;
                    xlApp = null;

                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();

                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return status;
        }

        public bool CheckIfAlreadyExists_KeyFinancial(int detailsId)
        {
            return dbContext.HFCNew_KeyFinancials.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_SubjectiveParameters(int detailsId)
        {
            return dbContext.HFCNew_SubjectiveParameters.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_OutputDetails(int detailsId)
        {
            return dbContext.HFCNew_Output_Details.Any(asset => asset.DetailsId == detailsId);
        }

        public bool ComputeOutputDetails(HFCNew_BasicDetailsEntity riskModelExcelEntity, string OutputTemplateFilePath)
        {
            CompanyDAL companyDAL = new CompanyDAL();
            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            try
            {
                mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                mWorkSheets = mWorkBook.Worksheets;
                mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Input Sheet"];

                string value = "";
                uint rowIndex = 0;
                int columnIndex = 0;

                string columnName = "";
                object obj;

                // Basic detail fields update - Company Name
                try
                {
                    string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);

                    rowIndex = _helperDAL.GetExcelRowIndex("B4");
                    columnName = _helperDAL.GetExcelColumnName("B4");
                    columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                    mWSheet.Cells[rowIndex, columnIndex] = companyName;
                }
                catch { }

                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
                properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = riskModelExcelEntity.GetType().GetProperty(property.Name).GetValue(riskModelExcelEntity, null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                try
                                {
                                    value = Convert.ToString(double.Parse(value) / 100);
                                    //value = (value == string.Empty || value.ToUpper().Trim() == "NA") ? "0" : Convert.ToString(double.Parse(value) / 100);
                                }
                                catch
                                {

                                }
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                properties = TypeDescriptor.GetProperties(riskModelExcelEntity.HFCNew_KeyFinancialsEntity);
                HFCNew_KeyFinancialsEntity getKeyFinancialsEntity = riskModelExcelEntity.HFCNew_KeyFinancialsEntity;
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = getKeyFinancialsEntity.GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity, null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                try
                                {
                                    value = Convert.ToString(double.Parse(value) / 100);
                                }
                                catch
                                {

                                }
                                //value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                properties = TypeDescriptor.GetProperties(riskModelExcelEntity.HFCNew_SubjectiveParametersEntity);
                HFCNew_SubjectiveParametersEntity getSubjectiveParametersEntity = riskModelExcelEntity.HFCNew_SubjectiveParametersEntity;

                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = getSubjectiveParametersEntity.GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity, null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                mWorkBook.Save();
                mWorkBook.Close(1, null, null);
                xlApp.Quit();
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                mWSheet = null;
                mWorkBook = null;
                mWorkSheets = null;
                xlApp = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return true;
        }


    }

}