﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Text;
using IndRa.RiskModel.DAL.Entities;
using DocumentFormat.OpenXml.Spreadsheet;
using System.ComponentModel;
using IndRa.RiskModel.DAL.DataAccess;
using System.Data.Entity.Validation;
using IndRa.RiskModel.DAL.DAL;
using System.Data.Entity;
using IndRa.RiskModel.Helpers;

namespace IndRa.RiskModel.DAL
{
    public class ACHFSDAL
    {
        HelperDAL _helperDAL = null;
        IndRaDBcontext dbContext = new IndRaDBcontext();

        public ACHFSDAL()
        {
            _helperDAL = new HelperDAL();
        }

        public List<ACHFS_OutputDetailsEntity> GetOutputTemplateEntity()
        {
            List<ACHFS_OutputDetailsEntity> outputTemplate = new List<ACHFS_OutputDetailsEntity>();
            outputTemplate = dbContext.ACHFS_Output_Template.Select(output => new ACHFS_OutputDetailsEntity
            {
                TemplateID = output.TemplateID,
                Parameter1 = string.IsNullOrEmpty(output.Parameter1) ? string.Empty : output.Parameter1,
                Parameter1Per = string.IsNullOrEmpty(output.Parameter1Per) ? string.Empty : output.Parameter1Per,
                Parameter2 = string.IsNullOrEmpty(output.Parameter2) ? string.Empty : output.Parameter2,
                Parameter2Per = string.IsNullOrEmpty(output.Parameter2Per) ? string.Empty : output.Parameter2Per,
                Parameter3 = string.IsNullOrEmpty(output.Parameter3) ? string.Empty : output.Parameter3,
                Parameter3Per = string.Empty,
                UnderBaselIII_Score = string.Empty,
                UnderBaselIII_Value = string.Empty,
                UnderIND_Score = string.Empty,
                UnderIND_Value = string.Empty,
                Comments = string.Empty,
            }).ToList();
            return outputTemplate;
        }
        public ACHFS_BasicDetailsEntity ImportCompanyDetailsFromExcel(string filePath, string fileName, string workSheet, int userId)
        {

            ACHFS_BasicDetailsEntity ACHFS_BasicDetails = new ACHFS_BasicDetailsEntity();
            ACHFS_KeyFinancialsEntity ACHFS_KeyFinancials = new ACHFS_KeyFinancialsEntity();
            ACHFS_SubjectiveParametersEntity ACHFS_SubjectiveParameters = new ACHFS_SubjectiveParametersEntity();

            string value = "";

            DataTable dtExcel = null;
            DataTable dtTranspose = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);
            dtTranspose = _helperDAL.GenerateTransposedTable(dtExcel);

            _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);

            if (dtTranspose.Rows.Count > 0)
            {
                // get values for ACHFS Basic Details
                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(ACHFS_BasicDetails);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }
                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);


                            property.SetValue(ACHFS_BasicDetails, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for ACHFS Key financials
                properties = TypeDescriptor.GetProperties(ACHFS_KeyFinancials);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(ACHFS_KeyFinancials, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for ACHFS Subjective Parameters
                properties = TypeDescriptor.GetProperties(ACHFS_SubjectiveParameters);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[2][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(ACHFS_SubjectiveParameters, safeValue);
                        }
                    }
                    catch { }

                }

                ACHFS_BasicDetails.ACHFS_KeyFinancialsEntity = ACHFS_KeyFinancials;
                ACHFS_BasicDetails.ACHFS_SubjectiveParametersEntity = ACHFS_SubjectiveParameters;

                CompanyDAL companyDAL = new CompanyDAL();
                int companyID = companyDAL.GetCompanyIDByCompanyName(ACHFS_BasicDetails.CompanyName, userId);
                ACHFS_BasicDetails.CompanyId = companyID;
                CommonDAL commonDAL = new CommonDAL();
                string finYear = commonDAL.GetFinYearBasedOnDate(DateTime.Now);
                ACHFS_BasicDetails.FinYear = finYear;
                //if (ACHFS_BasicDetails.DateOfInput.HasValue)
                //{
                //    DateTime dateOfInput = ACHFS_BasicDetails.DateOfInput.Value;
                //    string finYear = commonDAL.GetFinYearBasedOnDate(ACHFS_BasicDetails.DateOfInput.Value);
                //    ACHFS_BasicDetails.FinYear = finYear;
                //}
            }

            return ACHFS_BasicDetails;

        }

        public List<ACHFS_OutputDetailsEntity> GetOutputFromExcel(string filePath, string fileName, string workSheet, int userId)
        {
            List<ACHFS_OutputDetailsEntity> outputDetailsEntity = new List<ACHFS_OutputDetailsEntity>();
            DataTable dtExcel = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);

            string paramterName = "";

            if (dtExcel.Rows.Count > 0)
            {
                short row = 0;
                string underBaselIIIColumnName_Value = "Under Basel III";
                string underBaselIIIColumnName_Score = "";
                string UnderINDAS109ColumnName_Value = "Under IND AS 109";
                string UnderINDAS109ColumnName_Score = "";

                for (int col = 0; col < dtExcel.Columns.Count; col++)
                {
                    if (dtExcel.Columns[col].Caption == underBaselIIIColumnName_Value)
                    {
                        underBaselIIIColumnName_Score = dtExcel.Columns[col + 1].Caption;
                        continue;
                    }
                    else if (dtExcel.Columns[col].Caption == UnderINDAS109ColumnName_Value)
                    {
                        UnderINDAS109ColumnName_Score = dtExcel.Columns[col + 1].Caption;
                    }
                }
                for (int i = 1; i < dtExcel.Rows.Count; i++)
                {
                    ACHFS_OutputDetailsEntity newRow = new ACHFS_OutputDetailsEntity();
                    newRow.TemplateID = row;
                    paramterName = dtExcel.Rows[i]["F7"].ToString();
                    if (paramterName != string.Empty)
                    {
                    }
                    else
                    {
                        paramterName = dtExcel.Rows[i][0].ToString();
                    }
                    if (paramterName == string.Empty)
                    {
                        continue;
                    }
                    if (paramterName == "Rating / Probability of Default")
                    {
                        break;
                    }
                    newRow.Parameter1 = paramterName;
                    newRow.Parameter3Per = dtExcel.Rows[i]["F9"].ToString();
                    newRow.UnderBaselIII_Value = dtExcel.Rows[i][underBaselIIIColumnName_Value].ToString();
                    newRow.UnderBaselIII_Score = dtExcel.Rows[i][underBaselIIIColumnName_Score].ToString();

                    newRow.UnderIND_Value = dtExcel.Rows[i][UnderINDAS109ColumnName_Value].ToString();
                    newRow.UnderIND_Score = dtExcel.Rows[i][UnderINDAS109ColumnName_Score].ToString();

                    outputDetailsEntity.Add(newRow);
                    row++;
                }
            }


            return outputDetailsEntity;

        }
        public int SaveCompanyBasicDetailsAsDraft(int userId, int roleId, ACHFS_BasicDetailsEntity riskModelExcelEntity, out int basicDetails_ArchiveId, out short logID)
        {
            int detailsId = 0;
            basicDetails_ArchiveId = 0;
            logID = 0;
            CompanyDAL companyDAL = new CompanyDAL();
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                bool isRecordExist = companyDAL.CheckIfAlreadyExists_CompanyDetails(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                if (isRecordExist == true && riskModelExcelEntity.DetailsId == 0)
                {
                    detailsId = companyDAL.GetCompanyBasicDetailsID(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                    riskModelExcelEntity.DetailsId = detailsId;
                }
                if (riskModelExcelEntity.ButtonValue == ButtonValue.SubmitForApporval.ToString()) //"SubmitForApporval"
                {
                    riskModelExcelEntity.SubmitForApproval = true;
                    riskModelExcelEntity.SubmitForApprovalDate = DateTime.Now;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                {
                    riskModelExcelEntity.ApprovedDate = DateTime.Now;
                    riskModelExcelEntity.ReviewedDate = null;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ReviewDetails.ToString())
                {
                    riskModelExcelEntity.ReviewedDate = DateTime.Now;
                    riskModelExcelEntity.ApprovedDate = null;
                }

                logID = companyDAL.GetNHBLogId(riskModelExcelEntity.DetailsId);

                NHB_Details_Archive nHB_Details_Archive = new NHB_Details_Archive
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    SponsorBank = riskModelExcelEntity.SponsorBank,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString() ? true : false,
                    IsDraft = true
                };

                NHB_Details nHB_Details = new NHB_Details
                {
                    UserId = userId,
                    FinYear = riskModelExcelEntity.FinYear,

                    CompanyId = riskModelExcelEntity.CompanyId,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    SponsorBank = riskModelExcelEntity.SponsorBank,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    IsFinal = riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString() ? true : false,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                };

                NHB_Details_Final nHB_Details_Final = new NHB_Details_Final
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,

                    CompanyId = riskModelExcelEntity.CompanyId,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    SponsorBank = riskModelExcelEntity.SponsorBank,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    IsFinal = riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString() ? true : false,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                };

                if (userId != 0)
                {
                    #region Add Data

                    if (nHB_Details != null && companyDAL.CheckIfAlreadyExists_CompanyDetails(nHB_Details.CompanyId, nHB_Details.FinYear) == false)
                    {
                        try
                        {
                            detailsId = (int)companyDAL.AddCompanyDetails(nHB_Details);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }

                    }

                    #endregion

                    #region Update Data

                    else
                    {
                        try
                        {
                            NHB_Details details = dbContext.NHB_Details.Where(detail => detail.DetailsId == nHB_Details.DetailsId).FirstOrDefault();
                            if (details != null)
                            {
                                details.UserId = nHB_Details.UserId;
                                details.CompanyId = nHB_Details.CompanyId;
                                details.DateOfInput = nHB_Details.DateOfInput;
                                details.CurrencyUnits = nHB_Details.CurrencyUnits;
                                details.ParentCompanyId = nHB_Details.ParentCompanyId;
                                details.SponsorBank = nHB_Details.SponsorBank;
                                details.ParentCompanyShareHoldingPer = nHB_Details.ParentCompanyShareHoldingPer;
                                details.ParentCompanyName = nHB_Details.ParentCompanyName;
                                details.Comments = riskModelExcelEntity.Comments;
                                details.FinalRating = riskModelExcelEntity.FinalRating;
                                details.PD = riskModelExcelEntity.PD;
                                details.SubmitForApproval = nHB_Details.SubmitForApproval;
                                details.SubmitForApprovalDate = nHB_Details.SubmitForApprovalDate;
                                details.ApprovedDate = nHB_Details.ApprovedDate;
                                details.ReviewedDate = nHB_Details.ReviewedDate;

                                details.UpdatedBy = nHB_Details.UpdatedBy;
                                details.UpdatedDateTime = nHB_Details.UpdatedDateTime;
                                details.IsFinal = nHB_Details.IsFinal;
                                dbContext.SaveChanges();
                                detailsId = details.DetailsId;
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return -1;
                            }
                        }
                        catch (Exception exception)
                        {
                            throw exception;
                        }
                    }

                    #endregion

                    #region Final Data Add

                    if (nHB_Details.IsFinal == true)
                    {
                        try
                        {
                            companyDAL.AddCompanyDetails_Final(nHB_Details_Final);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    if (isRecordExist == false)
                    {
                        nHB_Details_Archive.UpdatedBy = null;
                        nHB_Details_Archive.UpdatedDateTime = null;
                    }
                    else
                    {
                        nHB_Details_Archive.CreatedBy = null;
                        nHB_Details_Archive.CreatedDateTime = null;
                    }
                    nHB_Details_Archive.DetailsId = detailsId;
                    basicDetails_ArchiveId = (int)companyDAL.AddCompanyDetails_Archive(nHB_Details_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return detailsId;

        }

        public bool SaveAsDraft_KeyFinancial(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, ACHFS_KeyFinancialsEntity keyFinancialsEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                ACHFS_KeyFinancials_Archive KeyFinancials_Archive = new ACHFS_KeyFinancials_Archive
                {
                    DetailsId = detailID,
                    UserId = userId,
                    LogId = logID,
                    PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                    PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                    PeriodEndingDate3 = keyFinancialsEntity.PeriodEndingDate3,
                    NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                    NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                    NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3,
                    Currency1 = keyFinancialsEntity.Currency1,
                    Currency2 = keyFinancialsEntity.Currency2,
                    Currency3 = keyFinancialsEntity.Currency3,
                    NetWorth1 = keyFinancialsEntity.NetWorth1,
                    NetWorth2 = keyFinancialsEntity.NetWorth2,
                    NetWorth3 = keyFinancialsEntity.NetWorth3,
                    TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                    TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                    TotalAssets3 = keyFinancialsEntity.TotalAssets3,
                    TotalMemberships1 = keyFinancialsEntity.TotalMemberships1,
                    TotalMemberships2 = keyFinancialsEntity.TotalMemberships2,
                    TotalMemberships3 = keyFinancialsEntity.TotalMemberships3,
                    TotalUnderconstructionCompletedHouses1 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses1,
                    TotalUnderconstructionCompletedHouses2 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses2,
                    TotalUnderconstructionCompletedHouses3 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses3,
                    GovtContributionTotalShareCapital1 = keyFinancialsEntity.GovtContributionTotalShareCapital1,
                    GovtContributionTotalShareCapital2 = keyFinancialsEntity.GovtContributionTotalShareCapital2,
                    GovtContributionTotalShareCapital3 = keyFinancialsEntity.GovtContributionTotalShareCapital3,
                    TotalAdvances1 = keyFinancialsEntity.TotalAdvances1,
                    TotalAdvances2 = keyFinancialsEntity.TotalAdvances2,
                    TotalAdvances3 = keyFinancialsEntity.TotalAdvances3,
                    InterestIncome1 = keyFinancialsEntity.InterestIncome1,
                    InterestIncome2 = keyFinancialsEntity.InterestIncome2,
                    InterestIncome3 = keyFinancialsEntity.InterestIncome3,
                    NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1,
                    NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2,
                    NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3,
                    InterestExpenses1 = keyFinancialsEntity.InterestExpenses1,
                    InterestExpenses2 = keyFinancialsEntity.InterestExpenses2,
                    InterestExpenses3 = keyFinancialsEntity.InterestExpenses3,
                    EmployeeGASDExpenses1 = keyFinancialsEntity.EmployeeGASDExpenses1,
                    EmployeeGASDExpenses2 = keyFinancialsEntity.EmployeeGASDExpenses2,
                    EmployeeGASDExpenses3 = keyFinancialsEntity.EmployeeGASDExpenses3,
                    PAT1 = keyFinancialsEntity.PAT1,
                    PAT2 = keyFinancialsEntity.PAT2,
                    PAT3 = keyFinancialsEntity.PAT3,
                    LiquidAssets1 = keyFinancialsEntity.LiquidAssets1,
                    LiquidAssets2 = keyFinancialsEntity.LiquidAssets2,
                    LiquidAssets3 = keyFinancialsEntity.LiquidAssets3,
                    ProvNPAWriteOffs1 = keyFinancialsEntity.ProvNPAWriteOffs1,
                    ProvNPAWriteOffs2 = keyFinancialsEntity.ProvNPAWriteOffs2,
                    ProvNPAWriteOffs3 = keyFinancialsEntity.ProvNPAWriteOffs3,
                    DiversitryDepositBase1 = keyFinancialsEntity.DiversitryDepositBasePer1,
                    DiversitryDepositBase2 = keyFinancialsEntity.DiversitryDepositBasePer2,
                    DiversitryDepositBase3 = keyFinancialsEntity.DiversitryDepositBasePer3,
                    AdvancesStressedSector1 = keyFinancialsEntity.AdvancesStressedSectorPer1,
                    AdvancesStressedSector2 = keyFinancialsEntity.AdvancesStressedSectorPer2,
                    AdvancesStressedSector3 = keyFinancialsEntity.AdvancesStressedSectorPer3,
                    CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                    CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                    CostOfFundsPer3 = keyFinancialsEntity.CostOfFundsPer3,
                    CRARPer1 = keyFinancialsEntity.CRARPer1,
                    CRARPer2 = keyFinancialsEntity.CRARPer2,
                    CRARPer3 = keyFinancialsEntity.CRARPer3,
                    Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                    Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                    Tier1Per3 = keyFinancialsEntity.Tier1Per3,
                    NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                    NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                    NetNPAPer3 = keyFinancialsEntity.NetNPAPer3,
                    AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                    AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                    AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3,
                    GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                    GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                    GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3,
                    ContingentLiability1 = keyFinancialsEntity.ContingentLiability1,
                    ContingentLiability2 = keyFinancialsEntity.ContingentLiability2,
                    ContingentLiability3 = keyFinancialsEntity.ContingentLiability3,
                    ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                    ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                    ALMGapin6monthsbucketPer3 = keyFinancialsEntity.ALMGapin6monthsbucketPer3,
                    GrowthMembership1 = keyFinancialsEntity.GrowthMembershipPer1,
                    GrowthMembership2 = keyFinancialsEntity.GrowthMembershipPer2,
                    GrowthMembership3 = keyFinancialsEntity.GrowthMembershipPer3,
                    BusinessEmployee1 = keyFinancialsEntity.BusinessEmployee1,
                    BusinessEmployee2 = keyFinancialsEntity.BusinessEmployee2,
                    BusinessEmployee3 = keyFinancialsEntity.BusinessEmployee3,
                    SecuredAdvancesTotalAdvances1 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer1,
                    SecuredAdvancesTotalAdvances2 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer2,
                    SecuredAdvancesTotalAdvances3 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer3,
                    StateEconomicGrowth1 = keyFinancialsEntity.StateEconomicGrowthPer1,
                    StateEconomicGrowth2 = keyFinancialsEntity.StateEconomicGrowthPer2,
                    StateEconomicGrowth3 = keyFinancialsEntity.StateEconomicGrowthPer3,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                ACHFS_KeyFinancials KeyFinancials = new ACHFS_KeyFinancials
                {
                    DetailsId = detailID,

                    PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                    PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                    PeriodEndingDate3 = keyFinancialsEntity.PeriodEndingDate3,
                    NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                    NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                    NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3,
                    Currency1 = keyFinancialsEntity.Currency1,
                    Currency2 = keyFinancialsEntity.Currency2,
                    Currency3 = keyFinancialsEntity.Currency3,
                    NetWorth1 = keyFinancialsEntity.NetWorth1,
                    NetWorth2 = keyFinancialsEntity.NetWorth2,
                    NetWorth3 = keyFinancialsEntity.NetWorth3,
                    TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                    TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                    TotalAssets3 = keyFinancialsEntity.TotalAssets3,
                    TotalMemberships1 = keyFinancialsEntity.TotalMemberships1,
                    TotalMemberships2 = keyFinancialsEntity.TotalMemberships2,
                    TotalMemberships3 = keyFinancialsEntity.TotalMemberships3,
                    TotalUnderconstructionCompletedHouses1 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses1,
                    TotalUnderconstructionCompletedHouses2 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses2,
                    TotalUnderconstructionCompletedHouses3 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses3,
                    GovtContributionTotalShareCapital1 = keyFinancialsEntity.GovtContributionTotalShareCapital1,
                    GovtContributionTotalShareCapital2 = keyFinancialsEntity.GovtContributionTotalShareCapital2,
                    GovtContributionTotalShareCapital3 = keyFinancialsEntity.GovtContributionTotalShareCapital3,
                    TotalAdvances1 = keyFinancialsEntity.TotalAdvances1,
                    TotalAdvances2 = keyFinancialsEntity.TotalAdvances2,
                    TotalAdvances3 = keyFinancialsEntity.TotalAdvances3,
                    InterestIncome1 = keyFinancialsEntity.InterestIncome1,
                    InterestIncome2 = keyFinancialsEntity.InterestIncome2,
                    InterestIncome3 = keyFinancialsEntity.InterestIncome3,
                    NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1,
                    NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2,
                    NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3,
                    InterestExpenses1 = keyFinancialsEntity.InterestExpenses1,
                    InterestExpenses2 = keyFinancialsEntity.InterestExpenses2,
                    InterestExpenses3 = keyFinancialsEntity.InterestExpenses3,
                    EmployeeGASDExpenses1 = keyFinancialsEntity.EmployeeGASDExpenses1,
                    EmployeeGASDExpenses2 = keyFinancialsEntity.EmployeeGASDExpenses2,
                    EmployeeGASDExpenses3 = keyFinancialsEntity.EmployeeGASDExpenses3,
                    PAT1 = keyFinancialsEntity.PAT1,
                    PAT2 = keyFinancialsEntity.PAT2,
                    PAT3 = keyFinancialsEntity.PAT3,
                    LiquidAssets1 = keyFinancialsEntity.LiquidAssets1,
                    LiquidAssets2 = keyFinancialsEntity.LiquidAssets2,
                    LiquidAssets3 = keyFinancialsEntity.LiquidAssets3,
                    ProvNPAWriteOffs1 = keyFinancialsEntity.ProvNPAWriteOffs1,
                    ProvNPAWriteOffs2 = keyFinancialsEntity.ProvNPAWriteOffs2,
                    ProvNPAWriteOffs3 = keyFinancialsEntity.ProvNPAWriteOffs3,
                    DiversitryDepositBase1 = keyFinancialsEntity.DiversitryDepositBasePer1,
                    DiversitryDepositBase2 = keyFinancialsEntity.DiversitryDepositBasePer2,
                    DiversitryDepositBase3 = keyFinancialsEntity.DiversitryDepositBasePer3,
                    AdvancesStressedSector1 = keyFinancialsEntity.AdvancesStressedSectorPer1,
                    AdvancesStressedSector2 = keyFinancialsEntity.AdvancesStressedSectorPer2,
                    AdvancesStressedSector3 = keyFinancialsEntity.AdvancesStressedSectorPer3,
                    CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                    CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                    CostOfFundsPer3 = keyFinancialsEntity.CostOfFundsPer3,
                    CRARPer1 = keyFinancialsEntity.CRARPer1,
                    CRARPer2 = keyFinancialsEntity.CRARPer2,
                    CRARPer3 = keyFinancialsEntity.CRARPer3,
                    Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                    Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                    Tier1Per3 = keyFinancialsEntity.Tier1Per3,
                    NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                    NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                    NetNPAPer3 = keyFinancialsEntity.NetNPAPer3,
                    AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                    AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                    AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3,
                    GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                    GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                    GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3,
                    ContingentLiability1 = keyFinancialsEntity.ContingentLiability1,
                    ContingentLiability2 = keyFinancialsEntity.ContingentLiability2,
                    ContingentLiability3 = keyFinancialsEntity.ContingentLiability3,
                    ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                    ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                    ALMGapin6monthsbucketPer3 = keyFinancialsEntity.ALMGapin6monthsbucketPer3,
                    GrowthMembership1 = keyFinancialsEntity.GrowthMembershipPer1,
                    GrowthMembership2 = keyFinancialsEntity.GrowthMembershipPer2,
                    GrowthMembership3 = keyFinancialsEntity.GrowthMembershipPer3,
                    BusinessEmployee1 = keyFinancialsEntity.BusinessEmployee1,
                    BusinessEmployee2 = keyFinancialsEntity.BusinessEmployee2,
                    BusinessEmployee3 = keyFinancialsEntity.BusinessEmployee3,
                    SecuredAdvancesTotalAdvances1 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer1,
                    SecuredAdvancesTotalAdvances2 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer2,
                    SecuredAdvancesTotalAdvances3 = keyFinancialsEntity.SecuredAdvancesTotalAdvancesPer3,
                    StateEconomicGrowth1 = keyFinancialsEntity.StateEconomicGrowthPer1,
                    StateEconomicGrowth2 = keyFinancialsEntity.StateEconomicGrowthPer2,
                    StateEconomicGrowth3 = keyFinancialsEntity.StateEconomicGrowthPer3,
                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    #region Add Data 

                    if (KeyFinancials != null && CheckIfAlreadyExists_KeyFinancial(detailID) == false)
                    {
                        try
                        {
                            status = Add_KeyFinancial(KeyFinancials);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            ACHFS_KeyFinancials keyFinancials_Update = dbContext.ACHFS_KeyFinancials.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (keyFinancials_Update != null)
                            {
                                keyFinancials_Update.PeriodEndingDate1 = KeyFinancials.PeriodEndingDate1;
                                keyFinancials_Update.PeriodEndingDate2 = KeyFinancials.PeriodEndingDate2;
                                keyFinancials_Update.PeriodEndingDate3 = KeyFinancials.PeriodEndingDate3;
                                keyFinancials_Update.NoofMonthsPeriod1 = KeyFinancials.NoofMonthsPeriod1;
                                keyFinancials_Update.NoofMonthsPeriod2 = KeyFinancials.NoofMonthsPeriod2;
                                keyFinancials_Update.NoofMonthsPeriod3 = KeyFinancials.NoofMonthsPeriod3;
                                keyFinancials_Update.Currency1 = KeyFinancials.Currency1;
                                keyFinancials_Update.Currency2 = KeyFinancials.Currency2;
                                keyFinancials_Update.Currency3 = KeyFinancials.Currency3;
                                keyFinancials_Update.NetWorth1 = KeyFinancials.NetWorth1;
                                keyFinancials_Update.NetWorth2 = KeyFinancials.NetWorth2;
                                keyFinancials_Update.NetWorth3 = KeyFinancials.NetWorth3;
                                keyFinancials_Update.TotalAssets1 = KeyFinancials.TotalAssets1;
                                keyFinancials_Update.TotalAssets2 = KeyFinancials.TotalAssets2;
                                keyFinancials_Update.TotalAssets3 = KeyFinancials.TotalAssets3;
                                keyFinancials_Update.TotalMemberships1 = KeyFinancials.TotalMemberships1;
                                keyFinancials_Update.TotalMemberships2 = KeyFinancials.TotalMemberships2;
                                keyFinancials_Update.TotalMemberships3 = KeyFinancials.TotalMemberships3;
                                keyFinancials_Update.TotalUnderconstructionCompletedHouses1 = KeyFinancials.TotalUnderconstructionCompletedHouses1;
                                keyFinancials_Update.TotalUnderconstructionCompletedHouses2 = KeyFinancials.TotalUnderconstructionCompletedHouses2;
                                keyFinancials_Update.TotalUnderconstructionCompletedHouses3 = KeyFinancials.TotalUnderconstructionCompletedHouses3;
                                keyFinancials_Update.GovtContributionTotalShareCapital1 = KeyFinancials.GovtContributionTotalShareCapital1;
                                keyFinancials_Update.GovtContributionTotalShareCapital2 = KeyFinancials.GovtContributionTotalShareCapital2;
                                keyFinancials_Update.GovtContributionTotalShareCapital3 = KeyFinancials.GovtContributionTotalShareCapital3;
                                keyFinancials_Update.TotalAdvances1 = KeyFinancials.TotalAdvances1;
                                keyFinancials_Update.TotalAdvances2 = KeyFinancials.TotalAdvances2;
                                keyFinancials_Update.TotalAdvances3 = KeyFinancials.TotalAdvances3;
                                keyFinancials_Update.InterestIncome1 = KeyFinancials.InterestIncome1;
                                keyFinancials_Update.InterestIncome2 = KeyFinancials.InterestIncome2;
                                keyFinancials_Update.InterestIncome3 = KeyFinancials.InterestIncome3;
                                keyFinancials_Update.NonInterestIncome1 = KeyFinancials.NonInterestIncome1;
                                keyFinancials_Update.NonInterestIncome2 = KeyFinancials.NonInterestIncome2;
                                keyFinancials_Update.NonInterestIncome3 = KeyFinancials.NonInterestIncome3;
                                keyFinancials_Update.InterestExpenses1 = KeyFinancials.InterestExpenses1;
                                keyFinancials_Update.InterestExpenses2 = KeyFinancials.InterestExpenses2;
                                keyFinancials_Update.InterestExpenses3 = KeyFinancials.InterestExpenses3;
                                keyFinancials_Update.EmployeeGASDExpenses1 = KeyFinancials.EmployeeGASDExpenses1;
                                keyFinancials_Update.EmployeeGASDExpenses2 = KeyFinancials.EmployeeGASDExpenses2;
                                keyFinancials_Update.EmployeeGASDExpenses3 = KeyFinancials.EmployeeGASDExpenses3;
                                keyFinancials_Update.PAT1 = KeyFinancials.PAT1;
                                keyFinancials_Update.PAT2 = KeyFinancials.PAT2;
                                keyFinancials_Update.PAT3 = KeyFinancials.PAT3;
                                keyFinancials_Update.LiquidAssets1 = KeyFinancials.LiquidAssets1;
                                keyFinancials_Update.LiquidAssets2 = KeyFinancials.LiquidAssets2;
                                keyFinancials_Update.LiquidAssets3 = KeyFinancials.LiquidAssets3;
                                keyFinancials_Update.ProvNPAWriteOffs1 = KeyFinancials.ProvNPAWriteOffs1;
                                keyFinancials_Update.ProvNPAWriteOffs2 = KeyFinancials.ProvNPAWriteOffs2;
                                keyFinancials_Update.ProvNPAWriteOffs3 = KeyFinancials.ProvNPAWriteOffs3;
                                keyFinancials_Update.DiversitryDepositBase1 = KeyFinancials.DiversitryDepositBase1;
                                keyFinancials_Update.DiversitryDepositBase2 = KeyFinancials.DiversitryDepositBase2;
                                keyFinancials_Update.DiversitryDepositBase3 = KeyFinancials.DiversitryDepositBase3;
                                keyFinancials_Update.AdvancesStressedSector1 = KeyFinancials.AdvancesStressedSector1;
                                keyFinancials_Update.AdvancesStressedSector2 = KeyFinancials.AdvancesStressedSector2;
                                keyFinancials_Update.AdvancesStressedSector3 = KeyFinancials.AdvancesStressedSector3;
                                keyFinancials_Update.CostOfFundsPer1 = KeyFinancials.CostOfFundsPer1;
                                keyFinancials_Update.CostOfFundsPer2 = KeyFinancials.CostOfFundsPer2;
                                keyFinancials_Update.CostOfFundsPer3 = KeyFinancials.CostOfFundsPer3;
                                keyFinancials_Update.CRARPer1 = KeyFinancials.CRARPer1;
                                keyFinancials_Update.CRARPer2 = KeyFinancials.CRARPer2;
                                keyFinancials_Update.CRARPer3 = KeyFinancials.CRARPer3;
                                keyFinancials_Update.Tier1Per1 = KeyFinancials.Tier1Per1;
                                keyFinancials_Update.Tier1Per2 = KeyFinancials.Tier1Per2;
                                keyFinancials_Update.Tier1Per3 = KeyFinancials.Tier1Per3;
                                keyFinancials_Update.NetNPAPer1 = KeyFinancials.NetNPAPer1;
                                keyFinancials_Update.NetNPAPer2 = KeyFinancials.NetNPAPer2;
                                keyFinancials_Update.NetNPAPer3 = KeyFinancials.NetNPAPer3;
                                keyFinancials_Update.AdditioninNPAsAdvancesPer1 = KeyFinancials.AdditioninNPAsAdvancesPer1;
                                keyFinancials_Update.AdditioninNPAsAdvancesPer2 = KeyFinancials.AdditioninNPAsAdvancesPer2;
                                keyFinancials_Update.AdditioninNPAsAdvancesPer3 = KeyFinancials.AdditioninNPAsAdvancesPer3;
                                keyFinancials_Update.GrossNPAPer1 = KeyFinancials.GrossNPAPer1;
                                keyFinancials_Update.GrossNPAPer2 = KeyFinancials.GrossNPAPer2;
                                keyFinancials_Update.GrossNPAPer3 = KeyFinancials.GrossNPAPer3;
                                keyFinancials_Update.ContingentLiability1 = KeyFinancials.ContingentLiability1;
                                keyFinancials_Update.ContingentLiability2 = KeyFinancials.ContingentLiability2;
                                keyFinancials_Update.ContingentLiability3 = KeyFinancials.ContingentLiability3;
                                keyFinancials_Update.ALMGapin6monthsbucketPer1 = KeyFinancials.ALMGapin6monthsbucketPer1;
                                keyFinancials_Update.ALMGapin6monthsbucketPer2 = KeyFinancials.ALMGapin6monthsbucketPer2;
                                keyFinancials_Update.ALMGapin6monthsbucketPer3 = KeyFinancials.ALMGapin6monthsbucketPer3;
                                keyFinancials_Update.GrowthMembership1 = KeyFinancials.GrowthMembership1;
                                keyFinancials_Update.GrowthMembership2 = KeyFinancials.GrowthMembership2;
                                keyFinancials_Update.GrowthMembership3 = KeyFinancials.GrowthMembership3;
                                keyFinancials_Update.BusinessEmployee1 = KeyFinancials.BusinessEmployee1;
                                keyFinancials_Update.BusinessEmployee2 = KeyFinancials.BusinessEmployee2;
                                keyFinancials_Update.BusinessEmployee3 = KeyFinancials.BusinessEmployee3;
                                keyFinancials_Update.SecuredAdvancesTotalAdvances1 = KeyFinancials.SecuredAdvancesTotalAdvances1;
                                keyFinancials_Update.SecuredAdvancesTotalAdvances2 = KeyFinancials.SecuredAdvancesTotalAdvances2;
                                keyFinancials_Update.SecuredAdvancesTotalAdvances3 = KeyFinancials.SecuredAdvancesTotalAdvances3;
                                keyFinancials_Update.StateEconomicGrowth1 = KeyFinancials.StateEconomicGrowth1;
                                keyFinancials_Update.StateEconomicGrowth2 = KeyFinancials.StateEconomicGrowth2;
                                keyFinancials_Update.StateEconomicGrowth3 = KeyFinancials.StateEconomicGrowth3;

                                keyFinancials_Update.UpdatedBy = userId;
                                keyFinancials_Update.UpdatedDateTime = DateTime.Now;
                                dbContext.SaveChanges();
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return false;
                            }
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            return false;
                        }
                    }

                    #endregion

                    status = Add_KeyFinancial_Archive(KeyFinancials_Archive);
                    dbContextTransaction.Commit();

                }
            }

            return true;

        }

        public bool Add_KeyFinancial(ACHFS_KeyFinancials KeyFinancials)
        {
            try
            {
                dbContext.ACHFS_KeyFinancials.Add(KeyFinancials);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_KeyFinancial_Archive(ACHFS_KeyFinancials_Archive KeyFinancials_Archive)
        {
            try
            {
                dbContext.ACHFS_KeyFinancials_Archive.Add(KeyFinancials_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_SubjectiveParameters(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, ACHFS_SubjectiveParametersEntity subjectiveParametersEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                ACHFS_SubjectiveParameters_Archive subjectiveParameters_Archive = new ACHFS_SubjectiveParameters_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,
                    IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                    AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS,
                    ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                    UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                    AdverseNews = subjectiveParametersEntity.AdverseNews,
                    IndependenceBoardDirectors = subjectiveParametersEntity.IndependenceBoardDirectors,
                    CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                    AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                    AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                    NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                    //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                    NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                    LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                    CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                    NPASysGen = subjectiveParametersEntity.NPASysGen,
                    NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                    CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                    NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                    SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                    QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                    DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,
                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                };

                ACHFS_SubjectiveParameters subjectiveParameters = new ACHFS_SubjectiveParameters
                {
                    DetailsId = detailID,
                    IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                    AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS,
                    ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                    UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                    AdverseNews = subjectiveParametersEntity.AdverseNews,
                    IndependenceBoardDirectors = subjectiveParametersEntity.IndependenceBoardDirectors,
                    CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                    AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                    AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                    NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                    //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                    NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                    LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                    CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                    NPASysGen = subjectiveParametersEntity.NPASysGen,
                    NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                    CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                    NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                    SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                    QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                    DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,
                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                };

                if (userId != 0)
                {
                    #region Add Data 
                    if (subjectiveParameters != null && CheckIfAlreadyExists_SubjectiveParameters(detailID) == false)
                    {
                        try
                        {
                            status = Add_SubjectiveParameter(subjectiveParameters);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }


                    #endregion

                    #region Update Existing Data

                    else
                    {
                        try
                        {
                            ACHFS_SubjectiveParameters subjectiveParameters_Update = dbContext.ACHFS_SubjectiveParameters.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (subjectiveParameters_Update != null)
                            {
                                subjectiveParameters_Update.IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore;

                                subjectiveParameters_Update.AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS;
                                subjectiveParameters_Update.ManagementQuality = subjectiveParametersEntity.ManagementQuality;
                                subjectiveParameters_Update.UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards;
                                subjectiveParameters_Update.AdverseNews = subjectiveParametersEntity.AdverseNews;
                                subjectiveParameters_Update.IndependenceBoardDirectors = subjectiveParametersEntity.IndependenceBoardDirectors;
                                subjectiveParameters_Update.CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility;
                                subjectiveParameters_Update.AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime;
                                subjectiveParameters_Update.AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems;
                                subjectiveParameters_Update.NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm;
                                //subjectiveParameters_Update.AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms;
                                subjectiveParameters_Update.NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm;
                                subjectiveParameters_Update.LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran;
                                subjectiveParameters_Update.CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData;
                                subjectiveParameters_Update.NPASysGen = subjectiveParametersEntity.NPASysGen;
                                subjectiveParameters_Update.NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting;
                                subjectiveParameters_Update.CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement;
                                subjectiveParameters_Update.NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess;
                                subjectiveParameters_Update.SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort;
                                subjectiveParameters_Update.QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor;
                                subjectiveParameters_Update.DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders;

                                subjectiveParameters_Update.UpdatedBy = subjectiveParametersEntity.UpdatedBy;
                                subjectiveParameters_Update.UpdatedDateTime = subjectiveParametersEntity.UpdatedDateTime;
                                dbContext.SaveChanges();
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return false;
                            }

                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            return false;
                        }

                    }
                    #endregion

                    status = Add_SubjectiveParameter_Archive(subjectiveParameters_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return true;

        }

        public bool Add_SubjectiveParameter(ACHFS_SubjectiveParameters subjectiveParameters)
        {
            try
            {
                dbContext.ACHFS_SubjectiveParameters.Add(subjectiveParameters);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_SubjectiveParameter_Archive(ACHFS_SubjectiveParameters_Archive subjectiveParameters_Archive)
        {
            try
            {
                dbContext.ACHFS_SubjectiveParameters_Archive.Add(subjectiveParameters_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_OutputDetails(int userId, int roleId, int detailID, short logID, int detail_ArchiveID, DateTime CreatedDateTime, List<ACHFS_OutputDetailsEntity> outputDetailsEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                if (outputDetailsEntity != null && userId != 0)
                {
                    List<ACHFS_Output_Details> output_Details = new List<ACHFS_Output_Details>();
                    List<ACHFS_Output_Details_Archive> output_Details_Archive = new List<ACHFS_Output_Details_Archive>();

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details.Add(new ACHFS_Output_Details
                        {
                            DetailsId = detailID,
                            TemplateId = values.TemplateID,
                            Parameter_Per = values.Parameter3Per,
                            Parameter_Name = string.IsNullOrEmpty(values.Parameter3) ? values.Parameter1 : values.Parameter3,
                            UnderBaselIII_Score = values.UnderBaselIII_Score,
                            UnderBaselIII_Value = values.UnderBaselIII_Value,
                            UnderIND_Score = values.UnderIND_Score,
                            UnderIND_Value = values.UnderIND_Value,
                            Comments = values.Comments,

                            CreatedDateTime = CreatedDateTime,
                        });
                    };

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details_Archive.Add(new ACHFS_Output_Details_Archive
                        {
                            DetailsId = detailID,
                            LogId = logID,
                            Details_ArchiveId = detail_ArchiveID,

                            UserId = userId,
                            TemplateId = values.TemplateID,
                            Parameter_Per = values.Parameter3Per,
                            Parameter_Name = string.IsNullOrEmpty(values.Parameter3) ? values.Parameter1 : values.Parameter3,

                            UnderBaselIII_Score = values.UnderBaselIII_Score,
                            UnderBaselIII_Value = values.UnderBaselIII_Value,
                            UnderIND_Score = values.UnderIND_Score,
                            UnderIND_Value = values.UnderIND_Value,
                            Comments = values.Comments,
                            CreatedBy = values.CreatedBy,
                            UpdatedBy = values.UpdatedBy,

                            CreatedDateTime = CreatedDateTime,
                            UpdatedDateTime = DateTime.Now,
                        });
                    };

                    if (output_Details != null)
                    {
                        if (CheckIfAlreadyExists_OutputDetails(detailID) == true)
                        {
                            Delete_OutputDetails(detailID);
                        }
                        status = Add_OutputDetails(output_Details);
                        status = Add_OutputDetails_Archive(output_Details_Archive);
                        dbContextTransaction.Commit();
                        status = true;
                    }
                }
            }

            return status;

        }

        public bool Add_OutputDetails(List<ACHFS_Output_Details> output_Details)
        {
            try
            {
                dbContext.ACHFS_Output_Details.AddRange(output_Details);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_OutputDetails_Archive(List<ACHFS_Output_Details_Archive> output_Details_Archive)
        {
            try
            {
                dbContext.ACHFS_Output_Details_Archive.AddRange(output_Details_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Delete_OutputDetails(int detailsID)
        {
            try
            {
                dbContext.ACHFS_Output_Details.RemoveRange(dbContext.ACHFS_Output_Details.Where(c => c.DetailsId == detailsID));
                //foreach (var ec in dbContext.ACHFS_Output_Details.Where(x => x.DetailsId == achfs_Output_Details[0].DetailsId))
                //{
                //    dbContext.ACHFS_Output_Details.Remove(ec);
                //}
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool CheckIfAlreadyExists_KeyFinancial(int detailsId)
        {
            return dbContext.ACHFS_KeyFinancials.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_SubjectiveParameters(int detailsId)
        {
            return dbContext.ACHFS_SubjectiveParameters.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_OutputDetails(int detailsId)
        {
            return dbContext.ACHFS_Output_Details.Any(asset => asset.DetailsId == detailsId);
        }

        public bool Get_OutputDetails_OpenXML(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            // Open the document for editing.
            using (DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadSheet = DocumentFormat.OpenXml.Packaging.SpreadsheetDocument.Open(OutputTemplateFilePath, true))
            {
                // Access the main Workbook part, which contains all references.
                DocumentFormat.OpenXml.Packaging.WorkbookPart workbookPart = spreadSheet.WorkbookPart;
                // get sheet by name
                DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbookPart.Workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == "Output NHB").FirstOrDefault();

                // get worksheetpart by sheet id
                DocumentFormat.OpenXml.Packaging.WorksheetPart worksheetPart = workbookPart.GetPartById(sheet.Id.Value) as DocumentFormat.OpenXml.Packaging.WorksheetPart;

                // The SheetData object will contain all the data.
                int? detailArchivedID = (from output in dbContext.ACHFS_Output_Details_Archive
                                         join basicDetails in dbContext.NHB_Details_Archive on output.Details_ArchiveId equals basicDetails.Details_ArchiveId
                                         where basicDetails.CompanyId == companyId
                                         && DbFunctions.TruncateTime(output.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime)
                                         select output.Details_ArchiveId).OrderByDescending(data => data).FirstOrDefault();

                //    ACHFS_Output_Details_Archive data = dbContext.ACHFS_Output_Details_Archive.Where(detail => detail.CompanyId == companyId
                //&& issuerinfo.PRDate == null).OrderByDescending(data => data.Details_ArchiveId).FirstOrDefault();

                if (detailArchivedID > 0)
                {
                    List<ACHFS_OutputDetailsEntity> getOutputDetails = dbContext.ACHFS_Output_Details_Archive
                       .Where(riskOutputs => riskOutputs.Details_ArchiveId == detailArchivedID.Value
                       )
                       .Select(Outputs => new ACHFS_OutputDetailsEntity
                       {
                           Parameter3 = Outputs.Parameter_Name,
                           UnderIND_Score = Outputs.UnderIND_Score,
                           UnderIND_Value = Outputs.UnderIND_Value,
                           UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                           UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
                       }).ToList();

                    uint rowNo = 3;
                    for (int i = 0; i < getOutputDetails.Count; i++)
                    {
                        Cell cell = GetCell(worksheetPart.Worksheet, "K", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Score);
                        cell = GetCell(worksheetPart.Worksheet, "L", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Value);
                        cell = GetCell(worksheetPart.Worksheet, "N", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Score);
                        cell = GetCell(worksheetPart.Worksheet, "O", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Value);
                        rowNo++;
                    }
                    // Save the worksheet.
                    worksheetPart.Worksheet.Save();

                    // for recacluation of formula
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;
                }
            }
            return true;
        }

        private Cell GetCell(Worksheet worksheet, string columnName, uint rowIndex)
        {
            Row row = GetRow(worksheet, rowIndex);

            if (row == null) return null;

            var FirstRow = row.Elements<Cell>().Where(c => string.Compare
            (c.CellReference.Value, columnName +
            rowIndex, true) == 0).FirstOrDefault();

            if (FirstRow == null) return null;

            return FirstRow;
        }

        private Row GetRow(Worksheet worksheet, uint rowIndex)
        {
            Row row = worksheet.GetFirstChild<SheetData>().
            Elements<Row>().FirstOrDefault(r => r.RowIndex == rowIndex);
            if (row == null)
            {
                throw new ArgumentException(String.Format("No row with index {0} found in spreadsheet", rowIndex));
            }
            return row;
        }

        public bool Get_OutputDetailsFromFrontEnd_InterOp(int detailsID, string OutputTemplateFilePath)
        {
            CompanyDAL companyDAL = new CompanyDAL();

            #region Basic Details List

            List<ACHFS_BasicDetailsEntity> getBasicDetailsEntity = dbContext.NHB_Details
              .Where(a => a.DetailsId == detailsID
              )
              .Select(riskModelExcelEntity => new ACHFS_BasicDetailsEntity
              {
                  CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                  ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                  SponsorBank = riskModelExcelEntity.SponsorBank,
                  ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
              }).ToList();

            #endregion

            #region Key Financials List

            List<ACHFS_KeyFinancialsEntity> getKeyFinancialsEntity = dbContext.ACHFS_KeyFinancials
              .Where(a => a.DetailsId == detailsID
              )
              .Select(keyFinancialsEntity => new ACHFS_KeyFinancialsEntity
              {
                  PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                  PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                  PeriodEndingDate3 = keyFinancialsEntity.PeriodEndingDate3,
                  NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                  NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                  NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3,
                  Currency1 = keyFinancialsEntity.Currency1,
                  Currency2 = keyFinancialsEntity.Currency2,
                  Currency3 = keyFinancialsEntity.Currency3,
                  NetWorth1 = keyFinancialsEntity.NetWorth1,
                  NetWorth2 = keyFinancialsEntity.NetWorth2,
                  NetWorth3 = keyFinancialsEntity.NetWorth3,
                  TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                  TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                  TotalAssets3 = keyFinancialsEntity.TotalAssets3,
                  TotalMemberships1 = keyFinancialsEntity.TotalMemberships1,
                  TotalMemberships2 = keyFinancialsEntity.TotalMemberships2,
                  TotalMemberships3 = keyFinancialsEntity.TotalMemberships3,
                  TotalUnderconstructionCompletedHouses1 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses1,
                  TotalUnderconstructionCompletedHouses2 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses2,
                  TotalUnderconstructionCompletedHouses3 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses3,
                  GovtContributionTotalShareCapital1 = keyFinancialsEntity.GovtContributionTotalShareCapital1,
                  GovtContributionTotalShareCapital2 = keyFinancialsEntity.GovtContributionTotalShareCapital2,
                  GovtContributionTotalShareCapital3 = keyFinancialsEntity.GovtContributionTotalShareCapital3,
                  TotalAdvances1 = keyFinancialsEntity.TotalAdvances1,
                  TotalAdvances2 = keyFinancialsEntity.TotalAdvances2,
                  TotalAdvances3 = keyFinancialsEntity.TotalAdvances3,
                  InterestIncome1 = keyFinancialsEntity.InterestIncome1,
                  InterestIncome2 = keyFinancialsEntity.InterestIncome2,
                  InterestIncome3 = keyFinancialsEntity.InterestIncome3,
                  NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1,
                  NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2,
                  NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3,
                  InterestExpenses1 = keyFinancialsEntity.InterestExpenses1,
                  InterestExpenses2 = keyFinancialsEntity.InterestExpenses2,
                  InterestExpenses3 = keyFinancialsEntity.InterestExpenses3,
                  EmployeeGASDExpenses1 = keyFinancialsEntity.EmployeeGASDExpenses1,
                  EmployeeGASDExpenses2 = keyFinancialsEntity.EmployeeGASDExpenses2,
                  EmployeeGASDExpenses3 = keyFinancialsEntity.EmployeeGASDExpenses3,
                  PAT1 = keyFinancialsEntity.PAT1,
                  PAT2 = keyFinancialsEntity.PAT2,
                  PAT3 = keyFinancialsEntity.PAT3,
                  LiquidAssets1 = keyFinancialsEntity.LiquidAssets1,
                  LiquidAssets2 = keyFinancialsEntity.LiquidAssets2,
                  LiquidAssets3 = keyFinancialsEntity.LiquidAssets3,
                  ProvNPAWriteOffs1 = keyFinancialsEntity.ProvNPAWriteOffs1,
                  ProvNPAWriteOffs2 = keyFinancialsEntity.ProvNPAWriteOffs2,
                  ProvNPAWriteOffs3 = keyFinancialsEntity.ProvNPAWriteOffs3,
                  DiversitryDepositBasePer1 = keyFinancialsEntity.DiversitryDepositBase1,
                  DiversitryDepositBasePer2 = keyFinancialsEntity.DiversitryDepositBase2,
                  DiversitryDepositBasePer3 = keyFinancialsEntity.DiversitryDepositBase3,
                  AdvancesStressedSectorPer1 = keyFinancialsEntity.AdvancesStressedSector1,
                  AdvancesStressedSectorPer2 = keyFinancialsEntity.AdvancesStressedSector2,
                  AdvancesStressedSectorPer3 = keyFinancialsEntity.AdvancesStressedSector3,
                  CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                  CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                  CostOfFundsPer3 = keyFinancialsEntity.CostOfFundsPer3,
                  CRARPer1 = keyFinancialsEntity.CRARPer1,
                  CRARPer2 = keyFinancialsEntity.CRARPer2,
                  CRARPer3 = keyFinancialsEntity.CRARPer3,
                  Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                  Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                  Tier1Per3 = keyFinancialsEntity.Tier1Per3,
                  NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                  NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                  NetNPAPer3 = keyFinancialsEntity.NetNPAPer3,
                  AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                  AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                  AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3,
                  GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                  GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                  GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3,
                  ContingentLiability1 = keyFinancialsEntity.ContingentLiability1,
                  ContingentLiability2 = keyFinancialsEntity.ContingentLiability2,
                  ContingentLiability3 = keyFinancialsEntity.ContingentLiability3,
                  ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                  ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                  ALMGapin6monthsbucketPer3 = keyFinancialsEntity.ALMGapin6monthsbucketPer3,
                  GrowthMembershipPer1 = keyFinancialsEntity.GrowthMembership1,
                  GrowthMembershipPer2 = keyFinancialsEntity.GrowthMembership2,
                  GrowthMembershipPer3 = keyFinancialsEntity.GrowthMembership3,
                  BusinessEmployee1 = keyFinancialsEntity.BusinessEmployee1,
                  BusinessEmployee2 = keyFinancialsEntity.BusinessEmployee2,
                  BusinessEmployee3 = keyFinancialsEntity.BusinessEmployee3,
                  SecuredAdvancesTotalAdvancesPer1 = keyFinancialsEntity.SecuredAdvancesTotalAdvances1,
                  SecuredAdvancesTotalAdvancesPer2 = keyFinancialsEntity.SecuredAdvancesTotalAdvances2,
                  SecuredAdvancesTotalAdvancesPer3 = keyFinancialsEntity.SecuredAdvancesTotalAdvances3,
                  StateEconomicGrowthPer1 = keyFinancialsEntity.StateEconomicGrowth1,
                  StateEconomicGrowthPer2 = keyFinancialsEntity.StateEconomicGrowth2,
                  StateEconomicGrowthPer3 = keyFinancialsEntity.StateEconomicGrowth3,
              }).ToList();

            #endregion

            #region Subjective Parameters List

            List<ACHFS_SubjectiveParametersEntity> getSubjectiveParametersEntity = dbContext.ACHFS_SubjectiveParameters
              .Where(a => a.DetailsId == detailsID
              )
              .Select(subjectiveParametersEntity => new ACHFS_SubjectiveParametersEntity
              {
                  IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                  AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS,
                  ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                  UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                  IndependenceBoardDirectors = subjectiveParametersEntity.IndependenceBoardDirectors,
                  AdverseNews = subjectiveParametersEntity.AdverseNews,
                  CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                  AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                  AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                  NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                  //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                  NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                  LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                  CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                  NPASysGen = subjectiveParametersEntity.NPASysGen,
                  NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                  CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                  NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                  SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                  QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                  DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders
              }).ToList();

            #endregion

            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            //Get the already exists sheet
            //mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(2);
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Input Sheet"];

            string value = "";
            uint rowIndex = 0;
            int columnIndex = 0;

            string columnName = "";
            object obj;
            //mWSheet.Cells[11, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate1_Liabilities;

            ACHFS_BasicDetailsEntity achfs_BasicDetailsEntity = new ACHFS_BasicDetailsEntity();
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(achfs_BasicDetailsEntity);
            properties = TypeDescriptor.GetProperties(achfs_BasicDetailsEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getBasicDetailsEntity[0].GetType().GetProperty(property.Name).GetValue(getBasicDetailsEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            ACHFS_KeyFinancialsEntity achfs_KeyFinancialsEntity = new ACHFS_KeyFinancialsEntity();
            properties = TypeDescriptor.GetProperties(achfs_KeyFinancialsEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getKeyFinancialsEntity[0].GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            ACHFS_SubjectiveParametersEntity achfs_SubjectiveParametersEntity = new ACHFS_SubjectiveParametersEntity();
            properties = TypeDescriptor.GetProperties(achfs_SubjectiveParametersEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getSubjectiveParametersEntity[0].GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }


            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();

            return true;
        }

        public bool Get_OutputDetails_InterOp_DetailsId(int detailsId, string companyName, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Key Financials List

            List<ACHFS_OutputDetailsEntity> getOutputDetails = dbContext.ACHFS_Output_Details
              .Where(a => a.DetailsId == detailsId
              )
              .Select(Outputs => new ACHFS_OutputDetailsEntity
              {
                  Parameter3Per = Outputs.Parameter_Per,
                  Parameter3 = Outputs.Parameter_Name,
                  UnderIND_Score = Outputs.UnderIND_Score,
                  UnderIND_Value = Outputs.UnderIND_Value,
                  UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                  UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
              }).ToList();

            #endregion


            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Output NHB"];

            uint rowIndex = 3;
            int columnIndex = 0;

            for (int i = 0; i < getOutputDetails.Count; i++)
            {
                columnIndex = _helperDAL.GetExcelColumnIndex("K");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("L");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Score;

                columnIndex = _helperDAL.GetExcelColumnIndex("N");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("O");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Score;
                rowIndex++;
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();


            return true;
        }


        public ACHFS_BasicDetailsEntity GetBasicDetails(int detailsId)
        {
            ACHFS_BasicDetailsEntity basicDetails = new ACHFS_BasicDetailsEntity();
            ACHFS_KeyFinancialsEntity keyFinancials = new ACHFS_KeyFinancialsEntity();
            ACHFS_SubjectiveParametersEntity subjectiveParameters = new ACHFS_SubjectiveParametersEntity();
            List<ACHFS_OutputDetailsEntity> outputDetails = new List<ACHFS_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details.Where(data => data.DetailsId == detailsId).Select(x => new ACHFS_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = 0,
                FinYear = x.FinYear,
                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                DateOfInput = x.DateOfInput,
                CurrencyUnits = x.CurrencyUnits,
                ParentCompanyName = x.ParentCompanyName,
                ParentCompanyId = x.ParentCompanyId,
                ParentRating = x.ParentRating,
                SponsorBank = x.SponsorBank,
                ParentCompanyShareHoldingPer = x.ParentCompanyShareHoldingPer,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

                IsFinal = x.IsFinal.Value
            }).FirstOrDefault();

            keyFinancials = dbContext.ACHFS_KeyFinancials.Where(data => data.DetailsId == detailsId).Select(keyFinancialsEntity => new ACHFS_KeyFinancialsEntity
            {
                PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                PeriodEndingDate3 = keyFinancialsEntity.PeriodEndingDate3,
                NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3,
                Currency1 = keyFinancialsEntity.Currency1,
                Currency2 = keyFinancialsEntity.Currency2,
                Currency3 = keyFinancialsEntity.Currency3,
                NetWorth1 = keyFinancialsEntity.NetWorth1,
                NetWorth2 = keyFinancialsEntity.NetWorth2,
                NetWorth3 = keyFinancialsEntity.NetWorth3,
                TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                TotalAssets3 = keyFinancialsEntity.TotalAssets3,
                TotalMemberships1 = keyFinancialsEntity.TotalMemberships1,
                TotalMemberships2 = keyFinancialsEntity.TotalMemberships2,
                TotalMemberships3 = keyFinancialsEntity.TotalMemberships3,
                TotalUnderconstructionCompletedHouses1 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses1,
                TotalUnderconstructionCompletedHouses2 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses2,
                TotalUnderconstructionCompletedHouses3 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses3,
                GovtContributionTotalShareCapital1 = keyFinancialsEntity.GovtContributionTotalShareCapital1,
                GovtContributionTotalShareCapital2 = keyFinancialsEntity.GovtContributionTotalShareCapital2,
                GovtContributionTotalShareCapital3 = keyFinancialsEntity.GovtContributionTotalShareCapital3,
                TotalAdvances1 = keyFinancialsEntity.TotalAdvances1,
                TotalAdvances2 = keyFinancialsEntity.TotalAdvances2,
                TotalAdvances3 = keyFinancialsEntity.TotalAdvances3,
                InterestIncome1 = keyFinancialsEntity.InterestIncome1,
                InterestIncome2 = keyFinancialsEntity.InterestIncome2,
                InterestIncome3 = keyFinancialsEntity.InterestIncome3,
                NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1,
                NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2,
                NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3,
                InterestExpenses1 = keyFinancialsEntity.InterestExpenses1,
                InterestExpenses2 = keyFinancialsEntity.InterestExpenses2,
                InterestExpenses3 = keyFinancialsEntity.InterestExpenses3,
                EmployeeGASDExpenses1 = keyFinancialsEntity.EmployeeGASDExpenses1,
                EmployeeGASDExpenses2 = keyFinancialsEntity.EmployeeGASDExpenses2,
                EmployeeGASDExpenses3 = keyFinancialsEntity.EmployeeGASDExpenses3,
                PAT1 = keyFinancialsEntity.PAT1,
                PAT2 = keyFinancialsEntity.PAT2,
                PAT3 = keyFinancialsEntity.PAT3,
                LiquidAssets1 = keyFinancialsEntity.LiquidAssets1,
                LiquidAssets2 = keyFinancialsEntity.LiquidAssets2,
                LiquidAssets3 = keyFinancialsEntity.LiquidAssets3,
                ProvNPAWriteOffs1 = keyFinancialsEntity.ProvNPAWriteOffs1,
                ProvNPAWriteOffs2 = keyFinancialsEntity.ProvNPAWriteOffs2,
                ProvNPAWriteOffs3 = keyFinancialsEntity.ProvNPAWriteOffs3,
                DiversitryDepositBasePer1 = keyFinancialsEntity.DiversitryDepositBase1,
                DiversitryDepositBasePer2 = keyFinancialsEntity.DiversitryDepositBase2,
                DiversitryDepositBasePer3 = keyFinancialsEntity.DiversitryDepositBase3,
                AdvancesStressedSectorPer1 = keyFinancialsEntity.AdvancesStressedSector1,
                AdvancesStressedSectorPer2 = keyFinancialsEntity.AdvancesStressedSector2,
                AdvancesStressedSectorPer3 = keyFinancialsEntity.AdvancesStressedSector3,
                CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                CostOfFundsPer3 = keyFinancialsEntity.CostOfFundsPer3,
                CRARPer1 = keyFinancialsEntity.CRARPer1,
                CRARPer2 = keyFinancialsEntity.CRARPer2,
                CRARPer3 = keyFinancialsEntity.CRARPer3,
                Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                Tier1Per3 = keyFinancialsEntity.Tier1Per3,
                NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                NetNPAPer3 = keyFinancialsEntity.NetNPAPer3,
                AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3,
                GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3,
                ContingentLiability1 = keyFinancialsEntity.ContingentLiability1,
                ContingentLiability2 = keyFinancialsEntity.ContingentLiability2,
                ContingentLiability3 = keyFinancialsEntity.ContingentLiability3,
                ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                ALMGapin6monthsbucketPer3 = keyFinancialsEntity.ALMGapin6monthsbucketPer3,
                GrowthMembershipPer1 = keyFinancialsEntity.GrowthMembership1,
                GrowthMembershipPer2 = keyFinancialsEntity.GrowthMembership2,
                GrowthMembershipPer3 = keyFinancialsEntity.GrowthMembership3,
                BusinessEmployee1 = keyFinancialsEntity.BusinessEmployee1,
                BusinessEmployee2 = keyFinancialsEntity.BusinessEmployee2,
                BusinessEmployee3 = keyFinancialsEntity.BusinessEmployee3,
                SecuredAdvancesTotalAdvancesPer1 = keyFinancialsEntity.SecuredAdvancesTotalAdvances1,
                SecuredAdvancesTotalAdvancesPer2 = keyFinancialsEntity.SecuredAdvancesTotalAdvances2,
                SecuredAdvancesTotalAdvancesPer3 = keyFinancialsEntity.SecuredAdvancesTotalAdvances3,
                StateEconomicGrowthPer1 = keyFinancialsEntity.StateEconomicGrowth1,
                StateEconomicGrowthPer2 = keyFinancialsEntity.StateEconomicGrowth2,
                StateEconomicGrowthPer3 = keyFinancialsEntity.StateEconomicGrowth3,

            }).FirstOrDefault();

            subjectiveParameters = dbContext.ACHFS_SubjectiveParameters.Where(data => data.DetailsId == detailsId).Select(subjectiveParametersEntity => new ACHFS_SubjectiveParametersEntity
            {
                IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS,
                ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                AdverseNews = subjectiveParametersEntity.AdverseNews,
                IndependenceBoardDirectors = subjectiveParametersEntity.IndependenceBoardDirectors,
                CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                NPASysGen = subjectiveParametersEntity.NPASysGen,
                NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders

            }).FirstOrDefault();

            outputDetails = (from output in dbContext.ACHFS_Output_Details
                             join template in dbContext.ACHFS_Output_Template on output.TemplateId equals template.TemplateID
                             where output.DetailsId == detailsId

                             select new ACHFS_OutputDetailsEntity
                             {
                                 TemplateID = output.TemplateId,
                                 Parameter1 = string.IsNullOrEmpty(template.Parameter1) ? string.Empty : template.Parameter1,
                                 Parameter1Per = string.IsNullOrEmpty(template.Parameter1Per) ? string.Empty : template.Parameter1Per,
                                 Parameter2 = string.IsNullOrEmpty(template.Parameter2) ? string.Empty : template.Parameter2,
                                 Parameter2Per = string.IsNullOrEmpty(template.Parameter2Per) ? string.Empty : template.Parameter2Per,
                                 Parameter3Per = output.Parameter_Per,
                                 Parameter3 = output.Parameter_Name,
                                 UnderBaselIII_Score = string.IsNullOrEmpty(output.UnderBaselIII_Score) ? string.Empty : output.UnderBaselIII_Score,
                                 UnderBaselIII_Value = string.IsNullOrEmpty(output.UnderBaselIII_Value) ? string.Empty : output.UnderBaselIII_Value,
                                 UnderIND_Score = string.IsNullOrEmpty(output.UnderIND_Score) ? string.Empty : output.UnderIND_Score,
                                 UnderIND_Value = string.IsNullOrEmpty(output.UnderIND_Value) ? string.Empty : output.UnderIND_Value,
                                 Comments = string.IsNullOrEmpty(output.Comments) ? string.Empty : output.Comments,
                             }).ToList();

            basicDetails.ACHFS_KeyFinancialsEntity = keyFinancials;
            basicDetails.ACHFS_SubjectiveParametersEntity = subjectiveParameters;
            basicDetails.ACHFS_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public ACHFS_BasicDetailsEntity GetBasicDetails_Archive(int detailsId, short logId)
        {
            ACHFS_BasicDetailsEntity basicDetails = new ACHFS_BasicDetailsEntity();
            ACHFS_KeyFinancialsEntity keyFinancials = new ACHFS_KeyFinancialsEntity();
            ACHFS_SubjectiveParametersEntity subjectiveParameters = new ACHFS_SubjectiveParametersEntity();
            List<ACHFS_OutputDetailsEntity> outputDetails = new List<ACHFS_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(x => new ACHFS_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = logId,

                FinYear = x.FinYear,
                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                DateOfInput = x.DateOfInput,
                CurrencyUnits = x.CurrencyUnits,
                ParentCompanyName = x.ParentCompanyName,
                ParentCompanyId = x.ParentCompanyId,
                ParentRating = x.ParentRating,
                SponsorBank = x.SponsorBank,
                ParentCompanyShareHoldingPer = x.ParentCompanyShareHoldingPer,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

                IsFinal = x.IsFinal.Value
            }).FirstOrDefault();

            keyFinancials = dbContext.ACHFS_KeyFinancials_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(keyFinancialsEntity => new ACHFS_KeyFinancialsEntity
            {
                PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                PeriodEndingDate3 = keyFinancialsEntity.PeriodEndingDate3,
                NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                NoofMonthsPeriod3 = keyFinancialsEntity.NoofMonthsPeriod3,
                Currency1 = keyFinancialsEntity.Currency1,
                Currency2 = keyFinancialsEntity.Currency2,
                Currency3 = keyFinancialsEntity.Currency3,
                NetWorth1 = keyFinancialsEntity.NetWorth1,
                NetWorth2 = keyFinancialsEntity.NetWorth2,
                NetWorth3 = keyFinancialsEntity.NetWorth3,
                TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                TotalAssets3 = keyFinancialsEntity.TotalAssets3,
                TotalMemberships1 = keyFinancialsEntity.TotalMemberships1,
                TotalMemberships2 = keyFinancialsEntity.TotalMemberships2,
                TotalMemberships3 = keyFinancialsEntity.TotalMemberships3,
                TotalUnderconstructionCompletedHouses1 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses1,
                TotalUnderconstructionCompletedHouses2 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses2,
                TotalUnderconstructionCompletedHouses3 = keyFinancialsEntity.TotalUnderconstructionCompletedHouses3,
                GovtContributionTotalShareCapital1 = keyFinancialsEntity.GovtContributionTotalShareCapital1,
                GovtContributionTotalShareCapital2 = keyFinancialsEntity.GovtContributionTotalShareCapital2,
                GovtContributionTotalShareCapital3 = keyFinancialsEntity.GovtContributionTotalShareCapital3,
                TotalAdvances1 = keyFinancialsEntity.TotalAdvances1,
                TotalAdvances2 = keyFinancialsEntity.TotalAdvances2,
                TotalAdvances3 = keyFinancialsEntity.TotalAdvances3,
                InterestIncome1 = keyFinancialsEntity.InterestIncome1,
                InterestIncome2 = keyFinancialsEntity.InterestIncome2,
                InterestIncome3 = keyFinancialsEntity.InterestIncome3,
                NonInterestIncome1 = keyFinancialsEntity.NonInterestIncome1,
                NonInterestIncome2 = keyFinancialsEntity.NonInterestIncome2,
                NonInterestIncome3 = keyFinancialsEntity.NonInterestIncome3,
                InterestExpenses1 = keyFinancialsEntity.InterestExpenses1,
                InterestExpenses2 = keyFinancialsEntity.InterestExpenses2,
                InterestExpenses3 = keyFinancialsEntity.InterestExpenses3,
                EmployeeGASDExpenses1 = keyFinancialsEntity.EmployeeGASDExpenses1,
                EmployeeGASDExpenses2 = keyFinancialsEntity.EmployeeGASDExpenses2,
                EmployeeGASDExpenses3 = keyFinancialsEntity.EmployeeGASDExpenses3,
                PAT1 = keyFinancialsEntity.PAT1,
                PAT2 = keyFinancialsEntity.PAT2,
                PAT3 = keyFinancialsEntity.PAT3,
                LiquidAssets1 = keyFinancialsEntity.LiquidAssets1,
                LiquidAssets2 = keyFinancialsEntity.LiquidAssets2,
                LiquidAssets3 = keyFinancialsEntity.LiquidAssets3,
                ProvNPAWriteOffs1 = keyFinancialsEntity.ProvNPAWriteOffs1,
                ProvNPAWriteOffs2 = keyFinancialsEntity.ProvNPAWriteOffs2,
                ProvNPAWriteOffs3 = keyFinancialsEntity.ProvNPAWriteOffs3,
                DiversitryDepositBasePer1 = keyFinancialsEntity.DiversitryDepositBase1,
                DiversitryDepositBasePer2 = keyFinancialsEntity.DiversitryDepositBase2,
                DiversitryDepositBasePer3 = keyFinancialsEntity.DiversitryDepositBase3,
                AdvancesStressedSectorPer1 = keyFinancialsEntity.AdvancesStressedSector1,
                AdvancesStressedSectorPer2 = keyFinancialsEntity.AdvancesStressedSector2,
                AdvancesStressedSectorPer3 = keyFinancialsEntity.AdvancesStressedSector3,
                CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                CostOfFundsPer3 = keyFinancialsEntity.CostOfFundsPer3,
                CRARPer1 = keyFinancialsEntity.CRARPer1,
                CRARPer2 = keyFinancialsEntity.CRARPer2,
                CRARPer3 = keyFinancialsEntity.CRARPer3,
                Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                Tier1Per3 = keyFinancialsEntity.Tier1Per3,
                NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                NetNPAPer3 = keyFinancialsEntity.NetNPAPer3,
                AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                AdditioninNPAsAdvancesPer3 = keyFinancialsEntity.AdditioninNPAsAdvancesPer3,
                GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                GrossNPAPer3 = keyFinancialsEntity.GrossNPAPer3,
                ContingentLiability1 = keyFinancialsEntity.ContingentLiability1,
                ContingentLiability2 = keyFinancialsEntity.ContingentLiability2,
                ContingentLiability3 = keyFinancialsEntity.ContingentLiability3,
                ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                ALMGapin6monthsbucketPer3 = keyFinancialsEntity.ALMGapin6monthsbucketPer3,
                GrowthMembershipPer1 = keyFinancialsEntity.GrowthMembership1,
                GrowthMembershipPer2 = keyFinancialsEntity.GrowthMembership2,
                GrowthMembershipPer3 = keyFinancialsEntity.GrowthMembership3,
                BusinessEmployee1 = keyFinancialsEntity.BusinessEmployee1,
                BusinessEmployee2 = keyFinancialsEntity.BusinessEmployee2,
                BusinessEmployee3 = keyFinancialsEntity.BusinessEmployee3,
                SecuredAdvancesTotalAdvancesPer1 = keyFinancialsEntity.SecuredAdvancesTotalAdvances1,
                SecuredAdvancesTotalAdvancesPer2 = keyFinancialsEntity.SecuredAdvancesTotalAdvances2,
                SecuredAdvancesTotalAdvancesPer3 = keyFinancialsEntity.SecuredAdvancesTotalAdvances3,
                StateEconomicGrowthPer1 = keyFinancialsEntity.StateEconomicGrowth1,
                StateEconomicGrowthPer2 = keyFinancialsEntity.StateEconomicGrowth2,
                StateEconomicGrowthPer3 = keyFinancialsEntity.StateEconomicGrowth3,

            }).FirstOrDefault();

            subjectiveParameters = dbContext.ACHFS_SubjectiveParameters_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(subjectiveParametersEntity => new ACHFS_SubjectiveParametersEntity
            {
                IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                AccesstoEKuberRTGS = subjectiveParametersEntity.AccesstoEKuberRTGS,
                ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                AdverseNews = subjectiveParametersEntity.AdverseNews,
                IndependenceBoardDirectors = subjectiveParametersEntity.IndependenceBoardDirectors,
                CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                NPASysGen = subjectiveParametersEntity.NPASysGen,
                NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders

            }).FirstOrDefault();

            outputDetails = (from output in dbContext.ACHFS_Output_Details_Archive
                             join template in dbContext.ACHFS_Output_Template on output.TemplateId equals template.TemplateID
                             where output.DetailsId == detailsId && output.LogId == logId

                             select new ACHFS_OutputDetailsEntity
                             {
                                 TemplateID = output.TemplateId,
                                 Parameter1 = string.IsNullOrEmpty(template.Parameter1) ? string.Empty : template.Parameter1,
                                 Parameter1Per = string.IsNullOrEmpty(template.Parameter1Per) ? string.Empty : template.Parameter1Per,
                                 Parameter2 = string.IsNullOrEmpty(template.Parameter2) ? string.Empty : template.Parameter2,
                                 Parameter2Per = string.IsNullOrEmpty(template.Parameter2Per) ? string.Empty : template.Parameter2Per,
                                 Parameter3Per = output.Parameter_Per,
                                 Parameter3 = output.Parameter_Name,
                                 UnderBaselIII_Score = string.IsNullOrEmpty(output.UnderBaselIII_Score) ? string.Empty : output.UnderBaselIII_Score,
                                 UnderBaselIII_Value = string.IsNullOrEmpty(output.UnderBaselIII_Value) ? string.Empty : output.UnderBaselIII_Value,
                                 UnderIND_Score = string.IsNullOrEmpty(output.UnderIND_Score) ? string.Empty : output.UnderIND_Score,
                                 UnderIND_Value = string.IsNullOrEmpty(output.UnderIND_Value) ? string.Empty : output.UnderIND_Value,
                                 Comments = string.IsNullOrEmpty(output.Comments) ? string.Empty : output.Comments,
                             }).ToList();

            basicDetails.ACHFS_KeyFinancialsEntity = keyFinancials;
            basicDetails.ACHFS_SubjectiveParametersEntity = subjectiveParameters;
            basicDetails.ACHFS_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public bool ComputeOutputDetails(ACHFS_BasicDetailsEntity riskModelExcelEntity, string OutputTemplateFilePath)
        {
            CompanyDAL companyDAL = new CompanyDAL();
            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            try
            {
                mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                mWorkSheets = mWorkBook.Worksheets;
                mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Input Sheet"];

                string value = "";
                uint rowIndex = 0;
                int columnIndex = 0;

                string columnName = "";
                object obj;

                // Basic detail fields update - Company Name
                try
                {
                    string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);

                    rowIndex = _helperDAL.GetExcelRowIndex("B4");
                    columnName = _helperDAL.GetExcelColumnName("B4");
                    columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                    mWSheet.Cells[rowIndex, columnIndex] = companyName;
                }
                catch { }

                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
                properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = riskModelExcelEntity.GetType().GetProperty(property.Name).GetValue(riskModelExcelEntity, null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                try
                                {
                                    value = Convert.ToString(double.Parse(value) / 100);
                                    //value = (value == string.Empty || value.ToUpper().Trim() == "NA") ? "0" : Convert.ToString(double.Parse(value) / 100);
                                }
                                catch
                                {

                                }
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
                properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = riskModelExcelEntity.GetType().GetProperty(property.Name).GetValue(riskModelExcelEntity, null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                try
                                {
                                    value = Convert.ToString(double.Parse(value) / 100);
                                }
                                catch
                                {

                                }
                                //value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                properties = TypeDescriptor.GetProperties(riskModelExcelEntity.ACHFS_KeyFinancialsEntity);
                ACHFS_KeyFinancialsEntity getKeyFinancialsEntity = riskModelExcelEntity.ACHFS_KeyFinancialsEntity;
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = getKeyFinancialsEntity.GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity, null);
                            value = obj.ToString();
                            var type = getKeyFinancialsEntity.GetType().GetProperty(property.Name).ToString();
                            if (type.ToLower().Contains("system.datetime"))
                            {
                                try
                                {
                                    DateTime dt = Convert.ToDateTime(value.ToString());
                                    mWSheet.Cells[rowIndex, columnIndex] = dt.ToString("dd-MMM-yyyy");
                                }
                                catch { }
                            }
                            else
                            {
                                string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                                if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                                {
                                    try
                                    {
                                        value = Convert.ToString(double.Parse(value) / 100);
                                    }
                                    catch
                                    {

                                    }
                                }
                                mWSheet.Cells[rowIndex, columnIndex] = value;
                            }
                        }
                        catch { }
                    }
                }

                properties = TypeDescriptor.GetProperties(riskModelExcelEntity.ACHFS_SubjectiveParametersEntity);
                ACHFS_SubjectiveParametersEntity getSubjectiveParametersEntity = riskModelExcelEntity.ACHFS_SubjectiveParametersEntity;

                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = getSubjectiveParametersEntity.GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity, null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                try
                                {
                                    value = Convert.ToString(double.Parse(value) / 100);
                                }
                                catch
                                {

                                }
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                mWorkBook.Save();
                mWorkBook.Close(1, null, null);
                xlApp.Quit();
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                mWSheet = null;
                mWorkBook = null;
                mWorkSheets = null;
                xlApp = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return true;
        }

    }

}