﻿using IndRa.RiskModel.DAL.DataAccess;
using IndRa.RiskModel.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.DAL
{

    public class ReportsDAL
    {
        IndRaDBcontext dbContext = new IndRaDBcontext();

        public DataTable GetSegmentWiseNumber(string fromYear, string toYear)
        {
            try
            {
                DataTable dataTable = null;

                SqlParameter param1 = new SqlParameter("@FromYear", SqlDbType.VarChar);
                param1.Value = fromYear;

                SqlParameter param2 = new SqlParameter("@ToYear", SqlDbType.VarChar);
                param2.Value = toYear;

                using (dataTable = GetDataSetResult("RM_SegmentEnityWiseNumber", param1, param2).Tables[0])
                {
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public DataTable GetEntityWiseRatingMatrix(string fromYear, string toYear)
        {
            try
            {
                DataTable dataTable = null;

                SqlParameter param1 = new SqlParameter("@FromYear", SqlDbType.VarChar);
                param1.Value = fromYear;

                SqlParameter param2 = new SqlParameter("@ToYear", SqlDbType.VarChar);
                param2.Value = toYear;

                using (dataTable = GetDataSetResult("RM_EntityWiseRatingMatrix", param1, param2).Tables[0])
                {
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public DataTable GetRatingSegmentWiseName(string rating, string modelId, string finYear, string pfrmType)
        {
            try
            {
                DataTable dataTable = null;


                SqlParameter param1 = new SqlParameter("@RatingId", SqlDbType.VarChar);
                param1.Value = rating;

                SqlParameter param2 = new SqlParameter("@ModelId", SqlDbType.VarChar);
                param2.Value = modelId;

                SqlParameter param3 = new SqlParameter("@FinYear", SqlDbType.VarChar);
                param3.Value = finYear;

                SqlParameter param4 = new SqlParameter("@PFRM_Type", SqlDbType.VarChar);

                if (string.IsNullOrEmpty(pfrmType))
                {
                    param4.Value = DBNull.Value;
                }
                else
                {
                    param4.Value = pfrmType;
                }

                using (dataTable = GetDataSetResult("RM_RatingWiseSegmentWiseName", param1, param2, param3, param4).Tables[0])
                {
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public DataTable GetRatingwiseNumber(string modelId, string fromYear, string toYear, string pfrmType)
        {
            try
            {
                DataTable dataTable = null;

                SqlParameter param1 = new SqlParameter("@ModelId", SqlDbType.VarChar);
                param1.Value = modelId;

                SqlParameter param3 = new SqlParameter("@Fromyear", SqlDbType.VarChar);
                param3.Value = fromYear;

                SqlParameter param2 = new SqlParameter("@ToYear", SqlDbType.VarChar);
                param2.Value = toYear;

                SqlParameter param4 = new SqlParameter("@PFRM_Type", SqlDbType.VarChar);
                if (string.IsNullOrEmpty(pfrmType))
                {
                    param4.Value = DBNull.Value;
                }
                else
                {
                    param4.Value = pfrmType;
                }

                using (dataTable = GetDataSetResult("RM_RatingWiseNumber", param1, param3, param2, param4).Tables[0])
                {
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        // RM ECL Report
        public DataTable GetECL(string year)
        {
            try
            {
                DataTable dataTable = null;

                SqlParameter param1 = new SqlParameter("@YEAR", SqlDbType.VarChar);
                param1.Value = year;

                using (dataTable = GetDataSetResult("RM_ECL", param1).Tables[0])
                {

                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public DataTable GetYearWiseParameter(string companyId, string fromYear, string toYear)
        {
            try
            {
                DataTable dataTable = null;

                SqlParameter param1 = new SqlParameter("@CompanyID", SqlDbType.VarChar);
                param1.Value = companyId;

                SqlParameter param2 = new SqlParameter("@FromYear", SqlDbType.VarChar);
                param2.Value = fromYear;

                SqlParameter param3 = new SqlParameter("@ToYear", SqlDbType.VarChar);
                param3.Value = toYear;

                using (dataTable = GetDataSetResult("RM_YearWiseParameter", param1, param2, param3).Tables[0])
                {
                    return dataTable;

                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public DataTable GetClientWiseParameter(string financialYear, string modelId)
        {
            try
            {
                DataTable dataTable = null;

                SqlParameter param1 = new SqlParameter("@FinancialYear", SqlDbType.VarChar);
                param1.Value = financialYear;

                SqlParameter param2 = new SqlParameter("@ModelId", SqlDbType.VarChar);
                param2.Value = modelId;

                using (dataTable = GetDataSetResult("RM_ClientWiseParameter", param1, param2).Tables[0])
                {
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        // RM Comoany Log Report
        public DataTable GetCompanylog(string companyId, string finYear)
        {
            try
            {
                DataTable dataTable = null;
                SqlParameter param1 = new SqlParameter("@CompanyId", SqlDbType.VarChar);
                param1.Value = companyId;
                SqlParameter param2 = new SqlParameter("@FinYear", SqlDbType.VarChar);
                param2.Value = finYear;

                using (dataTable = GetDataSetResult("RM_CompanyLog", param1, param2).Tables[0])
                {
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        // RM User Log Report
        public DataTable GetUserlog(string analystId, string finYear)
        {
            try
            {
                DataTable dataTable = null;
                SqlParameter param1 = new SqlParameter("@UserId", SqlDbType.VarChar);
                param1.Value = analystId;
                SqlParameter param2 = new SqlParameter("@FinYear", SqlDbType.VarChar);
                param2.Value = finYear;

                using (dataTable = GetDataSetResult("RM_UserLog", param1, param2).Tables[0])
                {
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        // Transition Report
        public DataTable GetRatingWiseTransition(string fromYear, string toYear, string modelId, string pfrmType)
        {
            try
            {
                DataTable dataTable = null;
                SqlParameter param1 = new SqlParameter("@FromFinancialYear", SqlDbType.VarChar);
                param1.Value = fromYear;
                SqlParameter param2 = new SqlParameter("@ToFinancialYear", SqlDbType.VarChar);
                param2.Value = toYear;
                SqlParameter param3 = new SqlParameter("@ModelId", SqlDbType.VarChar);
                param3.Value = modelId;

                SqlParameter param4 = new SqlParameter("@PFRM_Type", SqlDbType.VarChar);
                if (string.IsNullOrEmpty(pfrmType))
                {
                    param4.Value = DBNull.Value;
                }
                else
                {
                    param4.Value = pfrmType;
                }


                using (dataTable = GetDataSetResult("RM_RatingWiseTransition", param1, param2, param3, param4).Tables[0])
                {
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        //public DataSet GetResultReport(string commandText, params SqlParameter[] parameters)
        //{
        //    DataSet retVal = new DataSet();
        //    string strConn = dbContext.Database.Connection.ConnectionString;
        //    SqlConnection con = new SqlConnection(strConn);
        //    SqlCommand cmdReport = new SqlCommand(commandText, con);
        //    SqlDataAdapter daReport = new SqlDataAdapter(cmdReport);
        //    using (cmdReport)
        //    {
        //        cmdReport.CommandType = CommandType.StoredProcedure;
        //        cmdReport.Parameters.AddRange(parameters);
        //        daReport.Fill(retVal);
        //    }
        //    return retVal;
        //}

        public DataSet GetDataSetResult(string commandText, params SqlParameter[] parameters)
        {
            DataSet retVal = new DataSet();
            string strConn = dbContext.Database.Connection.ConnectionString;
            SqlConnection con = new SqlConnection(strConn);
            SqlCommand cmdReport = new SqlCommand(commandText, con);
            SqlDataAdapter daReport = new SqlDataAdapter(cmdReport);
            using (cmdReport)
            {
                cmdReport.CommandType = CommandType.StoredProcedure;
                cmdReport.Parameters.AddRange(parameters);
                daReport.Fill(retVal);
            }
            return retVal;
        }


        public List<DashboardEntity> GetHistoricalData(string finYear)
        {
            try
            {
                List<DashboardEntity> objList = null;
                DataTable dataTable = null;

                SqlParameter param1 = new SqlParameter("@Finyear", SqlDbType.VarChar);
                param1.Value = finYear;

                using (dataTable = GetDataSetResult("RM_GetMigratedData", param1).Tables[0])
                {
                    objList = CommonDAL.ConvertDataTable<DashboardEntity>(dataTable);
                    return objList;
                }
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        public List<DashboardAnalystEntity> GetCompanyData(string modelId, string year)
        {
            try
            {
                List<DashboardAnalystEntity> objList = null;
                DataTable dataTable = null;

                SqlParameter param1 = new SqlParameter("@ModelId", SqlDbType.VarChar);
                param1.Value = modelId;

                SqlParameter param2 = new SqlParameter("@Year", SqlDbType.VarChar);
                param2.Value = year;

                using (dataTable = GetDataSetResult("RM_GetCompanyData", param1, param2).Tables[0])
                {
                    objList = CommonDAL.ConvertDataTable<DashboardAnalystEntity>(dataTable);
                    return objList;
                }
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        public DataTable GetOutputSheetData(string fromYear, string toYear, string modelId)
        {
            try
            {
                DataTable dataTable = null;
                SqlParameter param1 = new SqlParameter("@FromFinancialYear", SqlDbType.VarChar);
                param1.Value = fromYear;
                SqlParameter param2 = new SqlParameter("@ToFinancialYear", SqlDbType.VarChar);
                param2.Value = toYear;
                SqlParameter param3 = new SqlParameter("@ModelId", SqlDbType.VarChar);
                param3.Value = modelId;
                using (dataTable = GetDataSetResult("RM_Output_Sheet", param1, param2, param3).Tables[0])
                {
                    for (int i = 0; i < dataTable.Columns.Count; i++)
                    {
                        string columName = dataTable.Columns[i].ColumnName;
                        if (columName.Contains("FromYear"))
                        {
                            dataTable.Columns[i].ColumnName = columName.Replace("FromYear", fromYear);
                        }
                        else if (columName.Contains("ToYear"))
                        {
                            dataTable.Columns[i].ColumnName = columName.Replace("ToYear", toYear);
                        }
                    }
                    return dataTable;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string GetOutputSheetData_Html(string fromYear, string toYear, string modelId)
        {
            try
            {
                DataTable dataTable = null;
                SqlParameter param1 = new SqlParameter("@FromFinancialYear", SqlDbType.VarChar);
                param1.Value = fromYear;
                SqlParameter param2 = new SqlParameter("@ToFinancialYear", SqlDbType.VarChar);
                param2.Value = toYear;
                SqlParameter param3 = new SqlParameter("@ModelId", SqlDbType.VarChar);
                param3.Value = modelId;
                using (dataTable = GetDataSetResult("RM_Output_Sheet_HTML", param1, param2, param3).Tables[0])
                {
                    return dataTable.Rows[0][0].ToString();
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}

