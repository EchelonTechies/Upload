﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.DAL
{
    public static class Generate
    {
        /// <summary>
        ///     Generate email activation code
        /// </summary>
        /// <returns></returns>
        public static string EmailActivationCode()
        {
            return Guid.NewGuid().ToString();
        }
    }

}
