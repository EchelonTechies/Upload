﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Text;
using IndRa.RiskModel.DAL.Entities;
using DocumentFormat.OpenXml.Spreadsheet;
using System.ComponentModel;
using IndRa.RiskModel.DAL.DataAccess;
using System.Data.Entity.Validation;
using IndRa.RiskModel.DAL.DAL;
using System.Data.Entity;
using IndRa.RiskModel.Helpers;

namespace IndRa.RiskModel.DAL
{
    public class SCBDAL
    {
        HelperDAL _helperDAL = null;
        IndRaDBcontext dbContext = new IndRaDBcontext();

        public SCBDAL()
        {
            _helperDAL = new HelperDAL();
        }

        public List<SCB_OutputDetailsEntity> GetOutputTemplateEntity()
        {
            List<SCB_OutputDetailsEntity> outputTemplate = new List<SCB_OutputDetailsEntity>();
            outputTemplate = dbContext.SCB_Output_Template.Where(a => a.InActive == null).OrderBy(a => a.Ranking).Select(output => new SCB_OutputDetailsEntity
            {
                TemplateID = output.TemplateID,
                Parameter1 = string.IsNullOrEmpty(output.Parameter1) ? string.Empty : output.Parameter1,
                Parameter1Per = string.IsNullOrEmpty(output.Parameter1Per) ? string.Empty : output.Parameter1Per,
                Parameter2 = string.IsNullOrEmpty(output.Parameter2) ? string.Empty : output.Parameter2,
                Parameter2Per = string.IsNullOrEmpty(output.Parameter2Per) ? string.Empty : output.Parameter2Per,
                Parameter3 = string.IsNullOrEmpty(output.Parameter3) ? string.Empty : output.Parameter3,
                Parameter3Per = string.Empty,
                UnderBaselIII_Score = string.Empty,
                UnderBaselIII_Value = string.Empty,
                UnderIND_Score = string.Empty,
                UnderIND_Value = string.Empty,
                Comments = string.Empty,
            }).ToList();
            return outputTemplate;
        }

        public SCB_BasicDetailsEntity ImportCompanyDetailsFromExcel(string filePath, string fileName, string workSheet, int userId)
        {

            SCB_BasicDetailsEntity basicDetails = new SCB_BasicDetailsEntity();
            SCB_KeyFinancialsEntity scb_KeyFinancials = new SCB_KeyFinancialsEntity();
            SCB_SubjectiveParametersEntity scb_SubjectiveParameters = new SCB_SubjectiveParametersEntity();
            SCB_IndustryExpsoureEntity scb_IndustryExpsoureEntity = new SCB_IndustryExpsoureEntity();

            string value = "";

            DataTable dtExcel = null;
            DataTable dtTranspose = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);
            dtTranspose = _helperDAL.GenerateTransposedTable(dtExcel);

            _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);

            if (dtTranspose.Rows.Count > 0)
            {
                // get values for SCB Basic Details
                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(basicDetails);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            value = dtTranspose.Rows[0][property.DisplayName].ToString();

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(basicDetails, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for SCB Key financials
                properties = TypeDescriptor.GetProperties(scb_KeyFinancials);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (displayName.Contains("Total") || displayName.Contains("Growth"))
                            {

                            }
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }
                            if (value.Contains(","))
                            {
                                value = value.Replace(",", string.Empty);
                            }
                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(scb_KeyFinancials, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for SCB Subjective Parameters
                properties = TypeDescriptor.GetProperties(scb_SubjectiveParameters);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[1][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(scb_SubjectiveParameters, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for SCB Industry Exposure
                properties = TypeDescriptor.GetProperties(scb_IndustryExpsoureEntity);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(scb_IndustryExpsoureEntity, safeValue);
                        }
                    }
                    catch { }

                }

                basicDetails.SCB_KeyFinancialsEntity = scb_KeyFinancials;
                basicDetails.SCB_SubjectiveParametersEntity = scb_SubjectiveParameters;
                basicDetails.SCB_IndustryExpsoureEntity = scb_IndustryExpsoureEntity;


                CompanyDAL companyDAL = new CompanyDAL();
                int companyID = companyDAL.GetCompanyIDByCompanyName(basicDetails.CompanyName, userId);
                basicDetails.CompanyId = companyID;
                CommonDAL commonDAL = new CommonDAL();
                string finYear = commonDAL.GetFinYearBasedOnDate(DateTime.Now);
                basicDetails.FinYear = finYear;
                //if (scb_BasicDetails.DateOfInput.HasValue)
                //{
                //    DateTime dateOfInput = scb_BasicDetails.DateOfInput.Value;
                //    string finYear = commonDAL.GetFinYearBasedOnDate(scb_BasicDetails.DateOfInput.Value);
                //    scb_BasicDetails.FinYear = finYear;
                //}
            }

            return basicDetails;

        }

        public List<SCB_OutputDetailsEntity> GetOutputFromExcel(string filePath, string fileName, string workSheet, int userId)
        {
            List<SCB_OutputDetailsEntity> outputDetailsEntity = new List<SCB_OutputDetailsEntity>();
            DataTable dtExcel = null;

            //dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);
            dtExcel = _helperDAL.READExcel(filePath, fileName, workSheet);

            string paramterName = "";

            if (dtExcel.Rows.Count > 0)
            {
                short row = 0;
                string underBaselIIIColumnName_Value = "Under Basel III";
                string underBaselIIIColumnName_Score = "";
                string UnderINDAS109ColumnName_Value = "Under IND AS 109";
                string UnderINDAS109ColumnName_Score = "";

                for (int col = 0; col < dtExcel.Columns.Count; col++)
                {
                    if (dtExcel.Columns[col].Caption == underBaselIIIColumnName_Value)
                    {
                        underBaselIIIColumnName_Score = dtExcel.Columns[col + 1].Caption;
                        continue;
                    }
                    else if (dtExcel.Columns[col].Caption == UnderINDAS109ColumnName_Value)
                    {
                        UnderINDAS109ColumnName_Score = dtExcel.Columns[col + 1].Caption;
                    }
                }
                for (int i = 1; i < dtExcel.Rows.Count; i++)
                {
                    SCB_OutputDetailsEntity newRow = new SCB_OutputDetailsEntity();
                    newRow.TemplateID = row;
                    paramterName = dtExcel.Rows[i]["F7"].ToString();
                    if (paramterName != string.Empty)
                    {
                    }
                    else
                    {
                        paramterName = dtExcel.Rows[i][0].ToString();
                    }
                    if (paramterName == string.Empty)
                    {
                        continue;
                    }
                    if (paramterName == "Rating / Probability of Default")
                    {
                        break;
                    }
                    newRow.Parameter1 = paramterName;
                    newRow.Parameter3Per = dtExcel.Rows[i]["F9"].ToString();
                    newRow.UnderBaselIII_Value = dtExcel.Rows[i][underBaselIIIColumnName_Value].ToString();
                    newRow.UnderBaselIII_Score = dtExcel.Rows[i][underBaselIIIColumnName_Score].ToString();

                    newRow.UnderIND_Value = dtExcel.Rows[i][UnderINDAS109ColumnName_Value].ToString();
                    newRow.UnderIND_Score = dtExcel.Rows[i][UnderINDAS109ColumnName_Score].ToString();

                    outputDetailsEntity.Add(newRow);
                    row++;
                }
            }

            return outputDetailsEntity;

        }


        public int SaveCompanyBasicDetailsAsDraft(int userId, int roleId, SCB_BasicDetailsEntity riskModelExcelEntity, out int basicDetails_ArchiveId, out short logID)
        {
            int detailsId = 0;
            basicDetails_ArchiveId = 0;
            CompanyDAL companyDAL = new CompanyDAL();
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                bool isRecordExist = companyDAL.CheckIfAlreadyExists_CompanyDetails(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                if (isRecordExist == true && riskModelExcelEntity.DetailsId == 0)
                {
                    detailsId = companyDAL.GetCompanyBasicDetailsID(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                    riskModelExcelEntity.DetailsId = detailsId;
                }
                if (riskModelExcelEntity.ButtonValue == ButtonValue.SubmitForApporval.ToString()) //"SubmitForApporval"
                {
                    riskModelExcelEntity.SubmitForApproval = true;
                    riskModelExcelEntity.SubmitForApprovalDate = DateTime.Now;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                {
                    riskModelExcelEntity.ApprovedDate = DateTime.Now;
                    riskModelExcelEntity.ReviewedDate = null;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ReviewDetails.ToString())
                {
                    riskModelExcelEntity.ReviewedDate = DateTime.Now;
                    riskModelExcelEntity.ApprovedDate = null;
                }
                logID = companyDAL.GetNHBLogId(riskModelExcelEntity.DetailsId);

                NHB_Details_Archive nHB_Details_Archive = new NHB_Details_Archive
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    //SponsorBank = riskModelExcelEntity.SponsorBank,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                    IsDraft = true
                };

                NHB_Details nHB_Details = new NHB_Details
                {
                    UserId = userId,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                };

                NHB_Details_Final nHB_Details_Final = new NHB_Details_Final
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                };

                if (userId != 0)
                {
                    #region Add Data

                    if (nHB_Details != null && companyDAL.CheckIfAlreadyExists_CompanyDetails(nHB_Details.CompanyId, nHB_Details.FinYear) == false)
                    {
                        try
                        {
                            detailsId = (int)companyDAL.AddCompanyDetails(nHB_Details);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }

                    }

                    #endregion

                    #region Update Data

                    else
                    {
                        try
                        {
                            NHB_Details details = dbContext.NHB_Details.Where(detail => detail.DetailsId == nHB_Details.DetailsId).FirstOrDefault();
                            if (details != null)
                            {
                                details.UserId = nHB_Details.UserId;
                                details.CompanyId = nHB_Details.CompanyId;
                                details.DateOfInput = nHB_Details.DateOfInput;
                                details.CurrencyUnits = nHB_Details.CurrencyUnits;
                                details.ParentCompanyId = nHB_Details.ParentCompanyId;
                                details.SponsorBank = nHB_Details.SponsorBank;
                                details.ParentCompanyName = nHB_Details.ParentCompanyName;
                                details.UpdatedBy = nHB_Details.UpdatedBy;
                                details.UpdatedDateTime = nHB_Details.UpdatedDateTime;
                                details.Comments = riskModelExcelEntity.Comments;
                                details.FinalRating = riskModelExcelEntity.FinalRating;
                                details.PD = riskModelExcelEntity.PD;
                                details.SubmitForApproval = nHB_Details.SubmitForApproval;
                                details.SubmitForApprovalDate = nHB_Details.SubmitForApprovalDate;
                                details.ApprovedDate = nHB_Details.ApprovedDate;
                                details.ReviewedDate = nHB_Details.ReviewedDate;

                                details.IsFinal = nHB_Details.IsFinal;
                                dbContext.SaveChanges();
                                detailsId = details.DetailsId;
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return -1;
                            }
                        }
                        catch (Exception exception)
                        {
                            throw exception;
                        }
                    }

                    #endregion

                    #region Final Data Add

                    if (nHB_Details.IsFinal == true)
                    {
                        try
                        {
                            companyDAL.AddCompanyDetails_Final(nHB_Details_Final);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    if (isRecordExist == false)
                    {
                        nHB_Details_Archive.UpdatedBy = null;
                        nHB_Details_Archive.UpdatedDateTime = null;
                    }
                    else
                    {
                        nHB_Details_Archive.CreatedBy = null;
                        nHB_Details_Archive.CreatedDateTime = null;
                    }

                    nHB_Details_Archive.DetailsId = detailsId;
                    basicDetails_ArchiveId = (int)companyDAL.AddCompanyDetails_Archive(nHB_Details_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return detailsId;

        }

        public bool SaveAsDraft_SCBKeyFinancial(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, SCB_KeyFinancialsEntity keyFinancialsEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                SCB_KeyFinancials_Archive scb_KeyFinancials_Archive = new SCB_KeyFinancials_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,

                    UserId = userId,
                    PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                    PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                    NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                    NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                    Currency1 = keyFinancialsEntity.Currency1,
                    Currency2 = keyFinancialsEntity.Currency2,
                    NetWorth1 = keyFinancialsEntity.NetWorth1,
                    NetWorth2 = keyFinancialsEntity.NetWorth2,
                    TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                    TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                    CreditDepositRatioPer1 = keyFinancialsEntity.CreditDepositRatioPer1,
                    CreditDepositRatioPer2 = keyFinancialsEntity.CreditDepositRatioPer2,
                    ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                    ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                    CASAPer1 = keyFinancialsEntity.CASAPer1,
                    CASAPer2 = keyFinancialsEntity.CASAPer2,
                    PrioritySectorAdvancesPer1 = keyFinancialsEntity.PrioritySectorAdvancesPer1,
                    PrioritySectorAdvancesPer2 = keyFinancialsEntity.PrioritySectorAdvancesPer2,
                    ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                    ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                    CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1,
                    CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2,
                    CRARPer1 = keyFinancialsEntity.CRARPer1,
                    CRARPer2 = keyFinancialsEntity.CRARPer2,
                    Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                    Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                    CommonEquityTierPer1 = keyFinancialsEntity.CommonEquityTierPer1,
                    CommonEquityTierPer2 = keyFinancialsEntity.CommonEquityTierPer2,
                    NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                    NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                    GrowthinDepositsPer1 = keyFinancialsEntity.GrowthinDepositsPer1,
                    GrowthinDepositsPer2 = keyFinancialsEntity.GrowthinDepositsPer2,
                    TotalNumBranches1 = keyFinancialsEntity.TotalNumBranches1,
                    TotalNumBranches2 = keyFinancialsEntity.TotalNumBranches2,
                    GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                    GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                    AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                    AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                    DiversityofIncomePer1 = keyFinancialsEntity.DiversityofIncomePer1,
                    DiversityofIncomePer2 = keyFinancialsEntity.DiversityofIncomePer2,
                    TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                    TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                    TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                    TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                    AdvancesToSensitiveSectorPer1 = keyFinancialsEntity.AdvancesToSensitiveSectorPer1,
                    AdvancesToSensitiveSectorPer2 = keyFinancialsEntity.AdvancesToSensitiveSectorPer2,
                    CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                    CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                    CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                    CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                    PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                    PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                    //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                    //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                    LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                    LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                    Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                    Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                    NetStableFundingRatioPer1 = keyFinancialsEntity.NetStableFundingRatioPer1,
                    NetStableFundingRatioPer2 = keyFinancialsEntity.NetStableFundingRatioPer2,
                    GearingPer1 = keyFinancialsEntity.GearingPer1,
                    GearingPer2 = keyFinancialsEntity.GearingPer2,
                    LeverageRatio1 = keyFinancialsEntity.LeverageRatioPer1,
                    LeverageRatio2 = keyFinancialsEntity.LeverageRatioPer2,
                    ProvisioningCoverageRatio1 = keyFinancialsEntity.ProvisioningCoverageRatio1,
                    ProvisioningCoverageRatio2 = keyFinancialsEntity.ProvisioningCoverageRatio2,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                SCB_KeyFinancials scb_KeyFinancials = new SCB_KeyFinancials
                {
                    DetailsId = detailID,
                    PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                    PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                    NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                    NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                    Currency1 = keyFinancialsEntity.Currency1,
                    Currency2 = keyFinancialsEntity.Currency2,
                    NetWorth1 = keyFinancialsEntity.NetWorth1,
                    NetWorth2 = keyFinancialsEntity.NetWorth2,
                    TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                    TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                    CreditDepositRatioPer1 = keyFinancialsEntity.CreditDepositRatioPer1,
                    CreditDepositRatioPer2 = keyFinancialsEntity.CreditDepositRatioPer2,
                    ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                    ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                    CASAPer1 = keyFinancialsEntity.CASAPer1,
                    CASAPer2 = keyFinancialsEntity.CASAPer2,
                    PrioritySectorAdvancesPer1 = keyFinancialsEntity.PrioritySectorAdvancesPer1,
                    PrioritySectorAdvancesPer2 = keyFinancialsEntity.PrioritySectorAdvancesPer2,
                    ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                    ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                    CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1,
                    CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2,
                    CRARPer1 = keyFinancialsEntity.CRARPer1,
                    CRARPer2 = keyFinancialsEntity.CRARPer2,
                    Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                    Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                    CommonEquityTierPer1 = keyFinancialsEntity.CommonEquityTierPer1,
                    CommonEquityTierPer2 = keyFinancialsEntity.CommonEquityTierPer2,
                    NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                    NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                    GrowthinDepositsPer1 = keyFinancialsEntity.GrowthinDepositsPer1,
                    GrowthinDepositsPer2 = keyFinancialsEntity.GrowthinDepositsPer2,
                    TotalNumBranches1 = keyFinancialsEntity.TotalNumBranches1,
                    TotalNumBranches2 = keyFinancialsEntity.TotalNumBranches2,
                    GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                    GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                    AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                    AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                    DiversityofIncomePer1 = keyFinancialsEntity.DiversityofIncomePer1,
                    DiversityofIncomePer2 = keyFinancialsEntity.DiversityofIncomePer2,
                    TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                    TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                    TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                    TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                    AdvancesToSensitiveSectorPer1 = keyFinancialsEntity.AdvancesToSensitiveSectorPer1,
                    AdvancesToSensitiveSectorPer2 = keyFinancialsEntity.AdvancesToSensitiveSectorPer2,
                    CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                    CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                    CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                    CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                    PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                    PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                    //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                    //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                    LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                    LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                    Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                    Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                    NetStableFundingRatioPer1 = keyFinancialsEntity.NetStableFundingRatioPer1,
                    NetStableFundingRatioPer2 = keyFinancialsEntity.NetStableFundingRatioPer2,
                    GearingPer1 = keyFinancialsEntity.GearingPer1,
                    GearingPer2 = keyFinancialsEntity.GearingPer2,
                    LeverageRatio1 = keyFinancialsEntity.LeverageRatioPer1,
                    LeverageRatio2 = keyFinancialsEntity.LeverageRatioPer2,
                    ProvisioningCoverageRatio1 = keyFinancialsEntity.ProvisioningCoverageRatio1,
                    ProvisioningCoverageRatio2 = keyFinancialsEntity.ProvisioningCoverageRatio2,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    // Add Data
                    if (scb_KeyFinancials != null && CheckIfAlreadyExists_SCBKeyFinancial(detailID) == false)
                    {
                        try
                        {
                            status = Add_SCBKeyFinancial(scb_KeyFinancials);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }
                    // Update Data
                    else
                    {
                        try
                        {
                            SCB_KeyFinancials SCB_KeyFinancials_Update = dbContext.SCB_KeyFinancials.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (SCB_KeyFinancials_Update != null)
                            {
                                SCB_KeyFinancials_Update.PeriodEndingDate1 = scb_KeyFinancials.PeriodEndingDate1;
                                SCB_KeyFinancials_Update.PeriodEndingDate2 = scb_KeyFinancials.PeriodEndingDate2;
                                SCB_KeyFinancials_Update.NoofMonthsPeriod1 = scb_KeyFinancials.NoofMonthsPeriod1;
                                SCB_KeyFinancials_Update.NoofMonthsPeriod2 = scb_KeyFinancials.NoofMonthsPeriod2;
                                SCB_KeyFinancials_Update.Currency1 = scb_KeyFinancials.Currency1;
                                SCB_KeyFinancials_Update.Currency2 = scb_KeyFinancials.Currency2;
                                SCB_KeyFinancials_Update.NetWorth1 = scb_KeyFinancials.NetWorth1;
                                SCB_KeyFinancials_Update.NetWorth2 = scb_KeyFinancials.NetWorth2;
                                SCB_KeyFinancials_Update.TotalAssets1 = scb_KeyFinancials.TotalAssets1;
                                SCB_KeyFinancials_Update.TotalAssets2 = scb_KeyFinancials.TotalAssets2;
                                SCB_KeyFinancials_Update.CreditDepositRatioPer1 = scb_KeyFinancials.CreditDepositRatioPer1;
                                SCB_KeyFinancials_Update.CreditDepositRatioPer2 = scb_KeyFinancials.CreditDepositRatioPer2;
                                SCB_KeyFinancials_Update.ReturnOnAssetsPer1 = scb_KeyFinancials.ReturnOnAssetsPer1;
                                SCB_KeyFinancials_Update.ReturnOnAssetsPer2 = scb_KeyFinancials.ReturnOnAssetsPer2;
                                SCB_KeyFinancials_Update.CASAPer1 = scb_KeyFinancials.CASAPer1;
                                SCB_KeyFinancials_Update.CASAPer2 = scb_KeyFinancials.CASAPer2;
                                SCB_KeyFinancials_Update.PrioritySectorAdvancesPer1 = scb_KeyFinancials.PrioritySectorAdvancesPer1;
                                SCB_KeyFinancials_Update.PrioritySectorAdvancesPer2 = scb_KeyFinancials.PrioritySectorAdvancesPer2;
                                SCB_KeyFinancials_Update.ReturnOnNetWorthPer1 = scb_KeyFinancials.ReturnOnNetWorthPer1;
                                SCB_KeyFinancials_Update.ReturnOnNetWorthPer2 = scb_KeyFinancials.ReturnOnNetWorthPer2;
                                SCB_KeyFinancials_Update.CostOfDepositsPer1 = scb_KeyFinancials.CostOfDepositsPer1;
                                SCB_KeyFinancials_Update.CostOfDepositsPer2 = scb_KeyFinancials.CostOfDepositsPer2;
                                SCB_KeyFinancials_Update.CRARPer1 = scb_KeyFinancials.CRARPer1;
                                SCB_KeyFinancials_Update.CRARPer2 = scb_KeyFinancials.CRARPer2;
                                SCB_KeyFinancials_Update.Tier1Per1 = scb_KeyFinancials.Tier1Per1;
                                SCB_KeyFinancials_Update.Tier1Per2 = scb_KeyFinancials.Tier1Per2;
                                SCB_KeyFinancials_Update.CommonEquityTierPer1 = scb_KeyFinancials.CommonEquityTierPer1;
                                SCB_KeyFinancials_Update.CommonEquityTierPer2 = scb_KeyFinancials.CommonEquityTierPer2;
                                SCB_KeyFinancials_Update.NetNPAPer1 = scb_KeyFinancials.NetNPAPer1;
                                SCB_KeyFinancials_Update.NetNPAPer2 = scb_KeyFinancials.NetNPAPer2;
                                SCB_KeyFinancials_Update.GrowthinDepositsPer1 = scb_KeyFinancials.GrowthinDepositsPer1;
                                SCB_KeyFinancials_Update.GrowthinDepositsPer2 = scb_KeyFinancials.GrowthinDepositsPer2;
                                SCB_KeyFinancials_Update.TotalNumBranches1 = scb_KeyFinancials.TotalNumBranches1;
                                SCB_KeyFinancials_Update.TotalNumBranches2 = scb_KeyFinancials.TotalNumBranches2;

                                SCB_KeyFinancials_Update.GrossNPAPer1 = scb_KeyFinancials.GrossNPAPer1;
                                SCB_KeyFinancials_Update.GrossNPAPer2 = scb_KeyFinancials.GrossNPAPer2;
                                SCB_KeyFinancials_Update.AdditioninNPAsAdvancesPer1 = scb_KeyFinancials.AdditioninNPAsAdvancesPer1;
                                SCB_KeyFinancials_Update.AdditioninNPAsAdvancesPer2 = scb_KeyFinancials.AdditioninNPAsAdvancesPer2;
                                SCB_KeyFinancials_Update.DiversityofIncomePer1 = scb_KeyFinancials.DiversityofIncomePer1;
                                SCB_KeyFinancials_Update.DiversityofIncomePer2 = scb_KeyFinancials.DiversityofIncomePer2;
                                SCB_KeyFinancials_Update.TangibleNWNetNPA1 = scb_KeyFinancials.TangibleNWNetNPA1;
                                SCB_KeyFinancials_Update.TangibleNWNetNPA2 = scb_KeyFinancials.TangibleNWNetNPA2;
                                SCB_KeyFinancials_Update.TotalContLiabilityTotalAssetsPer1 = scb_KeyFinancials.TotalContLiabilityTotalAssetsPer1;
                                SCB_KeyFinancials_Update.TotalContLiabilityTotalAssetsPer2 = scb_KeyFinancials.TotalContLiabilityTotalAssetsPer2;
                                SCB_KeyFinancials_Update.AdvancesToSensitiveSectorPer1 = scb_KeyFinancials.AdvancesToSensitiveSectorPer1;
                                SCB_KeyFinancials_Update.AdvancesToSensitiveSectorPer2 = scb_KeyFinancials.AdvancesToSensitiveSectorPer2;
                                SCB_KeyFinancials_Update.CosttoIncomePer1 = scb_KeyFinancials.CosttoIncomePer1;
                                SCB_KeyFinancials_Update.CosttoIncomePer2 = scb_KeyFinancials.CosttoIncomePer2;
                                SCB_KeyFinancials_Update.CreditCostPer1 = scb_KeyFinancials.CreditCostPer1;
                                SCB_KeyFinancials_Update.CreditCostPer2 = scb_KeyFinancials.CreditCostPer2;
                                SCB_KeyFinancials_Update.PPOPCreditCost1 = scb_KeyFinancials.PPOPCreditCost1;
                                SCB_KeyFinancials_Update.PPOPCreditCost2 = scb_KeyFinancials.PPOPCreditCost2;
                                SCB_KeyFinancials_Update.ALMGapin6monthsbucketPer1 = scb_KeyFinancials.ALMGapin6monthsbucketPer1;
                                SCB_KeyFinancials_Update.ALMGapin6monthsbucketPer2 = scb_KeyFinancials.ALMGapin6monthsbucketPer2;
                                SCB_KeyFinancials_Update.LiquidityCoverageRatioPer1 = scb_KeyFinancials.LiquidityCoverageRatioPer1;
                                SCB_KeyFinancials_Update.LiquidityCoverageRatioPer2 = scb_KeyFinancials.LiquidityCoverageRatioPer2;
                                SCB_KeyFinancials_Update.Top20ConcentrationPer1 = scb_KeyFinancials.Top20ConcentrationPer1;
                                SCB_KeyFinancials_Update.Top20ConcentrationPer2 = scb_KeyFinancials.Top20ConcentrationPer2;
                                SCB_KeyFinancials_Update.NetStableFundingRatioPer1 = scb_KeyFinancials.NetStableFundingRatioPer1;
                                SCB_KeyFinancials_Update.NetStableFundingRatioPer2 = scb_KeyFinancials.NetStableFundingRatioPer2;
                                SCB_KeyFinancials_Update.GearingPer1 = scb_KeyFinancials.GearingPer1;
                                SCB_KeyFinancials_Update.GearingPer2 = scb_KeyFinancials.GearingPer2;
                                SCB_KeyFinancials_Update.LeverageRatio1 = scb_KeyFinancials.LeverageRatio1;
                                SCB_KeyFinancials_Update.LeverageRatio2 = scb_KeyFinancials.LeverageRatio2;
                                SCB_KeyFinancials_Update.ProvisioningCoverageRatio1 = scb_KeyFinancials.ProvisioningCoverageRatio1;
                                SCB_KeyFinancials_Update.ProvisioningCoverageRatio2 = scb_KeyFinancials.ProvisioningCoverageRatio2;

                                SCB_KeyFinancials_Update.CreatedBy = scb_KeyFinancials.CreatedBy;
                                SCB_KeyFinancials_Update.CreatedDateTime = scb_KeyFinancials.CreatedDateTime;
                                SCB_KeyFinancials_Update.UpdatedBy = scb_KeyFinancials.UpdatedBy;
                                SCB_KeyFinancials_Update.UpdatedDateTime = scb_KeyFinancials.UpdatedDateTime;

                                dbContext.SaveChanges();
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return false;
                            }
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            return false;
                        }
                    }

                    status = Add_SCBKeyFinancial_Archive(scb_KeyFinancials_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return true;

        }

        public bool Add_SCBKeyFinancial(SCB_KeyFinancials scb_KeyFinancials)
        {
            try
            {
                dbContext.SCB_KeyFinancials.Add(scb_KeyFinancials);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_SCBKeyFinancial_Archive(SCB_KeyFinancials_Archive scb_KeyFinancials_Archive)
        {
            try
            {
                dbContext.SCB_KeyFinancials_Archive.Add(scb_KeyFinancials_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_SCBSubjectiveParameters(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, SCB_SubjectiveParametersEntity subjectiveParametersEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                SCB_SubjectiveParameters_Archive subjectiveParameters_Archive = new SCB_SubjectiveParameters_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,

                    //PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank,
                    ExternalRating = subjectiveParametersEntity.ExternalRating,
                    IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                    BusinessModel = subjectiveParametersEntity.BusinessModel,
                    ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                    //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                    AdverseNews = subjectiveParametersEntity.AdverseNews,
                    CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                    AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                    AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                    NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                    //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                    NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                    LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                    CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                    NPASysGen = subjectiveParametersEntity.NPASysGen,
                    NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                    CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                    NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                    SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                    QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                    DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,
                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                SCB_SubjectiveParameters subjectiveParameters = new SCB_SubjectiveParameters
                {
                    DetailsId = detailID,

                    //PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank,
                    ExternalRating = subjectiveParametersEntity.ExternalRating,

                    IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                    BusinessModel = subjectiveParametersEntity.BusinessModel,
                    ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                    //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                    AdverseNews = subjectiveParametersEntity.AdverseNews,

                    CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                    AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                    AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                    NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                    //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                    NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                    LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                    CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                    NPASysGen = subjectiveParametersEntity.NPASysGen,
                    NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                    CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                    NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                    SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                    QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                    DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    if (subjectiveParameters != null && CheckIfAlreadyExists_SCBSubjectiveParameters(detailID) == false)
                    {
                        try
                        {
                            status = Add_SCBSubjectiveParameter(subjectiveParameters);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }
                    else
                    {
                        try
                        {
                            SCB_SubjectiveParameters scb_SubjectiveParameters_Update = dbContext.SCB_SubjectiveParameters.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (scb_SubjectiveParameters_Update != null)
                            {
                                scb_SubjectiveParameters_Update.PropensityToSupportBank = subjectiveParameters.PropensityToSupportBank;
                                scb_SubjectiveParameters_Update.IndustryRiskScore = subjectiveParameters.IndustryRiskScore;
                                scb_SubjectiveParameters_Update.BusinessModel = subjectiveParameters.BusinessModel;
                                scb_SubjectiveParameters_Update.ManagementQuality = subjectiveParameters.ManagementQuality;
                                scb_SubjectiveParameters_Update.UnderwritingStandards = subjectiveParameters.UnderwritingStandards;
                                scb_SubjectiveParameters_Update.AdverseNews = subjectiveParameters.AdverseNews;

                                scb_SubjectiveParameters_Update.CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility;
                                scb_SubjectiveParameters_Update.AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime;
                                scb_SubjectiveParameters_Update.AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems;
                                scb_SubjectiveParameters_Update.NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm;
                                //scb_SubjectiveParameters_Update.AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms;
                                scb_SubjectiveParameters_Update.NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm;
                                scb_SubjectiveParameters_Update.LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran;
                                scb_SubjectiveParameters_Update.CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData;
                                scb_SubjectiveParameters_Update.NPASysGen = subjectiveParametersEntity.NPASysGen;
                                scb_SubjectiveParameters_Update.NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting;
                                scb_SubjectiveParameters_Update.CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement;
                                scb_SubjectiveParameters_Update.NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess;
                                scb_SubjectiveParameters_Update.SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort;
                                scb_SubjectiveParameters_Update.QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor;
                                scb_SubjectiveParameters_Update.DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders;

                                scb_SubjectiveParameters_Update.CreatedBy = subjectiveParameters.CreatedBy;
                                scb_SubjectiveParameters_Update.CreatedDateTime = subjectiveParameters.CreatedDateTime;
                                scb_SubjectiveParameters_Update.UpdatedBy = subjectiveParameters.UpdatedBy;
                                scb_SubjectiveParameters_Update.UpdatedDateTime = subjectiveParameters.UpdatedDateTime;

                                dbContext.SaveChanges();
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return false;
                            }
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            return false;
                        }
                    }

                    status = Add_SCBSubjectiveParameter_Archive(subjectiveParameters_Archive);
                    dbContextTransaction.Commit();

                }
            }

            return true;

        }

        public bool Add_SCBSubjectiveParameter(SCB_SubjectiveParameters scb_SubjectiveParameters)
        {
            try
            {
                dbContext.SCB_SubjectiveParameters.Add(scb_SubjectiveParameters);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_SCBSubjectiveParameter_Archive(SCB_SubjectiveParameters_Archive scb_SubjectiveParameters_Archive)
        {
            try
            {
                dbContext.SCB_SubjectiveParameters_Archive.Add(scb_SubjectiveParameters_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_SCBIndustryExposure(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, SCB_IndustryExpsoureEntity scb_IndustryExpsoureEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                SCB_IndustryExpsoure_Archive scb_IndustryExpsoure_Archive = new SCB_IndustryExpsoure_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,

                    AgricultureAlliedActivities1 = scb_IndustryExpsoureEntity.AgricultureAlliedActivities1,
                    AgricultureAlliedActivitiesPer2 = scb_IndustryExpsoureEntity.AgricultureAlliedActivitiesPer2,
                    AgricultureAlliedActivities3 = scb_IndustryExpsoureEntity.AgricultureAlliedActivities3,
                    MinigQuaring1 = scb_IndustryExpsoureEntity.MinigQuaring1,
                    MinigQuaringPer2 = scb_IndustryExpsoureEntity.MinigQuaringPer2,
                    MinigQuaring3 = scb_IndustryExpsoureEntity.MinigQuaring3,
                    FoodFoodProcessing1 = scb_IndustryExpsoureEntity.FoodFoodProcessing1,
                    FoodFoodProcessingPer2 = scb_IndustryExpsoureEntity.FoodFoodProcessingPer2,
                    FoodFoodProcessing3 = scb_IndustryExpsoureEntity.FoodFoodProcessing3,
                    Textiles1 = scb_IndustryExpsoureEntity.Textiles1,
                    TextilesPer2 = scb_IndustryExpsoureEntity.TextilesPer2,
                    Textiles3 = scb_IndustryExpsoureEntity.Textiles3,
                    MaterialtheirProducts1 = scb_IndustryExpsoureEntity.MaterialtheirProducts1,
                    MaterialtheirProductsPer2 = scb_IndustryExpsoureEntity.MaterialtheirProductsPer2,
                    MaterialtheirProducts3 = scb_IndustryExpsoureEntity.MaterialtheirProducts3,
                    PetroleumCoalProductsNuclearFuels1 = scb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels1,
                    PetroleumCoalProductsNuclearFuelsPer2 = scb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuelsPer2,
                    PetroleumCoalProductsNuclearFuels3 = scb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels3,
                    ChemicalChemicalProducts1 = scb_IndustryExpsoureEntity.ChemicalChemicalProducts1,
                    ChemicalChemicalProductsPer2 = scb_IndustryExpsoureEntity.ChemicalChemicalProductsPer2,
                    ChemicalChemicalProducts3 = scb_IndustryExpsoureEntity.ChemicalChemicalProducts3,
                    CementCementProducts1 = scb_IndustryExpsoureEntity.CementCementProducts1,
                    CementCementProductsPer2 = scb_IndustryExpsoureEntity.CementCementProductsPer2,
                    CementCementProducts3 = scb_IndustryExpsoureEntity.CementCementProducts3,
                    BasicMetalMetalProduct1 = scb_IndustryExpsoureEntity.BasicMetalMetalProduct1,
                    BasicMetalMetalProductPer2 = scb_IndustryExpsoureEntity.BasicMetalMetalProductPer2,
                    BasicMetalMetalProduct3 = scb_IndustryExpsoureEntity.BasicMetalMetalProduct3,
                    AllEngineering1 = scb_IndustryExpsoureEntity.AllEngineering1,
                    AllEngineeringPer2 = scb_IndustryExpsoureEntity.AllEngineeringPer2,
                    AllEngineering3 = scb_IndustryExpsoureEntity.AllEngineering3,
                    AutomobileAncillary1 = scb_IndustryExpsoureEntity.AutomobileAncillary1,
                    AutomobileAncillaryPer2 = scb_IndustryExpsoureEntity.AutomobileAncillaryPer2,
                    AutomobileAncillary3 = scb_IndustryExpsoureEntity.AutomobileAncillary3,
                    GemsJewellery1 = scb_IndustryExpsoureEntity.GemsJewellery1,
                    GemsJewelleryPer2 = scb_IndustryExpsoureEntity.GemsJewelleryPer2,
                    GemsJewellery3 = scb_IndustryExpsoureEntity.GemsJewellery3,
                    Construction1 = scb_IndustryExpsoureEntity.Construction1,
                    ConstructionPer2 = scb_IndustryExpsoureEntity.ConstructionPer2,
                    Construction3 = scb_IndustryExpsoureEntity.Construction3,
                    Power1 = scb_IndustryExpsoureEntity.Power1,
                    PowerPer2 = scb_IndustryExpsoureEntity.PowerPer2,
                    Power3 = scb_IndustryExpsoureEntity.Power3,
                    Telecommunication1 = scb_IndustryExpsoureEntity.Telecommunication1,
                    TelecommunicationPer2 = scb_IndustryExpsoureEntity.TelecommunicationPer2,
                    Telecommunication3 = scb_IndustryExpsoureEntity.Telecommunication3,
                    RestoftheInfrastructure1 = scb_IndustryExpsoureEntity.RestoftheInfrastructure1,
                    RestoftheInfrastructurePer2 = scb_IndustryExpsoureEntity.RestoftheInfrastructurePer2,
                    RestoftheInfrastructure3 = scb_IndustryExpsoureEntity.RestoftheInfrastructure3,
                    NBFCs1 = scb_IndustryExpsoureEntity.NBFCs1,
                    NBFCsPer2 = scb_IndustryExpsoureEntity.NBFCsPer2,
                    NBFCs3 = scb_IndustryExpsoureEntity.NBFCs3,
                    OtherIndustries1 = scb_IndustryExpsoureEntity.OtherIndustries1,
                    OtherIndustriesPer2 = scb_IndustryExpsoureEntity.OtherIndustriesPer2,
                    OtherIndustries3 = scb_IndustryExpsoureEntity.OtherIndustries3,
                    Retail1 = scb_IndustryExpsoureEntity.Retail1,
                    RetailPer2 = scb_IndustryExpsoureEntity.RetailPer2,
                    Retail3 = scb_IndustryExpsoureEntity.Retail3,
                    ResidualAdvances1 = scb_IndustryExpsoureEntity.ResidualAdvances1,
                    ResidualAdvancesPer2 = scb_IndustryExpsoureEntity.ResidualAdvancesPer2,
                    ResidualAdvances3 = scb_IndustryExpsoureEntity.ResidualAdvances3,
                    TotalAdvances = scb_IndustryExpsoureEntity.TotalAdvances,


                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                SCB_IndustryExpsoure scb_IndustryExpsoure = new SCB_IndustryExpsoure
                {
                    DetailsId = detailID,
                    AgricultureAlliedActivities1 = scb_IndustryExpsoureEntity.AgricultureAlliedActivities1,
                    AgricultureAlliedActivitiesPer2 = scb_IndustryExpsoureEntity.AgricultureAlliedActivitiesPer2,
                    AgricultureAlliedActivities3 = scb_IndustryExpsoureEntity.AgricultureAlliedActivities3,
                    MinigQuaring1 = scb_IndustryExpsoureEntity.MinigQuaring1,
                    MinigQuaringPer2 = scb_IndustryExpsoureEntity.MinigQuaringPer2,
                    MinigQuaring3 = scb_IndustryExpsoureEntity.MinigQuaring3,
                    FoodFoodProcessing1 = scb_IndustryExpsoureEntity.FoodFoodProcessing1,
                    FoodFoodProcessingPer2 = scb_IndustryExpsoureEntity.FoodFoodProcessingPer2,
                    FoodFoodProcessing3 = scb_IndustryExpsoureEntity.FoodFoodProcessing3,
                    Textiles1 = scb_IndustryExpsoureEntity.Textiles1,
                    TextilesPer2 = scb_IndustryExpsoureEntity.TextilesPer2,
                    Textiles3 = scb_IndustryExpsoureEntity.Textiles3,
                    MaterialtheirProducts1 = scb_IndustryExpsoureEntity.MaterialtheirProducts1,
                    MaterialtheirProductsPer2 = scb_IndustryExpsoureEntity.MaterialtheirProductsPer2,
                    MaterialtheirProducts3 = scb_IndustryExpsoureEntity.MaterialtheirProducts3,
                    PetroleumCoalProductsNuclearFuels1 = scb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels1,
                    PetroleumCoalProductsNuclearFuelsPer2 = scb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuelsPer2,
                    PetroleumCoalProductsNuclearFuels3 = scb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels3,
                    ChemicalChemicalProducts1 = scb_IndustryExpsoureEntity.ChemicalChemicalProducts1,
                    ChemicalChemicalProductsPer2 = scb_IndustryExpsoureEntity.ChemicalChemicalProductsPer2,
                    ChemicalChemicalProducts3 = scb_IndustryExpsoureEntity.ChemicalChemicalProducts3,
                    CementCementProducts1 = scb_IndustryExpsoureEntity.CementCementProducts1,
                    CementCementProductsPer2 = scb_IndustryExpsoureEntity.CementCementProductsPer2,
                    CementCementProducts3 = scb_IndustryExpsoureEntity.CementCementProducts3,
                    BasicMetalMetalProduct1 = scb_IndustryExpsoureEntity.BasicMetalMetalProduct1,
                    BasicMetalMetalProductPer2 = scb_IndustryExpsoureEntity.BasicMetalMetalProductPer2,
                    BasicMetalMetalProduct3 = scb_IndustryExpsoureEntity.BasicMetalMetalProduct3,
                    AllEngineering1 = scb_IndustryExpsoureEntity.AllEngineering1,
                    AllEngineeringPer2 = scb_IndustryExpsoureEntity.AllEngineeringPer2,
                    AllEngineering3 = scb_IndustryExpsoureEntity.AllEngineering3,
                    AutomobileAncillary1 = scb_IndustryExpsoureEntity.AutomobileAncillary1,
                    AutomobileAncillaryPer2 = scb_IndustryExpsoureEntity.AutomobileAncillaryPer2,
                    AutomobileAncillary3 = scb_IndustryExpsoureEntity.AutomobileAncillary3,
                    GemsJewellery1 = scb_IndustryExpsoureEntity.GemsJewellery1,
                    GemsJewelleryPer2 = scb_IndustryExpsoureEntity.GemsJewelleryPer2,
                    GemsJewellery3 = scb_IndustryExpsoureEntity.GemsJewellery3,
                    Construction1 = scb_IndustryExpsoureEntity.Construction1,
                    ConstructionPer2 = scb_IndustryExpsoureEntity.ConstructionPer2,
                    Construction3 = scb_IndustryExpsoureEntity.Construction3,
                    Power1 = scb_IndustryExpsoureEntity.Power1,
                    PowerPer2 = scb_IndustryExpsoureEntity.PowerPer2,
                    Power3 = scb_IndustryExpsoureEntity.Power3,
                    Telecommunication1 = scb_IndustryExpsoureEntity.Telecommunication1,
                    TelecommunicationPer2 = scb_IndustryExpsoureEntity.TelecommunicationPer2,
                    Telecommunication3 = scb_IndustryExpsoureEntity.Telecommunication3,
                    RestoftheInfrastructure1 = scb_IndustryExpsoureEntity.RestoftheInfrastructure1,
                    RestoftheInfrastructurePer2 = scb_IndustryExpsoureEntity.RestoftheInfrastructurePer2,
                    RestoftheInfrastructure3 = scb_IndustryExpsoureEntity.RestoftheInfrastructure3,
                    NBFCs1 = scb_IndustryExpsoureEntity.NBFCs1,
                    NBFCsPer2 = scb_IndustryExpsoureEntity.NBFCsPer2,
                    NBFCs3 = scb_IndustryExpsoureEntity.NBFCs3,
                    OtherIndustries1 = scb_IndustryExpsoureEntity.OtherIndustries1,
                    OtherIndustriesPer2 = scb_IndustryExpsoureEntity.OtherIndustriesPer2,
                    OtherIndustries3 = scb_IndustryExpsoureEntity.OtherIndustries3,
                    Retail1 = scb_IndustryExpsoureEntity.Retail1,
                    RetailPer2 = scb_IndustryExpsoureEntity.RetailPer2,
                    Retail3 = scb_IndustryExpsoureEntity.Retail3,
                    ResidualAdvances1 = scb_IndustryExpsoureEntity.ResidualAdvances1,
                    ResidualAdvancesPer2 = scb_IndustryExpsoureEntity.ResidualAdvancesPer2,
                    ResidualAdvances3 = scb_IndustryExpsoureEntity.ResidualAdvances3,
                    TotalAdvances = scb_IndustryExpsoureEntity.TotalAdvances,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    if (scb_IndustryExpsoure != null && CheckIfAlreadyExists_SCBIndustryExpsoure(detailID) == false)
                    {
                        try
                        {
                            status = Add_SCBIndustryExpsoure(scb_IndustryExpsoure);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    else
                    {
                        try
                        {
                            SCB_IndustryExpsoure update = dbContext.SCB_IndustryExpsoure.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (update != null)
                            {
                                update.AgricultureAlliedActivities1 = scb_IndustryExpsoure.AgricultureAlliedActivities1;
                                update.AgricultureAlliedActivitiesPer2 = scb_IndustryExpsoure.AgricultureAlliedActivitiesPer2;
                                update.AgricultureAlliedActivities3 = scb_IndustryExpsoure.AgricultureAlliedActivities3;
                                update.MinigQuaring1 = scb_IndustryExpsoure.MinigQuaring1;
                                update.MinigQuaringPer2 = scb_IndustryExpsoure.MinigQuaringPer2;
                                update.MinigQuaring3 = scb_IndustryExpsoure.MinigQuaring3;
                                update.FoodFoodProcessing1 = scb_IndustryExpsoure.FoodFoodProcessing1;
                                update.FoodFoodProcessingPer2 = scb_IndustryExpsoure.FoodFoodProcessingPer2;
                                update.FoodFoodProcessing3 = scb_IndustryExpsoure.FoodFoodProcessing3;
                                update.Textiles1 = scb_IndustryExpsoure.Textiles1;
                                update.TextilesPer2 = scb_IndustryExpsoure.TextilesPer2;
                                update.Textiles3 = scb_IndustryExpsoure.Textiles3;
                                update.MaterialtheirProducts1 = scb_IndustryExpsoure.MaterialtheirProducts1;
                                update.MaterialtheirProductsPer2 = scb_IndustryExpsoure.MaterialtheirProductsPer2;
                                update.MaterialtheirProducts3 = scb_IndustryExpsoure.MaterialtheirProducts3;
                                update.PetroleumCoalProductsNuclearFuels1 = scb_IndustryExpsoure.PetroleumCoalProductsNuclearFuels1;
                                update.PetroleumCoalProductsNuclearFuelsPer2 = scb_IndustryExpsoure.PetroleumCoalProductsNuclearFuelsPer2;
                                update.PetroleumCoalProductsNuclearFuels3 = scb_IndustryExpsoure.PetroleumCoalProductsNuclearFuels3;
                                update.ChemicalChemicalProducts1 = scb_IndustryExpsoure.ChemicalChemicalProducts1;
                                update.ChemicalChemicalProductsPer2 = scb_IndustryExpsoure.ChemicalChemicalProductsPer2;
                                update.ChemicalChemicalProducts3 = scb_IndustryExpsoure.ChemicalChemicalProducts3;
                                update.CementCementProducts1 = scb_IndustryExpsoure.CementCementProducts1;
                                update.CementCementProductsPer2 = scb_IndustryExpsoure.CementCementProductsPer2;
                                update.CementCementProducts3 = scb_IndustryExpsoure.CementCementProducts3;
                                update.BasicMetalMetalProduct1 = scb_IndustryExpsoure.BasicMetalMetalProduct1;
                                update.BasicMetalMetalProductPer2 = scb_IndustryExpsoure.BasicMetalMetalProductPer2;
                                update.BasicMetalMetalProduct3 = scb_IndustryExpsoure.BasicMetalMetalProduct3;
                                update.AllEngineering1 = scb_IndustryExpsoure.AllEngineering1;
                                update.AllEngineeringPer2 = scb_IndustryExpsoure.AllEngineeringPer2;
                                update.AllEngineering3 = scb_IndustryExpsoure.AllEngineering3;
                                update.AutomobileAncillary1 = scb_IndustryExpsoure.AutomobileAncillary1;
                                update.AutomobileAncillaryPer2 = scb_IndustryExpsoure.AutomobileAncillaryPer2;
                                update.AutomobileAncillary3 = scb_IndustryExpsoure.AutomobileAncillary3;
                                update.GemsJewellery1 = scb_IndustryExpsoure.GemsJewellery1;
                                update.GemsJewelleryPer2 = scb_IndustryExpsoure.GemsJewelleryPer2;
                                update.GemsJewellery3 = scb_IndustryExpsoure.GemsJewellery3;
                                update.Construction1 = scb_IndustryExpsoure.Construction1;
                                update.ConstructionPer2 = scb_IndustryExpsoure.ConstructionPer2;
                                update.Construction3 = scb_IndustryExpsoure.Construction3;
                                update.Power1 = scb_IndustryExpsoure.Power1;
                                update.PowerPer2 = scb_IndustryExpsoure.PowerPer2;
                                update.Power3 = scb_IndustryExpsoure.Power3;
                                update.Telecommunication1 = scb_IndustryExpsoure.Telecommunication1;
                                update.TelecommunicationPer2 = scb_IndustryExpsoure.TelecommunicationPer2;
                                update.Telecommunication3 = scb_IndustryExpsoure.Telecommunication3;
                                update.RestoftheInfrastructure1 = scb_IndustryExpsoure.RestoftheInfrastructure1;
                                update.RestoftheInfrastructurePer2 = scb_IndustryExpsoure.RestoftheInfrastructurePer2;
                                update.RestoftheInfrastructure3 = scb_IndustryExpsoure.RestoftheInfrastructure3;
                                update.NBFCs1 = scb_IndustryExpsoure.NBFCs1;
                                update.NBFCsPer2 = scb_IndustryExpsoure.NBFCsPer2;
                                update.NBFCs3 = scb_IndustryExpsoure.NBFCs3;
                                update.OtherIndustries1 = scb_IndustryExpsoure.OtherIndustries1;
                                update.OtherIndustriesPer2 = scb_IndustryExpsoure.OtherIndustriesPer2;
                                update.OtherIndustries3 = scb_IndustryExpsoure.OtherIndustries3;
                                update.Retail1 = scb_IndustryExpsoure.Retail1;
                                update.RetailPer2 = scb_IndustryExpsoure.RetailPer2;
                                update.Retail3 = scb_IndustryExpsoure.Retail3;
                                update.ResidualAdvances1 = scb_IndustryExpsoure.ResidualAdvances1;
                                update.ResidualAdvancesPer2 = scb_IndustryExpsoure.ResidualAdvancesPer2;
                                update.ResidualAdvances3 = scb_IndustryExpsoure.ResidualAdvances3;
                                update.TotalAdvances = scb_IndustryExpsoure.TotalAdvances;


                                update.CreatedBy = scb_IndustryExpsoure.CreatedBy;
                                update.CreatedDateTime = scb_IndustryExpsoure.CreatedDateTime;
                                update.UpdatedBy = scb_IndustryExpsoure.UpdatedBy;
                                update.UpdatedDateTime = scb_IndustryExpsoure.UpdatedDateTime;

                                dbContext.SaveChanges();
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return false;
                            }
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            return false;
                        }
                    }

                    status = Add_SCBIndustryExpsoure_Archive(scb_IndustryExpsoure_Archive);
                    dbContextTransaction.Commit();

                }
            }

            return true;

        }

        public bool Add_SCBIndustryExpsoure(SCB_IndustryExpsoure scb_IndustryExpsoure)
        {
            try
            {
                dbContext.SCB_IndustryExpsoure.Add(scb_IndustryExpsoure);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_SCBIndustryExpsoure_Archive(SCB_IndustryExpsoure_Archive scb_IndustryExpsoure_Archive)
        {
            try
            {
                dbContext.SCB_IndustryExpsoure_Archive.Add(scb_IndustryExpsoure_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        #region - Output
        public bool SaveAsDraft_OutputDetails(int userId, int roleId, int detailID, short logID, int detail_ArchiveID, DateTime CreatedDateTime, List<SCB_OutputDetailsEntity> outputDetailsEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                if (outputDetailsEntity != null && userId != 0)
                {
                    List<SCB_Output_Details> output_Details = new List<SCB_Output_Details>();
                    List<SCB_Output_Details_Archive> output_Details_Archive = new List<SCB_Output_Details_Archive>();

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details.Add(new SCB_Output_Details
                        {
                            DetailsId = detailID,
                            TemplateId = values.TemplateID,
                            Parameter_Per = values.Parameter3Per,
                            Parameter_Name = string.IsNullOrEmpty(values.Parameter3) ? values.Parameter1 : values.Parameter3,
                            UnderBaselIII_Score = values.UnderBaselIII_Score,
                            UnderBaselIII_Value = values.UnderBaselIII_Value,
                            UnderIND_Score = values.UnderIND_Score,
                            UnderIND_Value = values.UnderIND_Value,
                            Comments = values.Comments,
                            CreatedDateTime = CreatedDateTime,
                        });
                    };

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details_Archive.Add(new SCB_Output_Details_Archive
                        {
                            DetailsId = detailID,
                            LogId = logID,

                            Details_ArchiveId = detail_ArchiveID,
                            UserId = userId,
                            TemplateId = values.TemplateID,
                            Parameter_Per = values.Parameter3Per,
                            Parameter_Name = string.IsNullOrEmpty(values.Parameter3) ? values.Parameter1 : values.Parameter3,
                            UnderBaselIII_Score = values.UnderBaselIII_Score,
                            UnderBaselIII_Value = values.UnderBaselIII_Value,
                            UnderIND_Score = values.UnderIND_Score,
                            UnderIND_Value = values.UnderIND_Value,
                            Comments = values.Comments,
                            CreatedBy = values.CreatedBy,
                            UpdatedBy = values.UpdatedBy,

                            CreatedDateTime = CreatedDateTime,
                            UpdatedDateTime = DateTime.Now,
                        });
                    };

                    if (output_Details != null)
                    {
                        if (CheckIfAlreadyExists_OutputDetails(detailID) == true)
                        {
                            Delete_OutputDetails(detailID);
                        }
                        status = Add_OutputDetails(output_Details);
                        status = Add_OutputDetails_Archive(output_Details_Archive);
                        dbContextTransaction.Commit();
                        status = true;
                    }
                }
            }

            return status;

        }

        public bool Delete_OutputDetails(int detailsID)
        {
            try
            {
                dbContext.SCB_Output_Details.RemoveRange(dbContext.SCB_Output_Details.Where(c => c.DetailsId == detailsID));
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_OutputDetails(List<SCB_Output_Details> output_Details)
        {
            try
            {
                dbContext.SCB_Output_Details.AddRange(output_Details);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_OutputDetails_Archive(List<SCB_Output_Details_Archive> output_Details_Archive)
        {
            try
            {
                dbContext.SCB_Output_Details_Archive.AddRange(output_Details_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Get_OutputDetails_OpenXML(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            // Open the document for editing.
            using (DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadSheet = DocumentFormat.OpenXml.Packaging.SpreadsheetDocument.Open(OutputTemplateFilePath, true))
            {
                // Access the main Workbook part, which contains all references.
                DocumentFormat.OpenXml.Packaging.WorkbookPart workbookPart = spreadSheet.WorkbookPart;
                // get sheet by name
                DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbookPart.Workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == "Output NHB").FirstOrDefault();

                // get worksheetpart by sheet id
                DocumentFormat.OpenXml.Packaging.WorksheetPart worksheetPart = workbookPart.GetPartById(sheet.Id.Value) as DocumentFormat.OpenXml.Packaging.WorksheetPart;
                CompanyDAL companyDAL = new CompanyDAL();
                string companyName = companyDAL.GetCompanyNameByID(companyId);

                // The SheetData object will contain all the data.
                int? detailArchivedID = (from output in dbContext.SCB_Output_Details_Archive
                                         join basicDetails in dbContext.NHB_Details_Archive on output.Details_ArchiveId equals basicDetails.Details_ArchiveId
                                         where basicDetails.CompanyId == companyId
                                         && DbFunctions.TruncateTime(output.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime)
                                         select output.Details_ArchiveId).OrderByDescending(data => data).FirstOrDefault();

                //    RRB_Output_Details_Archive data = dbContext.RRB_Output_Details_Archive.Where(detail => detail.CompanyId == companyId
                //&& issuerinfo.PRDate == null).OrderByDescending(data => data.Details_ArchiveId).FirstOrDefault();

                if (detailArchivedID.HasValue)
                {
                    List<SCB_OutputDetailsEntity> getOutputDetails = dbContext.SCB_Output_Details_Archive
                       .Where(riskOutputs => riskOutputs.Details_ArchiveId == detailArchivedID.Value
                       )
                       .Select(Outputs => new SCB_OutputDetailsEntity
                       {
                           Parameter3 = Outputs.Parameter_Name,
                           UnderIND_Score = Outputs.UnderIND_Score,
                           UnderIND_Value = Outputs.UnderIND_Value,
                           UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                           UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
                       }).ToList();

                    uint rowNo = 0;
                    Cell cell = GetCell(worksheetPart.Worksheet, "G", 2);
                    cell.CellValue = new CellValue(companyName);
                    rowNo = 3;
                    for (int i = 0; i < getOutputDetails.Count; i++)
                    {
                        cell = GetCell(worksheetPart.Worksheet, "J", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Score);
                        cell = GetCell(worksheetPart.Worksheet, "K", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Value);
                        cell = GetCell(worksheetPart.Worksheet, "M", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Score);
                        cell = GetCell(worksheetPart.Worksheet, "N", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Value);
                        rowNo++;
                    }
                    // Save the worksheet.
                    worksheetPart.Worksheet.Save();

                    // for recacluation of formula
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;
                }
            }
            return true;
        }

        private Cell GetCell(Worksheet worksheet, string columnName, uint rowIndex)
        {
            Row row = GetRow(worksheet, rowIndex);

            if (row == null) return null;

            var FirstRow = row.Elements<Cell>().Where(c => string.Compare
            (c.CellReference.Value, columnName +
            rowIndex, true) == 0).FirstOrDefault();

            if (FirstRow == null) return null;

            return FirstRow;
        }

        private Row GetRow(Worksheet worksheet, uint rowIndex)
        {
            Row row = worksheet.GetFirstChild<SheetData>().
            Elements<Row>().FirstOrDefault(r => r.RowIndex == rowIndex);
            if (row == null)
            {
                throw new ArgumentException(String.Format("No row with index {0} found in spreadsheet", rowIndex));
            }
            return row;
        }

        public bool Delete_SCBOutputDetails(List<SCB_Output_Details> scb_Output_Details)
        {
            try
            {
                dbContext.SCB_Output_Details.RemoveRange(dbContext.SCB_Output_Details.Where(c => c.DetailsId == scb_Output_Details[0].DetailsId));
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }

                throw;
            }
        }

        #endregion


        public bool CheckIfAlreadyExists_SCBKeyFinancial(int detailsId)
        {
            return dbContext.SCB_KeyFinancials.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_SCBSubjectiveParameters(int detailsId)
        {
            return dbContext.SCB_SubjectiveParameters.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_SCBIndustryExpsoure(int detailsId)
        {
            return dbContext.SCB_IndustryExpsoure.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_OutputDetails(int detailsId)
        {
            return dbContext.SCB_Output_Details.Any(asset => asset.DetailsId == detailsId);
        }

        public List<SubjectiveParametersEntity> GetSubjectiveParametersList(int ModelId)
        {
            List<SubjectiveParametersEntity> objList = null;

            var result = (from T0 in dbContext.SubjectiveParameters_Headers_Definition_Map_Models
                          join T1 in dbContext.SubjectiveParameters_Headers_Map_Models
                          on T0.HeaderMapModelId equals T1.HeaderMapModelId
                          join T2 in dbContext.SubjectiveParameters_Headers_Master
                          on T1.HeaderId equals T2.HeaderId
                          join T3 in dbContext.Models
                          on T1.ModelId equals T3.ModelId
                          where T3.ModelId == ModelId
                          orderby T0.Value descending
                          select new SubjectiveParametersEntity
                          {
                              HeaderId = T0.HeaderDefinitionId,
                              HeaderName = T2.HeaderName,
                              Definitions = T0.Definitions,
                              value = T0.Value
                          });

            objList = result.ToList();

            return objList;
        }

        public bool ComputeOutputDetails(SCB_BasicDetailsEntity riskModelExcelEntity, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            //Get the already exists sheet
            //mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(2);
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Input Sheet"];

            string value = "";
            uint rowIndex = 0;
            int columnIndex = 0;

            string columnName = "";
            object obj;

            // Basic detail fields update - Company Name
            try
            {
                string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);

                rowIndex = _helperDAL.GetExcelRowIndex("B4");
                columnName = _helperDAL.GetExcelColumnName("B4");
                columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                mWSheet.Cells[rowIndex, columnIndex] = companyName;
            }
            catch { }


            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
            properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = riskModelExcelEntity.GetType().GetProperty(property.Name).GetValue(riskModelExcelEntity, null);
                        value = obj.ToString();

                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            try
                            {
                                value = Convert.ToString(double.Parse(value) / 100);
                                //value = (value == string.Empty || value.ToUpper().Trim() == "NA") ? "0" : Convert.ToString(double.Parse(value) / 100);
                            }
                            catch
                            {

                            }
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.SCB_KeyFinancialsEntity);
            SCB_KeyFinancialsEntity getKeyFinancialsEntity = riskModelExcelEntity.SCB_KeyFinancialsEntity;
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getKeyFinancialsEntity.GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity, null);
                        value = obj.ToString();
                        var type = getKeyFinancialsEntity.GetType().GetProperty(property.Name).ToString();
                        if (type.ToLower().Contains("system.datetime"))
                        {
                            try
                            {
                                DateTime dt = Convert.ToDateTime(value.ToString());
                                mWSheet.Cells[rowIndex, columnIndex] = dt.ToString("dd-MMM-yyyy");
                            }
                            catch { }
                        }
                        else
                        {
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per")
                                   || property.Name.Contains("ProvisioningCoverageRatio"))
                            {
                                try
                                {
                                    value = Convert.ToString(double.Parse(value) / 100);
                                }
                                catch
                                {

                                }
                                //value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                    }
                    catch { }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.SCB_SubjectiveParametersEntity);
            SCB_SubjectiveParametersEntity getSubjectiveParametersEntity = riskModelExcelEntity.SCB_SubjectiveParametersEntity;

            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getSubjectiveParametersEntity.GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity, null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            try
                            {
                                value = Convert.ToString(double.Parse(value) / 100);
                            }
                            catch
                            {

                            }
                            //value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            properties = TypeDescriptor.GetProperties(riskModelExcelEntity.SCB_IndustryExpsoureEntity);
            SCB_IndustryExpsoureEntity getIndustryExpsoureEntity = riskModelExcelEntity.SCB_IndustryExpsoureEntity;

            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getIndustryExpsoureEntity.GetType().GetProperty(property.Name).GetValue(getIndustryExpsoureEntity, null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();

            return true;
        }

        public bool Get_OutputDetailsFromFrontEnd_InterOp(int detailsID, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Key Financials List

            List<SCB_KeyFinancialsEntity> getKeyFinancialsEntity = dbContext.SCB_KeyFinancials
              .Where(a => a.DetailsId == detailsID
              )
              .Select(keyFinancialsEntity => new SCB_KeyFinancialsEntity
              {
                  PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                  PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                  NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                  NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                  Currency1 = keyFinancialsEntity.Currency1,
                  Currency2 = keyFinancialsEntity.Currency2,
                  NetWorth1 = keyFinancialsEntity.NetWorth1,
                  NetWorth2 = keyFinancialsEntity.NetWorth2,
                  TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                  TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                  CreditDepositRatioPer1 = keyFinancialsEntity.CreditDepositRatioPer1,
                  CreditDepositRatioPer2 = keyFinancialsEntity.CreditDepositRatioPer2,
                  ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                  ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                  CASAPer1 = keyFinancialsEntity.CASAPer1,
                  CASAPer2 = keyFinancialsEntity.CASAPer2,
                  PrioritySectorAdvancesPer1 = keyFinancialsEntity.PrioritySectorAdvancesPer1,
                  PrioritySectorAdvancesPer2 = keyFinancialsEntity.PrioritySectorAdvancesPer2,
                  ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                  ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                  CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1,
                  CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2,
                  CRARPer1 = keyFinancialsEntity.CRARPer1,
                  CRARPer2 = keyFinancialsEntity.CRARPer2,
                  Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                  Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                  CommonEquityTierPer1 = keyFinancialsEntity.CommonEquityTierPer1,
                  CommonEquityTierPer2 = keyFinancialsEntity.CommonEquityTierPer2,
                  NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                  NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                  GrowthinDepositsPer1 = keyFinancialsEntity.GrowthinDepositsPer1,
                  GrowthinDepositsPer2 = keyFinancialsEntity.GrowthinDepositsPer2,
                  TotalNumBranches1 = keyFinancialsEntity.TotalNumBranches1,
                  TotalNumBranches2 = keyFinancialsEntity.TotalNumBranches2,

                  GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                  GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                  AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                  AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                  DiversityofIncomePer1 = keyFinancialsEntity.DiversityofIncomePer1,
                  DiversityofIncomePer2 = keyFinancialsEntity.DiversityofIncomePer2,
                  TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                  TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                  TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                  TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                  AdvancesToSensitiveSectorPer1 = keyFinancialsEntity.AdvancesToSensitiveSectorPer1,
                  AdvancesToSensitiveSectorPer2 = keyFinancialsEntity.AdvancesToSensitiveSectorPer2,
                  CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                  CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                  CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                  CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                  PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                  PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                  //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                  //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                  LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                  LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                  Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                  Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                  GearingPer1 = keyFinancialsEntity.GearingPer1,
                  GearingPer2 = keyFinancialsEntity.GearingPer2,
                  NetStableFundingRatioPer1 = keyFinancialsEntity.NetStableFundingRatioPer1,
                  NetStableFundingRatioPer2 = keyFinancialsEntity.NetStableFundingRatioPer2,
                  LeverageRatioPer1 = keyFinancialsEntity.LeverageRatio1,
                  LeverageRatioPer2 = keyFinancialsEntity.LeverageRatio2,
              }).ToList();

            #endregion

            #region Subjective Parameters List

            List<SCB_SubjectiveParametersEntity> getSubjectiveParametersEntity = dbContext.SCB_SubjectiveParameters
              .Where(a => a.DetailsId == detailsID
              )
              .Select(subjectiveParametersEntity => new SCB_SubjectiveParametersEntity
              {
                  //PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank,
                  ExternalRating = subjectiveParametersEntity.ExternalRating,
                  IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                  BusinessModel = subjectiveParametersEntity.BusinessModel,
                  ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                  //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                  AdverseNews = subjectiveParametersEntity.AdverseNews,

                  CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                  AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                  AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                  NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                  //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                  NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                  LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                  CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                  NPASysGen = subjectiveParametersEntity.NPASysGen,
                  NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                  CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                  NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                  SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                  QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                  DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders

              }).ToList();

            #endregion

            #region Industry Exposure List

            List<SCB_IndustryExpsoureEntity> getIndustryExpsoureEntity = dbContext.SCB_IndustryExpsoure
              .Where(a => a.DetailsId == detailsID
              )
              .Select(industryExpsoureEntity => new SCB_IndustryExpsoureEntity
              {
                  AgricultureAlliedActivities1 = industryExpsoureEntity.AgricultureAlliedActivities1,
                  AgricultureAlliedActivitiesPer2 = industryExpsoureEntity.AgricultureAlliedActivitiesPer2,
                  AgricultureAlliedActivities3 = industryExpsoureEntity.AgricultureAlliedActivities3,
                  MinigQuaring1 = industryExpsoureEntity.MinigQuaring1,
                  MinigQuaringPer2 = industryExpsoureEntity.MinigQuaringPer2,
                  MinigQuaring3 = industryExpsoureEntity.MinigQuaring3,
                  FoodFoodProcessing1 = industryExpsoureEntity.FoodFoodProcessing1,
                  FoodFoodProcessingPer2 = industryExpsoureEntity.FoodFoodProcessingPer2,
                  FoodFoodProcessing3 = industryExpsoureEntity.FoodFoodProcessing3,
                  Textiles1 = industryExpsoureEntity.Textiles1,
                  TextilesPer2 = industryExpsoureEntity.TextilesPer2,
                  Textiles3 = industryExpsoureEntity.Textiles3,
                  MaterialtheirProducts1 = industryExpsoureEntity.MaterialtheirProducts1,
                  MaterialtheirProductsPer2 = industryExpsoureEntity.MaterialtheirProductsPer2,
                  MaterialtheirProducts3 = industryExpsoureEntity.MaterialtheirProducts3,
                  PetroleumCoalProductsNuclearFuels1 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuels1,
                  PetroleumCoalProductsNuclearFuelsPer2 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuelsPer2,
                  PetroleumCoalProductsNuclearFuels3 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuels3,
                  ChemicalChemicalProducts1 = industryExpsoureEntity.ChemicalChemicalProducts1,
                  ChemicalChemicalProductsPer2 = industryExpsoureEntity.ChemicalChemicalProductsPer2,
                  ChemicalChemicalProducts3 = industryExpsoureEntity.ChemicalChemicalProducts3,
                  CementCementProducts1 = industryExpsoureEntity.CementCementProducts1,
                  CementCementProductsPer2 = industryExpsoureEntity.CementCementProductsPer2,
                  CementCementProducts3 = industryExpsoureEntity.CementCementProducts3,
                  BasicMetalMetalProduct1 = industryExpsoureEntity.BasicMetalMetalProduct1,
                  BasicMetalMetalProductPer2 = industryExpsoureEntity.BasicMetalMetalProductPer2,
                  BasicMetalMetalProduct3 = industryExpsoureEntity.BasicMetalMetalProduct3,
                  AllEngineering1 = industryExpsoureEntity.AllEngineering1,
                  AllEngineeringPer2 = industryExpsoureEntity.AllEngineeringPer2,
                  AllEngineering3 = industryExpsoureEntity.AllEngineering3,
                  AutomobileAncillary1 = industryExpsoureEntity.AutomobileAncillary1,
                  AutomobileAncillaryPer2 = industryExpsoureEntity.AutomobileAncillaryPer2,
                  AutomobileAncillary3 = industryExpsoureEntity.AutomobileAncillary3,
                  GemsJewellery1 = industryExpsoureEntity.GemsJewellery1,
                  GemsJewelleryPer2 = industryExpsoureEntity.GemsJewelleryPer2,
                  GemsJewellery3 = industryExpsoureEntity.GemsJewellery3,
                  Construction1 = industryExpsoureEntity.Construction1,
                  ConstructionPer2 = industryExpsoureEntity.ConstructionPer2,
                  Construction3 = industryExpsoureEntity.Construction3,
                  Power1 = industryExpsoureEntity.Power1,
                  PowerPer2 = industryExpsoureEntity.PowerPer2,
                  Power3 = industryExpsoureEntity.Power3,
                  Telecommunication1 = industryExpsoureEntity.Telecommunication1,
                  TelecommunicationPer2 = industryExpsoureEntity.TelecommunicationPer2,
                  Telecommunication3 = industryExpsoureEntity.Telecommunication3,
                  RestoftheInfrastructure1 = industryExpsoureEntity.RestoftheInfrastructure1,
                  RestoftheInfrastructurePer2 = industryExpsoureEntity.RestoftheInfrastructurePer2,
                  RestoftheInfrastructure3 = industryExpsoureEntity.RestoftheInfrastructure3,
                  NBFCs1 = industryExpsoureEntity.NBFCs1,
                  NBFCsPer2 = industryExpsoureEntity.NBFCsPer2,
                  NBFCs3 = industryExpsoureEntity.NBFCs3,
                  OtherIndustries1 = industryExpsoureEntity.OtherIndustries1,
                  OtherIndustriesPer2 = industryExpsoureEntity.OtherIndustriesPer2,
                  OtherIndustries3 = industryExpsoureEntity.OtherIndustries3,
                  Retail1 = industryExpsoureEntity.Retail1,
                  RetailPer2 = industryExpsoureEntity.RetailPer2,
                  Retail3 = industryExpsoureEntity.Retail3,
                  ResidualAdvances1 = industryExpsoureEntity.ResidualAdvances1,
                  ResidualAdvancesPer2 = industryExpsoureEntity.ResidualAdvancesPer2,
                  ResidualAdvances3 = industryExpsoureEntity.ResidualAdvances3,
                  TotalAdvances = industryExpsoureEntity.TotalAdvances
              }).ToList();

            #endregion

            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            //Get the already exists sheet
            //mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(2);
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Input Sheet"];

            string value = "";
            uint rowIndex = 0;
            int columnIndex = 0;

            string columnName = "";
            object obj;
            //mWSheet.Cells[11, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate1_Liabilities;

            SCB_KeyFinancialsEntity scb_KeyFinancialsEntity = new SCB_KeyFinancialsEntity();
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(scb_KeyFinancialsEntity);
            properties = TypeDescriptor.GetProperties(scb_KeyFinancialsEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getKeyFinancialsEntity[0].GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            SCB_SubjectiveParametersEntity scb_SubjectiveParametersEntity = new SCB_SubjectiveParametersEntity();
            properties = TypeDescriptor.GetProperties(scb_SubjectiveParametersEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getSubjectiveParametersEntity[0].GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            SCB_IndustryExpsoureEntity scb_IndustryExpsoureEntity = new SCB_IndustryExpsoureEntity();
            properties = TypeDescriptor.GetProperties(scb_IndustryExpsoureEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getIndustryExpsoureEntity[0].GetType().GetProperty(property.Name).GetValue(getIndustryExpsoureEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();

            return true;
        }

        public bool Get_OutputDetails_OpenXML_DetailsId(int detailsId, string companyName, string OutputTemplateFilePath)
        {
            // Open the document for editing.
            using (DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadSheet = DocumentFormat.OpenXml.Packaging.SpreadsheetDocument.Open(OutputTemplateFilePath, true))
            {
                // Access the main Workbook part, which contains all references.
                DocumentFormat.OpenXml.Packaging.WorkbookPart workbookPart = spreadSheet.WorkbookPart;
                // get sheet by name
                DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbookPart.Workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == "Output NHB").FirstOrDefault();

                // get worksheetpart by sheet id
                DocumentFormat.OpenXml.Packaging.WorksheetPart worksheetPart = workbookPart.GetPartById(sheet.Id.Value) as DocumentFormat.OpenXml.Packaging.WorksheetPart;
                List<SCB_OutputDetailsEntity> getOutputDetails = dbContext.SCB_Output_Details
                  .Where(riskOutputs => riskOutputs.DetailsId == detailsId
                  )
                  .Select(Outputs => new SCB_OutputDetailsEntity
                  {
                      Parameter3 = Outputs.Parameter_Name,

                      UnderIND_Score = Outputs.UnderIND_Score,
                      UnderIND_Value = Outputs.UnderIND_Value,
                      UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                      UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
                  }).ToList();

                uint rowNo = 3;
                Cell cell = GetCell(worksheetPart.Worksheet, "G", 2);
                cell.CellValue = new CellValue(companyName);

                for (int i = 0; i < getOutputDetails.Count; i++)
                {
                    cell = GetCell(worksheetPart.Worksheet, "J", rowNo);
                    cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Value);
                    cell = GetCell(worksheetPart.Worksheet, "K", rowNo);
                    cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Score);
                    cell = GetCell(worksheetPart.Worksheet, "M", rowNo);
                    cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Value);
                    cell = GetCell(worksheetPart.Worksheet, "N", rowNo);
                    cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Score);
                    rowNo++;
                    //cell.DataType = new EnumValue<CellValues>(CellValues.Number);
                }
                // Save the worksheet.
                worksheetPart.Worksheet.Save();

                // for recacluation of formula
                spreadSheet.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                spreadSheet.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;
                // Regulatory Environment

            }
            return true;
        }

        public bool Get_OutputDetails_InterOp_DetailsId(int detailsId, string companyName, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Key Financials List

            List<SCB_OutputDetailsEntity> getOutputDetails = dbContext.SCB_Output_Details
              .Where(a => a.DetailsId == detailsId
              )
              .Select(Outputs => new SCB_OutputDetailsEntity
              {
                  Parameter3Per = Outputs.Parameter_Per,
                  Parameter3 = Outputs.Parameter_Name,
                  UnderIND_Score = Outputs.UnderIND_Score,
                  UnderIND_Value = Outputs.UnderIND_Value,
                  UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                  UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
              }).ToList();

            #endregion


            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Output NHB"];

            uint rowIndex = 2;
            int columnIndex = 0;
            columnIndex = _helperDAL.GetExcelColumnIndex("G");
            mWSheet.Cells[rowIndex, columnIndex] = companyName;
            rowIndex = 3;
            for (int i = 0; i < getOutputDetails.Count; i++)
            {
                columnIndex = _helperDAL.GetExcelColumnIndex("J");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("K");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Score;

                columnIndex = _helperDAL.GetExcelColumnIndex("M");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("N");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Score;
                rowIndex++;
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();


            return true;
        }

        public SCB_BasicDetailsEntity GetBasicDetails(int detailsId)
        {
            SCB_BasicDetailsEntity basicDetails = new SCB_BasicDetailsEntity();
            SCB_KeyFinancialsEntity keyFinancials = new SCB_KeyFinancialsEntity();
            SCB_SubjectiveParametersEntity subjectiveParameters = new SCB_SubjectiveParametersEntity();
            SCB_IndustryExpsoureEntity industryExpsoures = new SCB_IndustryExpsoureEntity();
            List<SCB_OutputDetailsEntity> outputDetails = new List<SCB_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details.Where(data => data.DetailsId == detailsId).Select(x => new SCB_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = 0,

                FinYear = x.FinYear,
                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                DateOfInput = x.DateOfInput,
                CurrencyUnits = x.CurrencyUnits,
                ParentCompanyName = x.ParentCompanyName,
                ParentCompanyId = x.ParentCompanyId,
                ParentRating = x.ParentRating,
                ParentCompanyShareHoldingPer = x.ParentCompanyShareHoldingPer,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

                IsFinal = x.IsFinal.Value
            }).FirstOrDefault();

            keyFinancials = dbContext.SCB_KeyFinancials.Where(data => data.DetailsId == detailsId).Select(keyFinancialsEntity => new SCB_KeyFinancialsEntity
            {
                DetailsId = detailsId,
                PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                Currency1 = keyFinancialsEntity.Currency1,
                Currency2 = keyFinancialsEntity.Currency2,
                NetWorth1 = keyFinancialsEntity.NetWorth1,
                NetWorth2 = keyFinancialsEntity.NetWorth2,
                TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                CreditDepositRatioPer1 = keyFinancialsEntity.CreditDepositRatioPer1,
                CreditDepositRatioPer2 = keyFinancialsEntity.CreditDepositRatioPer2,
                ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                CASAPer1 = keyFinancialsEntity.CASAPer1,
                CASAPer2 = keyFinancialsEntity.CASAPer2,
                PrioritySectorAdvancesPer1 = keyFinancialsEntity.PrioritySectorAdvancesPer1,
                PrioritySectorAdvancesPer2 = keyFinancialsEntity.PrioritySectorAdvancesPer2,
                ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1,
                CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2,
                CRARPer1 = keyFinancialsEntity.CRARPer1,
                CRARPer2 = keyFinancialsEntity.CRARPer2,
                Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                CommonEquityTierPer1 = keyFinancialsEntity.CommonEquityTierPer1,
                CommonEquityTierPer2 = keyFinancialsEntity.CommonEquityTierPer2,
                NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                GrowthinDepositsPer1 = keyFinancialsEntity.GrowthinDepositsPer1,
                GrowthinDepositsPer2 = keyFinancialsEntity.GrowthinDepositsPer2,
                TotalNumBranches1 = keyFinancialsEntity.TotalNumBranches1,
                TotalNumBranches2 = keyFinancialsEntity.TotalNumBranches2,

                GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                DiversityofIncomePer1 = keyFinancialsEntity.DiversityofIncomePer1,
                DiversityofIncomePer2 = keyFinancialsEntity.DiversityofIncomePer2,
                TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                AdvancesToSensitiveSectorPer1 = keyFinancialsEntity.AdvancesToSensitiveSectorPer1,
                AdvancesToSensitiveSectorPer2 = keyFinancialsEntity.AdvancesToSensitiveSectorPer2,
                CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                NetStableFundingRatioPer1 = keyFinancialsEntity.NetStableFundingRatioPer1,
                NetStableFundingRatioPer2 = keyFinancialsEntity.NetStableFundingRatioPer2,
                GearingPer1 = keyFinancialsEntity.GearingPer1,
                GearingPer2 = keyFinancialsEntity.GearingPer2,
                LeverageRatioPer1 = keyFinancialsEntity.LeverageRatio1,
                LeverageRatioPer2 = keyFinancialsEntity.LeverageRatio2,
                ProvisioningCoverageRatio1 = keyFinancialsEntity.ProvisioningCoverageRatio1,
                ProvisioningCoverageRatio2 = keyFinancialsEntity.ProvisioningCoverageRatio2,

            }).FirstOrDefault();

            subjectiveParameters = dbContext.SCB_SubjectiveParameters.Where(data => data.DetailsId == detailsId).Select(subjectiveParametersEntity => new SCB_SubjectiveParametersEntity
            {
                //PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank,
                ExternalRating = subjectiveParametersEntity.ExternalRating,
                IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                BusinessModel = subjectiveParametersEntity.BusinessModel,
                ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                AdverseNews = subjectiveParametersEntity.AdverseNews,
                CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                NPASysGen = subjectiveParametersEntity.NPASysGen,
                NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,
            }).FirstOrDefault();

            industryExpsoures = dbContext.SCB_IndustryExpsoure.Where(data => data.DetailsId == detailsId).Select(industryExpsoureEntity => new SCB_IndustryExpsoureEntity
            {
                AgricultureAlliedActivities1 = industryExpsoureEntity.AgricultureAlliedActivities1,
                AgricultureAlliedActivitiesPer2 = industryExpsoureEntity.AgricultureAlliedActivitiesPer2,
                AgricultureAlliedActivities3 = industryExpsoureEntity.AgricultureAlliedActivities3,
                MinigQuaring1 = industryExpsoureEntity.MinigQuaring1,
                MinigQuaringPer2 = industryExpsoureEntity.MinigQuaringPer2,
                MinigQuaring3 = industryExpsoureEntity.MinigQuaring3,
                FoodFoodProcessing1 = industryExpsoureEntity.FoodFoodProcessing1,
                FoodFoodProcessingPer2 = industryExpsoureEntity.FoodFoodProcessingPer2,
                FoodFoodProcessing3 = industryExpsoureEntity.FoodFoodProcessing3,
                Textiles1 = industryExpsoureEntity.Textiles1,
                TextilesPer2 = industryExpsoureEntity.TextilesPer2,
                Textiles3 = industryExpsoureEntity.Textiles3,
                MaterialtheirProducts1 = industryExpsoureEntity.MaterialtheirProducts1,
                MaterialtheirProductsPer2 = industryExpsoureEntity.MaterialtheirProductsPer2,
                MaterialtheirProducts3 = industryExpsoureEntity.MaterialtheirProducts3,
                PetroleumCoalProductsNuclearFuels1 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuels1,
                PetroleumCoalProductsNuclearFuelsPer2 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuelsPer2,
                PetroleumCoalProductsNuclearFuels3 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuels3,
                ChemicalChemicalProducts1 = industryExpsoureEntity.ChemicalChemicalProducts1,
                ChemicalChemicalProductsPer2 = industryExpsoureEntity.ChemicalChemicalProductsPer2,
                ChemicalChemicalProducts3 = industryExpsoureEntity.ChemicalChemicalProducts3,
                CementCementProducts1 = industryExpsoureEntity.CementCementProducts1,
                CementCementProductsPer2 = industryExpsoureEntity.CementCementProductsPer2,
                CementCementProducts3 = industryExpsoureEntity.CementCementProducts3,
                BasicMetalMetalProduct1 = industryExpsoureEntity.BasicMetalMetalProduct1,
                BasicMetalMetalProductPer2 = industryExpsoureEntity.BasicMetalMetalProductPer2,
                BasicMetalMetalProduct3 = industryExpsoureEntity.BasicMetalMetalProduct3,
                AllEngineering1 = industryExpsoureEntity.AllEngineering1,
                AllEngineeringPer2 = industryExpsoureEntity.AllEngineeringPer2,
                AllEngineering3 = industryExpsoureEntity.AllEngineering3,
                AutomobileAncillary1 = industryExpsoureEntity.AutomobileAncillary1,
                AutomobileAncillaryPer2 = industryExpsoureEntity.AutomobileAncillaryPer2,
                AutomobileAncillary3 = industryExpsoureEntity.AutomobileAncillary3,
                GemsJewellery1 = industryExpsoureEntity.GemsJewellery1,
                GemsJewelleryPer2 = industryExpsoureEntity.GemsJewelleryPer2,
                GemsJewellery3 = industryExpsoureEntity.GemsJewellery3,
                Construction1 = industryExpsoureEntity.Construction1,
                ConstructionPer2 = industryExpsoureEntity.ConstructionPer2,
                Construction3 = industryExpsoureEntity.Construction3,
                Power1 = industryExpsoureEntity.Power1,
                PowerPer2 = industryExpsoureEntity.PowerPer2,
                Power3 = industryExpsoureEntity.Power3,
                Telecommunication1 = industryExpsoureEntity.Telecommunication1,
                TelecommunicationPer2 = industryExpsoureEntity.TelecommunicationPer2,
                Telecommunication3 = industryExpsoureEntity.Telecommunication3,
                RestoftheInfrastructure1 = industryExpsoureEntity.RestoftheInfrastructure1,
                RestoftheInfrastructurePer2 = industryExpsoureEntity.RestoftheInfrastructurePer2,
                RestoftheInfrastructure3 = industryExpsoureEntity.RestoftheInfrastructure3,
                NBFCs1 = industryExpsoureEntity.NBFCs1,
                NBFCsPer2 = industryExpsoureEntity.NBFCsPer2,
                NBFCs3 = industryExpsoureEntity.NBFCs3,
                OtherIndustries1 = industryExpsoureEntity.OtherIndustries1,
                OtherIndustriesPer2 = industryExpsoureEntity.OtherIndustriesPer2,
                OtherIndustries3 = industryExpsoureEntity.OtherIndustries3,
                Retail1 = industryExpsoureEntity.Retail1,
                RetailPer2 = industryExpsoureEntity.RetailPer2,
                Retail3 = industryExpsoureEntity.Retail3,
                ResidualAdvances1 = industryExpsoureEntity.ResidualAdvances1,
                ResidualAdvancesPer2 = industryExpsoureEntity.ResidualAdvancesPer2,
                ResidualAdvances3 = industryExpsoureEntity.ResidualAdvances3,
                TotalAdvances = industryExpsoureEntity.TotalAdvances,


            }).FirstOrDefault();

            outputDetails = (from output in dbContext.SCB_Output_Details
                             join template in dbContext.SCB_Output_Template on output.TemplateId equals template.TemplateID
                             where output.DetailsId == detailsId

                             select new SCB_OutputDetailsEntity
                             {
                                 TemplateID = output.TemplateId,
                                 Parameter1 = string.IsNullOrEmpty(template.Parameter1) ? string.Empty : template.Parameter1,
                                 Parameter1Per = string.IsNullOrEmpty(template.Parameter1Per) ? string.Empty : template.Parameter1Per,
                                 Parameter2 = string.IsNullOrEmpty(template.Parameter2) ? string.Empty : template.Parameter2,
                                 Parameter2Per = string.IsNullOrEmpty(template.Parameter2Per) ? string.Empty : template.Parameter2Per,
                                 Parameter3Per = output.Parameter_Per,
                                 Parameter3 = output.Parameter_Name,
                                 UnderBaselIII_Score = string.IsNullOrEmpty(output.UnderBaselIII_Score) ? string.Empty : output.UnderBaselIII_Score,
                                 UnderBaselIII_Value = string.IsNullOrEmpty(output.UnderBaselIII_Value) ? string.Empty : output.UnderBaselIII_Value,
                                 UnderIND_Score = string.IsNullOrEmpty(output.UnderIND_Score) ? string.Empty : output.UnderIND_Score,
                                 UnderIND_Value = string.IsNullOrEmpty(output.UnderIND_Value) ? string.Empty : output.UnderIND_Value,
                                 Comments = string.IsNullOrEmpty(output.Comments) ? string.Empty : output.Comments,
                             }).ToList();

            basicDetails.SCB_KeyFinancialsEntity = keyFinancials;
            basicDetails.SCB_SubjectiveParametersEntity = subjectiveParameters;
            basicDetails.SCB_IndustryExpsoureEntity = industryExpsoures;
            basicDetails.SCB_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public SCB_BasicDetailsEntity GetBasicDetails_Archive(int detailsId, short logId)
        {
            SCB_BasicDetailsEntity basicDetails = new SCB_BasicDetailsEntity();
            SCB_KeyFinancialsEntity keyFinancials = new SCB_KeyFinancialsEntity();
            SCB_SubjectiveParametersEntity subjectiveParameters = new SCB_SubjectiveParametersEntity();
            SCB_IndustryExpsoureEntity industryExpsoures = new SCB_IndustryExpsoureEntity();
            List<SCB_OutputDetailsEntity> outputDetails = new List<SCB_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(x => new SCB_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = logId,

                FinYear = x.FinYear,
                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                DateOfInput = x.DateOfInput,
                CurrencyUnits = x.CurrencyUnits,
                ParentCompanyName = x.ParentCompanyName,
                ParentCompanyId = x.ParentCompanyId,
                ParentRating = x.ParentRating,
                ParentCompanyShareHoldingPer = x.ParentCompanyShareHoldingPer,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

                IsFinal = x.IsFinal.Value
            }).FirstOrDefault();

            keyFinancials = dbContext.SCB_KeyFinancials_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(keyFinancialsEntity => new SCB_KeyFinancialsEntity
            {
                DetailsId = detailsId,
                PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                Currency1 = keyFinancialsEntity.Currency1,
                Currency2 = keyFinancialsEntity.Currency2,
                NetWorth1 = keyFinancialsEntity.NetWorth1,
                NetWorth2 = keyFinancialsEntity.NetWorth2,
                TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                CreditDepositRatioPer1 = keyFinancialsEntity.CreditDepositRatioPer1,
                CreditDepositRatioPer2 = keyFinancialsEntity.CreditDepositRatioPer2,
                ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                CASAPer1 = keyFinancialsEntity.CASAPer1,
                CASAPer2 = keyFinancialsEntity.CASAPer2,
                PrioritySectorAdvancesPer1 = keyFinancialsEntity.PrioritySectorAdvancesPer1,
                PrioritySectorAdvancesPer2 = keyFinancialsEntity.PrioritySectorAdvancesPer2,
                ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                CostOfDepositsPer1 = keyFinancialsEntity.CostOfDepositsPer1,
                CostOfDepositsPer2 = keyFinancialsEntity.CostOfDepositsPer2,
                CRARPer1 = keyFinancialsEntity.CRARPer1,
                CRARPer2 = keyFinancialsEntity.CRARPer2,
                Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                CommonEquityTierPer1 = keyFinancialsEntity.CommonEquityTierPer1,
                CommonEquityTierPer2 = keyFinancialsEntity.CommonEquityTierPer2,
                NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                GrowthinDepositsPer1 = keyFinancialsEntity.GrowthinDepositsPer1,
                GrowthinDepositsPer2 = keyFinancialsEntity.GrowthinDepositsPer2,
                TotalNumBranches1 = keyFinancialsEntity.TotalNumBranches1,
                TotalNumBranches2 = keyFinancialsEntity.TotalNumBranches2,

                GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                DiversityofIncomePer1 = keyFinancialsEntity.DiversityofIncomePer1,
                DiversityofIncomePer2 = keyFinancialsEntity.DiversityofIncomePer2,
                TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                AdvancesToSensitiveSectorPer1 = keyFinancialsEntity.AdvancesToSensitiveSectorPer1,
                AdvancesToSensitiveSectorPer2 = keyFinancialsEntity.AdvancesToSensitiveSectorPer2,
                CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                NetStableFundingRatioPer1 = keyFinancialsEntity.NetStableFundingRatioPer1,
                NetStableFundingRatioPer2 = keyFinancialsEntity.NetStableFundingRatioPer2,
                GearingPer1 = keyFinancialsEntity.GearingPer1,
                GearingPer2 = keyFinancialsEntity.GearingPer2,
                LeverageRatioPer1 = keyFinancialsEntity.LeverageRatio1,
                LeverageRatioPer2 = keyFinancialsEntity.LeverageRatio2,
                ProvisioningCoverageRatio1 = keyFinancialsEntity.ProvisioningCoverageRatio1,
                ProvisioningCoverageRatio2 = keyFinancialsEntity.ProvisioningCoverageRatio2,

            }).FirstOrDefault();

            subjectiveParameters = dbContext.SCB_SubjectiveParameters_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(subjectiveParametersEntity => new SCB_SubjectiveParametersEntity
            {
                //PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank,
                ExternalRating = subjectiveParametersEntity.ExternalRating,

                IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                BusinessModel = subjectiveParametersEntity.BusinessModel,
                ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                AdverseNews = subjectiveParametersEntity.AdverseNews,
                CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                NPASysGen = subjectiveParametersEntity.NPASysGen,
                NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,
            }).FirstOrDefault();

            industryExpsoures = dbContext.SCB_IndustryExpsoure_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(industryExpsoureEntity => new SCB_IndustryExpsoureEntity
            {
                AgricultureAlliedActivities1 = industryExpsoureEntity.AgricultureAlliedActivities1,
                AgricultureAlliedActivitiesPer2 = industryExpsoureEntity.AgricultureAlliedActivitiesPer2,
                AgricultureAlliedActivities3 = industryExpsoureEntity.AgricultureAlliedActivities3,
                MinigQuaring1 = industryExpsoureEntity.MinigQuaring1,
                MinigQuaringPer2 = industryExpsoureEntity.MinigQuaringPer2,
                MinigQuaring3 = industryExpsoureEntity.MinigQuaring3,
                FoodFoodProcessing1 = industryExpsoureEntity.FoodFoodProcessing1,
                FoodFoodProcessingPer2 = industryExpsoureEntity.FoodFoodProcessingPer2,
                FoodFoodProcessing3 = industryExpsoureEntity.FoodFoodProcessing3,
                Textiles1 = industryExpsoureEntity.Textiles1,
                TextilesPer2 = industryExpsoureEntity.TextilesPer2,
                Textiles3 = industryExpsoureEntity.Textiles3,
                MaterialtheirProducts1 = industryExpsoureEntity.MaterialtheirProducts1,
                MaterialtheirProductsPer2 = industryExpsoureEntity.MaterialtheirProductsPer2,
                MaterialtheirProducts3 = industryExpsoureEntity.MaterialtheirProducts3,
                PetroleumCoalProductsNuclearFuels1 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuels1,
                PetroleumCoalProductsNuclearFuelsPer2 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuelsPer2,
                PetroleumCoalProductsNuclearFuels3 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuels3,
                ChemicalChemicalProducts1 = industryExpsoureEntity.ChemicalChemicalProducts1,
                ChemicalChemicalProductsPer2 = industryExpsoureEntity.ChemicalChemicalProductsPer2,
                ChemicalChemicalProducts3 = industryExpsoureEntity.ChemicalChemicalProducts3,
                CementCementProducts1 = industryExpsoureEntity.CementCementProducts1,
                CementCementProductsPer2 = industryExpsoureEntity.CementCementProductsPer2,
                CementCementProducts3 = industryExpsoureEntity.CementCementProducts3,
                BasicMetalMetalProduct1 = industryExpsoureEntity.BasicMetalMetalProduct1,
                BasicMetalMetalProductPer2 = industryExpsoureEntity.BasicMetalMetalProductPer2,
                BasicMetalMetalProduct3 = industryExpsoureEntity.BasicMetalMetalProduct3,
                AllEngineering1 = industryExpsoureEntity.AllEngineering1,
                AllEngineeringPer2 = industryExpsoureEntity.AllEngineeringPer2,
                AllEngineering3 = industryExpsoureEntity.AllEngineering3,
                AutomobileAncillary1 = industryExpsoureEntity.AutomobileAncillary1,
                AutomobileAncillaryPer2 = industryExpsoureEntity.AutomobileAncillaryPer2,
                AutomobileAncillary3 = industryExpsoureEntity.AutomobileAncillary3,
                GemsJewellery1 = industryExpsoureEntity.GemsJewellery1,
                GemsJewelleryPer2 = industryExpsoureEntity.GemsJewelleryPer2,
                GemsJewellery3 = industryExpsoureEntity.GemsJewellery3,
                Construction1 = industryExpsoureEntity.Construction1,
                ConstructionPer2 = industryExpsoureEntity.ConstructionPer2,
                Construction3 = industryExpsoureEntity.Construction3,
                Power1 = industryExpsoureEntity.Power1,
                PowerPer2 = industryExpsoureEntity.PowerPer2,
                Power3 = industryExpsoureEntity.Power3,
                Telecommunication1 = industryExpsoureEntity.Telecommunication1,
                TelecommunicationPer2 = industryExpsoureEntity.TelecommunicationPer2,
                Telecommunication3 = industryExpsoureEntity.Telecommunication3,
                RestoftheInfrastructure1 = industryExpsoureEntity.RestoftheInfrastructure1,
                RestoftheInfrastructurePer2 = industryExpsoureEntity.RestoftheInfrastructurePer2,
                RestoftheInfrastructure3 = industryExpsoureEntity.RestoftheInfrastructure3,
                NBFCs1 = industryExpsoureEntity.NBFCs1,
                NBFCsPer2 = industryExpsoureEntity.NBFCsPer2,
                NBFCs3 = industryExpsoureEntity.NBFCs3,
                OtherIndustries1 = industryExpsoureEntity.OtherIndustries1,
                OtherIndustriesPer2 = industryExpsoureEntity.OtherIndustriesPer2,
                OtherIndustries3 = industryExpsoureEntity.OtherIndustries3,
                Retail1 = industryExpsoureEntity.Retail1,
                RetailPer2 = industryExpsoureEntity.RetailPer2,
                Retail3 = industryExpsoureEntity.Retail3,
                ResidualAdvances1 = industryExpsoureEntity.ResidualAdvances1,
                ResidualAdvancesPer2 = industryExpsoureEntity.ResidualAdvancesPer2,
                ResidualAdvances3 = industryExpsoureEntity.ResidualAdvances3,
                TotalAdvances = industryExpsoureEntity.TotalAdvances,


            }).FirstOrDefault();

            outputDetails = (from output in dbContext.SCB_Output_Details_Archive
                             join template in dbContext.SCB_Output_Template on output.TemplateId equals template.TemplateID
                             where output.DetailsId == detailsId && output.LogId == logId

                             select new SCB_OutputDetailsEntity
                             {
                                 TemplateID = output.TemplateId,
                                 Parameter1 = string.IsNullOrEmpty(template.Parameter1) ? string.Empty : template.Parameter1,
                                 Parameter1Per = string.IsNullOrEmpty(template.Parameter1Per) ? string.Empty : template.Parameter1Per,
                                 Parameter2 = string.IsNullOrEmpty(template.Parameter2) ? string.Empty : template.Parameter2,
                                 Parameter2Per = string.IsNullOrEmpty(template.Parameter2Per) ? string.Empty : template.Parameter2Per,
                                 Parameter3Per = output.Parameter_Per,
                                 Parameter3 = output.Parameter_Name,
                                 UnderBaselIII_Score = string.IsNullOrEmpty(output.UnderBaselIII_Score) ? string.Empty : output.UnderBaselIII_Score,
                                 UnderBaselIII_Value = string.IsNullOrEmpty(output.UnderBaselIII_Value) ? string.Empty : output.UnderBaselIII_Value,
                                 UnderIND_Score = string.IsNullOrEmpty(output.UnderIND_Score) ? string.Empty : output.UnderIND_Score,
                                 UnderIND_Value = string.IsNullOrEmpty(output.UnderIND_Value) ? string.Empty : output.UnderIND_Value,
                                 Comments = string.IsNullOrEmpty(output.Comments) ? string.Empty : output.Comments,
                             }).ToList();

            basicDetails.SCB_KeyFinancialsEntity = keyFinancials;
            basicDetails.SCB_SubjectiveParametersEntity = subjectiveParameters;
            basicDetails.SCB_IndustryExpsoureEntity = industryExpsoures;
            basicDetails.SCB_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

    }

}