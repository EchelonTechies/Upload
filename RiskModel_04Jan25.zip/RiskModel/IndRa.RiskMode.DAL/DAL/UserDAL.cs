﻿using IndRa.RiskModel.DAL.DataAccess;
using IndRa.RiskModel.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;


namespace IndRa.RiskModel.DAL.DAL
{
    public class UserDAL : CommonEntity
    {
        IndRaDBcontext dbContext = new IndRaDBcontext();

        public bool CheckDuplicateUserName(string userName)
        {
            return (dbContext.Users.Any(p => p.UserName.ToLower() == userName.ToLower()));
        }
        public bool CheckDuplicateEmail(string emailID)
        {
            return (dbContext.Users.Any(p => p.Email.ToLower() == emailID.ToLower()));
        }
        public UserEntity GetLoginDetails(string username, string password)
        {
            var userList = dbContext.Users.Where(user => user.UserName == username && user.Password == password).Select(x => new UserEntity
            {
                Email = x.Email,
                UserName = x.UserName,
                Password = x.Password
            }).FirstOrDefault();

            return userList;
        }

        public User GetUserDetailsByUserName(string username)
        {
            return dbContext.Users.Where(user => user.UserName == username).FirstOrDefault();
        }

        public int GetUserIdByEmailAddressActivationCode(string email,string activationCode)
        {
            return dbContext.Users.Where(x => x.Email == email && x.ActivationCode == activationCode).Select(y => y.UserId).FirstOrDefault();
        }

        public int GetUserIdByEmailAddress(string email)
        {
            return dbContext.Users.Where(x => x.Email == email).Select(y => y.UserId).FirstOrDefault();
        }
        public bool GetUserStatus(string username)
        {
            User userActive = dbContext.Users.Where(user => user.UserName == username && user.IsActive == true).FirstOrDefault();
            if (userActive != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string GetUserEmailAddress(int userID)
        {
            return (from user in dbContext.Users
                    where user.UserId == userID
                    select user.Email).FirstOrDefault();
        }

        public UserEntity GetUserByEmailAddress(string email)
        {
            var userDetails = dbContext.Users.Where(user => user.Email == email).Select(x => new UserEntity
            {
                FirstName = x.FirstName,
                LastName = x.LastName,
                Email = email
            }).FirstOrDefault();

            return userDetails;
        }

        public bool UpdateEmailActivationCodeByUserName(string userName, string activationCode)
        {
            User userUpdate = (from user in dbContext.Users
                               where user.UserName == userName
                               select user).SingleOrDefault();

            if (userUpdate != null)
            {
                userUpdate.ActivationCode = activationCode;
                dbContext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        
        public bool UpdateEmailActivationCodeByEmail(string email, string activationCode)
        {
            User userUpdate = (from user in dbContext.Users
                               where user.Email == email
                               select user).SingleOrDefault();

            if (userUpdate != null)
            {
                userUpdate.ActivationCode = activationCode;
                dbContext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckEmailActivationCode(string emailAddress, string activationCode)
        {
            return (from user in dbContext.Users
                    where user.Email.Equals(emailAddress, StringComparison.OrdinalIgnoreCase) &&
                        user.ActivationCode.Equals(activationCode)
                    select user).Any();
        }

        public bool ResetPassword(string emailAddress, string password, string salt)
        {
            User userResetPassword = (from user in dbContext.Users
                                      where user.Email == emailAddress
                                      select user).SingleOrDefault();

            if (userResetPassword != null)
            {
                userResetPassword.Password = password;
                userResetPassword.Salt = salt;
                dbContext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public IEnumerable<User> GetAllUsersList(int roleID)
        {
            if (roleID == 1)
            {
                return (from user in dbContext.Users
                        where user.RoleId != 1 //&& user.IsActive == true  //join role in dbContext.Roles on user.RoleId equals role.RoleId where user.RoleId != roleID 
                        select user).AsEnumerable();
            }
            else
            {
                return (from user in dbContext.Users
                        where user.RoleId != 1 && user.RoleId != 2 //&& user.IsActive == true  //join role in dbContext.Roles on user.RoleId equals role.RoleId where user.RoleId != roleID 
                        select user).AsEnumerable();
            }
        }

        public string GetRoleName(int UserRoleID)
        {
            return (from role in dbContext.Roles
                    where role.RoleId == UserRoleID
                    select role.RoleName).SingleOrDefault();

        }

        public string[] GetAllRoles(int roleId)
        {
            if (roleId == 1)
            {
                return (from role in dbContext.Roles
                        where role.HiddenForSuperUserAdmin == null
                        select role.RoleName).ToArray();
            }
            else if (roleId == 2)
            {
                return (from role in dbContext.Roles
                        where role.HiddenForAdmin == null
                        select role.RoleName).ToArray();
            }
            return null;
        }

        public int GetRoleID(string roleName)
        {
            return (from role in dbContext.Roles
                    where role.RoleName.Equals(roleName)
                    select role.RoleId).SingleOrDefault();
        }

        public bool CreateUser(UserEntity userEntity)
        {
            bool status = false;
            int userID = 0;

            User user = new User
            {
                RoleId = userEntity.RoleId,
                FirstName = userEntity.FirstName,
                LastName = userEntity.LastName,
                UserCode = userEntity.UserCode,
                Email = userEntity.Email,
                UserName = userEntity.UserName,
                Password = userEntity.Password,
                Salt = userEntity.Salt,
                CreatedBy = userEntity.CreatedBy,
                CreatedDateTime = userEntity.CreatedDateTime,
                UpdatedBy = userEntity.UpdatedBy,
                UpdatedDateTime = userEntity.UpdatedDateTime,
                IsActive = userEntity.IsActive

            };

            Users_Archive user_Archive = new Users_Archive
            {
                RoleId = userEntity.RoleId,
                FirstName = userEntity.FirstName,
                LastName = userEntity.LastName,
                UserCode = userEntity.UserCode,
                Email = userEntity.Email,
                UserName = userEntity.UserName,
                Password = userEntity.Password,
                Salt = userEntity.Salt,
                CreatedBy = userEntity.CreatedBy,
                CreatedDateTime = userEntity.CreatedDateTime,
                IsActive = userEntity.IsActive
            };

            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    userID = (int)Add(user);
                    user_Archive.UserId = userID;

                    AddArchive(user_Archive);
                    dbContextTransaction.Commit();
                    status = true;
                }
                catch (Exception exception)
                {
                    dbContextTransaction.Rollback();
                    ResponseMessage = "An error occured while Creating User. Please try again.";
                }
                return status;
            }
        }

        public object Add(User user)
        {
            try
            {
                dbContext.Users.Add(user);
                dbContext.SaveChanges();
                return user.UserId;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public object AddArchive(Users_Archive user)
        {
            try
            {
                dbContext.Users_Archive.Add(user);
                dbContext.SaveChanges();
                return user.UserId;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public User GetUserByID(long userID)
        {
            return (from user in dbContext.Users
                    where user.UserId == userID
                    select user).SingleOrDefault();
        }

        public int GetUserID(string userName)
        {
            return dbContext.Users.Where(x => x.UserName == userName).Select(x => x.UserId).FirstOrDefault();
        }



        public bool UpdateUserDetails(UserEntity userEntity)
        {
            User userDetails = (from details in dbContext.Users
                                where details.UserId == userEntity.UserId
                                select details).SingleOrDefault();
            if (userDetails != null)
            {
                userDetails.RoleId = userEntity.RoleId;
                userDetails.FirstName = userEntity.FirstName;
                userDetails.LastName = userEntity.LastName;
                userDetails.UserCode = userEntity.UserCode;

                userDetails.Email = userEntity.Email;
                userDetails.UserName = userEntity.UserName;
                userDetails.UpdatedBy = userEntity.UpdatedBy;
                userDetails.UpdatedDateTime = userEntity.UpdatedDateTime;
                userDetails.IsActive = userEntity.IsActive;

                Users_Archive user_Archive = new Users_Archive
                {
                    UserId = userEntity.UserId,
                    RoleId = userEntity.RoleId,
                    FirstName = userEntity.FirstName,
                    LastName = userEntity.LastName,
                    UserCode = userEntity.UserCode,
                    Email = userEntity.Email,
                    //Password = userEntity.Password,
                    //Salt = userEntity.Salt,

                    UserName = userEntity.UserName,
                    Password = userDetails.Password,
                    Salt = userDetails.Salt,
                    UpdatedBy = userEntity.UpdatedBy,
                    UpdatedDateTime = userEntity.UpdatedDateTime,
                    IsActive = userEntity.IsActive
                };
                AddArchive(user_Archive);
                dbContext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool UpdatePassword(string userName, string oldPassword, string newPassword, string salt)
        {
            User userDelete = (from user in dbContext.Users
                               where user.Email.Equals(userName) && user.Password.Equals(oldPassword)
                               select user).SingleOrDefault();

            if (userDelete != null)
            {
                userDelete.Password = newPassword;
                userDelete.Salt = salt;
                dbContext.SaveChanges();
            }

            return true;
        }

        public bool DeleteUserById(object ID)
        {
            User userDetails = (from user in dbContext.Users
                                where user.UserId == (int)ID
                                select user).SingleOrDefault();

            if (userDetails != null)
            {
                //dbContext.Users.Remove(userExist);
                userDetails.IsActive = false;
                dbContext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteUser(int userId, int updatedBy)
        {
            List<User> userDetails = (from user in dbContext.Users
                                      join details in dbContext.NHB_Details on user.UserId equals details.UserId
                                      where user.UserId == userId
                                      select user).ToList();

            if (userDetails.Count == 0)
            {
                User userExist = dbContext.Users.Where(x => x.UserId == userId).FirstOrDefault();
                // dbContext.Users.Remove(userExist);
                userExist.IsActive = false;

                Users_Archive user_Archive = new Users_Archive
                {
                    UserId = userExist.UserId,
                    RoleId = userExist.RoleId,
                    FirstName = userExist.FirstName,
                    LastName = userExist.LastName,
                    UserCode = userExist.UserCode,
                    Email = userExist.Email,
                    UserName = userExist.UserName,
                    Password = userExist.Password,
                    Salt = userExist.Salt,
                    UpdatedBy = updatedBy,
                    UpdatedDateTime = DateTime.Now,
                    IsActive = userExist.IsActive
                };
                AddArchive(user_Archive);
                dbContext.SaveChanges();
                return true;
            }
            else
            {
                User userExist = dbContext.Users.Where(x => x.UserId == userId).FirstOrDefault();
                userExist.IsActive = false;
                dbContext.SaveChanges();
                return true;
            }
        }
    }
}
