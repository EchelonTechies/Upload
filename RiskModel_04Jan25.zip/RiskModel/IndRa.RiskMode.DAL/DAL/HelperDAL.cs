﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Text;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Text.RegularExpressions;

namespace IndRa.RiskModel.DAL
{
    public class HelperDAL
    {
        public DataTable ReadExcelFile_OleDB(string filePath, string fileName, string workSheet)
        {
            DataTable dt = new DataTable();
            OleDbConnection excelConnection = null;
            OleDbConnection excelConnection1 = null;

            string fileExtension = System.IO.Path.GetExtension(fileName);

            if (fileExtension == ".xls" || fileExtension == ".xlsx" || fileExtension == ".xlsm")
            {
                string excelConnectionString = string.Empty;
                excelConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;ImportMixedTypes=Text;HDR=Yes;IMEX=1\"";
                if (fileExtension == ".xls")
                {
                    excelConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties=\"Excel 8.0;ImportMixedTypes=Text;HDR=Yes;IMEX=1\"";
                }
                else if (fileExtension == ".xlsx" || fileExtension == ".xlsm")
                {
                    excelConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;ImportMixedTypes=Text;HDR=Yes;IMEX=1\"";
                }

                excelConnection = new OleDbConnection(excelConnectionString);
                excelConnection.Open();
                dt = excelConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                if (dt == null)
                {
                    return dt;
                }

                String[] excelSheets = new String[dt.Rows.Count];

                excelConnection1 = new OleDbConnection(excelConnectionString);
                DataSet ds = new DataSet();
                string query = "Select * from [" + workSheet + "]";
                using (OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, excelConnection1))
                {
                    dataAdapter.Fill(ds);
                    dataAdapter.Dispose();
                }

                //dtTranspose = GenerateTransposedTable(ds.Tables[0], out _result);


                excelConnection.Close();
                excelConnection.Dispose();

                excelConnection1.Close();
                excelConnection1.Dispose();
                return ds.Tables[0];
            }
            else
            {
                return null;
            }
        }

        public DataTable READExcel(string path, string fileName, string workSheet)
        {
            DataTable dt = new DataTable();
            try
            {
                Microsoft.Office.Interop.Excel.Application objXL = null;
                Microsoft.Office.Interop.Excel.Workbook objWB = null;
                objXL = new Microsoft.Office.Interop.Excel.Application();
                objWB = objXL.Workbooks.Open(path);
                Microsoft.Office.Interop.Excel.Sheets excelSheets = objWB.Worksheets;

                int worksheetIndex = 1;
                for (int i = 1; i < objWB.Worksheets.Count; i++)
                {
                    Microsoft.Office.Interop.Excel.Worksheet excelWorksheet = (Microsoft.Office.Interop.Excel.Worksheet)excelSheets.get_Item(i);
                    string name = excelWorksheet.Name;//Sheet Name
                    if (name == workSheet.Replace("$", ""))
                    {
                        worksheetIndex = i;
                        break;
                    }
                }
                //Microsoft.Office.Interop.Excel.Worksheet objSHT = objWB.Worksheets[5];

                Microsoft.Office.Interop.Excel.Worksheet objSHT = (Microsoft.Office.Interop.Excel.Worksheet)objWB.Worksheets[worksheetIndex];

                int rows = objSHT.UsedRange.Rows.Count;
                int cols = objSHT.UsedRange.Columns.Count;
                int noofrow = 1;

                for (int c = 1; c <= cols; c++)
                {
                    string colname = objSHT.Cells[1, c].Text;
                    if (colname == string.Empty)
                    {
                        colname = "F" + c.ToString();
                    }
                    dt.Columns.Add(colname);
                    noofrow = 2;
                }

                for (int r = noofrow; r <= rows; r++)
                {
                    DataRow dr = dt.NewRow();
                    for (int c = 1; c <= cols; c++)
                    {
                        dr[c - 1] = objSHT.Cells[r, c].Text;
                    }

                    dt.Rows.Add(dr);
                }

                objWB.Close();
                objXL.Quit();
            }
            catch (Exception ex)
            {

            }
            return dt;
        }


        public DataTable ReadExcelFile(string filePath, string fileName, string workSheet, out string _result)
        {
            _result = string.Empty;
            //Open the Excel file in Read Mode using OpenXml.
            using (SpreadsheetDocument doc = SpreadsheetDocument.Open(filePath, false))
            {
                WorkbookPart bkPart = doc.WorkbookPart;
                DocumentFormat.OpenXml.Spreadsheet.Workbook workbook = bkPart.Workbook;
                DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(sht => sht.Name == workSheet).FirstOrDefault();

                //Read the first Sheet from Excel file.
                //Sheet sheet = doc.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();

                //Get the Worksheet instance.
                Worksheet worksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;

                //Fetch all the rows present in the Worksheet.
                IEnumerable<Row> rows = worksheet.GetFirstChild<SheetData>().Descendants<Row>();

                //Create a new DataTable.
                DataTable dt = new DataTable();

                try
                {
                    //Loop through the Worksheet rows.
                    foreach (Row row in rows)
                    {
                        //Use the first row to add columns to DataTable.
                        if (row.RowIndex.Value == 1)
                        {
                            foreach (Cell cell in row.Descendants<Cell>())
                            {
                                try
                                {
                                    dt.Columns.Add(GetValue(doc, cell));
                                }
                                catch
                                {
                                    dt.Columns.Add(cell.CellReference);
                                }
                            }
                        }
                        else
                        {
                            try
                            {
                                //Add rows to DataTable.
                                dt.Rows.Add();
                                int i = 0;
                                foreach (Cell cell in row.Descendants<Cell>())
                                {
                                    dt.Rows[dt.Rows.Count - 1][i] = GetValue(doc, cell);
                                    i++;
                                }
                            }
                            catch (Exception ex)
                            {
                            }
                        }
                    }
                }
                catch { }
                return dt;
            }
        }


        public string GetValue(SpreadsheetDocument doc, Cell cell)
        {
            //string value = cell.CellValue.InnerText;
            //if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            //{
            //    return doc.WorkbookPart.SharedStringTablePart.SharedStringTable.ChildElements.GetItem(Int32.Parse(value)).InnerText;
            //}
            //return value;

            SharedStringTablePart stringTablePart = doc.WorkbookPart.SharedStringTablePart;
            string value = cell.CellValue.InnerXml;

            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return stringTablePart.SharedStringTable.ChildElements[Int32.Parse(value)].InnerText;
            }
            else
            {
                return value;
            }
        }


        /// <summary>
        /// Generate Transpose of Datatable
        /// </summary>
        /// <param name="inputTable"></param>
        /// <param name="_result"></param>
        /// <returns></returns>
        public DataTable GenerateTransposedTable(DataTable inputTable)
        {
            DataTable outputTable = new DataTable();
            try
            {
                // Add columns by looping rows

                // Header row's first column is same as in inputTable
                outputTable.Columns.Add(inputTable.Columns[0].ColumnName.ToString().Trim().Replace("\"", ""));

                // Header row's second column onwards, 'inputTable's first column taken
                foreach (DataRow inRow in inputTable.Rows)
                {
                    string newColName = inRow[0].ToString().Trim().Replace("\"", "");
                    try
                    {
                        outputTable.Columns.Add(newColName);
                    }
                    catch { }
                }

                // Add rows by looping columns        
                for (int rCount = 1; rCount <= inputTable.Columns.Count - 1; rCount++)
                {
                    DataRow newRow = outputTable.NewRow();

                    // First column is inputTable's Header row's second column
                    newRow[0] = inputTable.Columns[rCount].ColumnName.ToString();
                    for (int cCount = 0; cCount <= inputTable.Rows.Count - 1; cCount++)
                    {
                        try
                        {
                            string colValue = inputTable.Rows[cCount][rCount].ToString();
                            newRow[cCount + 1] = colValue;
                        }
                        catch { }
                    }
                    outputTable.Rows.Add(newRow);
                }


            }
            catch (Exception ex)
            {
                StringBuilder sbColumns = new StringBuilder();
                for (int i = 0; i < inputTable.Columns.Count; i++)
                {
                    sbColumns.Append(" ," + inputTable.Columns[i].ToString());
                }
                return null;
            }
            return outputTable;
        }

        public bool IsNumeric(string value)
        {
            return value.All(char.IsNumber);
        }

        public uint GetExcelRowIndex(string cellAddress)
        {
            try
            {
                uint rowIndex = uint.Parse(Regex.Match(cellAddress, @"[0-9]+").Value);
                return rowIndex;
            }
            catch { return 0; }
        }

        public string GetExcelColumnName(string cellAddress)
        {
            try
            {
                return Regex.Replace(cellAddress, @"[\d-]", string.Empty);
            }
            catch { return ""; }
        }

        public int GetExcelColumnIndex(string columnName)
        {
            int result = 0;
            for (int i = 0; i < columnName.Length; i++)
            {
                result *= 26;
                result += columnName[i] - 'A' + 1;
            }
            return result;
        }
    }
}
