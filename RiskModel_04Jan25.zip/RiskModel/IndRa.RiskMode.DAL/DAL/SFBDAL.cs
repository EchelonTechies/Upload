﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Text;
using IndRa.RiskModel.DAL.Entities;
using DocumentFormat.OpenXml.Spreadsheet;
using System.ComponentModel;
using IndRa.RiskModel.DAL.DataAccess;
using System.Data.Entity.Validation;
using IndRa.RiskModel.DAL.DAL;
using System.Data.Entity;
using IndRa.RiskModel.Helpers;

namespace IndRa.RiskModel.DAL
{
    public class SFBDAL
    {
        HelperDAL _helperDAL = null;
        IndRaDBcontext dbContext = new IndRaDBcontext();

        public SFBDAL()
        {
            _helperDAL = new HelperDAL();
        }

        public List<SFB_OutputDetailsEntity> GetOutputTemplateEntity()
        {
            List<SFB_OutputDetailsEntity> outputTemplate = new List<SFB_OutputDetailsEntity>();
            outputTemplate = dbContext.SFB_Output_Template.Where(a => a.InActive == null).OrderBy(a => a.Ranking).Select(output => new SFB_OutputDetailsEntity
            {
                TemplateID = output.TemplateID,
                Parameter1 = string.IsNullOrEmpty(output.Parameter1) ? string.Empty : output.Parameter1,
                Parameter1Per = string.IsNullOrEmpty(output.Parameter1Per) ? string.Empty : output.Parameter1Per,
                Parameter2 = string.IsNullOrEmpty(output.Parameter2) ? string.Empty : output.Parameter2,
                Parameter2Per = string.IsNullOrEmpty(output.Parameter2Per) ? string.Empty : output.Parameter2Per,
                Parameter3 = string.IsNullOrEmpty(output.Parameter3) ? string.Empty : output.Parameter3,
                Parameter3Per = string.Empty,
                UnderBaselIII_Score = string.Empty,
                UnderBaselIII_Value = string.Empty,
                UnderIND_Score = string.Empty,
                UnderIND_Value = string.Empty,
                Comments = string.Empty,
            }).ToList();
            return outputTemplate;
        }

        public SFB_BasicDetailsEntity ImportCompanyDetailsFromExcel(string filePath, string fileName, string workSheet, int userId)
        {

            SFB_BasicDetailsEntity SFB_BasicDetails = new SFB_BasicDetailsEntity();
            SFB_KeyFinancialsEntity SFB_KeyFinancials = new SFB_KeyFinancialsEntity();
            SFB_SubjectiveParametersEntity SFB_SubjectiveParameters = new SFB_SubjectiveParametersEntity();
            SFB_IndustryExpsoureEntity SFB_IndustryExpsoureEntity = new SFB_IndustryExpsoureEntity();

            string value = "";

            DataTable dtExcel = null;
            DataTable dtTranspose = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);
            dtTranspose = _helperDAL.GenerateTransposedTable(dtExcel);

            _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);

            if (dtTranspose.Rows.Count > 0)
            {
                // get values for SFB Basic Details
                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(SFB_BasicDetails);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            value = dtTranspose.Rows[0][property.DisplayName].ToString();

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(SFB_BasicDetails, safeValue);
                        }
                    }
                    catch { }
                }

                // get values for SFB Key financials
                properties = TypeDescriptor.GetProperties(SFB_KeyFinancials);
                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            //Ratio of secured advances to total advances
                            if (property.DisplayName == "Ratio of secured advances to total advances" || property.DisplayName == "Business (INR mn)/ employee")
                            {

                            }
                            try
                            {
                                if (_helperDAL.IsNumeric(lastWord))
                                {
                                    value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                                }
                                else
                                {
                                    value = dtTranspose.Rows[0][property.DisplayName].ToString();
                                }
                            }
                            catch (Exception ex)
                            {

                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(SFB_KeyFinancials, safeValue);
                        }
                    }
                    catch { }

                }

                // get values for SFB Subjective Parameters
                properties = TypeDescriptor.GetProperties(SFB_SubjectiveParameters);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);
                            if (displayName.Contains("SMA"))
                            {

                            }
                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                            }
                            else
                            {
                                value = dtTranspose.Rows[1][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(SFB_SubjectiveParameters, safeValue);
                        }
                    }
                    catch (Exception ex)
                    {
                    }

                }

                // get values for SFB Industry Exposure
                properties = TypeDescriptor.GetProperties(SFB_IndustryExpsoureEntity);

                foreach (PropertyDescriptor property in properties)
                {
                    try
                    {
                        if (property != null)
                        {
                            string displayName = property.DisplayName;
                            string lastWord = displayName.Substring(displayName.Length - 1, 1);

                            if (_helperDAL.IsNumeric(lastWord))
                            {
                                try
                                {
                                    value = dtTranspose.Rows[int.Parse(lastWord) - 1][displayName.Remove(displayName.Length - 1, 1)].ToString();
                                }
                                catch (Exception ex)
                                {

                                }
                            }
                            else
                            {
                                value = dtTranspose.Rows[0][property.DisplayName].ToString();
                            }

                            if (value.Contains("%"))
                            {
                                value = value.Replace('%', ' ');
                            }

                            Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                            object safeValue = (value == null) ? null : Convert.ChangeType(value, t);

                            property.SetValue(SFB_IndustryExpsoureEntity, safeValue);
                        }
                    }
                    catch { }

                }

                SFB_BasicDetails.SFB_KeyFinancialsEntity = SFB_KeyFinancials;
                SFB_BasicDetails.SFB_SubjectiveParametersEntity = SFB_SubjectiveParameters;
                SFB_BasicDetails.SFB_IndustryExpsoureEntity = SFB_IndustryExpsoureEntity;


                CompanyDAL companyDAL = new CompanyDAL();
                int companyID = companyDAL.GetCompanyIDByCompanyName(SFB_BasicDetails.CompanyName, userId);
                SFB_BasicDetails.CompanyId = companyID;
                CommonDAL commonDAL = new CommonDAL();
                string finYear = commonDAL.GetFinYearBasedOnDate(DateTime.Now);
                SFB_BasicDetails.FinYear = finYear;
                //if (SFB_BasicDetails.DateOfInput.HasValue)
                //{
                //    DateTime dateOfInput = SFB_BasicDetails.DateOfInput.Value;
                //    string finYear = commonDAL.GetFinYearBasedOnDate(SFB_BasicDetails.DateOfInput.Value);
                //    SFB_BasicDetails.FinYear = finYear;
                //}
            }

            return SFB_BasicDetails;

        }

        public List<SFB_OutputDetailsEntity> GetOutputFromExcel(string filePath, string fileName, string workSheet, int userId)
        {
            List<SFB_OutputDetailsEntity> outputDetailsEntity = new List<SFB_OutputDetailsEntity>();
            DataTable dtExcel = null;

            dtExcel = _helperDAL.ReadExcelFile_OleDB(filePath, fileName, workSheet);

            string paramterName = "";
            if (dtExcel.Rows.Count > 0)
            {
                short row = 0;
                string underBaselIIIColumnName_Value = "Under Basel III";
                string underBaselIIIColumnName_Score = "";
                string UnderINDAS109ColumnName_Value = "Under IND AS 109";
                string UnderINDAS109ColumnName_Score = "";

                for (int col = 0; col < dtExcel.Columns.Count; col++)
                {
                    if (dtExcel.Columns[col].Caption == underBaselIIIColumnName_Value)
                    {
                        underBaselIIIColumnName_Score = dtExcel.Columns[col + 1].Caption;
                        continue;
                    }
                    else if (dtExcel.Columns[col].Caption == UnderINDAS109ColumnName_Value)
                    {
                        UnderINDAS109ColumnName_Score = dtExcel.Columns[col + 1].Caption;
                    }
                }
                for (int i = 1; i < dtExcel.Rows.Count; i++)
                {
                    SFB_OutputDetailsEntity newRow = new SFB_OutputDetailsEntity();
                    newRow.TemplateID = row;
                    paramterName = dtExcel.Rows[i]["F7"].ToString();
                    if (paramterName != string.Empty)
                    {
                    }
                    else
                    {
                        paramterName = dtExcel.Rows[i][0].ToString();
                    }
                    if (paramterName == string.Empty)
                    {
                        continue;
                    }
                    if (paramterName == "Rating / Probability of Default")
                    {
                        break;
                    }
                    newRow.Parameter1 = paramterName;
                    newRow.Parameter3Per = dtExcel.Rows[i]["F9"].ToString();
                    newRow.UnderBaselIII_Value = dtExcel.Rows[i][underBaselIIIColumnName_Value].ToString();
                    newRow.UnderBaselIII_Score = dtExcel.Rows[i][underBaselIIIColumnName_Score].ToString();

                    newRow.UnderIND_Value = dtExcel.Rows[i][UnderINDAS109ColumnName_Value].ToString();
                    newRow.UnderIND_Score = dtExcel.Rows[i][UnderINDAS109ColumnName_Score].ToString();

                    outputDetailsEntity.Add(newRow);
                    row++;
                }
            }

            return outputDetailsEntity;

        }

        public int SaveCompanyBasicDetailsAsDraft(int userId, int roleId, SFB_BasicDetailsEntity riskModelExcelEntity, out int basicDetails_ArchiveId, out short logID)
        {
            int detailsId = 0;
            basicDetails_ArchiveId = 0;

            CompanyDAL companyDAL = new CompanyDAL();
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                bool isRecordExist = companyDAL.CheckIfAlreadyExists_CompanyDetails(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                if (isRecordExist == true && riskModelExcelEntity.DetailsId == 0)
                {
                    detailsId = companyDAL.GetCompanyBasicDetailsID(riskModelExcelEntity.CompanyId, riskModelExcelEntity.FinYear);
                    riskModelExcelEntity.DetailsId = detailsId;
                }
                //DateTime? approvedDate = null;
                //DateTime? reviewDate = null;
                //approvedDate = companyDAL.GetDetailsApprovedDate(riskModelExcelEntity.DetailsId);
                //reviewDate = companyDAL.GetDetailsReviewedDate(riskModelExcelEntity.DetailsId);

                //if (riskModelExcelEntity.ButtonValue == "ApproveDetails")
                //{
                //    approvedDate = DateTime.Now;
                //}
                //else if (riskModelExcelEntity.ButtonValue == "ReviewDetails")
                //{
                //    reviewDate = DateTime.Now;
                //}
                if (riskModelExcelEntity.ButtonValue == ButtonValue.SubmitForApporval.ToString()) //"SubmitForApporval"
                {
                    riskModelExcelEntity.SubmitForApproval = true;
                    riskModelExcelEntity.SubmitForApprovalDate = DateTime.Now;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ApproveDetails.ToString())
                {
                    riskModelExcelEntity.ApprovedDate = DateTime.Now;
                    riskModelExcelEntity.ReviewedDate = null;
                }
                else if (riskModelExcelEntity.ButtonValue == ButtonValue.ReviewDetails.ToString())
                {
                    riskModelExcelEntity.ReviewedDate = DateTime.Now;
                    riskModelExcelEntity.ApprovedDate = null;
                }
                logID = companyDAL.GetNHBLogId(riskModelExcelEntity.DetailsId);

                NHB_Details_Archive nHB_Details_Archive = new NHB_Details_Archive
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                    IsDraft = true
                };

                NHB_Details nHB_Details = new NHB_Details
                {
                    UserId = userId,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                };

                NHB_Details_Final nHB_Details_Final = new NHB_Details_Final
                {
                    UserId = userId,
                    LogId = logID,
                    FinYear = riskModelExcelEntity.FinYear,
                    DetailsId = riskModelExcelEntity.DetailsId,
                    CompanyId = riskModelExcelEntity.CompanyId,
                    DateOfInput = riskModelExcelEntity.DateOfInput,
                    CurrencyUnits = riskModelExcelEntity.CurrencyUnits,
                    ParentCompanyId = riskModelExcelEntity.ParentCompanyId,
                    ParentCompanyShareHoldingPer = riskModelExcelEntity.ParentCompanyShareHoldingPer,
                    Comments = riskModelExcelEntity.Comments,
                    FinalRating = riskModelExcelEntity.FinalRating,
                    PD = riskModelExcelEntity.PD,
                    SubmitForApproval = riskModelExcelEntity.SubmitForApproval,
                    SubmitForApprovalDate = riskModelExcelEntity.SubmitForApprovalDate,
                    ApprovedDate = riskModelExcelEntity.ApprovedDate,
                    ReviewedDate = riskModelExcelEntity.ReviewedDate,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = riskModelExcelEntity.ButtonValue == "ApproveDetails" ? true : false,
                };

                if (userId != 0)
                {
                    #region Add Data

                    if (nHB_Details != null && companyDAL.CheckIfAlreadyExists_CompanyDetails(nHB_Details.CompanyId, nHB_Details.FinYear) == false)
                    {
                        try
                        {
                            detailsId = (int)companyDAL.AddCompanyDetails(nHB_Details);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }

                    }

                    #endregion

                    #region Update Data

                    else
                    {
                        try
                        {
                            NHB_Details details = dbContext.NHB_Details.Where(detail => detail.DetailsId == nHB_Details.DetailsId).FirstOrDefault();
                            if (details != null)
                            {
                                details.UserId = nHB_Details.UserId;
                                details.CompanyId = nHB_Details.CompanyId;
                                details.DateOfInput = nHB_Details.DateOfInput;
                                details.CurrencyUnits = nHB_Details.CurrencyUnits;
                                details.ParentCompanyId = nHB_Details.ParentCompanyId;
                                details.SponsorBank = nHB_Details.SponsorBank;
                                details.ParentCompanyName = nHB_Details.ParentCompanyName;
                                details.UpdatedBy = nHB_Details.UpdatedBy;
                                details.UpdatedDateTime = nHB_Details.UpdatedDateTime;
                                details.Comments = riskModelExcelEntity.Comments;
                                details.FinalRating = riskModelExcelEntity.FinalRating;
                                details.PD = riskModelExcelEntity.PD;
                                details.SubmitForApproval = nHB_Details.SubmitForApproval;
                                details.SubmitForApprovalDate = nHB_Details.SubmitForApprovalDate;
                                details.ApprovedDate = nHB_Details.ApprovedDate;
                                details.ReviewedDate = nHB_Details.ReviewedDate;

                                details.IsFinal = nHB_Details.IsFinal;
                                dbContext.SaveChanges();
                                detailsId = details.DetailsId;
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return -1;
                            }
                        }
                        catch (Exception exception)
                        {
                            throw exception;
                        }
                    }

                    #endregion

                    #region Final Data Add

                    if (nHB_Details.IsFinal == true)
                    {
                        try
                        {
                            companyDAL.AddCompanyDetails_Final(nHB_Details_Final);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    #endregion

                    if (isRecordExist == false)
                    {
                        nHB_Details_Archive.UpdatedBy = null;
                        nHB_Details_Archive.UpdatedDateTime = null;
                    }
                    else
                    {
                        nHB_Details_Archive.CreatedBy = null;
                        nHB_Details_Archive.CreatedDateTime = null;
                    }

                    nHB_Details_Archive.DetailsId = detailsId;
                    basicDetails_ArchiveId = (int)companyDAL.AddCompanyDetails_Archive(nHB_Details_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return detailsId;

        }

        public bool SaveAsDraft_SFBKeyFinancial(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, SFB_KeyFinancialsEntity keyFinancialsEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                SFB_KeyFinancials_Archive SFB_KeyFinancials_Archive = new SFB_KeyFinancials_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,

                    UserId = userId,

                    PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                    PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                    NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                    NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                    Currency1 = keyFinancialsEntity.Currency1,
                    Currency2 = keyFinancialsEntity.Currency2,
                    NetWorth1 = keyFinancialsEntity.NetWorth1,
                    NetWorth2 = keyFinancialsEntity.NetWorth2,
                    TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                    TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                    CreditDepositRatioPer1 = keyFinancialsEntity.CreditDepositRatioPer1,
                    CreditDepositRatioPer2 = keyFinancialsEntity.CreditDepositRatioPer2,
                    ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                    ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                    CASAPer1 = keyFinancialsEntity.CASAPer1,
                    CASAPer2 = keyFinancialsEntity.CASAPer2,
                    PrioritySectorAdvancesPer1 = keyFinancialsEntity.PrioritySectorAdvancesPer1,
                    PrioritySectorAdvancesPer2 = keyFinancialsEntity.PrioritySectorAdvancesPer2,
                    ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                    ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                    CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                    CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                    CRARPer1 = keyFinancialsEntity.CRARPer1,
                    CRARPer2 = keyFinancialsEntity.CRARPer2,
                    Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                    Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                    CommonEquityTierPer1 = keyFinancialsEntity.CommonEquityTierPer1,
                    CommonEquityTierPer2 = keyFinancialsEntity.CommonEquityTierPer2,
                    NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                    NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                    GrowthinDepositsPer1 = keyFinancialsEntity.GrowthinDepositsPer1,
                    GrowthinDepositsPer2 = keyFinancialsEntity.GrowthinDepositsPer2,
                    GrowthinAdvances1 = keyFinancialsEntity.GrowthinAdvancesPer1,
                    GrowthinAdvances2 = keyFinancialsEntity.GrowthinAdvancesPer2,
                    TotalNumOfBranches1 = keyFinancialsEntity.TotalNumOfBranches1,
                    TotalNumOfBranches2 = keyFinancialsEntity.TotalNumOfBranches2,
                    GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                    GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                    AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                    AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                    DiversityofIncomePer1 = keyFinancialsEntity.DiversityofIncomePer1,
                    DiversityofIncomePer2 = keyFinancialsEntity.DiversityofIncomePer2,
                    TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                    TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                    TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                    TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                    AdvancesToSensitiveSectorPer1 = keyFinancialsEntity.AdvancesToSensitiveSectorPer1,
                    AdvancesToSensitiveSectorPer2 = keyFinancialsEntity.AdvancesToSensitiveSectorPer2,
                    CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                    CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                    CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                    CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                    PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                    PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                    //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                    //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                    LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                    LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                    Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                    Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                    NetStableFundingRatioPer1 = keyFinancialsEntity.NetStableFundingRatioPer1,
                    NetStableFundingRatioPer2 = keyFinancialsEntity.NetStableFundingRatioPer2,
                    GearingPer1 = keyFinancialsEntity.GearingPer1,
                    GearingPer2 = keyFinancialsEntity.GearingPer2,
                    LeverageRatioPer1 = keyFinancialsEntity.LeverageRatioPer1,
                    LeverageRatioPer2 = keyFinancialsEntity.LeverageRatioPer2,
                    BusinessEmployee1 = keyFinancialsEntity.BusinessEmployee1,
                    BusinessEmployee2 = keyFinancialsEntity.BusinessEmployee2,
                    RatioOfSecuredAdvancesToTotalAdvances1 = keyFinancialsEntity.RatioOfSecuredAdvancesToTotalAdvancesPer1,
                    RatioOfSecuredAdvancesToTotalAdvances2 = keyFinancialsEntity.RatioOfSecuredAdvancesToTotalAdvancesPer2,
                    PresenceInStatesAndUT1 = keyFinancialsEntity.PresenceInStatesAndUT1,
                    PresenceInStatesAndUT2 = keyFinancialsEntity.PresenceInStatesAndUT2,
                    RatioOfDepositsToTotalLiabilities1 = keyFinancialsEntity.RatioOfDepositsToTotalLiabilitiesPer1,
                    RatioOfDepositsToTotalLiabilities2 = keyFinancialsEntity.RatioOfDepositsToTotalLiabilitiesPer2,
                    YearsPassedSinceCommencement1 = keyFinancialsEntity.YearsPassedSinceCommencement1,
                    YearsPassedSinceCommencement2 = keyFinancialsEntity.YearsPassedSinceCommencement2,
                    PromoterShareholding1 = keyFinancialsEntity.PromoterShareholdingPer1,
                    PromoterShareholding2 = keyFinancialsEntity.PromoterShareholdingPer2,
                    ProvisioningCoverageRatioPer1 = keyFinancialsEntity.ProvisioningCoverageRatioPer1,
                    ProvisioningCoverageRatioPer2 = keyFinancialsEntity.ProvisioningCoverageRatioPer2,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    IsFinal = false,
                };

                SFB_KeyFinancials SFB_KeyFinancials = new SFB_KeyFinancials
                {
                    DetailsId = detailID,
                    PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                    PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                    NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                    NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                    Currency1 = keyFinancialsEntity.Currency1,
                    Currency2 = keyFinancialsEntity.Currency2,
                    NetWorth1 = keyFinancialsEntity.NetWorth1,
                    NetWorth2 = keyFinancialsEntity.NetWorth2,
                    TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                    TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                    CreditDepositRatioPer1 = keyFinancialsEntity.CreditDepositRatioPer1,
                    CreditDepositRatioPer2 = keyFinancialsEntity.CreditDepositRatioPer2,
                    ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                    ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                    CASAPer1 = keyFinancialsEntity.CASAPer1,
                    CASAPer2 = keyFinancialsEntity.CASAPer2,
                    PrioritySectorAdvancesPer1 = keyFinancialsEntity.PrioritySectorAdvancesPer1,
                    PrioritySectorAdvancesPer2 = keyFinancialsEntity.PrioritySectorAdvancesPer2,
                    ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                    ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                    CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                    CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                    CRARPer1 = keyFinancialsEntity.CRARPer1,
                    CRARPer2 = keyFinancialsEntity.CRARPer2,
                    Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                    Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                    CommonEquityTierPer1 = keyFinancialsEntity.CommonEquityTierPer1,
                    CommonEquityTierPer2 = keyFinancialsEntity.CommonEquityTierPer2,
                    NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                    NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                    GrowthinDepositsPer1 = keyFinancialsEntity.GrowthinDepositsPer1,
                    GrowthinDepositsPer2 = keyFinancialsEntity.GrowthinDepositsPer2,
                    GrowthinAdvances1 = keyFinancialsEntity.GrowthinAdvancesPer1,
                    GrowthinAdvances2 = keyFinancialsEntity.GrowthinAdvancesPer2,
                    TotalNumOfBranches1 = keyFinancialsEntity.TotalNumOfBranches1,
                    TotalNumOfBranches2 = keyFinancialsEntity.TotalNumOfBranches2,
                    GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                    GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                    AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                    AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                    DiversityofIncomePer1 = keyFinancialsEntity.DiversityofIncomePer1,
                    DiversityofIncomePer2 = keyFinancialsEntity.DiversityofIncomePer2,
                    TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                    TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                    TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                    TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                    AdvancesToSensitiveSectorPer1 = keyFinancialsEntity.AdvancesToSensitiveSectorPer1,
                    AdvancesToSensitiveSectorPer2 = keyFinancialsEntity.AdvancesToSensitiveSectorPer2,
                    CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                    CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                    CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                    CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                    PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                    PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                    //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                    //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                    LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                    LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                    Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                    Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                    NetStableFundingRatioPer1 = keyFinancialsEntity.NetStableFundingRatioPer1,
                    NetStableFundingRatioPer2 = keyFinancialsEntity.NetStableFundingRatioPer2,
                    GearingPer1 = keyFinancialsEntity.GearingPer1,
                    GearingPer2 = keyFinancialsEntity.GearingPer2,
                    LeverageRatioPer1 = keyFinancialsEntity.LeverageRatioPer1,
                    LeverageRatioPer2 = keyFinancialsEntity.LeverageRatioPer2,
                    BusinessEmployee1 = keyFinancialsEntity.BusinessEmployee1,
                    BusinessEmployee2 = keyFinancialsEntity.BusinessEmployee2,
                    RatioOfSecuredAdvancesToTotalAdvances1 = keyFinancialsEntity.RatioOfSecuredAdvancesToTotalAdvancesPer1,
                    RatioOfSecuredAdvancesToTotalAdvances2 = keyFinancialsEntity.RatioOfSecuredAdvancesToTotalAdvancesPer2,
                    PresenceInStatesAndUT1 = keyFinancialsEntity.PresenceInStatesAndUT1,
                    PresenceInStatesAndUT2 = keyFinancialsEntity.PresenceInStatesAndUT2,
                    RatioOfDepositsToTotalLiabilities1 = keyFinancialsEntity.RatioOfDepositsToTotalLiabilitiesPer1,
                    RatioOfDepositsToTotalLiabilities2 = keyFinancialsEntity.RatioOfDepositsToTotalLiabilitiesPer2,
                    YearsPassedSinceCommencement1 = keyFinancialsEntity.YearsPassedSinceCommencement1,
                    YearsPassedSinceCommencement2 = keyFinancialsEntity.YearsPassedSinceCommencement2,
                    PromoterShareholding1 = keyFinancialsEntity.PromoterShareholdingPer1,
                    PromoterShareholding2 = keyFinancialsEntity.PromoterShareholdingPer2,
                    ProvisioningCoverageRatioPer1 = keyFinancialsEntity.ProvisioningCoverageRatioPer1,
                    ProvisioningCoverageRatioPer2 = keyFinancialsEntity.ProvisioningCoverageRatioPer2,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    if (SFB_KeyFinancials != null && CheckIfAlreadyExists_SFBKeyFinancial(detailID) == false)
                    {
                        try
                        {
                            status = Add_SFBKeyFinancial(SFB_KeyFinancials);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }
                    else
                    {
                        try
                        {
                            SFB_KeyFinancials SFB_KeyFinancials_Update = dbContext.SFB_KeyFinancials.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (SFB_KeyFinancials_Update != null)
                            {
                                SFB_KeyFinancials_Update.PeriodEndingDate1 = SFB_KeyFinancials.PeriodEndingDate1;
                                SFB_KeyFinancials_Update.PeriodEndingDate2 = SFB_KeyFinancials.PeriodEndingDate2;
                                SFB_KeyFinancials_Update.NoofMonthsPeriod1 = SFB_KeyFinancials.NoofMonthsPeriod1;
                                SFB_KeyFinancials_Update.NoofMonthsPeriod2 = SFB_KeyFinancials.NoofMonthsPeriod2;
                                SFB_KeyFinancials_Update.Currency1 = SFB_KeyFinancials.Currency1;
                                SFB_KeyFinancials_Update.Currency2 = SFB_KeyFinancials.Currency2;
                                SFB_KeyFinancials_Update.NetWorth1 = SFB_KeyFinancials.NetWorth1;
                                SFB_KeyFinancials_Update.NetWorth2 = SFB_KeyFinancials.NetWorth2;
                                SFB_KeyFinancials_Update.TotalAssets1 = SFB_KeyFinancials.TotalAssets1;
                                SFB_KeyFinancials_Update.TotalAssets2 = SFB_KeyFinancials.TotalAssets2;
                                SFB_KeyFinancials_Update.CreditDepositRatioPer1 = SFB_KeyFinancials.CreditDepositRatioPer1;
                                SFB_KeyFinancials_Update.CreditDepositRatioPer2 = SFB_KeyFinancials.CreditDepositRatioPer2;
                                SFB_KeyFinancials_Update.ReturnOnAssetsPer1 = SFB_KeyFinancials.ReturnOnAssetsPer1;
                                SFB_KeyFinancials_Update.ReturnOnAssetsPer2 = SFB_KeyFinancials.ReturnOnAssetsPer2;
                                SFB_KeyFinancials_Update.CASAPer1 = SFB_KeyFinancials.CASAPer1;
                                SFB_KeyFinancials_Update.CASAPer2 = SFB_KeyFinancials.CASAPer2;
                                SFB_KeyFinancials_Update.PrioritySectorAdvancesPer1 = SFB_KeyFinancials.PrioritySectorAdvancesPer1;
                                SFB_KeyFinancials_Update.PrioritySectorAdvancesPer2 = SFB_KeyFinancials.PrioritySectorAdvancesPer2;
                                SFB_KeyFinancials_Update.ReturnOnNetWorthPer1 = SFB_KeyFinancials.ReturnOnNetWorthPer1;
                                SFB_KeyFinancials_Update.ReturnOnNetWorthPer2 = SFB_KeyFinancials.ReturnOnNetWorthPer2;
                                SFB_KeyFinancials_Update.CostOfFundsPer1 = SFB_KeyFinancials.CostOfFundsPer1;
                                SFB_KeyFinancials_Update.CostOfFundsPer2 = SFB_KeyFinancials.CostOfFundsPer2;
                                SFB_KeyFinancials_Update.CRARPer1 = SFB_KeyFinancials.CRARPer1;
                                SFB_KeyFinancials_Update.CRARPer2 = SFB_KeyFinancials.CRARPer2;
                                SFB_KeyFinancials_Update.Tier1Per1 = SFB_KeyFinancials.Tier1Per1;
                                SFB_KeyFinancials_Update.Tier1Per2 = SFB_KeyFinancials.Tier1Per2;
                                SFB_KeyFinancials_Update.CommonEquityTierPer1 = SFB_KeyFinancials.CommonEquityTierPer1;
                                SFB_KeyFinancials_Update.CommonEquityTierPer2 = SFB_KeyFinancials.CommonEquityTierPer2;
                                SFB_KeyFinancials_Update.NetNPAPer1 = SFB_KeyFinancials.NetNPAPer1;
                                SFB_KeyFinancials_Update.NetNPAPer2 = SFB_KeyFinancials.NetNPAPer2;
                                SFB_KeyFinancials_Update.GrowthinDepositsPer1 = SFB_KeyFinancials.GrowthinDepositsPer1;
                                SFB_KeyFinancials_Update.GrowthinDepositsPer2 = SFB_KeyFinancials.GrowthinDepositsPer2;
                                SFB_KeyFinancials_Update.GrowthinAdvances1 = SFB_KeyFinancials.GrowthinAdvances1;
                                SFB_KeyFinancials_Update.GrowthinAdvances2 = SFB_KeyFinancials.GrowthinAdvances2;
                                SFB_KeyFinancials_Update.TotalNumOfBranches1 = SFB_KeyFinancials.TotalNumOfBranches1;
                                SFB_KeyFinancials_Update.TotalNumOfBranches2 = SFB_KeyFinancials.TotalNumOfBranches2;
                                SFB_KeyFinancials_Update.GrossNPAPer1 = SFB_KeyFinancials.GrossNPAPer1;
                                SFB_KeyFinancials_Update.GrossNPAPer2 = SFB_KeyFinancials.GrossNPAPer2;
                                SFB_KeyFinancials_Update.AdditioninNPAsAdvancesPer1 = SFB_KeyFinancials.AdditioninNPAsAdvancesPer1;
                                SFB_KeyFinancials_Update.AdditioninNPAsAdvancesPer2 = SFB_KeyFinancials.AdditioninNPAsAdvancesPer2;
                                SFB_KeyFinancials_Update.DiversityofIncomePer1 = SFB_KeyFinancials.DiversityofIncomePer1;
                                SFB_KeyFinancials_Update.DiversityofIncomePer2 = SFB_KeyFinancials.DiversityofIncomePer2;
                                SFB_KeyFinancials_Update.TangibleNWNetNPA1 = SFB_KeyFinancials.TangibleNWNetNPA1;
                                SFB_KeyFinancials_Update.TangibleNWNetNPA2 = SFB_KeyFinancials.TangibleNWNetNPA2;
                                SFB_KeyFinancials_Update.TotalContLiabilityTotalAssetsPer1 = SFB_KeyFinancials.TotalContLiabilityTotalAssetsPer1;
                                SFB_KeyFinancials_Update.TotalContLiabilityTotalAssetsPer2 = SFB_KeyFinancials.TotalContLiabilityTotalAssetsPer2;
                                SFB_KeyFinancials_Update.AdvancesToSensitiveSectorPer1 = SFB_KeyFinancials.AdvancesToSensitiveSectorPer1;
                                SFB_KeyFinancials_Update.AdvancesToSensitiveSectorPer2 = SFB_KeyFinancials.AdvancesToSensitiveSectorPer2;
                                SFB_KeyFinancials_Update.CosttoIncomePer1 = SFB_KeyFinancials.CosttoIncomePer1;
                                SFB_KeyFinancials_Update.CosttoIncomePer2 = SFB_KeyFinancials.CosttoIncomePer2;
                                SFB_KeyFinancials_Update.CreditCostPer1 = SFB_KeyFinancials.CreditCostPer1;
                                SFB_KeyFinancials_Update.CreditCostPer2 = SFB_KeyFinancials.CreditCostPer2;
                                SFB_KeyFinancials_Update.PPOPCreditCost1 = SFB_KeyFinancials.PPOPCreditCost1;
                                SFB_KeyFinancials_Update.PPOPCreditCost2 = SFB_KeyFinancials.PPOPCreditCost2;
                                SFB_KeyFinancials_Update.ALMGapin6monthsbucketPer1 = SFB_KeyFinancials.ALMGapin6monthsbucketPer1;
                                SFB_KeyFinancials_Update.ALMGapin6monthsbucketPer2 = SFB_KeyFinancials.ALMGapin6monthsbucketPer2;
                                SFB_KeyFinancials_Update.LiquidityCoverageRatioPer1 = SFB_KeyFinancials.LiquidityCoverageRatioPer1;
                                SFB_KeyFinancials_Update.LiquidityCoverageRatioPer2 = SFB_KeyFinancials.LiquidityCoverageRatioPer2;
                                SFB_KeyFinancials_Update.GearingPer1 = SFB_KeyFinancials.GearingPer1;
                                SFB_KeyFinancials_Update.GearingPer2 = SFB_KeyFinancials.GearingPer2;
                                SFB_KeyFinancials_Update.Top20ConcentrationPer1 = SFB_KeyFinancials.Top20ConcentrationPer1;
                                SFB_KeyFinancials_Update.Top20ConcentrationPer2 = SFB_KeyFinancials.Top20ConcentrationPer2;
                                SFB_KeyFinancials_Update.NetStableFundingRatioPer1 = SFB_KeyFinancials.NetStableFundingRatioPer1;
                                SFB_KeyFinancials_Update.NetStableFundingRatioPer2 = SFB_KeyFinancials.NetStableFundingRatioPer2;
                                SFB_KeyFinancials_Update.LeverageRatioPer1 = SFB_KeyFinancials.LeverageRatioPer1;
                                SFB_KeyFinancials_Update.LeverageRatioPer2 = SFB_KeyFinancials.LeverageRatioPer2;
                                SFB_KeyFinancials_Update.BusinessEmployee1 = SFB_KeyFinancials.BusinessEmployee1;
                                SFB_KeyFinancials_Update.BusinessEmployee2 = SFB_KeyFinancials.BusinessEmployee2;
                                SFB_KeyFinancials_Update.RatioOfSecuredAdvancesToTotalAdvances1 = SFB_KeyFinancials.RatioOfSecuredAdvancesToTotalAdvances1;
                                SFB_KeyFinancials_Update.RatioOfSecuredAdvancesToTotalAdvances2 = SFB_KeyFinancials.RatioOfSecuredAdvancesToTotalAdvances2;
                                SFB_KeyFinancials_Update.PresenceInStatesAndUT1 = SFB_KeyFinancials.PresenceInStatesAndUT1;
                                SFB_KeyFinancials_Update.PresenceInStatesAndUT2 = SFB_KeyFinancials.PresenceInStatesAndUT2;
                                SFB_KeyFinancials_Update.RatioOfDepositsToTotalLiabilities1 = SFB_KeyFinancials.RatioOfDepositsToTotalLiabilities1;
                                SFB_KeyFinancials_Update.RatioOfDepositsToTotalLiabilities2 = SFB_KeyFinancials.RatioOfDepositsToTotalLiabilities2;
                                SFB_KeyFinancials_Update.YearsPassedSinceCommencement1 = SFB_KeyFinancials.YearsPassedSinceCommencement1;
                                SFB_KeyFinancials_Update.YearsPassedSinceCommencement2 = SFB_KeyFinancials.YearsPassedSinceCommencement2;
                                SFB_KeyFinancials_Update.PromoterShareholding1 = SFB_KeyFinancials.PromoterShareholding1;
                                SFB_KeyFinancials_Update.PromoterShareholding2 = SFB_KeyFinancials.PromoterShareholding2;
                                SFB_KeyFinancials_Update.ProvisioningCoverageRatioPer1 = SFB_KeyFinancials.ProvisioningCoverageRatioPer1;
                                SFB_KeyFinancials_Update.ProvisioningCoverageRatioPer2 = SFB_KeyFinancials.ProvisioningCoverageRatioPer2;

                                SFB_KeyFinancials_Update.CreatedBy = SFB_KeyFinancials.CreatedBy;
                                SFB_KeyFinancials_Update.CreatedDateTime = SFB_KeyFinancials.CreatedDateTime;
                                SFB_KeyFinancials_Update.UpdatedBy = SFB_KeyFinancials.UpdatedBy;
                                SFB_KeyFinancials_Update.UpdatedDateTime = SFB_KeyFinancials.UpdatedDateTime;

                                dbContext.SaveChanges();
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return false;
                            }
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            return false;
                        }
                    }

                    status = Add_SFBKeyFinancial_Archive(SFB_KeyFinancials_Archive);
                    dbContextTransaction.Commit();
                }

            }

            return true;

        }

        public bool Add_SFBKeyFinancial(SFB_KeyFinancials SFB_KeyFinancials)
        {
            try
            {
                dbContext.SFB_KeyFinancials.Add(SFB_KeyFinancials);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_SFBKeyFinancial_Archive(SFB_KeyFinancials_Archive SFB_KeyFinancials_Archive)
        {
            try
            {
                dbContext.SFB_KeyFinancials_Archive.Add(SFB_KeyFinancials_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_SFBSubjectiveParameters(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, SFB_SubjectiveParametersEntity subjectiveParametersEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                SFB_SubjectiveParameters_Archive SFB_SubjectiveParameters_Archive = new SFB_SubjectiveParameters_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,

                    //PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank,
                    ExternalRating = subjectiveParametersEntity.ExternalRating,
                    IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                    BusinessModel = subjectiveParametersEntity.BusinessModel,
                    ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                    //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                    AdverseNews = subjectiveParametersEntity.AdverseNews,
                    CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                    AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                    AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                    NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                    //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                    NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                    LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                    CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                    NPASysGen = subjectiveParametersEntity.NPASysGen,
                    NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                    CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                    NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                    SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                    QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                    DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                SFB_SubjectiveParameters SFB_SubjectiveParameters = new SFB_SubjectiveParameters
                {
                    DetailsId = detailID,

                    //PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank,
                    ExternalRating = subjectiveParametersEntity.ExternalRating,

                    IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                    BusinessModel = subjectiveParametersEntity.BusinessModel,
                    ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                    //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                    AdverseNews = subjectiveParametersEntity.AdverseNews,
                    CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                    AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                    AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                    NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                    //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                    NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                    LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                    CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                    NPASysGen = subjectiveParametersEntity.NPASysGen,
                    NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                    CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                    NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                    SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                    QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                    DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    if (SFB_SubjectiveParameters != null && CheckIfAlreadyExists_SFBSubjectiveParameters(detailID) == false)
                    {
                        try
                        {
                            status = Add_SFBSubjectiveParameter(SFB_SubjectiveParameters);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }
                    else
                    {
                        try
                        {
                            SFB_SubjectiveParameters SFB_SubjectiveParameters_Update = dbContext.SFB_SubjectiveParameters.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (SFB_SubjectiveParameters_Update != null)
                            {
                                //SFB_SubjectiveParameters_Update.PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank;
                                SFB_SubjectiveParameters_Update.ExternalRating = subjectiveParametersEntity.ExternalRating;
                                SFB_SubjectiveParameters_Update.IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore;
                                SFB_SubjectiveParameters_Update.BusinessModel = subjectiveParametersEntity.BusinessModel;
                                SFB_SubjectiveParameters_Update.ManagementQuality = subjectiveParametersEntity.ManagementQuality;
                                //SFB_SubjectiveParameters_Update.UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards;
                                SFB_SubjectiveParameters_Update.AdverseNews = subjectiveParametersEntity.AdverseNews;

                                SFB_SubjectiveParameters_Update.CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility;
                                SFB_SubjectiveParameters_Update.AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime;
                                SFB_SubjectiveParameters_Update.AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems;
                                SFB_SubjectiveParameters_Update.NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm;
                                //SFB_SubjectiveParameters_Update.AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms;
                                SFB_SubjectiveParameters_Update.NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm;
                                SFB_SubjectiveParameters_Update.LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran;
                                SFB_SubjectiveParameters_Update.CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData;
                                SFB_SubjectiveParameters_Update.NPASysGen = subjectiveParametersEntity.NPASysGen;
                                SFB_SubjectiveParameters_Update.NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting;
                                SFB_SubjectiveParameters_Update.CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement;
                                SFB_SubjectiveParameters_Update.NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess;
                                SFB_SubjectiveParameters_Update.SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort;
                                SFB_SubjectiveParameters_Update.QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor;
                                SFB_SubjectiveParameters_Update.DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders;

                                SFB_SubjectiveParameters_Update.CreatedBy = subjectiveParametersEntity.CreatedBy;
                                SFB_SubjectiveParameters_Update.CreatedDateTime = subjectiveParametersEntity.CreatedDateTime;
                                SFB_SubjectiveParameters_Update.UpdatedBy = subjectiveParametersEntity.UpdatedBy;
                                SFB_SubjectiveParameters_Update.UpdatedDateTime = subjectiveParametersEntity.UpdatedDateTime;

                                dbContext.SaveChanges();
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return false;
                            }
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            return false;
                        }
                    }

                    status = Add_SFBSubjectiveParameter_Archive(SFB_SubjectiveParameters_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return true;

        }

        public bool Add_SFBSubjectiveParameter(SFB_SubjectiveParameters SFB_SubjectiveParameters)
        {
            try
            {
                dbContext.SFB_SubjectiveParameters.Add(SFB_SubjectiveParameters);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_SFBSubjectiveParameter_Archive(SFB_SubjectiveParameters_Archive SFB_SubjectiveParameters_Archive)
        {
            try
            {
                dbContext.SFB_SubjectiveParameters_Archive.Add(SFB_SubjectiveParameters_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool SaveAsDraft_SFBIndustryExposure(int userId, int roleId, int detailID, short logID, DateTime CreatedDateTime, SFB_IndustryExpsoureEntity sfb_IndustryExpsoureEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                SFB_IndustryExpsoure_Archive SFB_IndustryExpsoure_Archive = new SFB_IndustryExpsoure_Archive
                {
                    DetailsId = detailID,
                    LogId = logID,

                    AgricultureAlliedActivities1 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivities1,
                    AgricultureAlliedActivitiesPer2 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivitiesPer2,
                    AgricultureAlliedActivities3 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivities3,
                    MinigQuaring1 = sfb_IndustryExpsoureEntity.MinigQuaring1,
                    MinigQuaringPer2 = sfb_IndustryExpsoureEntity.MinigQuaringPer2,
                    MinigQuaring3 = sfb_IndustryExpsoureEntity.MinigQuaring3,
                    FoodFoodProcessing1 = sfb_IndustryExpsoureEntity.FoodFoodProcessing1,
                    FoodFoodProcessingPer2 = sfb_IndustryExpsoureEntity.FoodFoodProcessingPer2,
                    FoodFoodProcessing3 = sfb_IndustryExpsoureEntity.FoodFoodProcessing3,
                    Textiles1 = sfb_IndustryExpsoureEntity.Textiles1,
                    TextilesPer2 = sfb_IndustryExpsoureEntity.TextilesPer2,
                    Textiles3 = sfb_IndustryExpsoureEntity.Textiles3,
                    MaterialtheirProducts1 = sfb_IndustryExpsoureEntity.MaterialtheirProducts1,
                    MaterialtheirProductsPer2 = sfb_IndustryExpsoureEntity.MaterialtheirProductsPer2,
                    MaterialtheirProducts3 = sfb_IndustryExpsoureEntity.MaterialtheirProducts3,
                    PetroleumCoalProductsNuclearFuels1 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels1,
                    PetroleumCoalProductsNuclearFuelsPer2 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuelsPer2,
                    PetroleumCoalProductsNuclearFuels3 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels3,
                    ChemicalChemicalProducts1 = sfb_IndustryExpsoureEntity.ChemicalChemicalProducts1,
                    ChemicalChemicalProductsPer2 = sfb_IndustryExpsoureEntity.ChemicalChemicalProductsPer2,
                    ChemicalChemicalProducts3 = sfb_IndustryExpsoureEntity.ChemicalChemicalProducts3,
                    CementCementProducts1 = sfb_IndustryExpsoureEntity.CementCementProducts1,
                    CementCementProductsPer2 = sfb_IndustryExpsoureEntity.CementCementProductsPer2,
                    CementCementProducts3 = sfb_IndustryExpsoureEntity.CementCementProducts3,
                    BasicMetalMetalProduct1 = sfb_IndustryExpsoureEntity.BasicMetalMetalProduct1,
                    BasicMetalMetalProductPer2 = sfb_IndustryExpsoureEntity.BasicMetalMetalProductPer2,
                    BasicMetalMetalProduct3 = sfb_IndustryExpsoureEntity.BasicMetalMetalProduct3,
                    AllEngineering1 = sfb_IndustryExpsoureEntity.AllEngineering1,
                    AllEngineeringPer2 = sfb_IndustryExpsoureEntity.AllEngineeringPer2,
                    AllEngineering3 = sfb_IndustryExpsoureEntity.AllEngineering3,
                    AutomobileAncillary1 = sfb_IndustryExpsoureEntity.AutomobileAncillary1,
                    AutomobileAncillaryPer2 = sfb_IndustryExpsoureEntity.AutomobileAncillaryPer2,
                    AutomobileAncillary3 = sfb_IndustryExpsoureEntity.AutomobileAncillary3,
                    GemsJewellery1 = sfb_IndustryExpsoureEntity.GemsJewellery1,
                    GemsJewelleryPer2 = sfb_IndustryExpsoureEntity.GemsJewelleryPer2,
                    GemsJewellery3 = sfb_IndustryExpsoureEntity.GemsJewellery3,
                    Construction1 = sfb_IndustryExpsoureEntity.Construction1,
                    ConstructionPer2 = sfb_IndustryExpsoureEntity.ConstructionPer2,
                    Construction3 = sfb_IndustryExpsoureEntity.Construction3,
                    Power1 = sfb_IndustryExpsoureEntity.Power1,
                    PowerPer2 = sfb_IndustryExpsoureEntity.PowerPer2,
                    Power3 = sfb_IndustryExpsoureEntity.Power3,
                    Telecommunication1 = sfb_IndustryExpsoureEntity.Telecommunication1,
                    TelecommunicationPer2 = sfb_IndustryExpsoureEntity.TelecommunicationPer2,
                    Telecommunication3 = sfb_IndustryExpsoureEntity.Telecommunication3,
                    RestoftheInfrastructure1 = sfb_IndustryExpsoureEntity.RestoftheInfrastructure1,
                    RestoftheInfrastructurePer2 = sfb_IndustryExpsoureEntity.RestoftheInfrastructurePer2,
                    RestoftheInfrastructure3 = sfb_IndustryExpsoureEntity.RestoftheInfrastructure3,
                    NBFCs1 = sfb_IndustryExpsoureEntity.NBFCs1,
                    NBFCsPer2 = sfb_IndustryExpsoureEntity.NBFCsPer2,
                    NBFCs3 = sfb_IndustryExpsoureEntity.NBFCs3,
                    OtherIndustries1 = sfb_IndustryExpsoureEntity.OtherIndustries1,
                    OtherIndustriesPer2 = sfb_IndustryExpsoureEntity.OtherIndustriesPer2,
                    OtherIndustries3 = sfb_IndustryExpsoureEntity.OtherIndustries3,
                    Retail1 = sfb_IndustryExpsoureEntity.Retail1,
                    RetailPer2 = sfb_IndustryExpsoureEntity.RetailPer2,
                    Retail3 = sfb_IndustryExpsoureEntity.Retail3,
                    MicroFinance1 = sfb_IndustryExpsoureEntity.MicroFinance1,
                    MicroFinancePer2 = sfb_IndustryExpsoureEntity.MicroFinancePer2,
                    MicroFinance3 = sfb_IndustryExpsoureEntity.MicroFinance3,
                    TotalAdvances = sfb_IndustryExpsoureEntity.TotalAdvances,

                    CreatedBy = userId,
                    CreatedDateTime = DateTime.Now,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now,
                    //IsFinal = false,
                };

                SFB_IndustryExpsoure SFB_IndustryExpsoure = new SFB_IndustryExpsoure
                {
                    DetailsId = detailID,


                    AgricultureAlliedActivities1 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivities1,
                    AgricultureAlliedActivitiesPer2 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivitiesPer2,
                    AgricultureAlliedActivities3 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivities3,
                    MinigQuaring1 = sfb_IndustryExpsoureEntity.MinigQuaring1,
                    MinigQuaringPer2 = sfb_IndustryExpsoureEntity.MinigQuaringPer2,
                    MinigQuaring3 = sfb_IndustryExpsoureEntity.MinigQuaring3,
                    FoodFoodProcessing1 = sfb_IndustryExpsoureEntity.FoodFoodProcessing1,
                    FoodFoodProcessingPer2 = sfb_IndustryExpsoureEntity.FoodFoodProcessingPer2,
                    FoodFoodProcessing3 = sfb_IndustryExpsoureEntity.FoodFoodProcessing3,
                    Textiles1 = sfb_IndustryExpsoureEntity.Textiles1,
                    TextilesPer2 = sfb_IndustryExpsoureEntity.TextilesPer2,
                    Textiles3 = sfb_IndustryExpsoureEntity.Textiles3,
                    MaterialtheirProducts1 = sfb_IndustryExpsoureEntity.MaterialtheirProducts1,
                    MaterialtheirProductsPer2 = sfb_IndustryExpsoureEntity.MaterialtheirProductsPer2,
                    MaterialtheirProducts3 = sfb_IndustryExpsoureEntity.MaterialtheirProducts3,
                    PetroleumCoalProductsNuclearFuels1 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels1,
                    PetroleumCoalProductsNuclearFuelsPer2 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuelsPer2,
                    PetroleumCoalProductsNuclearFuels3 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels3,
                    ChemicalChemicalProducts1 = sfb_IndustryExpsoureEntity.ChemicalChemicalProducts1,
                    ChemicalChemicalProductsPer2 = sfb_IndustryExpsoureEntity.ChemicalChemicalProductsPer2,
                    ChemicalChemicalProducts3 = sfb_IndustryExpsoureEntity.ChemicalChemicalProducts3,
                    CementCementProducts1 = sfb_IndustryExpsoureEntity.CementCementProducts1,
                    CementCementProductsPer2 = sfb_IndustryExpsoureEntity.CementCementProductsPer2,
                    CementCementProducts3 = sfb_IndustryExpsoureEntity.CementCementProducts3,
                    BasicMetalMetalProduct1 = sfb_IndustryExpsoureEntity.BasicMetalMetalProduct1,
                    BasicMetalMetalProductPer2 = sfb_IndustryExpsoureEntity.BasicMetalMetalProductPer2,
                    BasicMetalMetalProduct3 = sfb_IndustryExpsoureEntity.BasicMetalMetalProduct3,
                    AllEngineering1 = sfb_IndustryExpsoureEntity.AllEngineering1,
                    AllEngineeringPer2 = sfb_IndustryExpsoureEntity.AllEngineeringPer2,
                    AllEngineering3 = sfb_IndustryExpsoureEntity.AllEngineering3,
                    AutomobileAncillary1 = sfb_IndustryExpsoureEntity.AutomobileAncillary1,
                    AutomobileAncillaryPer2 = sfb_IndustryExpsoureEntity.AutomobileAncillaryPer2,
                    AutomobileAncillary3 = sfb_IndustryExpsoureEntity.AutomobileAncillary3,
                    GemsJewellery1 = sfb_IndustryExpsoureEntity.GemsJewellery1,
                    GemsJewelleryPer2 = sfb_IndustryExpsoureEntity.GemsJewelleryPer2,
                    GemsJewellery3 = sfb_IndustryExpsoureEntity.GemsJewellery3,
                    Construction1 = sfb_IndustryExpsoureEntity.Construction1,
                    ConstructionPer2 = sfb_IndustryExpsoureEntity.ConstructionPer2,
                    Construction3 = sfb_IndustryExpsoureEntity.Construction3,
                    Power1 = sfb_IndustryExpsoureEntity.Power1,
                    PowerPer2 = sfb_IndustryExpsoureEntity.PowerPer2,
                    Power3 = sfb_IndustryExpsoureEntity.Power3,
                    Telecommunication1 = sfb_IndustryExpsoureEntity.Telecommunication1,
                    TelecommunicationPer2 = sfb_IndustryExpsoureEntity.TelecommunicationPer2,
                    Telecommunication3 = sfb_IndustryExpsoureEntity.Telecommunication3,
                    RestoftheInfrastructure1 = sfb_IndustryExpsoureEntity.RestoftheInfrastructure1,
                    RestoftheInfrastructurePer2 = sfb_IndustryExpsoureEntity.RestoftheInfrastructurePer2,
                    RestoftheInfrastructure3 = sfb_IndustryExpsoureEntity.RestoftheInfrastructure3,
                    NBFCs1 = sfb_IndustryExpsoureEntity.NBFCs1,
                    NBFCsPer2 = sfb_IndustryExpsoureEntity.NBFCsPer2,
                    NBFCs3 = sfb_IndustryExpsoureEntity.NBFCs3,
                    OtherIndustries1 = sfb_IndustryExpsoureEntity.OtherIndustries1,
                    OtherIndustriesPer2 = sfb_IndustryExpsoureEntity.OtherIndustriesPer2,
                    OtherIndustries3 = sfb_IndustryExpsoureEntity.OtherIndustries3,
                    Retail1 = sfb_IndustryExpsoureEntity.Retail1,
                    RetailPer2 = sfb_IndustryExpsoureEntity.RetailPer2,
                    Retail3 = sfb_IndustryExpsoureEntity.Retail3,
                    MicroFinance1 = sfb_IndustryExpsoureEntity.MicroFinance1,
                    MicroFinancePer2 = sfb_IndustryExpsoureEntity.MicroFinancePer2,
                    MicroFinance3 = sfb_IndustryExpsoureEntity.MicroFinance3,
                    TotalAdvances = sfb_IndustryExpsoureEntity.TotalAdvances,


                    CreatedBy = userId,
                    CreatedDateTime = CreatedDateTime,
                    UpdatedBy = userId,
                    UpdatedDateTime = DateTime.Now
                    //IsFinal = false
                };

                if (userId != 0)
                {
                    if (SFB_IndustryExpsoure != null && CheckIfAlreadyExists_SFBIndustryExpsoure(detailID) == false)
                    {
                        try
                        {
                            status = Add_SFBIndustryExpsoure(SFB_IndustryExpsoure);
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            throw exception;
                        }
                    }

                    else
                    {
                        try
                        {
                            SFB_IndustryExpsoure update = dbContext.SFB_IndustryExpsoure.Where(detail => detail.DetailsId == detailID).FirstOrDefault();
                            if (update != null)
                            {
                                update.AgricultureAlliedActivities1 = SFB_IndustryExpsoure.AgricultureAlliedActivities1;
                                update.AgricultureAlliedActivitiesPer2 = SFB_IndustryExpsoure.AgricultureAlliedActivitiesPer2;
                                update.AgricultureAlliedActivities3 = SFB_IndustryExpsoure.AgricultureAlliedActivities3;
                                update.MinigQuaring1 = SFB_IndustryExpsoure.MinigQuaring1;
                                update.MinigQuaringPer2 = SFB_IndustryExpsoure.MinigQuaringPer2;
                                update.MinigQuaring3 = SFB_IndustryExpsoure.MinigQuaring3;
                                update.FoodFoodProcessing1 = SFB_IndustryExpsoure.FoodFoodProcessing1;
                                update.FoodFoodProcessingPer2 = SFB_IndustryExpsoure.FoodFoodProcessingPer2;
                                update.FoodFoodProcessing3 = SFB_IndustryExpsoure.FoodFoodProcessing3;
                                update.Textiles1 = SFB_IndustryExpsoure.Textiles1;
                                update.TextilesPer2 = SFB_IndustryExpsoure.TextilesPer2;
                                update.Textiles3 = SFB_IndustryExpsoure.Textiles3;
                                update.MaterialtheirProducts1 = SFB_IndustryExpsoure.MaterialtheirProducts1;
                                update.MaterialtheirProductsPer2 = SFB_IndustryExpsoure.MaterialtheirProductsPer2;
                                update.MaterialtheirProducts3 = SFB_IndustryExpsoure.MaterialtheirProducts3;
                                update.PetroleumCoalProductsNuclearFuels1 = SFB_IndustryExpsoure.PetroleumCoalProductsNuclearFuels1;
                                update.PetroleumCoalProductsNuclearFuelsPer2 = SFB_IndustryExpsoure.PetroleumCoalProductsNuclearFuelsPer2;
                                update.PetroleumCoalProductsNuclearFuels3 = SFB_IndustryExpsoure.PetroleumCoalProductsNuclearFuels3;
                                update.ChemicalChemicalProducts1 = SFB_IndustryExpsoure.ChemicalChemicalProducts1;
                                update.ChemicalChemicalProductsPer2 = SFB_IndustryExpsoure.ChemicalChemicalProductsPer2;
                                update.ChemicalChemicalProducts3 = SFB_IndustryExpsoure.ChemicalChemicalProducts3;
                                update.CementCementProducts1 = SFB_IndustryExpsoure.CementCementProducts1;
                                update.CementCementProductsPer2 = SFB_IndustryExpsoure.CementCementProductsPer2;
                                update.CementCementProducts3 = SFB_IndustryExpsoure.CementCementProducts3;
                                update.BasicMetalMetalProduct1 = SFB_IndustryExpsoure.BasicMetalMetalProduct1;
                                update.BasicMetalMetalProductPer2 = SFB_IndustryExpsoure.BasicMetalMetalProductPer2;
                                update.BasicMetalMetalProduct3 = SFB_IndustryExpsoure.BasicMetalMetalProduct3;
                                update.AllEngineering1 = SFB_IndustryExpsoure.AllEngineering1;
                                update.AllEngineeringPer2 = SFB_IndustryExpsoure.AllEngineeringPer2;
                                update.AllEngineering3 = SFB_IndustryExpsoure.AllEngineering3;
                                update.AutomobileAncillary1 = SFB_IndustryExpsoure.AutomobileAncillary1;
                                update.AutomobileAncillaryPer2 = SFB_IndustryExpsoure.AutomobileAncillaryPer2;
                                update.AutomobileAncillary3 = SFB_IndustryExpsoure.AutomobileAncillary3;
                                update.GemsJewellery1 = SFB_IndustryExpsoure.GemsJewellery1;
                                update.GemsJewelleryPer2 = SFB_IndustryExpsoure.GemsJewelleryPer2;
                                update.GemsJewellery3 = SFB_IndustryExpsoure.GemsJewellery3;
                                update.Construction1 = SFB_IndustryExpsoure.Construction1;
                                update.ConstructionPer2 = SFB_IndustryExpsoure.ConstructionPer2;
                                update.Construction3 = SFB_IndustryExpsoure.Construction3;
                                update.Power1 = SFB_IndustryExpsoure.Power1;
                                update.PowerPer2 = SFB_IndustryExpsoure.PowerPer2;
                                update.Power3 = SFB_IndustryExpsoure.Power3;
                                update.Telecommunication1 = SFB_IndustryExpsoure.Telecommunication1;
                                update.TelecommunicationPer2 = SFB_IndustryExpsoure.TelecommunicationPer2;
                                update.Telecommunication3 = SFB_IndustryExpsoure.Telecommunication3;
                                update.RestoftheInfrastructure1 = SFB_IndustryExpsoure.RestoftheInfrastructure1;
                                update.RestoftheInfrastructurePer2 = SFB_IndustryExpsoure.RestoftheInfrastructurePer2;
                                update.RestoftheInfrastructure3 = SFB_IndustryExpsoure.RestoftheInfrastructure3;
                                update.NBFCs1 = SFB_IndustryExpsoure.NBFCs1;
                                update.NBFCsPer2 = SFB_IndustryExpsoure.NBFCsPer2;
                                update.NBFCs3 = SFB_IndustryExpsoure.NBFCs3;
                                update.OtherIndustries1 = SFB_IndustryExpsoure.OtherIndustries1;
                                update.OtherIndustriesPer2 = SFB_IndustryExpsoure.OtherIndustriesPer2;
                                update.OtherIndustries3 = SFB_IndustryExpsoure.OtherIndustries3;
                                update.Retail1 = SFB_IndustryExpsoure.Retail1;
                                update.RetailPer2 = SFB_IndustryExpsoure.RetailPer2;
                                update.Retail3 = SFB_IndustryExpsoure.Retail3;
                                update.MicroFinance1 = SFB_IndustryExpsoure.MicroFinance1;
                                update.MicroFinancePer2 = SFB_IndustryExpsoure.MicroFinancePer2;
                                update.MicroFinance3 = SFB_IndustryExpsoure.MicroFinance3;
                                update.TotalAdvances = SFB_IndustryExpsoure.TotalAdvances;

                                update.CreatedBy = SFB_IndustryExpsoure.CreatedBy;
                                update.CreatedDateTime = SFB_IndustryExpsoure.CreatedDateTime;
                                update.UpdatedBy = SFB_IndustryExpsoure.UpdatedBy;
                                update.UpdatedDateTime = SFB_IndustryExpsoure.UpdatedDateTime;

                                dbContext.SaveChanges();
                            }
                            else
                            {
                                dbContextTransaction.Rollback();
                                return false;
                            }
                        }
                        catch (Exception exception)
                        {
                            dbContextTransaction.Rollback();
                            return false;
                        }
                    }
                    status = Add_SFBIndustryExpsoure_Archive(SFB_IndustryExpsoure_Archive);
                    dbContextTransaction.Commit();
                }
            }

            return false;

        }

        public bool Add_SFBIndustryExpsoure(SFB_IndustryExpsoure SFB_IndustryExpsoure)
        {
            try
            {
                dbContext.SFB_IndustryExpsoure.Add(SFB_IndustryExpsoure);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_SFBIndustryExpsoure_Archive(SFB_IndustryExpsoure_Archive SFB_IndustryExpsoure_Archive)
        {
            try
            {
                dbContext.SFB_IndustryExpsoure_Archive.Add(SFB_IndustryExpsoure_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        #region - Output

        public bool SaveAsDraft_OutputDetails(int userId, int roleId, int detailID, short logID, int detail_ArchiveID, DateTime CreatedDateTime, List<SFB_OutputDetailsEntity> outputDetailsEntity)
        {
            bool status = false;
            using (var dbContextTransaction = dbContext.Database.BeginTransaction())
            {
                if (outputDetailsEntity != null && userId != 0)
                {
                    List<SFB_Output_Details> output_Details = new List<SFB_Output_Details>();
                    List<SFB_Output_Details_Archive> output_Details_Archive = new List<SFB_Output_Details_Archive>();

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details.Add(new SFB_Output_Details
                        {
                            DetailsId = detailID,
                            TemplateId = values.TemplateID,
                            Parameter_Per = values.Parameter3Per,
                            Parameter_Name = string.IsNullOrEmpty(values.Parameter3) ? values.Parameter1 : values.Parameter3,
                            UnderBaselIII_Score = values.UnderBaselIII_Score,
                            UnderBaselIII_Value = values.UnderBaselIII_Value,
                            UnderIND_Score = values.UnderIND_Score,
                            UnderIND_Value = values.UnderIND_Value,
                            Comments = values.Comments,
                            CreatedDateTime = CreatedDateTime,
                        });
                    };

                    foreach (var values in outputDetailsEntity)
                    {
                        output_Details_Archive.Add(new SFB_Output_Details_Archive
                        {
                            DetailsId = detailID,
                            LogId = logID,

                            Details_ArchiveId = detail_ArchiveID,
                            UserId = userId,
                            TemplateId = values.TemplateID,
                            Parameter_Per = values.Parameter3Per,
                            Parameter_Name = string.IsNullOrEmpty(values.Parameter3) ? values.Parameter1 : values.Parameter3,

                            UnderBaselIII_Score = values.UnderBaselIII_Score,
                            UnderBaselIII_Value = values.UnderBaselIII_Value,
                            UnderIND_Score = values.UnderIND_Score,
                            UnderIND_Value = values.UnderIND_Value,
                            Comments = values.Comments,
                            CreatedBy = values.CreatedBy,
                            UpdatedBy = values.UpdatedBy,

                            CreatedDateTime = CreatedDateTime,
                            UpdatedDateTime = DateTime.Now,
                        });
                    };

                    if (output_Details != null)
                    {
                        if (CheckIfAlreadyExists_OutputDetails(detailID) == true)
                        {
                            Delete_OutputDetails(detailID);
                        }
                        status = Add_OutputDetails(output_Details);
                        status = Add_OutputDetails_Archive(output_Details_Archive);
                        dbContextTransaction.Commit();
                        status = true;
                    }
                }
            }

            return status;

        }

        public bool Delete_OutputDetails(int detailsID)
        {
            try
            {
                dbContext.SFB_Output_Details.RemoveRange(dbContext.SFB_Output_Details.Where(c => c.DetailsId == detailsID));
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_OutputDetails(List<SFB_Output_Details> output_Details)
        {
            try
            {
                dbContext.SFB_Output_Details.AddRange(output_Details);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public bool Add_OutputDetails_Archive(List<SFB_Output_Details_Archive> output_Details_Archive)
        {
            try
            {
                dbContext.SFB_Output_Details_Archive.AddRange(output_Details_Archive);
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }


        public bool Get_OutputDetails_OpenXML(int companyId, DateTime? CreatedDateTime, string OutputTemplateFilePath)
        {
            // Open the document for editing.
            using (DocumentFormat.OpenXml.Packaging.SpreadsheetDocument spreadSheet = DocumentFormat.OpenXml.Packaging.SpreadsheetDocument.Open(OutputTemplateFilePath, true))
            {
                //WorkbookPart bkPart = doc.WorkbookPart;
                //DocumentFormat.OpenXml.Spreadsheet.Workbook workbook = bkPart.Workbook;
                //DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(sht => sht.Name == "Data Input Sheet").FirstOrDefault();

                // Access the main Workbook part, which contains all references.
                DocumentFormat.OpenXml.Packaging.WorkbookPart workbookPart = spreadSheet.WorkbookPart;
                // get sheet by name
                DocumentFormat.OpenXml.Spreadsheet.Sheet sheet = workbookPart.Workbook.Descendants<DocumentFormat.OpenXml.Spreadsheet.Sheet>().Where(s => s.Name == "Output NHB").FirstOrDefault();

                // get worksheetpart by sheet id
                DocumentFormat.OpenXml.Packaging.WorksheetPart worksheetPart = workbookPart.GetPartById(sheet.Id.Value) as DocumentFormat.OpenXml.Packaging.WorksheetPart;

                // The SheetData object will contain all the data.
                int detailArchivedID = (from output in dbContext.SFB_Output_Details_Archive
                                        join basicDetails in dbContext.NHB_Details_Archive on output.Details_ArchiveId equals basicDetails.Details_ArchiveId
                                        where basicDetails.CompanyId == companyId
                                        && DbFunctions.TruncateTime(output.UpdatedDateTime) == DbFunctions.TruncateTime(CreatedDateTime)
                                        select output.Details_ArchiveId).OrderByDescending(data => data).FirstOrDefault();

                //    RRB_Output_Details_Archive data = dbContext.RRB_Output_Details_Archive.Where(detail => detail.CompanyId == companyId
                //&& issuerinfo.PRDate == null).OrderByDescending(data => data.Details_ArchiveId).FirstOrDefault();

                if (detailArchivedID != 0)
                {
                    List<SFB_OutputDetailsEntity> getOutputDetails = dbContext.SFB_Output_Details_Archive
                       .Where(riskOutputs => riskOutputs.Details_ArchiveId == detailArchivedID
                       )
                       .Select(Outputs => new SFB_OutputDetailsEntity
                       {
                           Parameter3 = Outputs.Parameter_Name,
                           UnderIND_Score = Outputs.UnderIND_Score,
                           UnderIND_Value = Outputs.UnderIND_Value,
                           UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                           UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
                       }).ToList();

                    uint rowNo = 3;
                    for (int i = 0; i < getOutputDetails.Count; i++)
                    {
                        Cell cell = GetCell(worksheetPart.Worksheet, "K", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Score);
                        cell = GetCell(worksheetPart.Worksheet, "L", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderBaselIII_Value);
                        cell = GetCell(worksheetPart.Worksheet, "N", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Score);
                        cell = GetCell(worksheetPart.Worksheet, "O", rowNo);
                        cell.CellValue = new CellValue(getOutputDetails[i].UnderIND_Value);
                        rowNo++;
                    }
                    // Save the worksheet.
                    worksheetPart.Worksheet.Save();

                    // for recacluation of formula
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                    spreadSheet.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;

                }

                // Regulatory Environment

            }
            return true;
        }

        private Cell GetCell(Worksheet worksheet, string columnName, uint rowIndex)
        {
            Row row = GetRow(worksheet, rowIndex);

            if (row == null) return null;

            var FirstRow = row.Elements<Cell>().Where(c => string.Compare
            (c.CellReference.Value, columnName +
            rowIndex, true) == 0).FirstOrDefault();

            if (FirstRow == null) return null;

            return FirstRow;
        }

        private Row GetRow(Worksheet worksheet, uint rowIndex)
        {
            Row row = worksheet.GetFirstChild<SheetData>().
            Elements<Row>().FirstOrDefault(r => r.RowIndex == rowIndex);
            if (row == null)
            {
                throw new ArgumentException(String.Format("No row with index {0} found in spreadsheet", rowIndex));
            }
            return row;
        }

        public bool Delete_SFBOutputDetails(List<SFB_Output_Details> SFB_Output_Details)
        {
            try
            {
                dbContext.SFB_Output_Details.RemoveRange(dbContext.SFB_Output_Details.Where(c => c.DetailsId == SFB_Output_Details[0].DetailsId));
                dbContext.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }

                throw;
            }
        }

        #endregion


        public bool CheckIfAlreadyExists_SFBKeyFinancial(int detailsId)
        {
            return dbContext.SFB_KeyFinancials.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_SFBSubjectiveParameters(int detailsId)
        {
            return dbContext.SFB_SubjectiveParameters.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_SFBIndustryExpsoure(int detailsId)
        {
            return dbContext.SFB_IndustryExpsoure.Any(asset => asset.DetailsId == detailsId);
        }

        public bool CheckIfAlreadyExists_OutputDetails(int detailsId)
        {
            return dbContext.SFB_Output_Details.Any(asset => asset.DetailsId == detailsId);
        }

        public bool Get_OutputDetailsFromFrontEnd_InterOp(int detailsID, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Key Financials List

            List<SFB_KeyFinancialsEntity> getKeyFinancialsEntity = dbContext.SFB_KeyFinancials
              .Where(a => a.DetailsId == detailsID
              )
              .Select(keyFinancialsEntity => new SFB_KeyFinancialsEntity
              {
                  PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                  PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                  NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                  NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                  Currency1 = keyFinancialsEntity.Currency1,
                  Currency2 = keyFinancialsEntity.Currency2,
                  NetWorth1 = keyFinancialsEntity.NetWorth1,
                  NetWorth2 = keyFinancialsEntity.NetWorth2,
                  TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                  TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                  CreditDepositRatioPer1 = keyFinancialsEntity.CreditDepositRatioPer1,
                  CreditDepositRatioPer2 = keyFinancialsEntity.CreditDepositRatioPer2,
                  ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                  ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                  CASAPer1 = keyFinancialsEntity.CASAPer1,
                  CASAPer2 = keyFinancialsEntity.CASAPer2,
                  PrioritySectorAdvancesPer1 = keyFinancialsEntity.PrioritySectorAdvancesPer1,
                  PrioritySectorAdvancesPer2 = keyFinancialsEntity.PrioritySectorAdvancesPer2,
                  ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                  ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                  CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                  CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                  CRARPer1 = keyFinancialsEntity.CRARPer1,
                  CRARPer2 = keyFinancialsEntity.CRARPer2,
                  Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                  Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                  CommonEquityTierPer1 = keyFinancialsEntity.CommonEquityTierPer1,
                  CommonEquityTierPer2 = keyFinancialsEntity.CommonEquityTierPer2,
                  NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                  NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                  GrowthinDepositsPer1 = keyFinancialsEntity.GrowthinDepositsPer1,
                  GrowthinDepositsPer2 = keyFinancialsEntity.GrowthinDepositsPer2,
                  GrowthinAdvancesPer1 = keyFinancialsEntity.GrowthinAdvances1,
                  GrowthinAdvancesPer2 = keyFinancialsEntity.GrowthinAdvances2,
                  TotalNumOfBranches1 = keyFinancialsEntity.TotalNumOfBranches1,
                  TotalNumOfBranches2 = keyFinancialsEntity.TotalNumOfBranches2,
                  GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                  GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                  AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                  AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                  DiversityofIncomePer1 = keyFinancialsEntity.DiversityofIncomePer1,
                  DiversityofIncomePer2 = keyFinancialsEntity.DiversityofIncomePer2,
                  TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                  TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                  TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                  TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                  AdvancesToSensitiveSectorPer1 = keyFinancialsEntity.AdvancesToSensitiveSectorPer1,
                  AdvancesToSensitiveSectorPer2 = keyFinancialsEntity.AdvancesToSensitiveSectorPer2,
                  CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                  CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                  CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                  CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                  PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                  PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                  //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                  //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                  LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                  LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                  Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                  Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                  NetStableFundingRatioPer1 = keyFinancialsEntity.NetStableFundingRatioPer1,
                  NetStableFundingRatioPer2 = keyFinancialsEntity.NetStableFundingRatioPer2,
                  GearingPer1 = keyFinancialsEntity.GearingPer1,
                  GearingPer2 = keyFinancialsEntity.GearingPer2,
                  LeverageRatioPer1 = keyFinancialsEntity.LeverageRatioPer1,
                  LeverageRatioPer2 = keyFinancialsEntity.LeverageRatioPer2,
                  BusinessEmployee1 = keyFinancialsEntity.BusinessEmployee1,
                  BusinessEmployee2 = keyFinancialsEntity.BusinessEmployee2,
                  RatioOfSecuredAdvancesToTotalAdvancesPer1 = keyFinancialsEntity.RatioOfSecuredAdvancesToTotalAdvances1,
                  RatioOfSecuredAdvancesToTotalAdvancesPer2 = keyFinancialsEntity.RatioOfSecuredAdvancesToTotalAdvances2,
                  PresenceInStatesAndUT1 = keyFinancialsEntity.PresenceInStatesAndUT1,
                  PresenceInStatesAndUT2 = keyFinancialsEntity.PresenceInStatesAndUT2,
                  RatioOfDepositsToTotalLiabilitiesPer1 = keyFinancialsEntity.RatioOfDepositsToTotalLiabilities1,
                  RatioOfDepositsToTotalLiabilitiesPer2 = keyFinancialsEntity.RatioOfDepositsToTotalLiabilities2,
                  YearsPassedSinceCommencement1 = keyFinancialsEntity.YearsPassedSinceCommencement1,
                  YearsPassedSinceCommencement2 = keyFinancialsEntity.YearsPassedSinceCommencement2,
                  PromoterShareholdingPer1 = keyFinancialsEntity.PromoterShareholding1,
                  PromoterShareholdingPer2 = keyFinancialsEntity.PromoterShareholding2,
                  ProvisioningCoverageRatioPer1 = keyFinancialsEntity.ProvisioningCoverageRatioPer1,
                  ProvisioningCoverageRatioPer2 = keyFinancialsEntity.ProvisioningCoverageRatioPer2,

              }).ToList();

            #endregion

            #region Subjective Parameters List

            List<SFB_SubjectiveParametersEntity> getSubjectiveParametersEntity = dbContext.SFB_SubjectiveParameters
              .Where(a => a.DetailsId == detailsID
              )
              .Select(subjectiveParametersEntity => new SFB_SubjectiveParametersEntity
              {
                  //PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank,
                  ExternalRating = subjectiveParametersEntity.ExternalRating,
                  IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                  BusinessModel = subjectiveParametersEntity.BusinessModel,
                  ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                  //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                  AdverseNews = subjectiveParametersEntity.AdverseNews,
                  CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                  AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                  AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                  NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                  //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                  NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                  LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                  CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                  NPASysGen = subjectiveParametersEntity.NPASysGen,
                  NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                  CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                  NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                  SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                  QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                  DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,

              }).ToList();

            #endregion

            #region Industry Exposure List

            List<SFB_IndustryExpsoureEntity> getIndustryExpsoureEntity = dbContext.SFB_IndustryExpsoure
              .Where(a => a.DetailsId == detailsID
              )
              .Select(industryExpsoureEntity => new SFB_IndustryExpsoureEntity
              {
                  AgricultureAlliedActivities1 = industryExpsoureEntity.AgricultureAlliedActivities1,
                  AgricultureAlliedActivitiesPer2 = industryExpsoureEntity.AgricultureAlliedActivitiesPer2,
                  AgricultureAlliedActivities3 = industryExpsoureEntity.AgricultureAlliedActivities3,
                  MinigQuaring1 = industryExpsoureEntity.MinigQuaring1,
                  MinigQuaringPer2 = industryExpsoureEntity.MinigQuaringPer2,
                  MinigQuaring3 = industryExpsoureEntity.MinigQuaring3,
                  FoodFoodProcessing1 = industryExpsoureEntity.FoodFoodProcessing1,
                  FoodFoodProcessingPer2 = industryExpsoureEntity.FoodFoodProcessingPer2,
                  FoodFoodProcessing3 = industryExpsoureEntity.FoodFoodProcessing3,
                  Textiles1 = industryExpsoureEntity.Textiles1,
                  TextilesPer2 = industryExpsoureEntity.TextilesPer2,
                  Textiles3 = industryExpsoureEntity.Textiles3,
                  MaterialtheirProducts1 = industryExpsoureEntity.MaterialtheirProducts1,
                  MaterialtheirProductsPer2 = industryExpsoureEntity.MaterialtheirProductsPer2,
                  MaterialtheirProducts3 = industryExpsoureEntity.MaterialtheirProducts3,
                  PetroleumCoalProductsNuclearFuels1 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuels1,
                  PetroleumCoalProductsNuclearFuelsPer2 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuelsPer2,
                  PetroleumCoalProductsNuclearFuels3 = industryExpsoureEntity.PetroleumCoalProductsNuclearFuels3,
                  ChemicalChemicalProducts1 = industryExpsoureEntity.ChemicalChemicalProducts1,
                  ChemicalChemicalProductsPer2 = industryExpsoureEntity.ChemicalChemicalProductsPer2,
                  ChemicalChemicalProducts3 = industryExpsoureEntity.ChemicalChemicalProducts3,
                  CementCementProducts1 = industryExpsoureEntity.CementCementProducts1,
                  CementCementProductsPer2 = industryExpsoureEntity.CementCementProductsPer2,
                  CementCementProducts3 = industryExpsoureEntity.CementCementProducts3,
                  BasicMetalMetalProduct1 = industryExpsoureEntity.BasicMetalMetalProduct1,
                  BasicMetalMetalProductPer2 = industryExpsoureEntity.BasicMetalMetalProductPer2,
                  BasicMetalMetalProduct3 = industryExpsoureEntity.BasicMetalMetalProduct3,
                  AllEngineering1 = industryExpsoureEntity.AllEngineering1,
                  AllEngineeringPer2 = industryExpsoureEntity.AllEngineeringPer2,
                  AllEngineering3 = industryExpsoureEntity.AllEngineering3,
                  AutomobileAncillary1 = industryExpsoureEntity.AutomobileAncillary1,
                  AutomobileAncillaryPer2 = industryExpsoureEntity.AutomobileAncillaryPer2,
                  AutomobileAncillary3 = industryExpsoureEntity.AutomobileAncillary3,
                  GemsJewellery1 = industryExpsoureEntity.GemsJewellery1,
                  GemsJewelleryPer2 = industryExpsoureEntity.GemsJewelleryPer2,
                  GemsJewellery3 = industryExpsoureEntity.GemsJewellery3,
                  Construction1 = industryExpsoureEntity.Construction1,
                  ConstructionPer2 = industryExpsoureEntity.ConstructionPer2,
                  Construction3 = industryExpsoureEntity.Construction3,
                  Power1 = industryExpsoureEntity.Power1,
                  PowerPer2 = industryExpsoureEntity.PowerPer2,
                  Power3 = industryExpsoureEntity.Power3,
                  Telecommunication1 = industryExpsoureEntity.Telecommunication1,
                  TelecommunicationPer2 = industryExpsoureEntity.TelecommunicationPer2,
                  Telecommunication3 = industryExpsoureEntity.Telecommunication3,
                  RestoftheInfrastructure1 = industryExpsoureEntity.RestoftheInfrastructure1,
                  RestoftheInfrastructurePer2 = industryExpsoureEntity.RestoftheInfrastructurePer2,
                  RestoftheInfrastructure3 = industryExpsoureEntity.RestoftheInfrastructure3,
                  NBFCs1 = industryExpsoureEntity.NBFCs1,
                  NBFCsPer2 = industryExpsoureEntity.NBFCsPer2,
                  NBFCs3 = industryExpsoureEntity.NBFCs3,
                  OtherIndustries1 = industryExpsoureEntity.OtherIndustries1,
                  OtherIndustriesPer2 = industryExpsoureEntity.OtherIndustriesPer2,
                  OtherIndustries3 = industryExpsoureEntity.OtherIndustries3,
                  Retail1 = industryExpsoureEntity.Retail1,
                  RetailPer2 = industryExpsoureEntity.RetailPer2,
                  Retail3 = industryExpsoureEntity.Retail3,
                  MicroFinance1 = industryExpsoureEntity.MicroFinance1,
                  MicroFinancePer2 = industryExpsoureEntity.MicroFinancePer2,
                  MicroFinance3 = industryExpsoureEntity.MicroFinance3,
                  TotalAdvances = industryExpsoureEntity.TotalAdvances,

              }).ToList();

            #endregion

            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            //Get the already exists sheet
            //mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkSheets.get_Item(2);
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Input Sheet"];

            string value = "";
            uint rowIndex = 0;
            int columnIndex = 0;

            string columnName = "";
            object obj;
            //mWSheet.Cells[11, 2] = riskModelExcelEntity.NHB_BalanceSheets_Liabilities.PeriodEndingDate1_Liabilities;

            SFB_KeyFinancialsEntity sfb_KeyFinancialsEntity = new SFB_KeyFinancialsEntity();
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(sfb_KeyFinancialsEntity);
            properties = TypeDescriptor.GetProperties(sfb_KeyFinancialsEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getKeyFinancialsEntity[0].GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            SFB_SubjectiveParametersEntity sfb_SubjectiveParametersEntity = new SFB_SubjectiveParametersEntity();
            properties = TypeDescriptor.GetProperties(sfb_SubjectiveParametersEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getSubjectiveParametersEntity[0].GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            SFB_IndustryExpsoureEntity sfb_IndustryExpsoureEntity = new SFB_IndustryExpsoureEntity();
            properties = TypeDescriptor.GetProperties(sfb_IndustryExpsoureEntity);
            foreach (PropertyDescriptor property in properties)
            {
                if (property != null)
                {
                    try
                    {
                        rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                        columnName = _helperDAL.GetExcelColumnName(property.Category);
                        columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                        if (rowIndex == 0)
                        {
                            continue;
                        }
                        obj = getIndustryExpsoureEntity[0].GetType().GetProperty(property.Name).GetValue(getIndustryExpsoureEntity[0], null);
                        value = obj.ToString();
                        string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                        if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                        {
                            value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                        }
                        mWSheet.Cells[rowIndex, columnIndex] = value;
                    }
                    catch { }
                }
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();

            return true;
        }


        public bool Get_OutputDetails_InterOp_DetailsId(int detailsId, string companyName, string OutputTemplateFilePath)
        {

            CompanyDAL companyDAL = new CompanyDAL();

            #region Key Financials List

            List<SFB_OutputDetailsEntity> getOutputDetails = dbContext.SFB_Output_Details
              .Where(a => a.DetailsId == detailsId
              )
              .Select(Outputs => new SFB_OutputDetailsEntity
              {
                  Parameter3Per = Outputs.Parameter_Per,
                  Parameter3 = Outputs.Parameter_Name,
                  UnderIND_Score = Outputs.UnderIND_Score,
                  UnderIND_Value = Outputs.UnderIND_Value,
                  UnderBaselIII_Score = Outputs.UnderBaselIII_Score,
                  UnderBaselIII_Value = Outputs.UnderBaselIII_Value,
              }).ToList();

            #endregion


            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            mWorkSheets = mWorkBook.Worksheets;
            mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Output NHB"];

            uint rowIndex = 2;
            int columnIndex = 0;
            columnIndex = _helperDAL.GetExcelColumnIndex("G");
            mWSheet.Cells[rowIndex, columnIndex] = companyName;

            rowIndex = 3;
            columnIndex = 0;
            for (int i = 0; i < getOutputDetails.Count; i++)
            {
                columnIndex = _helperDAL.GetExcelColumnIndex("J");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("K");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderBaselIII_Score;

                columnIndex = _helperDAL.GetExcelColumnIndex("M");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Value;

                columnIndex = _helperDAL.GetExcelColumnIndex("N");
                mWSheet.Cells[rowIndex, columnIndex] = getOutputDetails[i].UnderIND_Score;
                rowIndex++;
            }

            mWorkBook.Save();
            mWorkBook.Close(1, null, null);
            xlApp.Quit();

            mWSheet = null;
            mWorkBook = null;
            mWorkSheets = null;
            xlApp = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();


            return true;
        }


        public SFB_BasicDetailsEntity GetBasicDetails(int detailsId)
        {
            SFB_BasicDetailsEntity basicDetails = new SFB_BasicDetailsEntity();
            SFB_KeyFinancialsEntity keyFinancials = new SFB_KeyFinancialsEntity();
            SFB_SubjectiveParametersEntity subjectiveParameters = new SFB_SubjectiveParametersEntity();
            SFB_IndustryExpsoureEntity industryExpsoures = new SFB_IndustryExpsoureEntity();
            List<SFB_OutputDetailsEntity> outputDetails = new List<SFB_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details.Where(data => data.DetailsId == detailsId).Select(x => new SFB_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = 0,

                FinYear = x.FinYear,
                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                DateOfInput = x.DateOfInput,
                CurrencyUnits = x.CurrencyUnits,
                ParentCompanyName = x.ParentCompanyName,
                ParentCompanyId = x.ParentCompanyId,
                ParentRating = x.ParentRating,
                ParentCompanyShareHoldingPer = x.ParentCompanyShareHoldingPer,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

                IsFinal = x.IsFinal.Value
            }).FirstOrDefault();

            keyFinancials = dbContext.SFB_KeyFinancials.Where(data => data.DetailsId == detailsId).Select(keyFinancialsEntity => new SFB_KeyFinancialsEntity
            {
                PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                Currency1 = keyFinancialsEntity.Currency1,
                Currency2 = keyFinancialsEntity.Currency2,
                NetWorth1 = keyFinancialsEntity.NetWorth1,
                NetWorth2 = keyFinancialsEntity.NetWorth2,
                TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                CreditDepositRatioPer1 = keyFinancialsEntity.CreditDepositRatioPer1,
                CreditDepositRatioPer2 = keyFinancialsEntity.CreditDepositRatioPer2,
                ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                CASAPer1 = keyFinancialsEntity.CASAPer1,
                CASAPer2 = keyFinancialsEntity.CASAPer2,
                PrioritySectorAdvancesPer1 = keyFinancialsEntity.PrioritySectorAdvancesPer1,
                PrioritySectorAdvancesPer2 = keyFinancialsEntity.PrioritySectorAdvancesPer2,
                ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                CRARPer1 = keyFinancialsEntity.CRARPer1,
                CRARPer2 = keyFinancialsEntity.CRARPer2,
                Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                CommonEquityTierPer1 = keyFinancialsEntity.CommonEquityTierPer1,
                CommonEquityTierPer2 = keyFinancialsEntity.CommonEquityTierPer2,
                NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                GrowthinDepositsPer1 = keyFinancialsEntity.GrowthinDepositsPer1,
                GrowthinDepositsPer2 = keyFinancialsEntity.GrowthinDepositsPer2,
                GrowthinAdvancesPer1 = keyFinancialsEntity.GrowthinAdvances1,
                GrowthinAdvancesPer2 = keyFinancialsEntity.GrowthinAdvances2,
                TotalNumOfBranches1 = keyFinancialsEntity.TotalNumOfBranches1,
                TotalNumOfBranches2 = keyFinancialsEntity.TotalNumOfBranches2,
                GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                DiversityofIncomePer1 = keyFinancialsEntity.DiversityofIncomePer1,
                DiversityofIncomePer2 = keyFinancialsEntity.DiversityofIncomePer2,
                TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                AdvancesToSensitiveSectorPer1 = keyFinancialsEntity.AdvancesToSensitiveSectorPer1,
                AdvancesToSensitiveSectorPer2 = keyFinancialsEntity.AdvancesToSensitiveSectorPer2,
                CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                GearingPer1 = keyFinancialsEntity.GearingPer1,
                GearingPer2 = keyFinancialsEntity.GearingPer2,
                LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                NetStableFundingRatioPer1 = keyFinancialsEntity.NetStableFundingRatioPer1,
                NetStableFundingRatioPer2 = keyFinancialsEntity.NetStableFundingRatioPer2,
                LeverageRatioPer1 = keyFinancialsEntity.LeverageRatioPer1,
                LeverageRatioPer2 = keyFinancialsEntity.LeverageRatioPer2,

                BusinessEmployee1 = keyFinancialsEntity.BusinessEmployee1,
                BusinessEmployee2 = keyFinancialsEntity.BusinessEmployee2,

                RatioOfSecuredAdvancesToTotalAdvancesPer1 = keyFinancialsEntity.RatioOfSecuredAdvancesToTotalAdvances1,
                RatioOfSecuredAdvancesToTotalAdvancesPer2 = keyFinancialsEntity.RatioOfSecuredAdvancesToTotalAdvances2,

                PresenceInStatesAndUT1 = keyFinancialsEntity.PresenceInStatesAndUT1,
                PresenceInStatesAndUT2 = keyFinancialsEntity.PresenceInStatesAndUT2,

                RatioOfDepositsToTotalLiabilitiesPer1 = keyFinancialsEntity.RatioOfDepositsToTotalLiabilities1,
                RatioOfDepositsToTotalLiabilitiesPer2 = keyFinancialsEntity.RatioOfDepositsToTotalLiabilities2,

                YearsPassedSinceCommencement1 = keyFinancialsEntity.YearsPassedSinceCommencement1,
                YearsPassedSinceCommencement2 = keyFinancialsEntity.YearsPassedSinceCommencement2,

                PromoterShareholdingPer1 = keyFinancialsEntity.PromoterShareholding1,
                PromoterShareholdingPer2 = keyFinancialsEntity.PromoterShareholding2,

                ProvisioningCoverageRatioPer1 = keyFinancialsEntity.ProvisioningCoverageRatioPer1,
                ProvisioningCoverageRatioPer2 = keyFinancialsEntity.ProvisioningCoverageRatioPer2,


            }).FirstOrDefault();

            subjectiveParameters = dbContext.SFB_SubjectiveParameters.Where(data => data.DetailsId == detailsId).Select(subjectiveParametersEntity => new SFB_SubjectiveParametersEntity
            {
                //PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank,
                ExternalRating = subjectiveParametersEntity.ExternalRating,
                IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                BusinessModel = subjectiveParametersEntity.BusinessModel,
                ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                AdverseNews = subjectiveParametersEntity.AdverseNews,
                CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                NPASysGen = subjectiveParametersEntity.NPASysGen,
                NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,
            }).FirstOrDefault();

            industryExpsoures = dbContext.SFB_IndustryExpsoure.Where(data => data.DetailsId == detailsId).Select(sfb_IndustryExpsoureEntity => new SFB_IndustryExpsoureEntity
            {
                //IndustryExpsoure_ArchiveId = sfb_IndustryExpsoureEntity.IndustryExpsoureId,
                //UserId = sfb_IndustryExpsoureEntity.use,
                DetailsId = sfb_IndustryExpsoureEntity.DetailsId.Value,
                AgricultureAlliedActivities1 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivities1,
                AgricultureAlliedActivitiesPer2 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivitiesPer2,
                AgricultureAlliedActivities3 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivities3,
                MinigQuaring1 = sfb_IndustryExpsoureEntity.MinigQuaring1,
                MinigQuaringPer2 = sfb_IndustryExpsoureEntity.MinigQuaringPer2,
                MinigQuaring3 = sfb_IndustryExpsoureEntity.MinigQuaring3,
                FoodFoodProcessing1 = sfb_IndustryExpsoureEntity.FoodFoodProcessing1,
                FoodFoodProcessingPer2 = sfb_IndustryExpsoureEntity.FoodFoodProcessingPer2,
                FoodFoodProcessing3 = sfb_IndustryExpsoureEntity.FoodFoodProcessing3,
                Textiles1 = sfb_IndustryExpsoureEntity.Textiles1,
                TextilesPer2 = sfb_IndustryExpsoureEntity.TextilesPer2,
                Textiles3 = sfb_IndustryExpsoureEntity.Textiles3,
                MaterialtheirProducts1 = sfb_IndustryExpsoureEntity.MaterialtheirProducts1,
                MaterialtheirProductsPer2 = sfb_IndustryExpsoureEntity.MaterialtheirProductsPer2,
                MaterialtheirProducts3 = sfb_IndustryExpsoureEntity.MaterialtheirProducts3,
                PetroleumCoalProductsNuclearFuels1 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels1,
                PetroleumCoalProductsNuclearFuelsPer2 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuelsPer2,
                PetroleumCoalProductsNuclearFuels3 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels3,
                ChemicalChemicalProducts1 = sfb_IndustryExpsoureEntity.ChemicalChemicalProducts1,
                ChemicalChemicalProductsPer2 = sfb_IndustryExpsoureEntity.ChemicalChemicalProductsPer2,
                ChemicalChemicalProducts3 = sfb_IndustryExpsoureEntity.ChemicalChemicalProducts3,
                CementCementProducts1 = sfb_IndustryExpsoureEntity.CementCementProducts1,
                CementCementProductsPer2 = sfb_IndustryExpsoureEntity.CementCementProductsPer2,
                CementCementProducts3 = sfb_IndustryExpsoureEntity.CementCementProducts3,
                BasicMetalMetalProduct1 = sfb_IndustryExpsoureEntity.BasicMetalMetalProduct1,
                BasicMetalMetalProductPer2 = sfb_IndustryExpsoureEntity.BasicMetalMetalProductPer2,
                BasicMetalMetalProduct3 = sfb_IndustryExpsoureEntity.BasicMetalMetalProduct3,
                AllEngineering1 = sfb_IndustryExpsoureEntity.AllEngineering1,
                AllEngineeringPer2 = sfb_IndustryExpsoureEntity.AllEngineeringPer2,
                AllEngineering3 = sfb_IndustryExpsoureEntity.AllEngineering3,
                AutomobileAncillary1 = sfb_IndustryExpsoureEntity.AutomobileAncillary1,
                AutomobileAncillaryPer2 = sfb_IndustryExpsoureEntity.AutomobileAncillaryPer2,
                AutomobileAncillary3 = sfb_IndustryExpsoureEntity.AutomobileAncillary3,
                GemsJewellery1 = sfb_IndustryExpsoureEntity.GemsJewellery1,
                GemsJewelleryPer2 = sfb_IndustryExpsoureEntity.GemsJewelleryPer2,
                GemsJewellery3 = sfb_IndustryExpsoureEntity.GemsJewellery3,
                Construction1 = sfb_IndustryExpsoureEntity.Construction1,
                ConstructionPer2 = sfb_IndustryExpsoureEntity.ConstructionPer2,
                Construction3 = sfb_IndustryExpsoureEntity.Construction3,
                Power1 = sfb_IndustryExpsoureEntity.Power1,
                PowerPer2 = sfb_IndustryExpsoureEntity.PowerPer2,
                Power3 = sfb_IndustryExpsoureEntity.Power3,
                Telecommunication1 = sfb_IndustryExpsoureEntity.Telecommunication1,
                TelecommunicationPer2 = sfb_IndustryExpsoureEntity.TelecommunicationPer2,
                Telecommunication3 = sfb_IndustryExpsoureEntity.Telecommunication3,
                RestoftheInfrastructure1 = sfb_IndustryExpsoureEntity.RestoftheInfrastructure1,
                RestoftheInfrastructurePer2 = sfb_IndustryExpsoureEntity.RestoftheInfrastructurePer2,
                RestoftheInfrastructure3 = sfb_IndustryExpsoureEntity.RestoftheInfrastructure3,
                NBFCs1 = sfb_IndustryExpsoureEntity.NBFCs1,
                NBFCsPer2 = sfb_IndustryExpsoureEntity.NBFCsPer2,
                NBFCs3 = sfb_IndustryExpsoureEntity.NBFCs3,
                OtherIndustries1 = sfb_IndustryExpsoureEntity.OtherIndustries1,
                OtherIndustriesPer2 = sfb_IndustryExpsoureEntity.OtherIndustriesPer2,
                OtherIndustries3 = sfb_IndustryExpsoureEntity.OtherIndustries3,
                Retail1 = sfb_IndustryExpsoureEntity.Retail1,
                RetailPer2 = sfb_IndustryExpsoureEntity.RetailPer2,
                Retail3 = sfb_IndustryExpsoureEntity.Retail3,
                MicroFinance1 = sfb_IndustryExpsoureEntity.MicroFinance1,
                MicroFinancePer2 = sfb_IndustryExpsoureEntity.MicroFinancePer2,
                MicroFinance3 = sfb_IndustryExpsoureEntity.MicroFinance3,
                TotalAdvances = sfb_IndustryExpsoureEntity.TotalAdvances,

            }).FirstOrDefault();

            outputDetails = (from output in dbContext.SFB_Output_Details
                             join template in dbContext.SFB_Output_Template on output.TemplateId equals template.TemplateID
                             where output.DetailsId == detailsId

                             select new SFB_OutputDetailsEntity
                             {
                                 TemplateID = output.TemplateId,
                                 Parameter1 = string.IsNullOrEmpty(template.Parameter1) ? string.Empty : template.Parameter1,
                                 Parameter1Per = string.IsNullOrEmpty(template.Parameter1Per) ? string.Empty : template.Parameter1Per,
                                 Parameter2 = string.IsNullOrEmpty(template.Parameter2) ? string.Empty : template.Parameter2,
                                 Parameter2Per = string.IsNullOrEmpty(template.Parameter2Per) ? string.Empty : template.Parameter2Per,
                                 Parameter3Per = output.Parameter_Per,
                                 Parameter3 = output.Parameter_Name,
                                 UnderBaselIII_Score = string.IsNullOrEmpty(output.UnderBaselIII_Score) ? string.Empty : output.UnderBaselIII_Score,
                                 UnderBaselIII_Value = string.IsNullOrEmpty(output.UnderBaselIII_Value) ? string.Empty : output.UnderBaselIII_Value,
                                 UnderIND_Score = string.IsNullOrEmpty(output.UnderIND_Score) ? string.Empty : output.UnderIND_Score,
                                 UnderIND_Value = string.IsNullOrEmpty(output.UnderIND_Value) ? string.Empty : output.UnderIND_Value,
                                 Comments = string.IsNullOrEmpty(output.Comments) ? string.Empty : output.Comments,
                             }).ToList();

            basicDetails.SFB_KeyFinancialsEntity = keyFinancials;
            basicDetails.SFB_SubjectiveParametersEntity = subjectiveParameters;
            basicDetails.SFB_IndustryExpsoureEntity = industryExpsoures;
            basicDetails.SFB_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public SFB_BasicDetailsEntity GetBasicDetails_Archive(int detailsId, short logId)
        {
            SFB_BasicDetailsEntity basicDetails = new SFB_BasicDetailsEntity();
            SFB_KeyFinancialsEntity keyFinancials = new SFB_KeyFinancialsEntity();
            SFB_SubjectiveParametersEntity subjectiveParameters = new SFB_SubjectiveParametersEntity();
            SFB_IndustryExpsoureEntity industryExpsoures = new SFB_IndustryExpsoureEntity();
            List<SFB_OutputDetailsEntity> outputDetails = new List<SFB_OutputDetailsEntity>();

            basicDetails = dbContext.NHB_Details_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(x => new SFB_BasicDetailsEntity
            {
                DetailsId = x.DetailsId,
                LogId = logId,
                FinYear = x.FinYear,
                CompanyId = x.CompanyId,
                LocationId = x.LocationId,
                DateOfInput = x.DateOfInput,
                CurrencyUnits = x.CurrencyUnits,
                ParentCompanyName = x.ParentCompanyName,
                ParentCompanyId = x.ParentCompanyId,
                ParentRating = x.ParentRating,
                ParentCompanyShareHoldingPer = x.ParentCompanyShareHoldingPer,
                Comments = x.Comments,
                FinalRating = x.FinalRating,
                PD = x.PD,
                SubmitForApproval = x.SubmitForApproval,
                SubmitForApprovalDate = x.SubmitForApprovalDate,
                ApprovedDate = x.ApprovedDate,
                ReviewedDate = x.ReviewedDate,

                IsFinal = x.IsFinal.Value
            }).FirstOrDefault();

            keyFinancials = dbContext.SFB_KeyFinancials_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(keyFinancialsEntity => new SFB_KeyFinancialsEntity
            {
                PeriodEndingDate1 = keyFinancialsEntity.PeriodEndingDate1,
                PeriodEndingDate2 = keyFinancialsEntity.PeriodEndingDate2,
                NoofMonthsPeriod1 = keyFinancialsEntity.NoofMonthsPeriod1,
                NoofMonthsPeriod2 = keyFinancialsEntity.NoofMonthsPeriod2,
                Currency1 = keyFinancialsEntity.Currency1,
                Currency2 = keyFinancialsEntity.Currency2,
                NetWorth1 = keyFinancialsEntity.NetWorth1,
                NetWorth2 = keyFinancialsEntity.NetWorth2,
                TotalAssets1 = keyFinancialsEntity.TotalAssets1,
                TotalAssets2 = keyFinancialsEntity.TotalAssets2,
                CreditDepositRatioPer1 = keyFinancialsEntity.CreditDepositRatioPer1,
                CreditDepositRatioPer2 = keyFinancialsEntity.CreditDepositRatioPer2,
                ReturnOnAssetsPer1 = keyFinancialsEntity.ReturnOnAssetsPer1,
                ReturnOnAssetsPer2 = keyFinancialsEntity.ReturnOnAssetsPer2,
                CASAPer1 = keyFinancialsEntity.CASAPer1,
                CASAPer2 = keyFinancialsEntity.CASAPer2,
                PrioritySectorAdvancesPer1 = keyFinancialsEntity.PrioritySectorAdvancesPer1,
                PrioritySectorAdvancesPer2 = keyFinancialsEntity.PrioritySectorAdvancesPer2,
                ReturnOnNetWorthPer1 = keyFinancialsEntity.ReturnOnNetWorthPer1,
                ReturnOnNetWorthPer2 = keyFinancialsEntity.ReturnOnNetWorthPer2,
                CostOfFundsPer1 = keyFinancialsEntity.CostOfFundsPer1,
                CostOfFundsPer2 = keyFinancialsEntity.CostOfFundsPer2,
                CRARPer1 = keyFinancialsEntity.CRARPer1,
                CRARPer2 = keyFinancialsEntity.CRARPer2,
                Tier1Per1 = keyFinancialsEntity.Tier1Per1,
                Tier1Per2 = keyFinancialsEntity.Tier1Per2,
                CommonEquityTierPer1 = keyFinancialsEntity.CommonEquityTierPer1,
                CommonEquityTierPer2 = keyFinancialsEntity.CommonEquityTierPer2,
                NetNPAPer1 = keyFinancialsEntity.NetNPAPer1,
                NetNPAPer2 = keyFinancialsEntity.NetNPAPer2,
                GrowthinDepositsPer1 = keyFinancialsEntity.GrowthinDepositsPer1,
                GrowthinDepositsPer2 = keyFinancialsEntity.GrowthinDepositsPer2,
                GrowthinAdvancesPer1 = keyFinancialsEntity.GrowthinAdvances1,
                GrowthinAdvancesPer2 = keyFinancialsEntity.GrowthinAdvances2,
                TotalNumOfBranches1 = keyFinancialsEntity.TotalNumOfBranches1,
                TotalNumOfBranches2 = keyFinancialsEntity.TotalNumOfBranches2,
                GrossNPAPer1 = keyFinancialsEntity.GrossNPAPer1,
                GrossNPAPer2 = keyFinancialsEntity.GrossNPAPer2,
                AdditioninNPAsAdvancesPer1 = keyFinancialsEntity.AdditioninNPAsAdvancesPer1,
                AdditioninNPAsAdvancesPer2 = keyFinancialsEntity.AdditioninNPAsAdvancesPer2,
                DiversityofIncomePer1 = keyFinancialsEntity.DiversityofIncomePer1,
                DiversityofIncomePer2 = keyFinancialsEntity.DiversityofIncomePer2,
                TangibleNWNetNPA1 = keyFinancialsEntity.TangibleNWNetNPA1,
                TangibleNWNetNPA2 = keyFinancialsEntity.TangibleNWNetNPA2,
                TotalContLiabilityTotalAssetsPer1 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer1,
                TotalContLiabilityTotalAssetsPer2 = keyFinancialsEntity.TotalContLiabilityTotalAssetsPer2,
                AdvancesToSensitiveSectorPer1 = keyFinancialsEntity.AdvancesToSensitiveSectorPer1,
                AdvancesToSensitiveSectorPer2 = keyFinancialsEntity.AdvancesToSensitiveSectorPer2,
                CosttoIncomePer1 = keyFinancialsEntity.CosttoIncomePer1,
                CosttoIncomePer2 = keyFinancialsEntity.CosttoIncomePer2,
                CreditCostPer1 = keyFinancialsEntity.CreditCostPer1,
                CreditCostPer2 = keyFinancialsEntity.CreditCostPer2,
                PPOPCreditCost1 = keyFinancialsEntity.PPOPCreditCost1,
                PPOPCreditCost2 = keyFinancialsEntity.PPOPCreditCost2,
                //ALMGapin6monthsbucketPer1 = keyFinancialsEntity.ALMGapin6monthsbucketPer1,
                //ALMGapin6monthsbucketPer2 = keyFinancialsEntity.ALMGapin6monthsbucketPer2,
                GearingPer1 = keyFinancialsEntity.GearingPer1,
                GearingPer2 = keyFinancialsEntity.GearingPer2,
                LiquidityCoverageRatioPer1 = keyFinancialsEntity.LiquidityCoverageRatioPer1,
                LiquidityCoverageRatioPer2 = keyFinancialsEntity.LiquidityCoverageRatioPer2,
                Top20ConcentrationPer1 = keyFinancialsEntity.Top20ConcentrationPer1,
                Top20ConcentrationPer2 = keyFinancialsEntity.Top20ConcentrationPer2,
                NetStableFundingRatioPer1 = keyFinancialsEntity.NetStableFundingRatioPer1,
                NetStableFundingRatioPer2 = keyFinancialsEntity.NetStableFundingRatioPer2,
                LeverageRatioPer1 = keyFinancialsEntity.LeverageRatioPer1,
                LeverageRatioPer2 = keyFinancialsEntity.LeverageRatioPer2,

                BusinessEmployee1 = keyFinancialsEntity.BusinessEmployee1,
                BusinessEmployee2 = keyFinancialsEntity.BusinessEmployee2,

                RatioOfSecuredAdvancesToTotalAdvancesPer1 = keyFinancialsEntity.RatioOfSecuredAdvancesToTotalAdvances1,
                RatioOfSecuredAdvancesToTotalAdvancesPer2 = keyFinancialsEntity.RatioOfSecuredAdvancesToTotalAdvances2,

                PresenceInStatesAndUT1 = keyFinancialsEntity.PresenceInStatesAndUT1,
                PresenceInStatesAndUT2 = keyFinancialsEntity.PresenceInStatesAndUT2,

                RatioOfDepositsToTotalLiabilitiesPer1 = keyFinancialsEntity.RatioOfDepositsToTotalLiabilities1,
                RatioOfDepositsToTotalLiabilitiesPer2 = keyFinancialsEntity.RatioOfDepositsToTotalLiabilities2,

                YearsPassedSinceCommencement1 = keyFinancialsEntity.YearsPassedSinceCommencement1,
                YearsPassedSinceCommencement2 = keyFinancialsEntity.YearsPassedSinceCommencement2,

                PromoterShareholdingPer1 = keyFinancialsEntity.PromoterShareholding1,
                PromoterShareholdingPer2 = keyFinancialsEntity.PromoterShareholding2,

                ProvisioningCoverageRatioPer1 = keyFinancialsEntity.ProvisioningCoverageRatioPer1,
                ProvisioningCoverageRatioPer2 = keyFinancialsEntity.ProvisioningCoverageRatioPer2,


            }).FirstOrDefault();

            subjectiveParameters = dbContext.SFB_SubjectiveParameters_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(subjectiveParametersEntity => new SFB_SubjectiveParametersEntity
            {
                //PropensityToSupportBank = subjectiveParametersEntity.PropensityToSupportBank,
                ExternalRating = subjectiveParametersEntity.ExternalRating,
                IndustryRiskScore = subjectiveParametersEntity.IndustryRiskScore,
                BusinessModel = subjectiveParametersEntity.BusinessModel,
                ManagementQuality = subjectiveParametersEntity.ManagementQuality,
                //UnderwritingStandards = subjectiveParametersEntity.UnderwritingStandards,
                AdverseNews = subjectiveParametersEntity.AdverseNews,
                CompanySpendsCorporateSocialResponsibility = subjectiveParametersEntity.CompanySpendsCorporateSocialResponsibility,
                AuditCommitteeHeldOnTime = subjectiveParametersEntity.AuditCommitteeHeldOnTime,
                AuditCommitteeDiscuAllCalendarItems = subjectiveParametersEntity.AuditCommitteeDiscuAllCalendarItems,
                NoChangeAuditorsBeforeTerm = subjectiveParametersEntity.NoChangeAuditorsBeforeTerm,
                //AuditCondByRepAuditFirms = subjectiveParametersEntity.AuditCondByRepAuditFirms,
                NoIndKeyManResignBeforeTerm = subjectiveParametersEntity.NoIndKeyManResignBeforeTerm,
                LessThanOnePerTotTran = subjectiveParametersEntity.LessThanOnePerTotTran,
                CentDBCapturesAllData = subjectiveParametersEntity.CentDBCapturesAllData,
                NPASysGen = subjectiveParametersEntity.NPASysGen,
                NoDelayInReporting = subjectiveParametersEntity.NoDelayInReporting,
                CompAndIndManagement = subjectiveParametersEntity.CompAndIndManagement,
                NoDivBetRegAssess = subjectiveParametersEntity.NoDivBetRegAssess,
                SMA1And2UnderLoanPort = subjectiveParametersEntity.SMA1And2UnderLoanPort,
                QualifiedOpinionByAuditor = subjectiveParametersEntity.QualifiedOpinionByAuditor,
                DefaultWithOtherLenders = subjectiveParametersEntity.DefaultWithOtherLenders,
            }).FirstOrDefault();

            industryExpsoures = dbContext.SFB_IndustryExpsoure_Archive.Where(data => data.DetailsId == detailsId && data.LogId == logId).Select(sfb_IndustryExpsoureEntity => new SFB_IndustryExpsoureEntity
            {
                //IndustryExpsoure_ArchiveId = sfb_IndustryExpsoureEntity.IndustryExpsoureId,
                //UserId = sfb_IndustryExpsoureEntity.use,
                DetailsId = sfb_IndustryExpsoureEntity.DetailsId.Value,
                AgricultureAlliedActivities1 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivities1,
                AgricultureAlliedActivitiesPer2 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivitiesPer2,
                AgricultureAlliedActivities3 = sfb_IndustryExpsoureEntity.AgricultureAlliedActivities3,
                MinigQuaring1 = sfb_IndustryExpsoureEntity.MinigQuaring1,
                MinigQuaringPer2 = sfb_IndustryExpsoureEntity.MinigQuaringPer2,
                MinigQuaring3 = sfb_IndustryExpsoureEntity.MinigQuaring3,
                FoodFoodProcessing1 = sfb_IndustryExpsoureEntity.FoodFoodProcessing1,
                FoodFoodProcessingPer2 = sfb_IndustryExpsoureEntity.FoodFoodProcessingPer2,
                FoodFoodProcessing3 = sfb_IndustryExpsoureEntity.FoodFoodProcessing3,
                Textiles1 = sfb_IndustryExpsoureEntity.Textiles1,
                TextilesPer2 = sfb_IndustryExpsoureEntity.TextilesPer2,
                Textiles3 = sfb_IndustryExpsoureEntity.Textiles3,
                MaterialtheirProducts1 = sfb_IndustryExpsoureEntity.MaterialtheirProducts1,
                MaterialtheirProductsPer2 = sfb_IndustryExpsoureEntity.MaterialtheirProductsPer2,
                MaterialtheirProducts3 = sfb_IndustryExpsoureEntity.MaterialtheirProducts3,
                PetroleumCoalProductsNuclearFuels1 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels1,
                PetroleumCoalProductsNuclearFuelsPer2 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuelsPer2,
                PetroleumCoalProductsNuclearFuels3 = sfb_IndustryExpsoureEntity.PetroleumCoalProductsNuclearFuels3,
                ChemicalChemicalProducts1 = sfb_IndustryExpsoureEntity.ChemicalChemicalProducts1,
                ChemicalChemicalProductsPer2 = sfb_IndustryExpsoureEntity.ChemicalChemicalProductsPer2,
                ChemicalChemicalProducts3 = sfb_IndustryExpsoureEntity.ChemicalChemicalProducts3,
                CementCementProducts1 = sfb_IndustryExpsoureEntity.CementCementProducts1,
                CementCementProductsPer2 = sfb_IndustryExpsoureEntity.CementCementProductsPer2,
                CementCementProducts3 = sfb_IndustryExpsoureEntity.CementCementProducts3,
                BasicMetalMetalProduct1 = sfb_IndustryExpsoureEntity.BasicMetalMetalProduct1,
                BasicMetalMetalProductPer2 = sfb_IndustryExpsoureEntity.BasicMetalMetalProductPer2,
                BasicMetalMetalProduct3 = sfb_IndustryExpsoureEntity.BasicMetalMetalProduct3,
                AllEngineering1 = sfb_IndustryExpsoureEntity.AllEngineering1,
                AllEngineeringPer2 = sfb_IndustryExpsoureEntity.AllEngineeringPer2,
                AllEngineering3 = sfb_IndustryExpsoureEntity.AllEngineering3,
                AutomobileAncillary1 = sfb_IndustryExpsoureEntity.AutomobileAncillary1,
                AutomobileAncillaryPer2 = sfb_IndustryExpsoureEntity.AutomobileAncillaryPer2,
                AutomobileAncillary3 = sfb_IndustryExpsoureEntity.AutomobileAncillary3,
                GemsJewellery1 = sfb_IndustryExpsoureEntity.GemsJewellery1,
                GemsJewelleryPer2 = sfb_IndustryExpsoureEntity.GemsJewelleryPer2,
                GemsJewellery3 = sfb_IndustryExpsoureEntity.GemsJewellery3,
                Construction1 = sfb_IndustryExpsoureEntity.Construction1,
                ConstructionPer2 = sfb_IndustryExpsoureEntity.ConstructionPer2,
                Construction3 = sfb_IndustryExpsoureEntity.Construction3,
                Power1 = sfb_IndustryExpsoureEntity.Power1,
                PowerPer2 = sfb_IndustryExpsoureEntity.PowerPer2,
                Power3 = sfb_IndustryExpsoureEntity.Power3,
                Telecommunication1 = sfb_IndustryExpsoureEntity.Telecommunication1,
                TelecommunicationPer2 = sfb_IndustryExpsoureEntity.TelecommunicationPer2,
                Telecommunication3 = sfb_IndustryExpsoureEntity.Telecommunication3,
                RestoftheInfrastructure1 = sfb_IndustryExpsoureEntity.RestoftheInfrastructure1,
                RestoftheInfrastructurePer2 = sfb_IndustryExpsoureEntity.RestoftheInfrastructurePer2,
                RestoftheInfrastructure3 = sfb_IndustryExpsoureEntity.RestoftheInfrastructure3,
                NBFCs1 = sfb_IndustryExpsoureEntity.NBFCs1,
                NBFCsPer2 = sfb_IndustryExpsoureEntity.NBFCsPer2,
                NBFCs3 = sfb_IndustryExpsoureEntity.NBFCs3,
                OtherIndustries1 = sfb_IndustryExpsoureEntity.OtherIndustries1,
                OtherIndustriesPer2 = sfb_IndustryExpsoureEntity.OtherIndustriesPer2,
                OtherIndustries3 = sfb_IndustryExpsoureEntity.OtherIndustries3,
                Retail1 = sfb_IndustryExpsoureEntity.Retail1,
                RetailPer2 = sfb_IndustryExpsoureEntity.RetailPer2,
                Retail3 = sfb_IndustryExpsoureEntity.Retail3,
                MicroFinance1 = sfb_IndustryExpsoureEntity.MicroFinance1,
                MicroFinancePer2 = sfb_IndustryExpsoureEntity.MicroFinancePer2,
                MicroFinance3 = sfb_IndustryExpsoureEntity.MicroFinance3,
                TotalAdvances = sfb_IndustryExpsoureEntity.TotalAdvances,

            }).FirstOrDefault();

            outputDetails = (from output in dbContext.SFB_Output_Details_Archive
                             join template in dbContext.SFB_Output_Template on output.TemplateId equals template.TemplateID
                             where output.DetailsId == detailsId && output.LogId == logId

                             select new SFB_OutputDetailsEntity
                             {
                                 TemplateID = output.TemplateId,
                                 Parameter1 = string.IsNullOrEmpty(template.Parameter1) ? string.Empty : template.Parameter1,
                                 Parameter1Per = string.IsNullOrEmpty(template.Parameter1Per) ? string.Empty : template.Parameter1Per,
                                 Parameter2 = string.IsNullOrEmpty(template.Parameter2) ? string.Empty : template.Parameter2,
                                 Parameter2Per = string.IsNullOrEmpty(template.Parameter2Per) ? string.Empty : template.Parameter2Per,
                                 Parameter3Per = output.Parameter_Per,
                                 Parameter3 = output.Parameter_Name,
                                 UnderBaselIII_Score = string.IsNullOrEmpty(output.UnderBaselIII_Score) ? string.Empty : output.UnderBaselIII_Score,
                                 UnderBaselIII_Value = string.IsNullOrEmpty(output.UnderBaselIII_Value) ? string.Empty : output.UnderBaselIII_Value,
                                 UnderIND_Score = string.IsNullOrEmpty(output.UnderIND_Score) ? string.Empty : output.UnderIND_Score,
                                 UnderIND_Value = string.IsNullOrEmpty(output.UnderIND_Value) ? string.Empty : output.UnderIND_Value,
                                 Comments = string.IsNullOrEmpty(output.Comments) ? string.Empty : output.Comments,
                             }).ToList();

            basicDetails.SFB_KeyFinancialsEntity = keyFinancials;
            basicDetails.SFB_SubjectiveParametersEntity = subjectiveParameters;
            basicDetails.SFB_IndustryExpsoureEntity = industryExpsoures;
            basicDetails.SFB_OutputDetailsEntity = outputDetails;

            return basicDetails;
        }

        public bool ComputeOutputDetails(SFB_BasicDetailsEntity riskModelExcelEntity, string OutputTemplateFilePath)
        {
            CompanyDAL companyDAL = new CompanyDAL();
            Microsoft.Office.Interop.Excel.Workbook mWorkBook = null;
            Microsoft.Office.Interop.Excel.Sheets mWorkSheets = null;
            Microsoft.Office.Interop.Excel.Worksheet mWSheet = null;
            Microsoft.Office.Interop.Excel.Application xlApp = null;

            xlApp = new Microsoft.Office.Interop.Excel.Application();
            object misValue = System.Reflection.Missing.Value;
            xlApp.DisplayAlerts = false;
            xlApp.EditDirectlyInCell = true;
            xlApp.EnableEvents = true;
            try
            {
                mWorkBook = xlApp.Workbooks.Open(OutputTemplateFilePath, 0, false, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                mWorkSheets = mWorkBook.Worksheets;
                mWSheet = (Microsoft.Office.Interop.Excel.Worksheet)mWorkBook.Worksheets["Data Input Sheet"];

                string value = "";
                uint rowIndex = 0;
                int columnIndex = 0;

                string columnName = "";
                object obj;

                // Basic detail fields update - Company Name
                try
                {
                    string companyName = companyDAL.GetCompanyNameByID(riskModelExcelEntity.CompanyId);

                    rowIndex = _helperDAL.GetExcelRowIndex("B4");
                    columnName = _helperDAL.GetExcelColumnName("B4");
                    columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                    mWSheet.Cells[rowIndex, columnIndex] = companyName;
                }
                catch { }

                PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
                properties = TypeDescriptor.GetProperties(riskModelExcelEntity);
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = riskModelExcelEntity.GetType().GetProperty(property.Name).GetValue(riskModelExcelEntity, null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                try
                                {
                                    value = Convert.ToString(double.Parse(value) / 100);
                                    //value = (value == string.Empty || value.ToUpper().Trim() == "NA") ? "0" : Convert.ToString(double.Parse(value) / 100);
                                }
                                catch
                                {

                                }
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                properties = TypeDescriptor.GetProperties(riskModelExcelEntity.SFB_KeyFinancialsEntity);
                SFB_KeyFinancialsEntity getKeyFinancialsEntity = riskModelExcelEntity.SFB_KeyFinancialsEntity;
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = getKeyFinancialsEntity.GetType().GetProperty(property.Name).GetValue(getKeyFinancialsEntity, null);
                            value = obj.ToString();
                            var type = getKeyFinancialsEntity.GetType().GetProperty(property.Name).ToString();
                            if (type.ToLower().Contains("system.datetime"))
                            {
                                try
                                {
                                    DateTime dt = Convert.ToDateTime(value.ToString());
                                    mWSheet.Cells[rowIndex, columnIndex] = dt.ToString("dd-MMM-yyyy");
                                }
                                catch { }
                            }
                            else
                            {
                                string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                                if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                                {
                                    try
                                    {
                                        value = Convert.ToString(double.Parse(value) / 100);
                                    }
                                    catch
                                    {

                                    }
                                    //value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                                }
                                mWSheet.Cells[rowIndex, columnIndex] = value;
                            }
                        }
                        catch { }
                    }
                }

                properties = TypeDescriptor.GetProperties(riskModelExcelEntity.SFB_SubjectiveParametersEntity);
                SFB_SubjectiveParametersEntity getSubjectiveParametersEntity = riskModelExcelEntity.SFB_SubjectiveParametersEntity;
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = getSubjectiveParametersEntity.GetType().GetProperty(property.Name).GetValue(getSubjectiveParametersEntity, null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                properties = TypeDescriptor.GetProperties(riskModelExcelEntity.SFB_IndustryExpsoureEntity);
                SFB_IndustryExpsoureEntity getIndustryExpsoureEntity = riskModelExcelEntity.SFB_IndustryExpsoureEntity;
                foreach (PropertyDescriptor property in properties)
                {
                    if (property != null)
                    {
                        try
                        {
                            rowIndex = _helperDAL.GetExcelRowIndex(property.Category);
                            columnName = _helperDAL.GetExcelColumnName(property.Category);
                            columnIndex = _helperDAL.GetExcelColumnIndex(columnName);
                            if (rowIndex == 0)
                            {
                                continue;
                            }
                            obj = getIndustryExpsoureEntity.GetType().GetProperty(property.Name).GetValue(getIndustryExpsoureEntity, null);
                            value = obj.ToString();
                            string a = property.Name.Substring(property.Name.Length - 4, 4).ToLower();
                            if (property.Name.Substring(property.Name.Length - 4, 4).ToLower().Contains("per"))
                            {
                                value = value == string.Empty ? "0" : Convert.ToString(double.Parse(value) / 100);
                            }
                            mWSheet.Cells[rowIndex, columnIndex] = value;
                        }
                        catch { }
                    }
                }

                mWorkBook.Save();
                mWorkBook.Close(1, null, null);
                xlApp.Quit();
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                mWSheet = null;
                mWorkBook = null;
                mWorkSheets = null;
                xlApp = null;

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            return true;
        }

    }

}