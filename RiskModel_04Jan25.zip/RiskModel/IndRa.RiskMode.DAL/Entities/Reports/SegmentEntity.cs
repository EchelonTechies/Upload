﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class SegmentEntity
    {
        public long SrNo { get; set; }
        public long ModelId { get; set; }
        public string ModelName { get; set; }
        public string CompanyName { get; set; }

        public string year { get; set; }
    }
}
