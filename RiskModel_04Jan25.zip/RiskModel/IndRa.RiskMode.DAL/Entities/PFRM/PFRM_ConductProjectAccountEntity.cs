﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_ConductProjectAccountEntity
    {
        public int ConductProjectAccountId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }


        [DisplayName("Actual Schedule versus Project Plan (not applicable in case of a new project)")]
        [Category("B37")]
        public string ActualScheduleVersusProjectPlan { get; set; }

        [DisplayName("Percentage of project completion")]
        [Category("B38")]
        public string PercentageProjectCompletion { get; set; }


        [DisplayName("Moratorium (not applicable in case of a new project)")]
        [Category("B39")]
        public string Moratorium { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsStaging { get; set; }
        public bool IsFinal { get; set; }
    }
}
