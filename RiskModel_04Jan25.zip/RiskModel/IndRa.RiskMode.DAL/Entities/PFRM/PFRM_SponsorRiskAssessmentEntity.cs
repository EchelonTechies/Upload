﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_SponsorRiskAssessmentEntity
    {
        public int SponsorRiskAssessmentId { get; set; }
        public int DetailsId { get; set; }

        public short LogId { get; set; }

        [DisplayName("Equity participation by the Promoters")]
        [Category("B7")]
        public string EquityparticipationPromoters { get; set; }

        [DisplayName("Project Equity/ Total Net Worth of Promoters or Net worth of the government bodies (in case of joint venture (private and government stakeholders), net worth of the government bodies should be taken irrespective of its share in the project. )")]
        [Category("B8")]
        public string ProjectEquityTotalNetWorthPromoters { get; set; }
        
        //[DisplayName("Ability to Fund Cost Overruns")]
        //[Category("B7")]
        //public string AbilityFundCostOverruns { get; set; }
        
        //[DisplayName("Ability to Handle Projects in hand")]
        //[Category("B8")]
        //public string AbilityHandleProjectsHand { get; set; }
        
        //[DisplayName("Competence of Senior Management in the Sector")]
        //[Category("B9")]
        //public string CompetenceSeniorManagementSector { get; set; }
        
        [DisplayName("Competence of Senior Management in Project Execution (In case of government entities, highest points should be awarded in the assessment given the projects are led by IAS officers and associated risk is minimal. Further, the parameter should only be assessed in case of private entities)")]
        [Category("B9")] 
        public string CompetenceSeniorManagementProjectExecution { get; set; }
        
        //[DisplayName("Management Integrity")]
        //[Category("B11")]
        //public string ManagementIntegrity { get; set; }

        [DisplayName("Credit Track Record")]
        [Category("B10")]
        public string CreditTrackRecord { get; set; }

        //[DisplayName("General Reputation")]
        //[Category("B13")]
        //public string GeneralReputation { get; set; }
        
        //[DisplayName("Intra Promoter Conflicts")]
        //[Category("B14")]
        //public string IntraPromoterConflicts { get; set; }
        
        //[DisplayName("Past track record of Projects")]
        //[Category("B15")]
        //public string PastTrackRecordProjects { get; set; }
        
        //[DisplayName("Banking History")]
        //[Category("B16")]
        //public string BankingHistory { get; set; }
        
        //[DisplayName("Transfer of ownership track record")]
        //[Category("B17")]
        //public string TransferOwnershipTrackRecord { get; set; }

        //[DisplayName("Dispute and Litigation track record of the developer")]
        //[Category("B18")]
        //public string DisputeLitigationTrackRecordDeveloper { get; set; }

        //[DisplayName("Marketing/ Sales Performance (average for last 3 years)")]
        //[Category("B19")]
        //public string MarketingSalesPerformance { get; set; }
        
        //[DisplayName("Clientile/ Customer Satisfaction")]
        //[Category("B20")]
        //public string ClientileCustomerSatisfaction { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

    }
}
