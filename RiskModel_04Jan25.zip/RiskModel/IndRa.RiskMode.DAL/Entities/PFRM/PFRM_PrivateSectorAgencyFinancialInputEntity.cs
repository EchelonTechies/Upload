﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_PrivateSectorAgencyFinancialInputEntity
    {
        public int PrivateSectorAgencyFinancialInputId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        [DisplayName("Net Worth (in Rs. Cr) in last accounting year")]
        [Category("B44")]
        public string NetWorthLastAccountingYear { get; set; }

        [DisplayName("Return on Capital Employed (ROCE) for last accounting year")]
        [Category("B45")]
        public string ReturnCapitalEmployedLastAccountingyearPer { get; set; }
        
        [DisplayName("Debt/ EBITDA for last accounting year")]
        [Category("B46")]
        public string DebtEBITDALastAccountingYear { get; set; }

        [DisplayName("Interest Coverage for last accounting year")]
        [Category("B47")]
        public string InterestCoverageLastAccountingYear { get; set; }

        [DisplayName("Cash Interest Coverage for last accounting year")]
        [Category("B48")]
        public string CashInterestCoveragelastAccountingYear { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

    }
}






