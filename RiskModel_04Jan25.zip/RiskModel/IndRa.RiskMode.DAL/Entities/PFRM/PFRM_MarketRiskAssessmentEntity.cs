﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_MarketRiskAssessmentEntity
    {
        public int MarketRiskAssessmentId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        [DisplayName("State of the economy")]
        [Category("B18")]
        public string StateEconomy { get; set; }

        [DisplayName("Regulatory issues/fiscal policy dependence")]
        [Category("B19")]
        public string RegulatoryIssuesFiscalPolicyDependence { get; set; }
        
        [DisplayName("Environmental impact")]
        [Category("B20")]
        public string EnvironmentalImpact { get; set; }
        
        //[DisplayName("Demand Supply situation")]
        //[Category("B32")]
        //public string DemandSupplySituation { get; set; }
        
        [DisplayName("Offtake Price Competitiveness")]
        [Category("B21")]
        public string OfftakePriceCompetitiveness { get; set; }

        [DisplayName("Extent of Integrated Product Offering")]
        [Category("B22")]
        public string ExtentIntegratedProductOffering { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

    }
}