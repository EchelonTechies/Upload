﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_ProjectCostViablityEntity
    {
        public int ProjectCostViablityId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }


        [DisplayName("Projected Debt Service Coverage Ratio (Average DSCR)")]
        [Category("B24")]
        public string ProjectedDebtServiceCoverageRatio { get; set; }

        [DisplayName("Internal Rate of Return (IRR)")]
        [Category("B25")]
        public string InternalRateReturn { get; set; }
        
        [DisplayName("Firmness of Project Cost")]
        [Category("B26")]
        public string FirmnessProjectCost { get; set; }
        
        //[DisplayName("Certainty of Construction Cost")]
        //[Category("B39")]
        //public string CertaintyConstructionCost { get; set; }
        
        [DisplayName("Sensitivity analysis (10% reduction in demand or 10% increase in project cost)")]
        [Category("B27")]
        public string SensitivityAnalysis { get; set; }
        
        [DisplayName("Contingent Liability")]
        [Category("B28")]
        public string ContingentLiability { get; set; }

        //[DisplayName("Fund Transfer Mechansim")]
        //[Category("B42")]
        //public string FundTransferMechansim { get; set; }


        [DisplayName("Security and Government support")]
        [Category("B29")]
        public string SecurityandGovernmentSupport { get; set; }

        [DisplayName("Force Majeure Risk")]
        [Category("B30")]
        public string ForceMajeureRisk { get; set; }
        
        [DisplayName("Interest Rate Hedging")]
        [Category("B31")]
        public string InterestRateHedging { get; set; }

        [DisplayName("Debt Equity Ratio")]
        [Category("B32")]
        public string DebtEquityRatio { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

    }
}
