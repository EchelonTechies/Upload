﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_MicroFinanceInstitutionEntity
    {
        public int MicroFinanceInstitutionId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }


        [DisplayName("CRAR % in last accounting year")]
        [Category("B58")]
        public string CRARLastAccountingYearPer { get; set; }

        [DisplayName("Portfolio at Risk > 90 days (%)")]
        [Category("B59")]
        public string PortfolioRiskGreaterNintyDaysPer { get; set; }
        
        
        [DisplayName("Return on Capital Employed for last accounting year")]
        [Category("B60")]
        public string MicroReturnCapitalEmployedLastAccountingYearPer { get; set; }

        
        [DisplayName("Operational Self Sufficiency")]
        [Category("B61")]
        public string OperationalSelfSufficiency { get; set; }

        [DisplayName("Average Portfolio Deployed in Rs. Crore")]
        [Category("B62")]
        public string AveragePortfolioDeployedRsCrore { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

    }
}






