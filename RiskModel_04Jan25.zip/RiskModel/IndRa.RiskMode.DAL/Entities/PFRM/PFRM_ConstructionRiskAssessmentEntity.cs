﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_ConstructionRiskAssessmentEntity
    {
        public int ConstructionRiskAssessmentId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        [DisplayName("Land Availability")]
        [Category("B12")]
        public string LandAvailabillity { get; set; }

        [DisplayName("Labour Availability")]
        [Category("B13")]
        public string LabourAvailabillity { get; set; }
        
        [DisplayName("Infrastructure (Connectivity and Transportation)")]
        [Category("B14")]
        public string InfrastructureConnection { get; set; }
        
        [DisplayName("Availability of Utility")]
        [Category("B15")]
        public string AvailabilityUtility { get; set; }
        
        //[DisplayName("Legal Risk")]
        //[Category("B26")]
        //public string LegalRisk { get; set; }

        [DisplayName("Permits and Licenses")]
        [Category("B16")]
        public string PermitsLicenses { get; set; }

        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
    }
}
