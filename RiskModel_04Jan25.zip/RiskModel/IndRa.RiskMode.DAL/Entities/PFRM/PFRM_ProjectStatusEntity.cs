﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_ProjectStatusEntity
    {
        public int ProjectStatusId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }


        [DisplayName("Project Design/ Structure")]
        [Category("B34")]
        public string ProjectDesignStructure { get; set; }
        
        [DisplayName("Detailed Project Feasibility Report")]
        [Category("B35")]
        public string DetailedProjectFeasibilityReport { get; set; }

        //[DisplayName("Status of Project Clearances")]
        //[Category("B49")]
        //public string StatusProjectClearances { get; set; }
        
        //[DisplayName("Status of Financial closure")]
        //[Category("B50")]
        //public string StatusFinancialclosure { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

    }
}





