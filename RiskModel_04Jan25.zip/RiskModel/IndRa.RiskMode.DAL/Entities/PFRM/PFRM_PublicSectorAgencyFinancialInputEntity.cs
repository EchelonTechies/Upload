﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_PublicSectorAgencyFinancialInputEntity
    {
        public int PublicSectorAgencyFinancialInputId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }


        [DisplayName("Tax Revenue Collection Efficiency")]
        [Category("B51")]
        public string TaxRevenueCollectionEfficiencyPer { get; set; }

        [DisplayName("Average LCR for last 3 years")]
        [Category("B52")]
        public string AverageLCRLastThreeyears { get; set; }
        
        [DisplayName("LCR for last accounting year")]
        [Category("B53")]
        public string LCRLastAccountingYear { get; set; }
        
        [DisplayName("Surplus Generation (PAT %) for last accounting year")]
        [Category("B54")]
        public string SurplusGenerationLastAccountingYearPer { get; set; }

        [DisplayName("Average Surplus Generation (PAT %) for last 3 years")]
        [Category("B55")]
        public string AverageSurplusGenerationLastThreeYearsPer { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

    }
}
