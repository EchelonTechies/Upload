﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_BasicDetailsEntity
    {

        public int DetailsId { get; set; }
        public short LogId { get; set; }

        public HttpPostedFileBase ExcelFile { get; set; }
        public int UserId { get; set; }
        public string ButtonValue { get; set; }

        public int CompanyId { get; set; }
        public int reportCompanyId { get; set; }


        [Category("B1")]
        [DisplayName("Financial Year")]
        public string FinYear { get; set; }

        [Category("B2")]
        [DisplayName("Name of the Project")]
        public string CompanyName { get; set; }

        [Category("B3")]
        [DisplayName("Date of Balance Sheet")]
        public DateTime? DateOfInput { get; set; }

        [Category("B4")]
        [DisplayName("Type of Project")]
        public string ProjectTypeName { get; set; }
        public short? ProjectTypeId { get; set; }

        [Category("B5")]
        [DisplayName("Name of the Promoter")]
        public string PromoterName { get; set; }

        [DisplayName("Company")]
        public string reportCompany { get; set; }
        public int LocationId { get; set; }
        [DisplayName("Location")]
        public string LocationName { get; set; }
        public string selectedLocation { get; set; }
       
        [DisplayName("Financial Year Ending Date")]
        public string FinancialYearEndingDate { get; set; }
        [DisplayName("Input Currency")]
        public string CurrencyUnits { get; set; }
        public string ParentCompanyIsExist { get; set; }
        public int? ParentCompanyId { get; set; }
        [DisplayName("Parent Company")]
        public string ParentCompanyName { get; set; }
        public int? ParentRatingId { get; set; }
        [DisplayName("Parent Rating")]
        public string ParentRating { get; set; }
        [DisplayName("Sponsor Bank")]
        public string SponsorBank{ get; set; }
        [DisplayName("Parent Company Share Holding (%)")]
        public decimal? ParentCompanyShareHoldingPer { get; set; }

      

        [DisplayName("Admin Comments")]
        public string Comments { get; set; }

        [DisplayName("Final Rating As Per Rating Committe")]
        public string FinalRating { get; set; }

        [DisplayName("PD")]
        public string PD { get; set; }

        public string InputFilePath { get; set; }

        public bool? SubmitForApproval { get; set; }

        public DateTime? SubmitForApprovalDate { get; set; }

        public DateTime? ApprovedDate { get; set; }

        public DateTime? ReviewedDate { get; set; }

        public int CreatedBy { get; set; }
        [DisplayName("Created Date")]
        public DateTime CreatedDateTime { get; set; }
        [DisplayName("Created Date")]
        public DateTime reportCreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

        public PFRM_ConductProjectAccountEntity PFRM_ConductProjectAccountEntity { get; set; }
        public PFRM_ConstructionRiskAssessmentEntity PFRM_ConstructionRiskAssessmentEntity { get; set; }
        public PFRM_MarketRiskAssessmentEntity PFRM_MarketRiskAssessmentEntity { get; set; }
        public PFRM_MicroFinanceInstitutionEntity PFRM_MicroFinanceInstitutionEntity { get; set; }
        public PFRM_PrivateSectorAgencyFinancialInputEntity PFRM_PrivateSectorAgencyFinancialInputEntity { get; set; }
        public PFRM_PublicSectorAgencyFinancialInputEntity PFRM_PublicSectorAgencyFinancialInputEntity { get; set; }
        public PFRM_ProjectCostViablityEntity PFRM_ProjectCostViablityEntity { get; set; }
        public PFRM_ProjectStatusEntity PFRM_ProjectStatusEntity { get; set; }
        public PFRM_SponsorRiskAssessmentEntity PFRM_SponsorRiskAssessmentEntity { get; set; }
        public List<PFRM_OutputDetailsEntity> PFRM_OutputDetailsEntity { get; set; }

    }
}
