﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class PFRM_OutputDetailsEntity
    {
        public int OutputDetailsId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        public short LineId { get; set; }
        public string First_Column_Name { get; set; }
        public string Parameter_Name { get; set; }
        public string Rank { get; set; }
        public string Score { get; set; }
        public string Comment { get; set; }
        public string Values { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

    }
}
