﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_ALM_Statement_Latests
    {
        public int ALMStatementId { get; set; }
        public int DetailsId { get; set; }

        [DisplayName("Date of Statement")]
        public string StatementDate { get; set; }
        public DateTime? Statement_Date { get; set; }
        public string Particulars { get; set; }
        [DisplayName("Particulars Inflow")]
        public string ParticularsInflow { get; set; }
        [DisplayName("Particulars Ourflow")]
        public string ParticularsOurflow { get; set; }
        [DisplayName("Particulars Mismatch")]
        public string ParticularsMismatch { get; set; }

        [DisplayName("1 to 14 days")]
        public string Day1to14Days { get; set; }
        public string Day1to14DaysInflow { get; set; }
        public string Day1to14DaysOurflow { get; set; }
        public string Day1to14DaysMismatch { get; set; }

        [DisplayName("Over 14 days to one month")]
        public string Day14DaysTo1Month { get; set; }
        public string Day14DaysTo1MonthInflow { get; set; }
        public string Day14DaysTo1MonthOurflow { get; set; }
        public string Day14DaysTo1MonthMismatch { get; set; }

        [DisplayName("Over one month to 2 months")]
        public string Month1To2Months { get; set; }
        public string Month1To2MonthsInflow { get; set; }
        public string Month1To2MonthsOurflow { get; set; }
        public string Month1To2MonthsMismatch { get; set; }

        [DisplayName("Over 2 months to 3 months")]
        public string Month2To3Months { get; set; }
        public string Month2To3MonthsInflow { get; set; }
        public string Month2To3MonthsOurflow { get; set; }
        public string Month2To3MonthsMismatch { get; set; }

        [DisplayName("Over 3 Months upto 6 months")]
        public string Month3To6Months { get; set; }
        public string Month3To6MonthsInflow { get; set; }
        public string Month3To6MonthsOurflow { get; set; }
        public string Month3To6MonthsMismatch { get; set; }

        [DisplayName("Over 6 Months upto 1 year")]
        public string Month6MonthsTo1Year { get; set; }
        public string Month6MonthsTo1YearInflow { get; set; }
        public string Month6MonthsTo1YearOurflow { get; set; }
        public string Month6MonthsTo1YearMismatch { get; set; }

        [DisplayName("Over 1 year upto 3 years")]
        public string Year1To3Years { get; set; }
        public string Year1To3YearsInflow { get; set; }
        public string Year1To3YearsOurflow { get; set; }
        public string Year1To3YearsMismatch { get; set; }

        [DisplayName("Over 3 years upto 5 years")]
        public string Year3To5Years { get; set; }
        public string Year3To5YearsInflow { get; set; }
        public string Year3To5YearsOurflow { get; set; }
        public string Year3To5YearsMismatch { get; set; }

        [DisplayName("Over 5 years upto 7 years")]
        public string Year5To7Years { get; set; }
        public string Year5To7YearsInflow { get; set; }
        public string Year5To7YearsOurflow { get; set; }
        public string Year5To7YearsMismatch { get; set; }

        [DisplayName("Over 7 years upto 10 years")]
        public string Year7To10Years { get; set; }
        public string Year7To10YearsInflow { get; set; }
        public string Year7To10YearsOurflow { get; set; }
        public string Year7To10YearsMismatch { get; set; }

        [DisplayName("Over 10 years")]
        public string Over10Years { get; set; }
        public string Over10YearsInflow { get; set; }
        public string Over10YearsOurflow { get; set; }
        public string Over10YearsMismatch { get; set; }

        public int CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }
    }
}
