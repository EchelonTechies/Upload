﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class SubjectiveParametersEntity
    {
        public int HeaderId { get; set; }
        public string HeaderName { get; set; }
        public string Definitions { get; set; }
        public string value { get; set; }
    }
}
