﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class OutputTemplateEntity
    {
        public short TemplateID { get; set; }
        public string Parameter1 { get; set; }
        public string Parameter1Per { get; set; }
        public string Parameter2 { get; set; }
        public string Parameter2Per { get; set; }
        public string Parameter3 { get; set; }
        public string Parameter3Per { get; set; }
        public string UnderBaselIII_Score { get; set; }
        public string UnderBaselIII_Value { get; set; }
        public string UnderIND_Score { get; set; }
        public string UnderIND_Value { get; set; }
        public string Comments { get; set; }
    }
}
