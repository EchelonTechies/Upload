﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class CompanyEntity
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string PanCard { get; set; }
        public string ModelName { get; set; }
        public short? ModelId { get; set; }
        public int? AssignedAnalystId { get; set; }
        public DateTime? AssignedDate { get; set; }

        public string AssignedAnalystName { get; set; }
        public bool InActive { get; set; }
        public int LocationId { get; set; }
        public int RatingId { get; set; }
        public string RatingName { get; set; }
        public string LocationName { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public int UserId { get; set; }
        public string ActivityType { get; set; }
        public string AnalystName { get; set; }
        public string CreatedDate { get; set; }
        public string UpdatedDate { get; set; }
        public string CreatedByName { get; set; }

    }
}
