﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_Management_RiskInputss
    {
        public int ManagementRiskId { get; set; }
        public int DetailsId { get; set; }
        [DisplayName("Ability to meet/ Achievement of Revenue Projections")]
        public string AbilityToMeetRevenueProjection { get; set; }
        [DisplayName("Ability to meet/ Achievement of Profit Projections")]
        public string AbilityToMeetProfitProjection { get; set; }
        [DisplayName("Past Payment Record and Track record of payment of statutory dues/financial obligations ")]
        public string PastPaymentRecord { get; set; }
        [DisplayName("Risk Management System")]
        public string RiskManagementSystem { get; set; }
        [DisplayName("Management Credibility")]
        public string ManagementCredibility { get; set; }
        [DisplayName("Management Experience and Competence")]
        public string ManagementExperienceAndCompetence { get; set; }
        [DisplayName("Risk Appetite")]
        public string RiskAppetite { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }

    }
}
