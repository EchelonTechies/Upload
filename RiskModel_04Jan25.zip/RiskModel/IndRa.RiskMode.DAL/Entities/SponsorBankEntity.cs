﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class SponsorBankEntity
    {
        public int SponsorBankId { get; set; }
        public string SponsorBankName { get; set; }
    }
}
