﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_Industry_RiskInputss
    {
        public int IndustryRiskId { get; set; }
        public int DetailsId { get; set; }
        [DisplayName("Financial Performance of Players")]
        public string FinancialPerformanceofPlayer { get; set; }
        [DisplayName("Extent of Competition")]
        public string ExtentOfCompetition { get; set; }
        [DisplayName("Prospect of Real Estate Market")]
        public string ProspectOfRealEstateMarket { get; set; }
        [DisplayName("Regulatory Impact - Government Policy")]
        public string RegulatoryImpact { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }

    }
}
