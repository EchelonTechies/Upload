﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class HFCNew_KeyFinancialsEntity
    {
        public int KeyFinancialsId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        [DisplayName("Period of Year End")]
        [Category("B6")]
        public DateTime? PeriodEndingDate1 { get; set; }
        [DisplayName("Period of Year End2")]
        [Category("C6")]
        public DateTime? PeriodEndingDate2 { get; set; }

        [DisplayName("No. of Months in the Period")]
        [Category("B7")]
        public short? NoofMonthsPeriod1 { get; set; }
        [DisplayName("No. of Months in the Period2")]
        [Category("C7")]
        public short? NoofMonthsPeriod2 { get; set; }

        [DisplayName("Currency")]
        [Category("B8")]
        public string Currency1 { get; set; }
        [Category("C8")]
        [DisplayName("Currency2")]
        public string Currency2 { get; set; }

        [DisplayName("Tangible Net Worth")]
        [Category("B9")]
        public string NetWorth1 { get; set; }
        [DisplayName("Tangible Net Worth2")]
        [Category("C9")]
        public string NetWorth2 { get; set; }

        [DisplayName("Total Assets")]
        [Category("B10")]
        public string TotalAssets1 { get; set; }
        [DisplayName("Total Assets2")]
        [Category("C10")]
        public string TotalAssets2 { get; set; }

        //[DisplayName("Unencumbered Liquid Assets (As % of Total Assets)")]
        //[Category("B11")]
        //public string UnencumberedLiquidAssetsPer1 { get; set; }
        //[DisplayName("Unencumbered Liquid Assets (As % of Total Assets)2")]
        //[Category("C11")]
        //public string UnencumberedLiquidAssetsPer2 { get; set; }


        [DisplayName("Return on Assets (%)")]
        [Category("B11")]
        public string ReturnOnAssetsPer1 { get; set; }
        [DisplayName("Return on Assets (%)2")]
        [Category("C11")]
        public string ReturnOnAssetsPer2 { get; set; }


        [DisplayName("Return on Equity (%)")]
        [Category("B12")]
        public string ReturnonEquityPer1 { get; set; }
        [DisplayName("Return on Equity (%)2")]
        [Category("C12")]
        public string ReturnonEquityPer2 { get; set; }

        //[DisplayName("Return on Net Worth")]
        //[Category("B13")]
        //public string ReturnOnNetWorthPer1 { get; set; }
        //[DisplayName("Return on Net Worth2")]
        //[Category("C13")]
        //public string ReturnOnNetWorthPer2 { get; set; }

        [DisplayName("Cost Of Funds (%)")]
        [Category("B13")]
        public string CostOfFundsPer1 { get; set; }
        [DisplayName("Cost Of Funds (%)2")]
        [Category("C13")]
        public string CostOfFundsPer2 { get; set; }

        [DisplayName("Net Interest Margin (%)")]
        [Category("B14")]
        public string NetInterestMarginPer1 { get; set; }
        [DisplayName("Net Interest Margin (%)2")]
        [Category("C14")]
        public string NetInterestMarginPer2 { get; set; }

        [DisplayName("CRAR (%)")]
        [Category("B15")]
        public string CRARPer1 { get; set; }
        [DisplayName("CRAR (%)2")]
        [Category("C15")]
        public string CRARPer2 { get; set; }

        [DisplayName("Tier 1 (%)")]
        [Category("B16")]
        public string Tier1Per1  { get; set; }
        [DisplayName("Tier 1 (%)2")]
        [Category("C16")]
        public string Tier1Per2 { get; set; }

        [DisplayName("Net NPA (%)")]
        [Category("B17")]
        public string NetNPAPer1 { get; set; }
        [DisplayName("Net NPA (%)2")]
        [Category("C17")]
        public string NetNPAPer2 { get; set; }

        [DisplayName("Total No. of Branches")]
        [Category("B18")]
        public string TotalNoOfBranches1 { get; set; }
        [DisplayName("Total No. of Branches2")]
        [Category("C18")]
        public string TotalNoOfBranches2 { get; set; }

        [DisplayName("Gross NPA (%)")]
        [Category("B19")]
        public string GrossNPAPer1 { get; set; }
        [DisplayName("Gross NPA (%)2")]
        [Category("C19")]
        public string GrossNPAPer2 { get; set; }

        [DisplayName("Addition in NPAs/ Advances (%)")]
        [Category("B20")]
        public string AdditioninNPAsAdvancesPer1 { get; set; }
        [DisplayName("Addition in NPAs/ Advances (%)2")]
        [Category("C20")]
        public string AdditioninNPAsAdvancesPer2 { get; set; }

        [DisplayName("Tangible NW/ Net NPA (x)")]
        [Category("B21")]
        public string TangibleNWNetNPA1 { get; set; }
        [DisplayName("Tangible NW/ Net NPA (x)2")]
        [Category("C21")]
        public string TangibleNWNetNPA2 { get; set; }

        [DisplayName("Total Cont. Liability/ Total Assets (%)")]
        [Category("B22")]
        public string TotalContLiabilityTotalAssetsPer1 { get; set; }
        [DisplayName("Total Cont. Liability/ Total Assets (%)2")]
        [Category("C22")]
        public string TotalContLiabilityTotalAssetsPer2 { get; set; }

        [DisplayName("PBC towards Housing Finance for individuals as a % of total assets")]
        [Category("B23")]
        public string PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer1 { get; set; }

        [DisplayName("PBC towards Housing Finance for individuals as a % of total assets2")]
        [Category("C23")]
        public string PBCtowardsHousingFinanceForIndividualsAsofTotalAssetsPer2 { get; set; }


        [DisplayName("PBC towards Housing Finance as a % of total assets")]
        [Category("B24")]
        public string PBCtowardsHousingFinanceAsofTotalAssetsPer1 { get; set; }

        [DisplayName("PBC towards Housing Finance as a % of total assets2")]
        [Category("C24")]
        public string PBCtowardsHousingFinanceAsofTotalAssetsPer2 { get; set; }


        //public string IndividualHousingLoanTotalAdvancesPer1 { get; set; }
        //public string IndividualHousingLoanTotalAdvancesPer2 { get; set; }

        [DisplayName("Liquidity Coverage Ratio (%)")]
        [Category("B25")]
        public string LiquidityCoverageRatioPer1 { get; set; }
        [DisplayName("Liquidity Coverage Ratio (%)2")]
        [Category("C25")]
        public string LiquidityCoverageRatioPer2 { get; set; }

        [DisplayName("Cost to Income (%)")]
        [Category("B26")]
        public string CosttoIncomePer1 { get; set; }
        [DisplayName("Cost to Income (%)2")]
        [Category("C26")]
        public string CosttoIncomePer2 { get; set; }

        [DisplayName("Credit Cost (%)")]
        [Category("B27")]
        public string CreditCostPer1 { get; set; }
        [DisplayName("Credit Cost (%)2")]
        [Category("C27")]
        public string CreditCostPer2 { get; set; }

        [DisplayName("PPOP/ Credit Cost (x)")]
        [Category("B28")]
        public string PPOPCreditCost1 { get; set; }
        [DisplayName("PPOP/ Credit Cost (x)2")]
        [Category("C28")]
        public string PPOPCreditCost2 { get; set; }

        //[DisplayName("ALM Gap in 6 months bucket")]
        //[Category("B29")]
        //public string ALMGapin6monthsbucketPer1 { get; set; }
        //[DisplayName("ALM Gap in 6 months bucket2")]
        //[Category("C29")]
        //public string ALMGapin6monthsbucketPer2 { get; set; }

        [DisplayName("Top 20 Concentration (%)")]
        [Category("B29")]
        public string Top20ConcentrationPer1 { get; set; }
        [DisplayName("Top 20 Concentration (%)2")]
        [Category("C29")]
        public string Top20ConcentrationPer2 { get; set; }

        //[DisplayName("Asset Growth (Individual Housing Loans)")]
        //[Category("B31")]
        //public string AssetGrowthHousingLoansPer1 { get; set; }
        //[DisplayName("Asset Growth (Individual Housing Loans)2")]
        //[Category("C31")]
        //public string AssetGrowthHousingLoansPer2 { get; set; }

        [DisplayName("Business (INR mn)/ employee")]
        [Category("B30")]
        public string BusinessINRmnemployee1 { get; set; }
        [DisplayName("Business (INR mn)/ employee2")]
        [Category("C30")]
        public string BusinessINRmnemployee2 { get; set; }

        [DisplayName("Presence in States & UT")]
        [Category("B31")]
        public string PresenceinStatesUT1 { get; set; }
        [DisplayName("Presence in States & UT2")]
        [Category("C31")]
        public string PresenceinStatesUT2 { get; set; }

        [DisplayName("Years Passed Since Commencement of HFC")]
        [Category("B32")]
        public string YearsPassedSinceCommencementofHFC1 { get; set; }
        [DisplayName("Years Passed Since Commencement of HFC2")]
        [Category("C32")]
        public string YearsPassedSinceCommencementofHFC2 { get; set; }

        [DisplayName("Growth in Advances (%)")]
        [Category("B33")]
        public string GrowthinAdvancesPer1 { get; set; }
        [DisplayName("Growth in Advances (%)2")]
        [Category("C33")]
        public string GrowthinAdvancesPer2 { get; set; }

        [DisplayName("Gearing")]
        [Category("B34")]
        public string Gearing1 { get; set; }
        [DisplayName("Gearing2")]
        [Category("C34")]
        public string Gearing2 { get; set; }

        //[DisplayName("Leverage")]
        //[Category("B37")]
        //public string Leverage1 { get; set; }
        //[DisplayName("Leverage2")]
        //[Category("C37")]
        //public string Leverage2 { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsStaging { get; set; }
        public bool IsFinal { get; set; }
    }
}
