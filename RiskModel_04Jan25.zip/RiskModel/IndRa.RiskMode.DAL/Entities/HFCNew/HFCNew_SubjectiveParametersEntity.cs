﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class HFCNew_SubjectiveParametersEntity
    {
        public int SubjectiveParametersId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        [DisplayName("External Rating")]
        [Category("C36")]
        public string ExternalRating { get; set; }

        [DisplayName("Industry Risk Score")]
        [Category("C37")]
        public string IndustryRiskScore { get; set; }

        [DisplayName("Business Model")]
        [Category("C38")]
        public string BusinessModel { get; set; }

        [DisplayName("Management Quality")]
        [Category("C39")]
        public string ManagementQuality { get; set; }

        [DisplayName("Collateral Coverage Ratio")]
        [Category("C40")]
        public string CollateralCoverageRatio { get; set; }
        
        [DisplayName("Adverse News")]
        [Category("C41")]
        public string AdverseNews { get; set; }
        
        //[DisplayName("Prospect of Key Markets")]
        //[Category("C42")]
        //public string ProspectOfKeyMarkets { get; set; }

        [DisplayName("Geographical Diversification")]
        [Category("C42")]
        public string GeographicalDiversification { get; set; }

        [DisplayName("Diversity of Resources")]
        [Category("C43")]
        public string DiversityOfResources { get; set; }

        //[DisplayName("Access to Funds")]
        //[Category("C45")]
        //public string AccessToFunds { get; set; }

        [DisplayName("Company spends on Corporate Social Responsibility as per regulatory requirement")]
        [Category("C44")]
        public string CompanySpendsCorporateSocialResponsibility { get; set; }

        [DisplayName("Audit Committee meetings held on time")]
        [Category("C45")]
        public string AuditCommitteeHeldOnTime { get; set; }

        [DisplayName("Audit Committee discussed all the calendar items in the meeting")]
        [Category("C46")]
        public string AuditCommitteeDiscuAllCalendarItems { get; set; }

        [DisplayName("No Change of Auditors before the term")]
        [Category("C47")]
        public string NoChangeAuditorsBeforeTerm { get; set; }

        [DisplayName("No Independent directors or Key  Management officials resigned before term")]
        [Category("C48")]
        public string NoIndKeyManResignBeforeTerm { get; set; }

        [DisplayName("Related Party Transcations")]
        [Category("C49")]
        public string RelatedPartyTranscations { get; set; }

        //[DisplayName("No Independent directors or Key  Management officials resigned before term")]
        //[Category("C53")]
        //public string NoIndKeyManResignBeforeTerm { get; set; }

        //[DisplayName("Less than 1% of total transcations are  Related Party Transcations")]
        //[Category("C54")]
        //public string LessThanOnePerTotTran { get; set; }

        [DisplayName("Centralized database captures all data including branch level operations for all asset and liabilities")]
        [Category("C50")]
        public string CentDBCapturesAllData { get; set; }

        [DisplayName("NPA is System Generated")]
        [Category("C51")]
        public string NPASysGen { get; set; }

        [DisplayName("No Delay in  reporting and disclosure as per regulatory requirement")]
        [Category("C52")]
        public string NoDelayInReporting { get; set; }

        [DisplayName("Competent and Independent Management handles operation of company and promoter is not directly involved in day to day  operation")]
        [Category("C53")]
        public string CompAndIndManagement { get; set; }

        [DisplayName("No divergence between regulator assessment of company financials and Company Audited Financials")]
        [Category("C54")]
        public string NoDivBetRegAssess { get; set; }

        [DisplayName("SMA  2 under loan portfolio")]
        [Category("C55")]
        public string SMA1And2UnderLoanPort { get; set; }

        [DisplayName("Qualified Opinion by Auditor")]
        [Category("C56")]
        public string QualifiedOpinionByAuditor { get; set; }

        [DisplayName("Default with Lenders")]
        [Category("C57")]
        public string DefaultWithOtherLenders { get; set; }

        [DisplayName("Gaps in SLS are within regulatory limits")]
        [Category("C58")]
        public string GapsinSLSWithinRegulatoryLimits { get; set; }

        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
    }
}
