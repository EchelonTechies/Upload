﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_OtherBalanceSheet_Disclosuress
    {
        public int DisclosureId { get; set; }
        public int DetailsId { get; set; }

        [DisplayName("Tier I Capital Ratio")]
        public string TierICapitalRatioPercentage { get; set; }
        public string TierICapitalRatioPercentage1 { get; set; }
        public string TierICapitalRatioPercentage2 { get; set; }
        public string TierICapitalRatioPercentage3 { get; set; }
        public string TierICapitalRatioPercentage4 { get; set; }

        [DisplayName("Tier II Capital Ratio")]
        public string TierIICapitalRatioPercentage { get; set; }
        public string TierIICapitalRatioPercentage1 { get; set; }
        public string TierIICapitalRatioPercentage2 { get; set; }
        public string TierIICapitalRatioPercentage3 { get; set; }
        public string TierIICapitalRatioPercentage4 { get; set; }

        [DisplayName("Total Capital Ratio")]
        public string TotalCapitalRatioPercentage { get; set; }
        public string TotalCapitalRatioPercentage1 { get; set; }
        public string TotalCapitalRatioPercentage2 { get; set; }
        public string TotalCapitalRatioPercentage3 { get; set; }
        public string TotalCapitalRatioPercentage4 { get; set; }

        [DisplayName("Third Party Originations and Servicing")]
        public string ThirdPartyOriginationsAndServicingPercentage { get; set; }
        public string ThirdPartyOriginationsAndServicingPercentage1 { get; set; }
        public string ThirdPartyOriginationsAndServicingPercentage2 { get; set; }
        public string ThirdPartyOriginationsAndServicingPercentage3 { get; set; }
        public string ThirdPartyOriginationsAndServicingPercentage4 { get; set; }

        [DisplayName("Securitised Portfolio outstanding")]
        public string SecuritisedPortfolioOutstandingPercentage { get; set; }
        public string SecuritisedPortfolioOutstandingPercentage1 { get; set; }
        public string SecuritisedPortfolioOutstandingPercentage2 { get; set; }
        public string SecuritisedPortfolioOutstandingPercentage3 { get; set; }
        public string SecuritisedPortfolioOutstandingPercentage4 { get; set; }

        [DisplayName("Total Managed Assets")]
        public string TotalManagedAssetsPercentage { get; set; }
        public string TotalManagedAssetsPercentage1 { get; set; }
        public string TotalManagedAssetsPercentage2 { get; set; }
        public string TotalManagedAssetsPercentage3 { get; set; }
        public string TotalManagedAssetsPercentage4 { get; set; }

        [DisplayName("Gross NPAs")]
        public string GrossNPAs { get; set; }
        public string GrossNPAs1 { get; set; }
        public string GrossNPAs2 { get; set; }
        public string GrossNPAs3 { get; set; }
        public string GrossNPAs4 { get; set; }

        [DisplayName("Specific Loss Provisions Held")]
        public string SpecificLossProvisionsHeld { get; set; }
        public string SpecificLossProvisionsHeld1 { get; set; }
        public string SpecificLossProvisionsHeld2 { get; set; }
        public string SpecificLossProvisionsHeld3 { get; set; }
        public string SpecificLossProvisionsHeld4 { get; set; }

        [DisplayName("Net NPAs")]
        public string NetNPAs { get; set; }
        public string NetNPAs1 { get; set; }
        public string NetNPAs2 { get; set; }
        public string NetNPAs3 { get; set; }
        public string NetNPAs4 { get; set; }

        public int CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }
    }
}
