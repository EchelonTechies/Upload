﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_NotchUp_CriteriaInputss
    {
        public int NotchUpCriteriaId { get; set; }
        public int DetailsId { get; set; }
        [DisplayName("Ownership / Shareholding structure")]
        public string ShareholdingStructure { get; set; }
        [DisplayName("Management Control")]
        public string ManagementControl { get; set; }
        [DisplayName("Stated Posture of the Parent")]
        public string StatedPostureOfTheParent { get; set; }
        [DisplayName("Past Track Record")]
        public string PastTrackRecord { get; set; }
        [DisplayName("Brand Name")]
        public string BrandName { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }

    }
}
