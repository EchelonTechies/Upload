﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_Financial_RiskInputss
    {
        public int FinancialRiskId { get; set; }
        public int DetailsId { get; set; }
        [DisplayName("Ability of the company to raise funds and Liquidity management")]
        public string CompanysAbility { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }

    }
}
