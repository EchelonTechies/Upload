﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class RiskModelExcelEntity
    {
        public int DetailsId { get; set; }
        public HttpPostedFileBase ExcelFile { get; set; }
        public int UserId { get; set; }
        public string ButtonValue { get; set; }
        public int CompanyId { get; set; }
        public int reportCompanyId { get; set; }
        [DisplayName("Company")]
        public string CompanyName { get; set; }
        [DisplayName("Company")]
        public string reportCompany { get; set; }
        public int LocationId { get; set; }
        [DisplayName("Location")]
        public string LocationName { get; set; }
        public string selectedLocation { get; set; }
        [DisplayName("Date Of Input")]
        public DateTime? DateOfInput { get; set; }
        [DisplayName("Financial Year Ending Date")]
        public string FinancialYearEndingDate { get; set; }
        [DisplayName("Currency Units")]
        public string CurrencyUnits { get; set; }
        public string ParentCompanyIsExist { get; set; }
        public int? ParentCompanyId { get; set; }
        [DisplayName("Parent Company")]
        public string ParentCompanyName { get; set; }
        public int? ParentRatingId { get; set; }
        [DisplayName("Parent Rating")]
        public string ParentRating { get; set; }
        public string SponsorBank { get; set; }
        public decimal? ParentCompanyShareHoldingPer { get; set; }

        public int CreatedBy { get; set; }
        [DisplayName("Created Date")]
        public DateTime CreatedDateTime { get; set; }
        [DisplayName("Created Date")]
        public DateTime reportCreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public NHB_BalanceSheets_Liabilitiess NHB_BalanceSheets_Liabilities { get; set; }
        public NHB_BalanceSheet_Assetss NHB_BalanceSheet_Assets { get; set; }
        public NHB_Contingent_Liabilitiess NHB_Contingent_Liabilities { get; set; }
        public NHB_OtherBalanceSheet_Disclosuress NHB_OtherBalanceSheet_Disclosures { get; set; }
        public NHB_ProfitAndLossStatementss NHB_ProfitAndLossStatements { get; set; }
        public NHB_ALM_Statement_Latests NHB_ALM_Statement_Latests { get; set; }
        public NHB_KeyRatioss NHB_KeyRatios { get; set; }
        public NHB_Industry_RiskInputss NHB_Industry_RiskInputs { get; set; }
        public NHB_Business_RiskInputss NHB_Business_RiskInputs { get; set; }
        public NHB_Financial_RiskInputss NHB_Financial_RiskInputs { get; set; }
        public NHB_Management_RiskInputss NHB_Management_RiskInputs { get; set; }
        public NHB_NotchUp_CriteriaInputss NHB_NotchUp_CriteriaInputs { get; set; }
        public NHB_RiskModel_Outputss NHB_RiskModel_Outputs { get; set; }

    }
}
