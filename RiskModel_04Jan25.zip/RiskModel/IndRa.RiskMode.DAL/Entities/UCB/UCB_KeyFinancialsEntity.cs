﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class UCB_KeyFinancialsEntity
    {
        public int KeyFinancialsId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }


        [Category("B10")]
        [DisplayName("Period of Year End")]
        public DateTime? PeriodEndingDate1 { get; set; }
        [Category("C10")]
        [DisplayName("Period of Year End2")]
        public DateTime? PeriodEndingDate2 { get; set; }
        [Category("D10")]
        [DisplayName("Period of Year End3")]
        public DateTime? PeriodEndingDate3 { get; set; }

        [Category("B11")]
        [DisplayName("No. of Months in the Period")]
        public short? NoofMonthsPeriod1 { get; set; }
        [Category("C11")]
        [DisplayName("No. of Months in the Period2")]
        public short? NoofMonthsPeriod2 { get; set; }
        [Category("D11")]
        [DisplayName("No. of Months in the Period3")]
        public short? NoofMonthsPeriod3 { get; set; }

        [Category("B9")]
        [DisplayName("Currency")]
        public string Currency1 { get; set; }
        [Category("C9")]
        [DisplayName("Currency2")]
        public string Currency2 { get; set; }
        [Category("D9")]
        [DisplayName("Currency3")]
        public string Currency3 { get; set; }

        [Category("B12")]
        [DisplayName("Tangible Net Worth")]
        public string NetWorth1 { get; set; }
        [Category("C12")]
        [DisplayName("Tangible Net Worth2")]
        public string NetWorth2 { get; set; }
        [Category("D12")]
        [DisplayName("Tangible Net Worth3")]
        public string NetWorth3 { get; set; }

        [Category("B13")]
        [DisplayName("Total Assets")]
        public string TotalAssets1 { get; set; }
        [Category("C13")]
        [DisplayName("Total Assets2")]
        public string TotalAssets2 { get; set; }
        [Category("D13")]
        [DisplayName("Total Assets3")]
        public string TotalAssets3 { get; set; }

        [Category("B14")]
        [DisplayName("Total Deposits")]
        public string TotalDeposits1 { get; set; }
        [Category("C14")]
        [DisplayName("Total Deposits2")]
        public string TotalDeposits2 { get; set; }
        [Category("D14")]
        [DisplayName("Total Deposits3")]
        public string TotalDeposits3 { get; set; }

        [Category("B15")]
        [DisplayName("Total Advances")]
        public string TotalAdvances1 { get; set; }
        [Category("C15")]
        [DisplayName("Total Advances2")]
        public string TotalAdvances2 { get; set; }
        [Category("D15")]
        [DisplayName("Total Advances3")]
        public string TotalAdvances3 { get; set; }

        [ReadOnly(true)]
        [Category("B16")]
        [DisplayName("Interest Income")]
        public string InterestIncome1 { get; set; }
        [Category("C16")]
        [DisplayName("Interest Income2")]
        public string InterestIncome2 { get; set; }
        [Category("D16")]
        [DisplayName("Interest Income3")]
        public string InterestIncome3 { get; set; }

        [ReadOnly(true)]
        [Category("B17")]
        [DisplayName("Non-Interest Income")]
        public string NonInterestIncome1 { get; set; }
        [Category("C17")]
        [DisplayName("Non-Interest Income2")]
        public string NonInterestIncome2 { get; set; }
        [Category("D17")]
        [DisplayName("Non-Interest Income3")]
        public string NonInterestIncome3 { get; set; }

        [ReadOnly(true)]
        [Category("B18")]
        [DisplayName("Interest Expenses")]
        public string InterestExpenses1 { get; set; }
        [Category("C18")]
        [DisplayName("Interest Expenses2")]
        public string InterestExpenses2 { get; set; }
        [Category("D18")]
        [DisplayName("Interest Expenses3")]
        public string InterestExpenses3 { get; set; }

        [ReadOnly(true)]
        [Category("B19")]
        [DisplayName("Employee, G&A and S&D Expenses Expenses")]
        public string EmployeeGAandSDExpensesExpenses1 { get; set; }
        [Category("C19")]
        [DisplayName("Employee, G&A and S&D Expenses Expenses2")]
        public string EmployeeGAandSDExpensesExpenses2 { get; set; }
        [Category("D19")]
        [DisplayName("Employee, G&A and S&D Expenses Expenses3")]
        public string EmployeeGAandSDExpensesExpenses3 { get; set; }

        [ReadOnly(true)]
        [Category("B20")]
        [DisplayName("PAT")]
        public string PAT1 { get; set; }
        [Category("C20")]
        [DisplayName("PAT2")]
        public string PAT2 { get; set; }
        [Category("D20")]
        [DisplayName("PAT3")]
        public string PAT3 { get; set; }

        [ReadOnly(true)]
        [Category("B21")]
        [DisplayName("Liquid Assets")]
        public string LiquidAssets1 { get; set; }
        [Category("C21")]
        [DisplayName("Liquid Assets2")]
        public string LiquidAssets2 { get; set; }
        [Category("D21")]
        [DisplayName("Liquid Assets3")]
        public string LiquidAssets3 { get; set; }

        [ReadOnly(true)]
        [Category("B22")]
        [DisplayName("Prov. For NPAs and Write-offs")]
        public string ProvForNPAsandWriteoffs1 { get; set; }
        [Category("C22")]
        [DisplayName("Prov. For NPAs and Write-offs2")]
        public string ProvForNPAsandWriteoffs2 { get; set; }
        [Category("D22")]
        [DisplayName("Prov. For NPAs and Write-offs3")]
        public string ProvForNPAsandWriteoffs3 { get; set; }

        [ReadOnly(true)]
        [Category("B23")]
        [DisplayName("CASA")]
        public string CASAPer1 { get; set; }
        [Category("C23")]
        [DisplayName("CASA2")]
        public string CASAPer2 { get; set; }
        [Category("D23")]
        [DisplayName("CASA3")]
        public string CASAPer3 { get; set; }

        [ReadOnly(true)]
        [Category("B24")]
        [DisplayName("Priority Sector Advances (%)")]
        public string PrioritySectorAdvancesPer1 { get; set; }
        [Category("C24")]
        [DisplayName("Priority Sector Advances (%)2")]
        public string PrioritySectorAdvancesPer2 { get; set; }
        [Category("D24")]
        [DisplayName("Priority Sector Advances (%)3")]
        public string PrioritySectorAdvancesPer3 { get; set; }

        [ReadOnly(true)]
        [Category("B25")]
        [DisplayName("Cost Of Deposits (%)")]
        public string CostOfDepositsPer1 { get; set; }
        [Category("C25")]
        [DisplayName("Cost Of Deposits (%)2")]
        public string CostOfDepositsPer2 { get; set; }
        [Category("D25")]
        [DisplayName("Cost Of Deposits (%)3")]
        public string CostOfDepositsPer3 { get; set; }

        [DisplayName("CRAR (%)")]
        [ReadOnly(true)]
        [Category("B26")]
        public string CRARPer1 { get; set; }
        [Category("C26")]
        [DisplayName("CRAR (%)2")]
        public string CRARPer2 { get; set; }
        [Category("D26")]
        [DisplayName("CRAR (%)3")]
        public string CRARPer3 { get; set; }

        //[ReadOnly(true)]
        //[Category("B27")]
        //[DisplayName("Tier 1 %")]
        //public string Tier1Per1 { get; set; }
        //[Category("C27")]
        //[DisplayName("Tier 1 %2")]
        //public string Tier1Per2 { get; set; }
        //[Category("D27")]
        //[DisplayName("Tier 1 %3")]
        //public string Tier1Per3 { get; set; }

        [ReadOnly(true)]
        [Category("B27")]
        [DisplayName("Net NPA (%)")]
        public string NetNPAPer1 { get; set; }
        [Category("C27")]
        [DisplayName("Net NPA (%)2")]
        public string NetNPAPer2 { get; set; }
        [Category("D27")]
        [DisplayName("Net NPA (%)3")]
        public string NetNPAPer3 { get; set; }

        [ReadOnly(true)]
        [Category("B28")]
        [DisplayName("Addition in NPAs/ Advances")]
        public string AdditioninNPAsAdvancesPer1 { get; set; }
        [Category("C28")]
        [DisplayName("Addition in NPAs/ Advances2")]
        public string AdditioninNPAsAdvancesPer2 { get; set; }
        [Category("D28")]
        [DisplayName("Addition in NPAs/ Advances3")]
        public string AdditioninNPAsAdvancesPer3 { get; set; }

        [ReadOnly(true)]
        [Category("B29")]
        [DisplayName("Gross NPA (%)")]
        public string GrossNPAPer1 { get; set; }
        [Category("C29")]
        [DisplayName("Gross NPA (%)2")]
        public string GrossNPAPer2 { get; set; }
        [Category("D29")]
        [DisplayName("Gross NPA (%)3")]
        public string GrossNPAPer3 { get; set; }

        [ReadOnly(true)]
        [Category("B30")]
        [DisplayName("Contingent Liability")]
        public string ContingentLiability1 { get; set; }
        [Category("C30")]
        [DisplayName("Contingent Liability2")]
        public string ContingentLiability2 { get; set; }
        [Category("D30")]
        [DisplayName("Contingent Liability3")]
        public string ContingentLiability3 { get; set; }

        //[ReadOnly(true)]
        //[Category("B32")]
        //[DisplayName("ALM Gap in 6 months bucket")]
        //public string ALMGapin6MonthsBucketPer1 { get; set; }
        //[Category("C32")]
        //[DisplayName("ALM Gap in 6 months bucket2")]
        //public string ALMGapin6MonthsBucketPer2 { get; set; }
        //[Category("D32")]
        //[DisplayName("ALM Gap in 6 months bucket3")]
        //public string ALMGapin6MonthsBucketPer3 { get; set; }

        [ReadOnly(true)]
        [Category("B31")]
        [DisplayName("No. of Branches")]
        public string NoOfBranches1 { get; set; }
        [Category("C31")]
        [DisplayName("No. of Branches2")]
        public string NoOfBranches2 { get; set; }
        [Category("D31")]
        [DisplayName("No. of Branches3")]
        public string NoOfBranches3 { get; set; }

        [ReadOnly(true)]
        [Category("B32")]
        [DisplayName("Growth in Membership")]
        public string GrowthInMembershipPer1 { get; set; }
        [Category("C32")]
        [DisplayName("Growth in Membership2")]
        public string GrowthInMembershipPer2 { get; set; }
        [Category("D32")]
        [DisplayName("Growth in Membership3")]
        public string GrowthInMembershipPer3 { get; set; }

        [ReadOnly(true)]
        [Category("B33")]
        [DisplayName("Business per employee")]
        public string BusinessPerEmployee1 { get; set; }
        [Category("C33")]
        [DisplayName("Business per employee2")]
        public string BusinessPerEmployee2 { get; set; }
        [Category("D33")]
        [DisplayName("Business per employee3")]
        public string BusinessPerEmployee3 { get; set; }

        [ReadOnly(true)]
        [Category("B34")]
        [DisplayName("Secured Advances / Total Advances (%)")]
        public string SecuredAdvancesTotalAdvancesPer1 { get; set; }
        [Category("C34")]
        [DisplayName("Secured Advances / Total Advances (%)2")]
        public string SecuredAdvancesTotalAdvancesPer2 { get; set; }
        [Category("D34")]
        [DisplayName("Secured Advances / Total Advances (%)3")]
        public string SecuredAdvancesTotalAdvancesPer3 { get; set; }

        //[ReadOnly(true)]
        //[Category("B37")]
        //[DisplayName("State Economic Growth (GSDP)")]
        //public string StateEconomicGrowthGSDPPer1 { get; set; }
        //[Category("C37")]
        //[DisplayName("State Economic Growth (GSDP)2")]
        //public string StateEconomicGrowthGSDPPer2 { get; set; }
        //[Category("D37")]
        //[DisplayName("State Economic Growth (GSDP)3")]
        //public string StateEconomicGrowthGSDPPer3 { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsStaging { get; set; }
        public bool IsFinal { get; set; }
    }
}
