﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class HFC_OutputDeatils_Old
    {
        public int OutputDetailsId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        [DisplayName("Regulatory Environment")]
        public DateTime? IndustryRiskRegulatoryEnvironment1 { get; set; }
        [DisplayName("Regulatory Environment2")]
        public DateTime? IndustryRiskRegulatoryEnvironment2 { get; set; }
        [DisplayName("Regulatory Environment3")]
        public DateTime? IndustryRiskRegulatoryEnvironment3 { get; set; }
        [DisplayName("Regulatory Environment4")]
        public DateTime? IndustryRiskRegulatoryEnvironment4 { get; set; }
        [DisplayName("Regulatory Environment5")]
        public DateTime? IndustryRiskRegulatoryEnvironment5 { get; set; }

        [DisplayName("Prospect of Real Estate Market")]
        public string IndustryRiskProspectOfRealEstateMarket1 { get; set; }
        [DisplayName("Prospect of Real Estate Market2")]
        public string IndustryRiskProspectOfRealEstateMarket2 { get; set; }
        [DisplayName("Prospect of Real Estate Market3")]
        public string IndustryRiskProspectOfRealEstateMarket3 { get; set; }
        [DisplayName("Prospect of Real Estate Market4")]
        public string IndustryRiskProspectOfRealEstateMarket4 { get; set; }
        [DisplayName("Prospect of Real Estate Market5")]
        public string IndustryRiskProspectOfRealEstateMarket5 { get; set; }


        [DisplayName("Total Assets")]
        public string BusinessRiskResourceProfileTotalAsset1 { get; set; }
        [DisplayName("Total Assets2")]
        public string BusinessRiskResourceProfileTotalAsset2 { get; set; }
        [DisplayName("Total Assets3")]
        public string BusinessRiskResourceProfileTotalAsset3 { get; set; }
        [DisplayName("Total Assets4")]
        public string BusinessRiskResourceProfileTotalAsset4 { get; set; }
        [DisplayName("Total Assets5")]
        public string BusinessRiskResourceProfileTotalAsset5 { get; set; }

        [DisplayName("Geographical Diversification")]
        public string BusinessRiskResourceProfileGeographicalDiversification1 { get; set; }
        [DisplayName("Geographical Diversification2")]
        public string BusinessRiskResourceProfileGeographicalDiversification2 { get; set; }
        [DisplayName("Geographical Diversification3")]
        public string BusinessRiskResourceProfileGeographicalDiversification3 { get; set; }
        [DisplayName("Geographical Diversification4")]
        public string BusinessRiskResourceProfileGeographicalDiversification4 { get; set; }
        [DisplayName("Geographical Diversification5")]
        public string BusinessRiskResourceProfileGeographicalDiversification5 { get; set; }

        [DisplayName("Net NPA (%)")]
        public string BusinessRiskAssetQualityNetNPA1 { get; set; }
        [DisplayName("Net NPA (%)2")]
        public string BusinessRiskAssetQualityNetNPA2 { get; set; }
        [DisplayName("Net NPA (%)3")]
        public string BusinessRiskAssetQualityNetNPA3 { get; set; }
        [DisplayName("Net NPA (%)4")]
        public string BusinessRiskAssetQualityNetNPA4 { get; set; }
        [DisplayName("Net NPA (%)5")]
        public string BusinessRiskAssetQualityNetNPA5 { get; set; }

        [DisplayName("Gross NPA (%)")]
        public string BusinessRiskAssetQualityGrossNPA1 { get; set; }
        [DisplayName("Gross NPA (%)2")]
        public string BusinessRiskAssetQualityGrossNPA2 { get; set; }
        [DisplayName("Gross NPA (%)3")]
        public string BusinessRiskAssetQualityGrossNPA3 { get; set; }
        [DisplayName("Gross NPA (%)4")]
        public string BusinessRiskAssetQualityGrossNPA4 { get; set; }
        [DisplayName("Gross NPA (%)5")]
        public string BusinessRiskAssetQualityGrossNPA5 { get; set; }


        [DisplayName("Contingent Liability (% of total assets)")]
        public string BusinessRiskAssetQualityContingentLiability1 { get; set; }
        [DisplayName("Contingent Liability (% of total assets)2")]
        public string BusinessRiskAssetQualityContingentLiability2 { get; set; }
        [DisplayName("Contingent Liability (% of total assets)3")]
        public string BusinessRiskAssetQualityContingentLiability3 { get; set; }
        [DisplayName("Contingent Liability (% of total assets)4")]
        public string BusinessRiskAssetQualityContingentLiability4 { get; set; }
        [DisplayName("Contingent Liability (% of total assets)5")]
        public string BusinessRiskAssetQualityContingentLiability5 { get; set; }

        [DisplayName("Top 20 Borrower Concentration")]
        public string BusinessRiskAssetQualityTop20BorrowerConcentration1 { get; set; }
        [DisplayName("Top 20 Borrower Concentration2")]
        public string BusinessRiskAssetQualityTop20BorrowerConcentration2 { get; set; }
        [DisplayName("Top 20 Borrower Concentration3")]
        public string BusinessRiskAssetQualityTop20BorrowerConcentration3 { get; set; }
        [DisplayName("Top 20 Borrower Concentration4")]
        public string BusinessRiskAssetQualityTop20BorrowerConcentration4 { get; set; }
        [DisplayName("Top 20 Borrower Concentration5")]
        public string BusinessRiskAssetQualityTop20BorrowerConcentration5 { get; set; }

        [DisplayName("Credit Cost")]
        public string BusinessRiskAssetQualityCreditCost1 { get; set; }
        [DisplayName("Credit Cost2")]
        public string BusinessRiskAssetQualityCreditCost2 { get; set; }
        [DisplayName("Credit Cost3")]
        public string BusinessRiskAssetQualityCreditCost3 { get; set; }
        [DisplayName("Credit Cost4")]
        public string BusinessRiskAssetQualityCreditCost4 { get; set; }
        [DisplayName("Credit Cost5")]
        public string BusinessRiskAssetQualityCreditCost5 { get; set; }

        [DisplayName("Fresh NPA / Net Advances at the beginning of the year (%)")]
        public string BusinessRiskAssetQualityFreshNPANetAdvancesAtBeginningYear1 { get; set; }
        [DisplayName("Fresh NPA / Net Advances at the beginning of the year (%)2")]
        public string BusinessRiskAssetQualityFreshNPANetAdvancesAtBeginningYear2 { get; set; }
        [DisplayName("Fresh NPA / Net Advances at the beginning of the year (%)3")]
        public string BusinessRiskAssetQualityFreshNPANetAdvancesAtBeginningYear3 { get; set; }
        [DisplayName("Fresh NPA / Net Advances at the beginning of the year (%)4")]
        public string BusinessRiskAssetQualityFreshNPANetAdvancesAtBeginningYear4 { get; set; }
        [DisplayName("Fresh NPA / Net Advances at the beginning of the year (%)5")]
        public string BusinessRiskAss5tQualityFreshNPANetAdvancesAtBeginningYear1 { get; set; }
        
        [DisplayName("Housing Loans as % of Advances")]
        public string BusinessRiskAssetQualityHousingLoansAsPercentageOfAdvances1 { get; set; }
        [DisplayName("Housing Loans as % of Advances2")]
        public string BusinessRiskAssetQualityHousingLoansAsPercentageOfAdvances2 { get; set; }
        [DisplayName("Housing Loans as % of Advances3")]
        public string BusinessRiskAssetQualityHousingLoansAsPercentageOfAdvances3 { get; set; }
        [DisplayName("Housing Loans as % of Advances4")]
        public string BusinessRiskAssetQualityHousingLoansAsPercentageOfAdvances4 { get; set; }
        [DisplayName("Housing Loans as % of Advances5")]
        public string BusinessRiskAssetQualityHousingLoansAsPercentageOfAdvances5 { get; set; }
               
        [DisplayName("Cost of Funds(%)")]
        public string BusinessRiskOperatingEfficiencyCostOfFunds1 { get; set; }
        [DisplayName("Cost of Funds(%)2")]
        public string BusinessRiskOperatingEfficiencyCostOfFunds2 { get; set; }
        [DisplayName("Cost of Funds(%)3")]
        public string BusinessRiskOperatingEfficiencyCostOfFunds3 { get; set; }
        [DisplayName("Cost of Funds(%)4")]
        public string BusinessRiskOperatingEfficiencyCostOfFunds4 { get; set; }
        [DisplayName("Cost of Funds(%)5")]
        public string BusinessRiskOperatingEfficiencyCostOfFunds5 { get; set; }


        [DisplayName("Growth in Housing Loans")]
        public string BusinessRiskOperatingEfficiencyGrowthInHousingLoans1 { get; set; }
        [DisplayName("Growth in Housing Loans2")]
        public string BusinessRiskOperatingEfficiencyGrowthInHousingLoans2 { get; set; }
        [DisplayName("Growth in Housing Loans3")]
        public string BusinessRiskOperatingEfficiencyGrowthInHousingLoans3 { get; set; }
        [DisplayName("Growth in Housing Loans4")]
        public string BusinessRiskOperatingEfficiencyGrowthInHousingLoans4 { get; set; }
        [DisplayName("Growth in Housing Loans5")]
        public string BusinessRiskOperatingEfficiencyGrowthInHousingLoans5 { get; set; }

        [DisplayName("Growth in Advances")]
        public string BusinessRiskOperatingEfficiencyGrowthInAdvances1 { get; set; }
        [DisplayName("Growth in Advances2")]
        public string BusinessRiskOperatingEfficiencyGrowthInAdvances2 { get; set; }
        [DisplayName("Growth in Advances3")]
        public string BusinessRiskOperatingEfficiencyGrowthInAdvances3 { get; set; }
        [DisplayName("Growth in Advances4")]
        public string BusinessRiskOperatingEfficiencyGrowthInAdvances4 { get; set; }
        [DisplayName("Growth in Advances5")]
        public string BusinessRiskOperatingEfficiencyGrowthInAdvances5 { get; set; }


        [DisplayName("Cost to Income %")]
        public string BusinessRiskOperatingEfficiencyCostToIncome1 { get; set; }
        [DisplayName("Cost to Income %2")]
        public string BusinessRiskOperatingEfficiencyCostToIncome2 { get; set; }
        [DisplayName("Cost to Income %3")]
        public string BusinessRiskOperatingEfficiencyCostToIncome3 { get; set; }
        [DisplayName("Cost to Income %4")]
        public string BusinessRiskOperatingEfficiencyCostToIncome4 { get; set; }
        [DisplayName("Cost to Income %5")]
        public string BusinessRiskOperatingEfficiencyCostToIncome5 { get; set; }


        [DisplayName("Contingency Funding Plan for next one year")]
        public string BusinessRiskOperatingEfficiencyContingencyFundingPlanForNextOneYear1 { get; set; }
        [DisplayName("Contingency Funding Plan for next one year2")]
        public string BusinessRiskOperatingEfficiencyContingencyFundingPlanForNextOneYear2 { get; set; }
        [DisplayName("Contingency Funding Plan for next one year3")]
        public string BusinessRiskOperatingEfficiencyContingencyFundingPlanForNextOneYear3 { get; set; }
        [DisplayName("Contingency Funding Plan for next one year4")]
        public string BusinessRiskOperatingEfficiencyContingencyFundingPlanForNextOneYear4 { get; set; }
        [DisplayName("Contingency Funding Plan for next one year5")]
        public string BusinessRiskOperatingEfficiencyContingencyFundingPlanForNextOneYear5 { get; set; }


        [DisplayName("Diversity of Resources")]
        public string BusinessRiskOperatingEfficiencyDiversityOfResources1 { get; set; }
        [DisplayName("Diversity of Resources2")]
        public string BusinessRiskOperatingEfficiencyDiversityOfResources2 { get; set; }
        [DisplayName("Diversity of Resources3")]
        public string BusinessRiskOperatingEfficiencyDiversityOfResources3 { get; set; }
        [DisplayName("Diversity of Resources4")]
        public string BusinessRiskOperatingEfficiencyDiversityOfResources4 { get; set; }
        [DisplayName("Diversity of Resources5")]
        public string BusinessRiskOperatingEfficiencyDiversityOfResources5 { get; set; }


        [DisplayName("ALM")]
        public string FinancialRiskLiquidityALM1 { get; set; }
        [DisplayName("ALM2")]
        public string FinancialRiskLiquidityALM2 { get; set; }
        [DisplayName("ALM3")]
        public string FinancialRiskLiquidityALM3 { get; set; }
        [DisplayName("ALM4")]
        public string FinancialRiskLiquidityALM4 { get; set; }
        [DisplayName("ALM5")]
        public string FinancialRiskLiquidityALM5 { get; set; }


        [DisplayName("Access to Funds")]
        public string FinancialRiskLiquidityAccessToFunds1 { get; set; }
        [DisplayName("Access to Funds2")]
        public string FinancialRiskLiquidityAccessToFunds2 { get; set; }
        [DisplayName("Access to Funds3")]
        public string FinancialRiskLiquidityAccessToFunds3 { get; set; }
        [DisplayName("Access to Funds4")]
        public string FinancialRiskLiquidityAccessToFunds4 { get; set; }
        [DisplayName("Access to Funds5")]
        public string FinancialRiskLiquidityAccessToFunds5 { get; set; }


        [DisplayName("LCR")]
        public string FinancialRiskLiquidityLCR1 { get; set; }
        [DisplayName("LCR2")]
        public string FinancialRiskLiquidityLCR2 { get; set; }
        [DisplayName("LCR3")]
        public string FinancialRiskLiquidityLCR3 { get; set; }
        [DisplayName("LCR4")]
        public string FinancialRiskLiquidityLCR4 { get; set; }
        [DisplayName("LCR5")]
        public string FinancialRiskLiquidityLCR5 { get; set; }


        [DisplayName("Unencumbered Liquid Assets")]
        public string FinancialRiskLiquidityUnencumberedLiquidAssets1 { get; set; }
        [DisplayName("Unencumbered Liquid Assets2")]
        public string FinancialRiskLiquidityUnencumberedLiquidAssets2 { get; set; }
        [DisplayName("Unencumbered Liquid Assets3")]
        public string FinancialRiskLiquidityUnencumberedLiquidAssets3 { get; set; }
        [DisplayName("Unencumbered Liquid Assets4")]
        public string FinancialRiskLiquidityUnencumberedLiquidAssets4 { get; set; }
        [DisplayName("Unencumbered Liquid Assets5")]
        public string FinancialRiskLiquidityUnencumberedLiquidAssets5 { get; set; }

        [DisplayName("Capital Adequacy Ratio (%)")]
        public string FinancialRiskCapitalCapitalAdequacyRatio1 { get; set; }
        [DisplayName("Capital Adequacy Ratio (%)2")]
        public string FinancialRiskCapitalCapitalAdequacyRatio2 { get; set; }
        [DisplayName("Capital Adequacy Ratio (%)3")]
        public string FinancialRiskCapitalCapitalAdequacyRatio3 { get; set; }
        [DisplayName("Capital Adequacy Ratio (%)4")]
        public string FinancialRiskCapitalCapitalAdequacyRatio4 { get; set; }
        [DisplayName("Capital Adequacy Ratio (%)5")]
        public string FinancialRiskCapitalCapitalAdequacyRatio5 { get; set; }


        [DisplayName("Tangible Networth")]
        public string FinancialRiskCapitalTangibleNetworth1 { get; set; }
        [DisplayName("Tangible Networth2")]
        public string FinancialRiskCapitalTangibleNetworth2 { get; set; }
        [DisplayName("Tangible Networth3")]
        public string FinancialRiskCapitalTangibleNetworth3 { get; set; }
        [DisplayName("Tangible Networth4")]
        public string FinancialRiskCapitalTangibleNetworth4 { get; set; }
        [DisplayName("Tangible Networth5")]
        public string FinancialRiskCap5italTangibleNetworth5 { get; set; }


        [DisplayName("Leverage")]
        public string FinancialRiskCapitalLeverage1 { get; set; }
        [DisplayName("Leverage2")]
        public string FinancialRiskCapitalLeverage2 { get; set; }
        [DisplayName("Leverage3")]
        public string FinancialRiskCapitalLeverage3 { get; set; }
        [DisplayName("Leverage4")]
        public string FinancialRiskCapitalLeverage4 { get; set; }
        [DisplayName("Leverage5")]
        public string FinancialRiskCapitalLeverage5 { get; set; }


        [DisplayName("Tangible Networth / Net NPA (%)")]
        public string FinancialRiskCapitalTangibleNetworthNetNPA1 { get; set; }
        [DisplayName("Tangible Networth / Net NPA (%)2")]
        public string FinancialRiskCapitalTangibleNetworthNetNPA2 { get; set; }
        [DisplayName("Tangible Networth / Net NPA (%)3")]
        public string FinancialRiskCapitalTangibleNetworthNetNPA3 { get; set; }
        [DisplayName("Tangible Networth / Net NPA (%)4")]
        public string FinancialRiskCapitalTangibleNetworthNetNPA4 { get; set; }
        [DisplayName("Tangible Networth / Net NPA (%)5")]
        public string FinancialRiskCapitalTangibleNetworthNetNPA5 { get; set; }

        [DisplayName("Return on Net Worth (%)")]
        public string FinancialRiskEarningsReturnOnNetWorth1 { get; set; }
        [DisplayName("Return on Net Worth (%)2")]
        public string FinancialRiskEarningsReturnOnNetWorth2 { get; set; }
        [DisplayName("Return on Net Worth (%)3")]
        public string FinancialRiskEarningsReturnOnNetWorth3 { get; set; }
        [DisplayName("Return on Net Worth (%)4")]
        public string FinancialRiskEarningsReturnOnNetWorth4 { get; set; }
        [DisplayName("Return on Net Worth (%)5")]
        public string FinancialRiskEarningsReturnOnNetWorth5 { get; set; }

        [DisplayName("PPOP/Credit Cost")]
        public string FinancialRiskEarningsPPOPCreditCost1 { get; set; }
        [DisplayName("PPOP/Credit Cost2")]
        public string FinancialRiskEarningsPPOPCreditCost2 { get; set; }
        [DisplayName("PPOP/Credit Cost3")]
        public string FinancialRiskEarningsPPOPCreditCost3 { get; set; }
        [DisplayName("PPOP/Credit Cost4")]
        public string FinancialRiskEarningsPPOPCreditCost4 { get; set; }
        [DisplayName("PPOP/Credit Cost5")]
        public string FinancialRiskEarningsPPOPCreditCost5 { get; set; }

        [DisplayName("Return on Assets (%)")]
        public string FinancialRiskEarningsReturnOnAssets1 { get; set; }
        [DisplayName("Return on Assets (%)2")]
        public string FinancialRiskEarningsReturnOnAssets2 { get; set; }
        [DisplayName("Return on Assets (%)3")]
        public string FinancialRiskEarningsReturnOnAssets3 { get; set; }
        [DisplayName("Return on Assets (%)4")]
        public string FinancialRiskEarningsReturnOnAssets4 { get; set; }
        [DisplayName("Return on Assets (%)5")]
        public string FinancialRiskEarningsReturnOnAssets5 { get; set; }


        [DisplayName("Business Model")]
        public string ManagementRiskBusinessModel1 { get; set; }
        [DisplayName("Business Model2")]
        public string ManagementRiskBusinessModel2 { get; set; }
        [DisplayName("Business Model3")]
        public string ManagementRiskBusinessModel3 { get; set; }
        [DisplayName("Business Model4")]
        public string ManagementRiskBusinessModel4 { get; set; }
        [DisplayName("Business Model5")]
        public string ManagementRiskBusinessModel5 { get; set; }


        [DisplayName("Management Quality")]
        public string ManagementRiskManagementQuality1 { get; set; }
        [DisplayName("Management Quality2")]
        public string ManagementRiskManagementQuality2 { get; set; }
        [DisplayName("Management Quality3")]
        public string ManagementRiskManagementQuality3 { get; set; }
        [DisplayName("Management Quality4")]
        public string ManagementRiskManagementQuality4 { get; set; }
        [DisplayName("Management Quality5")]
        public string ManagementRiskManagementQuality5 { get; set; }


        [DisplayName("Corporate Governance & Reporting")]
        public string ManagementRiskCorporateGovernanceAndReporting1 { get; set; }
        [DisplayName("Corporate Governance & Reporting2")]
        public string ManagementRiskCorporateGovernanceAndReporting2 { get; set; }
        [DisplayName("Corporate Governance & Reporting3")]
        public string ManagementRiskCorporateGovernanceAndReporting3 { get; set; }
        [DisplayName("Corporate Governance & Reporting4")]
        public string ManagementRiskCorporateGovernanceAndReporting4 { get; set; }
        [DisplayName("Corporate Governance & Reporting5")]
        public string ManagementRiskCorporateGovernanceAndReporting5 { get; set; }



        [DisplayName("Adverse News")]
        public string ManagementRiskAdverseNews1 { get; set; }
        [DisplayName("Adverse News2")]
        public string ManagementRiskAdverseNews2 { get; set; }
        [DisplayName("Adverse News3")]
        public string ManagementRiskAdverseNews3 { get; set; }
        [DisplayName("Adverse News4")]
        public string ManagementRiskAdverseNews4 { get; set; }
        [DisplayName("Adverse News5")]
        public string ManagementRiskAdverseNews5 { get; set; }

        [DisplayName("Conduct of Account")]
        public string ManagementRiskConductOfAccount1 { get; set; }
        [DisplayName("Conduct of Account2")]
        public string ManagementRiskConductOfAccount2 { get; set; }
        [DisplayName("Conduct of Account3")]
        public string ManagementRiskConductOfAccount3 { get; set; }
        [DisplayName("Conduct of Account4")]
        public string ManagementRiskConductOfAccount4 { get; set; }
        [DisplayName("Conduct of Account5")]
        public string ManagementRiskConductOfAccount5 { get; set; }


        [DisplayName("Underwriting Standards")]
        public string ManagementRiskUnderwritingStandards1 { get; set; }
        [DisplayName("Underwriting Standards2")]
        public string ManagementRiskUnderwritingStandards2 { get; set; }
        [DisplayName("Underwriting Standards3")]
        public string ManagementRiskUnderwritingStandards3 { get; set; }
        [DisplayName("Underwriting Standards4")]
        public string ManagementRiskUnderwritingStandards4 { get; set; }
        [DisplayName("Underwriting Standards5")]
        public string ManagementRiskUnderwritingStandards5 { get; set; }



        [DisplayName("Risk Management System and Monotoring")]
        public string ManagementRiskRiskManagementSystemAndMonotoring1 { get; set; }
        [DisplayName("Risk Management System and Monotoring2")]
        public string ManagementRiskRiskManagementSystemAndMonotoring2 { get; set; }
        [DisplayName("Risk Management System and Monotoring3")]
        public string ManagementRiskRiskManagementSystemAndMonotoring3 { get; set; }
        [DisplayName("Risk Management System and Monotoring4")]
        public string ManagementRiskRiskManagementSystemAndMonotoring4 { get; set; }
        [DisplayName("Risk Management System and Monotoring5")]
        public string ManagementRiskRiskManagementSystemAndMonotoring5 { get; set; }



        [DisplayName("Standalone Rating")]
        public string StandaloneRating1 { get; set; }
        [DisplayName("Standalone Rating2")]
        public string StandaloneRating2 { get; set; }
        [DisplayName("Standalone Rating3")]
        public string StandaloneRating3 { get; set; }
        [DisplayName("Standalone Rating4")]
        public string StandaloneRating4 { get; set; }
        [DisplayName("Standalone Rating5")]
        public string StandaloneRating5 { get; set; }


        [DisplayName("Final Rating")]
        public string FinalRating1 { get; set; }
        [DisplayName("Final Rating2")]
        public string FinalRating2 { get; set; }
        [DisplayName("Final Rating3")]
        public string FinalRating3 { get; set; }
        [DisplayName("Final Rating4")]
        public string FinalRating4 { get; set; }
        [DisplayName("Final Rating5")]
        public string FinalRating5 { get; set; }


        [DisplayName("Rating/ Probability of Default")]
        public string RatingProbabilityOfDefault1 { get; set; }
        [DisplayName("Rating/ Probability of Default2")]
        public string RatingProbabilityOfDefault2 { get; set; }
        [DisplayName("Rating/ Probability of Default3")]
        public string RatingProbabilityOfDefault3 { get; set; }
        [DisplayName("Rating/ Probability of Default4")]
        public string RatingProbabilityOfDefault4 { get; set; }
        [DisplayName("Rating/ Probability of Default5")]
        public string RatingProbabilityOfDefault5 { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

    }
}
