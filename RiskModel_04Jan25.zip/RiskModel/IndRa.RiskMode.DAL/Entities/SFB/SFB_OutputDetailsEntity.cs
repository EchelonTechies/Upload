﻿using System;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class SFB_OutputDetailsEntity
    {
        public int OutputDetailsId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        public short TemplateID { get; set; }
        public short LineId { get; set; }
        public string Parameter1 { get; set; }
        public string Parameter1Per { get; set; }
        public string Parameter2 { get; set; }
        public string Parameter2Per { get; set; }
        public string Parameter3 { get; set; }
        public string Parameter3Per { get; set; }

        public string UnderBaselIII_Score { get; set; }
        public string UnderBaselIII_Value { get; set; }

        public string UnderIND_Score { get; set; }
        public string UnderIND_Value { get; set; }
        public string Comments { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

    }
}
