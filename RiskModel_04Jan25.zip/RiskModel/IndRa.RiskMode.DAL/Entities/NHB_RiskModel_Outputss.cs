﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_RiskModel_Outputss
    {
        public int RiskModelOutputValueID { get; set; }
        public int DetailsId { get; set; }

        [DisplayName("Financial performance of players")]
        public string IndustryRiskFinancialPerformanceOfPlayers { get; set; }
        public string IndustryRiskFinancialPerformanceOfPlayersWeight { get; set; }
        public string IndustryRiskFinancialPerformanceOfPlayersValue { get; set; }
        public string IndustryRiskFinancialPerformanceOfPlayersScore { get; set; }

        [DisplayName("Competitions")]
        public string IndustryRiskCompetitions { get; set; }
        public string IndustryRiskCompetitionsWeight { get; set; }
        public string IndustryRiskCompetitionsValue { get; set; }
        public string IndustryRiskCompetitionsScore { get; set; }

        [DisplayName("Prospect of real estate market")]
        public string IndustryRiskProspectOfRealEstateMarket { get; set; }
        public string IndustryRiskProspectOfRealEstateMarketWeight { get; set; }
        public string IndustryRiskProspectOfRealEstateMarketValue { get; set; }
        public string IndustryRiskProspectOfRealEstateMarketScore { get; set; }

        [DisplayName("Regulatory Impact – Government Policy")]
        public string IndustryRiskRegulatoryImpactGovernmentPolicy { get; set; }
        public string IndustryRiskRegulatoryImpactGovernmentPolicyWeight { get; set; }
        public string IndustryRiskRegulatoryImpactGovernmentPolicyValue { get; set; }
        public string IndustryRiskRegulatoryImpactGovernmentPolicyScore { get; set; }

        [DisplayName("Rank of Market Position")]
        public string BusinessRiskMarketPositionRank { get; set; }
        public string BusinessRiskMarketPositionRankWeight { get; set; }
        public string BusinessRiskMarketPositionRankValue { get; set; }
        public string BusinessRiskMarketPositionRankScore { get; set; }

        [DisplayName("Geographical diversification")]
        public string BusinessRiskMarketPositionGeographicalDiversification { get; set; }
        public string BusinessRiskMarketPositionGeographicalDiversificationWeight { get; set; }
        public string BusinessRiskMarketPositionGeographicalDiversificationValue { get; set; }
        public string BusinessRiskMarketPositionGeographicalDiversificationScore { get; set; }

        [DisplayName("Product mix (Housing loan vs. LAP)")]
        public string BusinessRiskAssetQualityProductMix { get; set; }
        public string BusinessRiskAssetQualityProductMixWeight { get; set; }
        public string BusinessRiskAssetQualityProductMixValue { get; set; }
        public string BusinessRiskAssetQualityProductMixScore { get; set; }

        [DisplayName("Customer mix (Salaried people Vs others)-Optional")]
        public string BusinessRiskAssetQualityCustomerMix { get; set; }
        public string BusinessRiskAssetQualityCustomerMixWeight { get; set; }
        public string BusinessRiskAssetQualityCustomerMixValue { get; set; }
        public string BusinessRiskAssetQualityCustomerMixScore { get; set; }

        [DisplayName("Gross NPA (incl. write offs) / Gross Advances (%)")]
        public string BusinessRiskAssetQualityGrossNPA { get; set; }
        public string BusinessRiskAssetQualityGrossNPAWeight { get; set; }
        public string BusinessRiskAssetQualityGrossNPAValue { get; set; }
        public string BusinessRiskAssetQualityGrossNPAScore { get; set; }

        [DisplayName("Cost of Resources")]
        public string BusinessRiskOperatingEfficiencyCostOfResources { get; set; }
        public string BusinessRiskOperatingEfficiencyCostOfResourcesWeight { get; set; }
        public string BusinessRiskOperatingEfficiencyCostOfResourcesValue { get; set; }
        public string BusinessRiskOperatingEfficiencyCostOfResourcesScore { get; set; }

        [DisplayName("Total Asset growth")]
        public string BusinessRiskOperatingEfficiencyTotalAssetGrowth { get; set; }
        public string BusinessRiskOperatingEfficiencyTotalAssetGrowthWeight { get; set; }
        public string BusinessRiskOperatingEfficiencyTotalAssetGrowthValue { get; set; }
        public string BusinessRiskOperatingEfficiencyTotalAssetGrowthScore { get; set; }

        [DisplayName("Diversity of Resources")]
        public string BusinessRiskOperatingEfficiencyDiversityOfResources { get; set; }
        public string BusinessRiskOperatingEfficiencyDiversityOfResourcesWeight { get; set; }
        public string BusinessRiskOperatingEfficiencyDiversityOfResourcesValue { get; set; }
        public string BusinessRiskOperatingEfficiencyDiversityOfResourcesScore { get; set; }

        [DisplayName("Total Asset Base")]
        public string BusinessRiskTotalAssetBase { get; set; }
        public string BusinessRiskTotalAssetBaseWeight { get; set; }
        public string BusinessRiskTotalAssetBaseValue { get; set; }
        public string BusinessRiskTotalAssetBaseScore { get; set; }

        [DisplayName("Asset liability mismatch")]
        public string FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatch { get; set; }
        public string FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchWeight { get; set; }
        public string FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchValue { get; set; }
        public string FinancialRiskLiquidityAndFinancialFlexibilityAssetLiabilityMismatchScore { get; set; }

        [DisplayName("Ability of the company to raise funds and liquidity mangement")]
        public string FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagement { get; set; }
        public string FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementWeight { get; set; }
        public string FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementValue { get; set; }
        public string FinancialRiskLiquidityAndFinancialFlexibilityAbilityOfTheCompanyToRaiseFundsAndLiquidityManagementScore { get; set; }

        [DisplayName("Tangible Networth")]
        public string FinancialRiskCapitalTangibleNetworth { get; set; }
        public string FinancialRiskCapitalTangibleNetworthWeight { get; set; }
        public string FinancialRiskCapitalTangibleNetworthValue { get; set; }
        public string FinancialRiskCapitalTangibleNetworthScore { get; set; }

        [DisplayName("Capital Adequacy Ratio")]
        public string FinancialRiskCapitalAdequacyRatio { get; set; }
        public string FinancialRiskCapitalAdequacyRatioWeight { get; set; }
        public string FinancialRiskCapitalAdequacyRatioValue { get; set; }
        public string FinancialRiskCapitalAdequacyRatioScore { get; set; }

        [DisplayName("Gearing")]
        public string FinancialRiskCapitalGearingRatio { get; set; }
        public string FinancialRiskCapitalGearingWeight { get; set; }
        public string FinancialRiskCapitalGearingValue { get; set; }
        public string FinancialRiskCapitalGearingScore { get; set; }

        [DisplayName("Tangible Net worth / Net NPA")]
        public string FinancialRiskEarningsTangibleNetworthNetNPA { get; set; }
        public string FinancialRiskEarningsTangibleNetworthNetNPAWeight { get; set; }
        public string FinancialRiskEarningsTangibleNetworthNetNPAValue { get; set; }
        public string FinancialRiskEarningsTangibleNetworthNetNPAScore { get; set; }

        [DisplayName("Net Profit Margin (%)")]
        public string FinancialRiskEarningsNetProfitMargin { get; set; }
        public string FinancialRiskEarningsNetProfitMarginWeight { get; set; }
        public string FinancialRiskEarningsNetProfitMarginValue { get; set; }
        public string FinancialRiskEarningsNetProfitMarginScore { get; set; }

        [DisplayName("Return on Assets (%)")]
        public string FinancialRiskEarningsReturnOnAssets { get; set; }
        public string FinancialRiskEarningsReturnOnAssetsWeight { get; set; }
        public string FinancialRiskEarningsReturnOnAssetsValue { get; set; }
        public string FinancialRiskEarningsReturnOnAssetsScore { get; set; }

        [DisplayName("Return on Networth (%)")]
        public string FinancialRiskEarningsReturnOnNetworth { get; set; }
        public string FinancialRiskEarningsReturnOnNetworthWeight { get; set; }
        public string FinancialRiskEarningsReturnOnNetworthValue { get; set; }
        public string FinancialRiskEarningsReturnOnNetworthScore { get; set; }

        [DisplayName("Ability to meet / Achievement of profit projections")]
        public string ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjections { get; set; }
        public string ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsWeight { get; set; }
        public string ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsValue { get; set; }
        public string ManagementRiskTrackRecordAbilityToMeetOrAchievementProfitProjectionsScore { get; set; }

        [DisplayName("Ability to meet / Achievement of sales projections")]
        public string ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjections { get; set; }
        public string ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsWeight { get; set; }
        public string ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsValue { get; set; }
        public string ManagementRiskTrackRecordAbilityToMeetOrAchievementSalesProjectionsScore { get; set; }

        [DisplayName("Past Payment Record and Track record of payment of statutory dues/financial obligations")]
        public string ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligations { get; set; }
        public string ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsWeight { get; set; }
        public string ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsValue { get; set; }
        public string ManagementRiskTrackRecordPastPaymentRecordAndTrackRecordPaymentStatutoryDuesFinancialObligationsScore { get; set; }

        [DisplayName("Risk management system")]
        public string ManagementRiskTrackRecordRiskManagementSystem { get; set; }
        public string ManagementRiskTrackRecordRiskManagementSystemWeight { get; set; }
        public string ManagementRiskTrackRecordRiskManagementSystemValue { get; set; }
        public string ManagementRiskTrackRecordRiskManagementSystemScore { get; set; }

        [DisplayName("Credibility")]
        public string ManagementRiskKeyFactorsCredibility { get; set; }
        public string ManagementRiskKeyFactorsCredibilityWeight { get; set; }
        public string ManagementRiskKeyFactorsCredibilityValue { get; set; }
        public string ManagementRiskKeyFactorsCredibilityScore { get; set; }

        [DisplayName("Competence and Experience")]
        public string ManagementRiskKeyFactorsCompetenceAndExperience { get; set; }
        public string ManagementRiskKeyFactorsCompetenceAndExperienceWeight { get; set; }
        public string ManagementRiskKeyFactorsCompetenceAndExperienceValue { get; set; }
        public string ManagementRiskKeyFactorsCompetenceAndExperienceScore { get; set; }

        [DisplayName("Risk Appetite")]
        public string ManagementRiskKeyFactorsRiskAppetite { get; set; }
        public string ManagementRiskKeyFactorsRiskAppetiteWeight { get; set; }
        public string ManagementRiskKeyFactorsRiskAppetiteValue { get; set; }
        public string ManagementRiskKeyFactorsRiskAppetiteScore { get; set; }

        [DisplayName("Ownership / Shareholding structure")]
        public string NotchUpCriteriaOwnershipShareholdingStructure { get; set; }
        public string NotchUpCriteriaOwnershipShareholdingStructureWeight { get; set; }
        public string NotchUpCriteriaOwnershipShareholdingStructureValue { get; set; }
        public string NotchUpCriteriaOwnershipShareholdingStructureScore { get; set; }

        [DisplayName("Management Control")]
        public string NotchUpCriteriaManagementControl { get; set; }
        public string NotchUpCriteriaManagementControlWeight { get; set; }
        public string NotchUpCriteriaManagementControlValue { get; set; }
        public string NotchUpCriteriaManagementControlScore { get; set; }

        [DisplayName("Stated Posture of the parent")]
        public string NotchUpCriteriaStatedPostureOfTheParent { get; set; }
        public string NotchUpCriteriaStatedPostureOfTheParentWeight { get; set; }
        public string NotchUpCriteriaStatedPostureOfTheParentValue { get; set; }
        public string NotchUpCriteriaStatedPostureOfTheParentScore { get; set; }

        [DisplayName("Past Track Record")]
        public string NotchUpCriteriaPastTrackRecord { get; set; }
        public string NotchUpCriteriaPastTrackRecordWeight { get; set; }
        public string NotchUpCriteriaPastTrackRecordValue { get; set; }
        public string NotchUpCriteriaPastTrackRecordScore { get; set; }

        [DisplayName("Brand Name")]
        public string NotchUpCriteriaBrandName { get; set; }
        public string NotchUpCriteriaBrandNameWeight { get; set; }
        public string NotchUpCriteriaBrandNameValue { get; set; }
        public string NotchUpCriteriaBrandNameScore { get; set; }

        public string IndustryRiskOutput { get; set; }
        public string BusinessRiskOutput { get; set; }
        public string FinancialRiskOutput { get; set; }
        public string ManagementRiskOutput { get; set; }
        public string OverAllScore { get; set; }
        public string PreNotchUpRating { get; set; }
        public string ParentRating { get; set; }
        public string FinalRating { get; set; }

        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }

    }
}
