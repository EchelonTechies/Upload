﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_Business_RiskInputss
    {
        public int BusinessRiskId { get; set; }
        public int DetailsId { get; set; }
        [DisplayName("Rank of Market Position")]
        public string RankOfMarketPosition { get; set; }
        [DisplayName("Geographical Diversification")]
        public string GeographicalDiversification { get; set; }
        [DisplayName("Product mix (Housing loan vs. LAP)")]
        public string ProductMix { get; set; }
        [DisplayName("Customer mix (Salaried people Vs others)")]
        public string CustomerMix { get; set; }
        [DisplayName("Cost of Resources")]
        public string CostOfResources { get; set; }
        [DisplayName("Total Asset growth")]
        public string TotalAssetGrowth { get; set; }
        [DisplayName("Diversification of Funding Profile")]
        public string DiversificationOfFundingProfile { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }

    }
}
