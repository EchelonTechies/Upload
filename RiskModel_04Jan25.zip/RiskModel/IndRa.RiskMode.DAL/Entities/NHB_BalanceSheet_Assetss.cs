﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_BalanceSheet_Assetss
    {
        public int AssetId { get; set; }
        public int DetailsId { get; set; }
        [DisplayName("Period Ending")]
        public string PeriodEndingDate { get; set; }
        public DateTime? PeriodEndingDate1_Assets { get; set; }
        public DateTime? PeriodEndingDate2_Assets { get; set; }
        public DateTime? PeriodEndingDate3_Assets { get; set; }
        public DateTime? PeriodEndingDate4_Assets { get; set; }

        [DisplayName("Fixed Assets")]
        public string FixedAssetsOutput { get; set; }
        public string FixedAssetsOutput1 { get; set; }
        public string FixedAssetsOutput2 { get; set; }
        public string FixedAssetsOutput3 { get; set; }
        public string FixedAssetsOutput4 { get; set; }

        [DisplayName("Owned Net Block")]
        public string OwnedNetBlock { get; set; }
        public string OwnedNetBlock1 { get; set; }
        public string OwnedNetBlock2 { get; set; }
        public string OwnedNetBlock3 { get; set; }
        public string OwnedNetBlock4 { get; set; }

        [DisplayName("Leased Net Block")]
        public string LeasedNetBlock { get; set; }
        public string LeasedNetBlock1 { get; set; }
        public string LeasedNetBlock2 { get; set; }
        public string LeasedNetBlock3 { get; set; }
        public string LeasedNetBlock4 { get; set; }

        [DisplayName("Capital Work-in-progress")]
        public string CapitalWorkInProgress { get; set; }
        public string CapitalWorkInProgress1 { get; set; }
        public string CapitalWorkInProgress2 { get; set; }
        public string CapitalWorkInProgress3 { get; set; }
        public string CapitalWorkInProgress4 { get; set; }

        [DisplayName("Investments")]
        public string InvestmentsOutput { get; set; }
        public string InvestmentsOutput1 { get; set; }
        public string InvestmentsOutput2 { get; set; }
        public string InvestmentsOutput3 { get; set; }
        public string InvestmentsOutput4 { get; set; }

        [DisplayName("Central Government Securities - Quoted")]
        public string CentralGovernmentSecuritiesQuoted { get; set; }
        public string CentralGovernmentSecuritiesQuoted1 { get; set; }
        public string CentralGovernmentSecuritiesQuoted2 { get; set; }
        public string CentralGovernmentSecuritiesQuoted3 { get; set; }
        public string CentralGovernmentSecuritiesQuoted4 { get; set; }

        [DisplayName("Central Government Debt - Unquoted")]
        public string CentralGovernmentDebtUnquoted { get; set; }
        public string CentralGovernmentDebtUnquoted1 { get; set; }
        public string CentralGovernmentDebtUnquoted2 { get; set; }
        public string CentralGovernmentDebtUnquoted3 { get; set; }
        public string CentralGovernmentDebtUnquoted4 { get; set; }

        [DisplayName("State Government Securities")]
        public string StateGovernmentSecurities { get; set; }
        public string StateGovernmentSecurities1 { get; set; }
        public string StateGovernmentSecurities2 { get; set; }
        public string StateGovernmentSecurities3 { get; set; }
        public string StateGovernmentSecurities4 { get; set; }

        [DisplayName("Guaranteed Public Sector Bonds")]
        public string GuaranteedPublicSectorBonds { get; set; }
        public string GuaranteedPublicSectorBonds1 { get; set; }
        public string GuaranteedPublicSectorBonds2 { get; set; }
        public string GuaranteedPublicSectorBonds3 { get; set; }
        public string GuaranteedPublicSectorBonds4 { get; set; }

        [DisplayName("Other Public Sector Bonds")]
        public string OtherPublicSectorBonds { get; set; }
        public string OtherPublicSectorBonds1 { get; set; }
        public string OtherPublicSectorBonds2 { get; set; }
        public string OtherPublicSectorBonds3 { get; set; }
        public string OtherPublicSectorBonds4 { get; set; }

        [DisplayName("Private Sector Bonds - Investment Grade")]
        public string PrivateSectorBondsInvestmentGrade { get; set; }
        public string PrivateSectorBondsInvestmentGrade1 { get; set; }
        public string PrivateSectorBondsInvestmentGrade2 { get; set; }
        public string PrivateSectorBondsInvestmentGrade3 { get; set; }
        public string PrivateSectorBondsInvestmentGrade4 { get; set; }

        [DisplayName("Private Sector Bonds - Others (including Un-rated)")]
        public string OtherPrivateSectorBonds { get; set; }
        public string OtherPrivateSectorBonds1 { get; set; }
        public string OtherPrivateSectorBonds2 { get; set; }
        public string OtherPrivateSectorBonds3 { get; set; }
        public string OtherPrivateSectorBonds4 { get; set; }

        [DisplayName("Mutual Funds")]
        public string MutualFunds { get; set; }
        public string MutualFunds1 { get; set; }
        public string MutualFunds2 { get; set; }
        public string MutualFunds3 { get; set; }
        public string MutualFunds4 { get; set; }

        [DisplayName("Listed Equity")]
        public string ListedEquity { get; set; }
        public string ListedEquity1 { get; set; }
        public string ListedEquity2 { get; set; }
        public string ListedEquity3 { get; set; }
        public string ListedEquity4 { get; set; }

        [DisplayName("Unlisted Equity")]
        public string UnlistedEquity { get; set; }
        public string UnlistedEquity1 { get; set; }
        public string UnlistedEquity2 { get; set; }
        public string UnlistedEquity3 { get; set; }
        public string UnlistedEquity4 { get; set; }

        [DisplayName("Investments in Parent, Subsidiaries and Associates")]
        public string InvestmentsInParentAndSubsidiariesAndAssociates { get; set; }
        public string InvestmentsInParentAndSubsidiariesAndAssociates1 { get; set; }
        public string InvestmentsInParentAndSubsidiariesAndAssociates2 { get; set; }
        public string InvestmentsInParentAndSubsidiariesAndAssociates3 { get; set; }
        public string InvestmentsInParentAndSubsidiariesAndAssociates4 { get; set; }

        [DisplayName("Current Assets")]
        public string CurrentAssetsOutput { get; set; }
        public string CurrentAssetsOutput1 { get; set; }
        public string CurrentAssetsOutput2 { get; set; }
        public string CurrentAssetsOutput3 { get; set; }
        public string CurrentAssetsOutput4 { get; set; }

        [DisplayName("Hire Purchase Receivables")]
        public string HirePurchaseReceivables { get; set; }
        public string HirePurchaseReceivables1 { get; set; }
        public string HirePurchaseReceivables2 { get; set; }
        public string HirePurchaseReceivables3 { get; set; }
        public string HirePurchaseReceivables4 { get; set; }

        [DisplayName("Finance Leases")]
        public string FinanceLeases { get; set; }
        public string FinanceLeases1 { get; set; }
        public string FinanceLeases2 { get; set; }
        public string FinanceLeases3 { get; set; }
        public string FinanceLeases4 { get; set; }

        [DisplayName("Secured Loans")]
        public string SecuredLoans { get; set; }
        public string SecuredLoans1 { get; set; }
        public string SecuredLoans2 { get; set; }
        public string SecuredLoans3 { get; set; }
        public string SecuredLoans4 { get; set; }

        [DisplayName("Unsecured Loans")]
        public string UnsecuredLoans { get; set; }
        public string UnsecuredLoans1 { get; set; }
        public string UnsecuredLoans2 { get; set; }
        public string UnsecuredLoans3 { get; set; }
        public string UnsecuredLoans4 { get; set; }

        [DisplayName("Debtors")]
        public string Debtors { get; set; }
        public string Debtors1 { get; set; }
        public string Debtors2 { get; set; }
        public string Debtors3 { get; set; }
        public string Debtors4 { get; set; }

        [DisplayName("Bills Discounted")]
        public string BillsDiscounted { get; set; }
        public string BillsDiscounted1 { get; set; }
        public string BillsDiscounted2 { get; set; }
        public string BillsDiscounted3 { get; set; }
        public string BillsDiscounted4 { get; set; }

        [DisplayName("Other interest-bearing Loans")]
        public string OtherInterestBearingLoans { get; set; }
        public string OtherInterestBearingLoans1 { get; set; }
        public string OtherInterestBearingLoans2 { get; set; }
        public string OtherInterestBearingLoans3 { get; set; }
        public string OtherInterestBearingLoans4 { get; set; }

        [DisplayName("Loans to related parties")]
        public string LoansToRelatedParties { get; set; }
        public string LoansToRelatedParties1 { get; set; }
        public string LoansToRelatedParties2 { get; set; }
        public string LoansToRelatedParties3 { get; set; }
        public string LoansToRelatedParties4 { get; set; }

        [DisplayName("Cash & Bank")]
        public string CashAndBank { get; set; }
        public string CashAndBank1 { get; set; }
        public string CashAndBank2 { get; set; }
        public string CashAndBank3 { get; set; }
        public string CashAndBank4 { get; set; }

        [DisplayName("Advances Paid (including taxes)")]
        public string AdvancesPaid { get; set; }
        public string AdvancesPaid1 { get; set; }
        public string AdvancesPaid2 { get; set; }
        public string AdvancesPaid3 { get; set; }
        public string AdvancesPaid4 { get; set; }

        [DisplayName("Other Current Assets")]
        public string OtherCurrentAssets { get; set; }
        public string OtherCurrentAssets1 { get; set; }
        public string OtherCurrentAssets2 { get; set; }
        public string OtherCurrentAssets3 { get; set; }
        public string OtherCurrentAssets4 { get; set; }

        [DisplayName("Investments in Securitised Assets")]
        public string InvestmentsInSecuritisedAssets { get; set; }
        public string InvestmentsInSecuritisedAssets1 { get; set; }
        public string InvestmentsInSecuritisedAssets2 { get; set; }
        public string InvestmentsInSecuritisedAssets3 { get; set; }
        public string InvestmentsInSecuritisedAssets4 { get; set; }

        [DisplayName("Current Liabilities")]
        public string CurrentLiabilitiesOutput { get; set; }
        public string CurrentLiabilitiesOutput1 { get; set; }
        public string CurrentLiabilitiesOutput2 { get; set; }
        public string CurrentLiabilitiesOutput3 { get; set; }
        public string CurrentLiabilitiesOutput4 { get; set; }

        [DisplayName("Interest Accrued but not due")]
        public string InterestAccruedButNotDue { get; set; }
        public string InterestAccruedButNotDue1 { get; set; }
        public string InterestAccruedButNotDue2 { get; set; }
        public string InterestAccruedButNotDue3 { get; set; }
        public string InterestAccruedButNotDue4 { get; set; }

        [DisplayName("Deposits Received")]
        public string DepositsReceived { get; set; }
        public string DepositsReceived1 { get; set; }
        public string DepositsReceived2 { get; set; }
        public string DepositsReceived3 { get; set; }
        public string DepositsReceived4 { get; set; }

        [DisplayName("Advances Received")]
        public string AdvancesReceived { get; set; }
        public string AdvancesReceived1 { get; set; }
        public string AdvancesReceived2 { get; set; }
        public string AdvancesReceived3 { get; set; }
        public string AdvancesReceived4 { get; set; }

        [DisplayName("Other Current Liabilities")]
        public string OtherCurrentLiabilities { get; set; }
        public string OtherCurrentLiabilities1 { get; set; }
        public string OtherCurrentLiabilities2 { get; set; }
        public string OtherCurrentLiabilities3 { get; set; }
        public string OtherCurrentLiabilities4 { get; set; }

        [DisplayName("Deferred tax liability")]
        public string DeferredtaxLiability { get; set; }
        public string DeferredtaxLiability1 { get; set; }
        public string DeferredtaxLiability2 { get; set; }
        public string DeferredtaxLiability3 { get; set; }
        public string DeferredtaxLiability4 { get; set; }

        [DisplayName("Receivables Securitised")]
        public string ReceivablesSecuritised { get; set; }
        public string ReceivablesSecuritised1 { get; set; }
        public string ReceivablesSecuritised2 { get; set; }
        public string ReceivablesSecuritised3 { get; set; }
        public string ReceivablesSecuritised4 { get; set; }

        [DisplayName("Provisions")]
        public string ProvisionsOutput { get; set; }
        public string ProvisionsOutput1 { get; set; }
        public string ProvisionsOutput2 { get; set; }
        public string ProvisionsOutput3 { get; set; }
        public string ProvisionsOutput4 { get; set; }

        [DisplayName("Provision for Loan Losses")]
        public string ProvisionForLoanLosses { get; set; }
        public string ProvisionForLoanLosses1 { get; set; }
        public string ProvisionForLoanLosses2 { get; set; }
        public string ProvisionForLoanLosses3 { get; set; }
        public string ProvisionForLoanLosses4 { get; set; }
       
        [DisplayName(" Provision for Doubtful Debtors")]
        public string ProvisionForDoubtfulDebtors { get; set; }
        public string ProvisionForDoubtfulDebtors1 { get; set; }
        public string ProvisionForDoubtfulDebtors2 { get; set; }
        public string ProvisionForDoubtfulDebtors3 { get; set; }
        public string ProvisionForDoubtfulDebtors4 { get; set; }

        [DisplayName("Provision for depreciation in value of investments")]
        public string ProvisionForDepreciation { get; set; }
        public string ProvisionForDepreciation1 { get; set; }
        public string ProvisionForDepreciation2 { get; set; }
        public string ProvisionForDepreciation3 { get; set; }
        public string ProvisionForDepreciation4 { get; set; }

        [DisplayName("Provision for Impairment of Assets")]
        public string ProvisionForImpairmentofAssets { get; set; }
        public string ProvisionForImpairmentofAssets1 { get; set; }
        public string ProvisionForImpairmentofAssets2 { get; set; }
        public string ProvisionForImpairmentofAssets3 { get; set; }
        public string ProvisionForImpairmentofAssets4 { get; set; }

        [DisplayName("Provision for Dividend")]
        public string ProvisionForDividend { get; set; }
        public string ProvisionForDividend1 { get; set; }
        public string ProvisionForDividend2 { get; set; }
        public string ProvisionForDividend3 { get; set; }
        public string ProvisionForDividend4 { get; set; }

        [DisplayName("Provision for Taxes (Excluding on Dividend)")]
        public string ProvisionForTaxes { get; set; }
        public string ProvisionForTaxes1 { get; set; }
        public string ProvisionForTaxes2 { get; set; }
        public string ProvisionForTaxes3 { get; set; }
        public string ProvisionForTaxes4 { get; set; }

        [DisplayName("Provision for Deferred Taxes")]
        public string ProvisionForDeferredTaxes { get; set; }
        public string ProvisionForDeferredTaxes1 { get; set; }
        public string ProvisionForDeferredTaxes2 { get; set; }
        public string ProvisionForDeferredTaxes3 { get; set; }
        public string ProvisionForDeferredTaxes4 { get; set; }

        [DisplayName("Provision for Expenses")]
        public string ProvisionForExpenses { get; set; }
        public string ProvisionForExpenses1 { get; set; }
        public string ProvisionForExpenses2 { get; set; }
        public string ProvisionForExpenses3 { get; set; }
        public string ProvisionForExpenses4 { get; set; }

        [DisplayName("Other Provisions")]
        public string OtherProvisions { get; set; }
        public string OtherProvisions1 { get; set; }
        public string OtherProvisions2 { get; set; }
        public string OtherProvisions3 { get; set; }
        public string OtherProvisions4 { get; set; }

        [DisplayName("Net Current Assets")]
        public string NetCurrentAssetsOutput { get; set; }
        public string NetCurrentAssetsOutput1 { get; set; }
        public string NetCurrentAssetsOutput2 { get; set; }
        public string NetCurrentAssetsOutput3 { get; set; }
        public string NetCurrentAssetsOutput4 { get; set; }

        [DisplayName("Total Assets")]
        public string TotalAssetsOutput { get; set; }
        public string TotalAssetsOutput1 { get; set; }
        public string TotalAssetsOutput2 { get; set; }
        public string TotalAssetsOutput3 { get; set; }
        public string TotalAssetsOutput4 { get; set; }

        [DisplayName("Error Check")]
        public string ErrorCheck { get; set; }
        public string ErrorCheck1 { get; set; }
        public string ErrorCheck2 { get; set; }
        public string ErrorCheck3 { get; set; }
        public string ErrorCheck4 { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsStaging { get; set; }
        public bool IsFinal { get; set; }
    }
}
