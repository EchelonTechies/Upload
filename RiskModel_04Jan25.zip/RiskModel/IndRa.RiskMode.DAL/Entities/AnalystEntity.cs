﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class AnalystEntity
    {
        public int AnalystId { get; set; }
        public int DetailsId { get; set; }
        public int ModelId { get; set; }
        public int EntityId { get; set; }
        public string EntityName { get; set; }
        public string EntityType { get; set; }
        public string AnalystName { get; set; }
        public string CreatedDate { get; set; }
        public string FinancialYear { get; set; }
        public string Status { get; set; }
    }
}
