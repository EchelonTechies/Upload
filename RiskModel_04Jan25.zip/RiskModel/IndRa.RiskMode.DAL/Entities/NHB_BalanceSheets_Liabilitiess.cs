﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_BalanceSheets_Liabilitiess
    {
        public long LiabilitiesId { get; set; }
        public long DetailsId { get; set; }

        [DisplayName("Period Ending")]
        public string PeriodEndingDate { get; set; }
        public DateTime? PeriodEndingDate1_Liabilities { get; set; }
        public DateTime? PeriodEndingDate2_Liabilities { get; set; }
        public DateTime? PeriodEndingDate3_Liabilities { get; set; }
        public DateTime? PeriodEndingDate4_Liabilities { get; set; }

        [DisplayName("Type")]
        public string LiabilitiesType { get; set; }
        public string LiabilitiesType1 { get; set; } // int?
        public string LiabilitiesType2 { get; set; } // int?
        public string LiabilitiesType3 { get; set; } // int?
        public string LiabilitiesType4 { get; set; } // int?

        [DisplayName("Capital")]
        public string CapitalOutput { get; set; }
        public string CapitalPEOutput1 { get; set; }
        public string CapitalPEOutput2 { get; set; }
        public string CapitalPEOutput3 { get; set; }
        public string CapitalPEOutput4 { get; set; }

        [DisplayName("Called and Paid Up")]
        public string CalledAndPaidUp { get; set; }
        public string CalledAndPaid_Up1 { get; set; }
        public string CalledAndPaid_Up2 { get; set; }
        public string CalledAndPaid_Up3 { get; set; }
        public string CalledAndPaid_Up4 { get; set; }

        [DisplayName("Equity Share Warrant")]
        public string EquityShareWarrant { get; set; }
        public string EquityShareWarrant1 { get; set; }
        public string EquityShareWarrant2 { get; set; }
        public string EquityShareWarrant3 { get; set; }
        public string EquityShareWarrant4 { get; set; }

        [DisplayName("Reserve & Surplus")]
        public string ReserveAndSurplus { get; set; }
        public string ReservesAndSurplusOutput1 { get; set; }
        public string ReservesAndSurplusOutput2 { get; set; }
        public string ReservesAndSurplusOutput3 { get; set; }
        public string ReservesAndSurplusOutput4 { get; set; }

        [DisplayName("Capital Reserves")]
        public string CapitalReserves { get; set; }
        public string CapitalReserves1 { get; set; }
        public string CapitalReserves2 { get; set; }
        public string CapitalReserves3 { get; set; }
        public string CapitalReserves4 { get; set; }

        [DisplayName("General Reserves")]
        public string GeneralReserves { get; set; }
        public string GeneralReserves1 { get; set; }
        public string GeneralReserves2 { get; set; }
        public string GeneralReserves3 { get; set; }
        public string GeneralReserves4 { get; set; }

        [DisplayName("Share Premium")]
        public string SharePremium { get; set; }
        public string SharePremium1 { get; set; }
        public string SharePremium2 { get; set; }
        public string SharePremium3 { get; set; }
        public string SharePremium4 { get; set; }

        [DisplayName("Special Purpose Reserves")]
        public string SpecialPurposeReserves { get; set; }
        public string SpecialPurposeReserves1 { get; set; }
        public string SpecialPurposeReserves2 { get; set; }
        public string SpecialPurposeReserves3 { get; set; }
        public string SpecialPurposeReserves4 { get; set; }

        [DisplayName("Other Reserves")]
        public string OtherReserves { get; set; }
        public string OtherReserves1 { get; set; }
        public string OtherReserves2 { get; set; }
        public string OtherReserves3 { get; set; }
        public string OtherReserves4 { get; set; }

        [DisplayName("Revenue Reserves")]
        public string RevenueReserves { get; set; }
        public string RevenueReserves1 { get; set; }
        public string RevenueReserves2 { get; set; }
        public string RevenueReserves3 { get; set; }
        public string RevenueReserves4 { get; set; }

        [DisplayName("Less: Intangible Assets (incl. Deferred Tax Assets)")]
        public string IntangibleAssets { get; set; }
        public string IntangibleAssets1 { get; set; }
        public string IntangibleAssets2 { get; set; }
        public string IntangibleAssets3 { get; set; }
        public string IntangibleAssets4 { get; set; }

        [DisplayName("Borrowings")]
        public string BorrowingsOutput { get; set; }
        public string BorrowingsOutput1 { get; set; }
        public string BorrowingsOutput2 { get; set; }
        public string BorrowingsOutput3 { get; set; }
        public string BorrowingsOutput4 { get; set; }

        [DisplayName("Commercial Paper")]
        public string CommercialPaper { get; set; }
        public string CommercialPaper1 { get; set; }
        public string CommercialPaper2 { get; set; }
        public string CommercialPaper3 { get; set; }
        public string CommercialPaper4 { get; set; }

        [DisplayName("Inter-Corporate Deposits")]
        public string InterCorporateDeposit { get; set; }
        public string InterCorporateDeposits1 { get; set; }
        public string InterCorporateDeposits2 { get; set; }
        public string InterCorporateDeposits3 { get; set; }
        public string InterCorporateDeposits4 { get; set; }

        [DisplayName("Call And Notice Money")]
        public string CallAndNoticeMoney { get; set; }
        public string CallAndNoticeMoney1 { get; set; }
        public string CallAndNoticeMoney2 { get; set; }
        public string CallAndNoticeMoney3 { get; set; }
        public string CallAndNoticeMoney4 { get; set; }

        [DisplayName("Other Borrowings")]
        public string OtherBorrowings { get; set; }
        public string OtherBorrowings1 { get; set; }
        public string OtherBorrowings2 { get; set; }
        public string OtherBorrowings3 { get; set; }
        public string OtherBorrowings4 { get; set; }

        [DisplayName("Long Term Borrowings Within Year")]
        public string LongTermBorrowingsWithinYear { get; set; }
        public string LongTermBorrowingsWithinYear1 { get; set; }
        public string LongTermBorrowingsWithinYear2 { get; set; }
        public string LongTermBorrowingsWithinYear3 { get; set; }
        public string LongTermBorrowingsWithinYear4 { get; set; }

        [DisplayName("Public Deposits")]
        public string PublicDeposits { get; set; }
        public string PublicDeposits1 { get; set; }
        public string PublicDeposits2 { get; set; }
        public string PublicDeposits3 { get; set; }
        public string PublicDeposits4 { get; set; }

        [DisplayName("Secured short-term borrowings")]
        public string ShortTermBorrowings { get; set; }
        public string ShortTermBorrowings1 { get; set; }
        public string ShortTermBorrowings2 { get; set; }
        public string ShortTermBorrowings3 { get; set; }
        public string ShortTermBorrowings4 { get; set; }

        [DisplayName("Long term borrowings - Floating (from NHB)")]
        public string LongTermBorrowingsFloatingNHB { get; set; }
        public string LongTermBorrowingsFloatingNHB1 { get; set; }
        public string LongTermBorrowingsFloatingNHB2 { get; set; }
        public string LongTermBorrowingsFloatingNHB3 { get; set; }
        public string LongTermBorrowingsFloatingNHB4 { get; set; }

        [DisplayName("Long term borrowings - Floating (from Others)")]
        public string LongTermBorrowingsFloatingOthers { get; set; }
        public string LongTermBorrowingsFloatingOthers1 { get; set; }
        public string LongTermBorrowingsFloatingOthers2 { get; set; }
        public string LongTermBorrowingsFloatingOthers3 { get; set; }
        public string LongTermBorrowingsFloatingOthers4 { get; set; }

        [DisplayName("Long term borrowings - Fixed (from NHB)")]
        public string LongTermBorrowingsFixedNHB { get; set; }
        public string LongTermBorrowingsFixedNHB1 { get; set; }
        public string LongTermBorrowingsFixedNHB2 { get; set; }
        public string LongTermBorrowingsFixedNHB3 { get; set; }
        public string LongTermBorrowingsFixedNHB4 { get; set; }

        [DisplayName("Long term borrowings - Fixed(from Others)")]
        public string LongTermBorrowingsFixedOthers { get; set; }
        public string LongTermBorrowingsFixedOthers1 { get; set; }
        public string LongTermBorrowingsFixedOthers2 { get; set; }
        public string LongTermBorrowingsFixedOthers3 { get; set; }
        public string LongTermBorrowingsFixedOthers4 { get; set; }

        [DisplayName("Unsecured long term borrowings")]
        public string UnsecuredLongTermBorrowings { get; set; }
        public string UnsecuredLongTermBorrowings1 { get; set; }
        public string UnsecuredLongTermBorrowings2 { get; set; }
        public string UnsecuredLongTermBorrowings3 { get; set; }
        public string UnsecuredLongTermBorrowings4 { get; set; }

        [DisplayName("Long Term Foreign Currency/External Borrowings")]
        public string LongTermForeignCurrency { get; set; }
        public string LongTermForeignCurrency1 { get; set; }
        public string LongTermForeignCurrency2 { get; set; }
        public string LongTermForeignCurrency3 { get; set; }
        public string LongTermForeignCurrency4 { get; set; }

        [DisplayName("Borrowings from Related Parties")]
        public string BorrowingsFromRelatedParties { get; set; }
        public string BorrowingsFromRelatedParties1 { get; set; }
        public string BorrowingsFromRelatedParties2 { get; set; }
        public string BorrowingsFromRelatedParties3 { get; set; }
        public string BorrowingsFromRelatedParties4 { get; set; }

        [DisplayName("Hybrid Instruments(including Subordinated debt)")]
        public string HybridInstruments { get; set; }
        public string HybridInstruments1 { get; set; }
        public string HybridInstruments2 { get; set; }
        public string HybridInstruments3 { get; set; }
        public string HybridInstruments4 { get; set; }

        [DisplayName("Total Liabilities + Capital")]
        public string LiabilitiesAndCapitalTotalOutput { get; set; }
        public string LiabilitiesAndCapitalTotalOutput1 { get; set; }
        public string LiabilitiesAndCapitalTotalOutput2 { get; set; }
        public string LiabilitiesAndCapitalTotalOutput3 { get; set; }
        public string LiabilitiesAndCapitalTotalOutput4 { get; set; }

        public int CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }
    }
}
