﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_Contingent_Liabilities
    {
        public int ContingentLiabilitiesId { get; set; }
        public int DetailsId { get; set; }

        [DisplayName("Liability on Securitisation Contracts")]
        public string LiabilityOnSecuritisationContracts { get; set; }
        public string LiabilityOnSecuritisationContracts1 { get; set; }
        public string LiabilityOnSecuritisationContracts2 { get; set; }
        public string LiabilityOnSecuritisationContracts3 { get; set; }
        public string LiabilityOnSecuritisationContracts4 { get; set; }

        [DisplayName("Guarantees given")]
        public string GuaranteesGiven { get; set; }
        public string GuaranteesGiven1 { get; set; }
        public string GuaranteesGiven2 { get; set; }
        public string GuaranteesGiven3 { get; set; }
        public string GuaranteesGiven4 { get; set; }

        [DisplayName("Liability on partly paid investments")]
        public string LiabilityOnPartlyPaidInvestments { get; set; }
        public string LiabilityOnPartlyPaidInvestments1 { get; set; }
        public string LiabilityOnPartlyPaidInvestments2 { get; set; }
        public string LiabilityOnPartlyPaidInvestments3 { get; set; }
        public string LiabilityOnPartlyPaidInvestments4 { get; set; }

        [DisplayName("Liability on Foreign Exchange Contracts")]
        public string LiabilityOnForeignExchangContracts { get; set; }
        public string LiabilityOnForeignExchangContracts1 { get; set; }
        public string LiabilityOnForeignExchangContracts2 { get; set; }
        public string LiabilityOnForeignExchangContracts3 { get; set; }
        public string LiabilityOnForeignExchangContracts4 { get; set; }

        [DisplayName("Liability on Derivative Contracts")]
        public string LiabilityOnDerivativeContracts { get; set; }
        public string LiabilityOnDerivativeContracts1 { get; set; }
        public string LiabilityOnDerivativeContracts2 { get; set; }
        public string LiabilityOnDerivativeContracts3 { get; set; }
        public string LiabilityOnDerivativeContracts4 { get; set; }

        [DisplayName("Endorsements, Acceptances & other obligations")]
        public string EndorsementsAndAcceptancesAndOtherObligations { get; set; }
        public string EndorsementsAndAcceptancesAndOtherObligations1{ get; set; }
        public string EndorsementsAndAcceptancesAndOtherObligations2 { get; set; }
        public string EndorsementsAndAcceptancesAndOtherObligations3 { get; set; }
        public string EndorsementsAndAcceptancesAndOtherObligations4 { get; set; }

        [DisplayName("Claims not acknowledged as Debts")]
        public string ClaimsNotAcknowledgedAsDebts { get; set; }
        public string ClaimsNotAcknowledgedAsDebts1 { get; set; }
        public string ClaimsNotAcknowledgedAsDebts2 { get; set; }
        public string ClaimsNotAcknowledgedAsDebts3 { get; set; }
        public string ClaimsNotAcknowledgedAsDebts4 { get; set; }

        [DisplayName("Other items")]
        public string OtherItems { get; set; }
        public string OtherItems1 { get; set; }
        public string OtherItems2 { get; set; }
        public string OtherItems3 { get; set; }
        public string OtherItems4 { get; set; }


        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }
    }
}
