﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_KeyRatioss
    {
        public int KeyRatioId { get; set; }
        public int DetailsId { get; set; }

        [DisplayName("Period Ending")]
        public string PeriodEndingDate { get; set; }
        public DateTime? PeriodEndingDate1_KeyRatios { get; set; }
        public DateTime? PeriodEndingDate2_KeyRatios { get; set; }
        public DateTime? PeriodEndingDate3_KeyRatios { get; set; }
        public DateTime? PeriodEndingDate4_KeyRatios { get; set; }

        [DisplayName("Total Assets")]
        public string TotalAssets { get; set; }
        public int? TotalAssets1 { get; set; }
        public int? TotalAssets2 { get; set; }
        public int? TotalAssets3 { get; set; }
        public int? TotalAssets4 { get; set; }

        [DisplayName("Gross NPA (%)")]
        public string GrossNPAPercentage { get; set; }
        public decimal? GrossNPAPercentage1 { get; set; }
        public decimal? GrossNPAPercentage2 { get; set; }
        public decimal? GrossNPAPercentage3 { get; set; }
        public decimal? GrossNPAPercentage4 { get; set; }

        [DisplayName("ALM Mismatch")]
        public string ALMMismatchPercentage { get; set; }
        public decimal? ALMMismatchPercentage1 { get; set; }
        public decimal? ALMMismatchPercentage2 { get; set; }
        public decimal? ALMMismatchPercentage3 { get; set; }
        public decimal? ALMMismatchPercentage4 { get; set; }

        [DisplayName("Net Worth")]
        public string NetWorth { get; set; }
        public int? NetWorth1 { get; set; }
        public int? NetWorth2 { get; set; }
        public int? NetWorth3 { get; set; }
        public int? NetWorth4 { get; set; }

        [DisplayName("CRAR (%)")]
        public string CRARPercentage { get; set; }
        public decimal? CRARPercentage1 { get; set; }
        public decimal? CRARPercentage2 { get; set; }
        public decimal? CRARPercentage3 { get; set; }
        public decimal? CRARPercentage4 { get; set; }

        [DisplayName("Gearing")]
        public string GearingPercentage { get; set; }
        public decimal? GearingPercentage1 { get; set; }
        public decimal? GearingPercentage2 { get; set; }
        public decimal? GearingPercentage3 { get; set; }
        public decimal? GearingPercentage4 { get; set; }

        [DisplayName("Tangible NW/ Net NPA")]
        public string TangibleNWNetNPA { get; set; }
        public int? TangibleNWNetNPA1 { get; set; }
        public int? TangibleNWNetNPA2 { get; set; }
        public int? TangibleNWNetNPA3 { get; set; }
        public int? TangibleNWNetNPA4 { get; set; }

        [DisplayName("Net Margin")]
        public string NetMarginPercentage { get; set; }
        public decimal? NetMarginPercentage1 { get; set; }
        public decimal? NetMarginPercentage2 { get; set; }
        public decimal? NetMarginPercentage3 { get; set; }
        public decimal? NetMarginPercentage4 { get; set; }

        [DisplayName("PAT/ Average Funds Deployed")]
        public string PATAverageFundsDeployedPercentage { get; set; }
        public decimal? PATAverageFundsDeployedPercentage1 { get; set; }
        public decimal? PATAverageFundsDeployedPercentage2 { get; set; }
        public decimal? PATAverageFundsDeployedPercentage3 { get; set; }
        public decimal? PATAverageFundsDeployedPercentage4 { get; set; }

        [DisplayName("PAT/ Average Net Worth")]
        public string PATAverageNetWorthPercentage { get; set; }
        public decimal? PATAverageNetWorthPercentage1 { get; set; }
        public decimal? PATAverageNetWorthPercentage2 { get; set; }
        public decimal? PATAverageNetWorthPercentage3 { get; set; }
        public decimal? PATAverageNetWorthPercentage4 { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }


    }
}
