﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class SCB_IndustryExpsoureEntity
    {
        public int IndustryExpsoureId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }


        [DisplayName("Agriculture & Allied Activities")]
        [Category("B40")]
        public string AgricultureAlliedActivities1 { get; set; }
        [DisplayName("Agriculture & Allied Activities2")]
        [Category("C40")]
        public string AgricultureAlliedActivitiesPer2 { get; set; }
        [DisplayName("Agriculture & Allied Activities3")]
        [Category("D40")]
        public string AgricultureAlliedActivities3 { get; set; }

        [DisplayName("Minig & Quaring")]
        [Category("B41")]
        public string MinigQuaring1 { get; set; }
        [DisplayName("Minig & Quaring2")]
        [Category("C41")]
        public string MinigQuaringPer2 { get; set; }
        [DisplayName("Minig & Quaring3")]
        [Category("D41")]
        public string MinigQuaring3 { get; set; }

        [DisplayName("Food & Food Processing")]
        [Category("B42")]
        public string FoodFoodProcessing1 { get; set; }
        [DisplayName("Food & Food Processing2")]
        [Category("C42")]
        public string FoodFoodProcessingPer2 { get; set; }
        [DisplayName("Food & Food Processing3")]
        [Category("D42")]
        public string FoodFoodProcessing3 { get; set; }

        [DisplayName("Textiles")]
        [Category("B43")]
        public string Textiles1 { get; set; }
        [DisplayName("Textiles2")]
        [Category("C43")]
        public string TextilesPer2 { get; set; }
        [Category("D43")]
        [DisplayName("Textiles3")]
        public string Textiles3 { get; set; }

        [DisplayName("Material & their Products")]
        [Category("B44")]
        public string MaterialtheirProducts1 { get; set; }
        [DisplayName("Material & their Products2")]
        [Category("C44")]
        public string MaterialtheirProductsPer2 { get; set; }
        [DisplayName("Material & their Products3")]
        [Category("D44")]
        public string MaterialtheirProducts3 { get; set; }

        [DisplayName("Petroleum, Coal Products & Nuclear Fuels")]
        [Category("B45")]
        public string PetroleumCoalProductsNuclearFuels1 { get; set; }
        [DisplayName("Petroleum, Coal Products & Nuclear Fuels2")]
        [Category("C45")]
        public string PetroleumCoalProductsNuclearFuelsPer2 { get; set; }
        [DisplayName("Petroleum, Coal Products & Nuclear Fuels3")]
        [Category("D45")]
        public string PetroleumCoalProductsNuclearFuels3 { get; set; }

        [DisplayName("Chemical & Chemical Products")]
        [Category("B46")]
        public string ChemicalChemicalProducts1 { get; set; }
        [DisplayName("Chemical & Chemical Products2")]
        [Category("C46")]
        public string ChemicalChemicalProductsPer2 { get; set; }
        [DisplayName("Chemical & Chemical Products3")]
        [Category("D46")]
        public string ChemicalChemicalProducts3 { get; set; }

        [DisplayName("Cement & Cement Products")]
        [Category("B47")]
        public string CementCementProducts1 { get; set; }
        [DisplayName("Cement & Cement Products2")]
        [Category("C47")]
        public string CementCementProductsPer2 { get; set; }
        [DisplayName("Cement & Cement Products3")]
        [Category("D47")]
        public string CementCementProducts3 { get; set; }

        [DisplayName("Basic Metal & Metal Product")]
        [Category("B48")]
        public string BasicMetalMetalProduct1 { get; set; }
        [DisplayName("Basic Metal & Metal Product2")]
        [Category("C48")]
        public string BasicMetalMetalProductPer2 { get; set; }
        [DisplayName("Basic Metal & Metal Product3")]
        [Category("D48")]
        public string BasicMetalMetalProduct3 { get; set; }

        [DisplayName("All Engineering")]
        [Category("B49")]
        public string AllEngineering1 { get; set; }
        [DisplayName("All Engineering2")]
        [Category("C49")]
        public string AllEngineeringPer2 { get; set; }
        [DisplayName("All Engineering3")]
        [Category("D49")]
        public string AllEngineering3 { get; set; }

        [DisplayName("Automobile & Ancillary")]
        [Category("B50")]
        public string AutomobileAncillary1 { get; set; }
        [DisplayName("Automobile & Ancillary2")]
        [Category("C50")]
        public string AutomobileAncillaryPer2 { get; set; }
        [DisplayName("Automobile & Ancillary3")]
        [Category("D50")]
        public string AutomobileAncillary3 { get; set; }

        [DisplayName("Gems & Jewellery")]
        [Category("B51")]
        public string GemsJewellery1 { get; set; }
        [DisplayName("Gems & Jewellery2")]
        [Category("C51")]
        public string GemsJewelleryPer2 { get; set; }
        [DisplayName("Gems & Jewellery3")]
        [Category("D51")]
        public string GemsJewellery3 { get; set; }

        [DisplayName("Construction (other than Infrastructure)")]
        [Category("B52")]
        public string Construction1 { get; set; }
        [DisplayName("Construction (other than Infrastructure)2")]
        [Category("C52")]
        public string ConstructionPer2 { get; set; }
        [DisplayName("Construction (other than Infrastructure)3")]
        [Category("D52")]
        public string Construction3 { get; set; }

        [DisplayName("Power")]
        [Category("B53")]
        public string Power1 { get; set; }
        [DisplayName("Power2")]
        [Category("C53")]
        public string PowerPer2 { get; set; }
        [DisplayName("Power3")]
        [Category("D53")]
        public string Power3 { get; set; }

        [DisplayName("Telecommunication")]
        [Category("B54")]
        public string Telecommunication1 { get; set; }
        [DisplayName("Telecommunication2")]
        [Category("C54")]
        public string TelecommunicationPer2 { get; set; }
        [DisplayName("Telecommunication3")]
        [Category("D54")]
        public string Telecommunication3 { get; set; }

        [DisplayName("Rest of the Infrastructure")]
        [Category("B55")]
        public string RestoftheInfrastructure1 { get; set; }
        [DisplayName("Rest of the Infrastructure2")]
        [Category("C55")]
        public string RestoftheInfrastructurePer2 { get; set; }
        [DisplayName("Rest of the Infrastructure3")]
        [Category("D55")]
        public string RestoftheInfrastructure3 { get; set; }

        [DisplayName("NBFCs")]
        [Category("B56")]
        public string NBFCs1 { get; set; }
        [DisplayName("NBFCs2")]
        [Category("C56")]
        public string NBFCsPer2 { get; set; }
        [DisplayName("NBFCs3")]
        [Category("D56")]
        public string NBFCs3 { get; set; }

        [DisplayName("Other Industries")]
        [Category("B57")]
        public string OtherIndustries1 { get; set; }
        [DisplayName("Other Industries2")]
        [Category("C57")]
        public string OtherIndustriesPer2 { get; set; }
        [DisplayName("Other Industries3")]
        [Category("D57")]
        public string OtherIndustries3 { get; set; }

        [DisplayName("Retail")]
        [Category("B58")]
        public string Retail1 { get; set; }
        [DisplayName("Retail2")]
        [Category("C58")]
        public string RetailPer2 { get; set; }
        [DisplayName("Retail3")]
        [Category("D58")]
        public string Retail3 { get; set; }

        [DisplayName("Residual Advances")]
        [Category("B59")]
        public string ResidualAdvances1 { get; set; }
        [DisplayName("Residual Advances2")]
        [Category("C59")]
        public string ResidualAdvancesPer2 { get; set; }
        [DisplayName("Residual Advances3")]
        [Category("D59")]
        public string ResidualAdvances3 { get; set; }

        [DisplayName("Total Advances")]
        [Category("B60")]
        public string TotalAdvances { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }

        public bool IsStaging { get; set; }
        public bool IsFinal { get; set; }
    }
}
