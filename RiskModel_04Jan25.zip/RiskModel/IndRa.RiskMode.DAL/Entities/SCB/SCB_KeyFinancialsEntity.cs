﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class SCB_KeyFinancialsEntity
    {
        public int KeyFinancialsId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        [DisplayName("Period of Year End")]
        [Category("B7")] 
        public DateTime? PeriodEndingDate1 { get; set; }
        [DisplayName("Period of Year End2")]
        [Category("C7")] 
        public DateTime? PeriodEndingDate2 { get; set; }

        [DisplayName("No. of Months in the Period")]
        [Category("B8")] 
        public int? NoofMonthsPeriod1 { get; set; }
        [DisplayName("No. of Months in the Period2")]
        [Category("C8")] 
        public int? NoofMonthsPeriod2 { get; set; }

        [DisplayName("Currency")]
        [Category("B9")]
        public string Currency1 { get; set; }
        [DisplayName("Currency2")]
        [Category("C9")] 
        public string Currency2 { get; set; }

        [DisplayName("Tangible Net Worth")]
        [Category("B10")] 
        public string NetWorth1 { get; set; }
        [DisplayName("Tangible Net Worth2")]
        [Category("C10")] 
        public string NetWorth2 { get; set; }

        [DisplayName("Total Assets")]
        [Category("B11")] 
        public string TotalAssets1 { get; set; }
        [DisplayName("Total Assets2")]
        [Category("C11")] 
        public string TotalAssets2 { get; set; }

        [DisplayName("Credit Deposit Ratio (%)")]
        [Category("B12")]
        public string CreditDepositRatioPer1 { get; set; }
        [DisplayName("Credit Deposit Ratio (%)2")]
        [Category("C12")] 
        public string CreditDepositRatioPer2 { get; set; }

        [DisplayName("CASA (%)")]
        [Category("B13")] 
        public string CASAPer1 { get; set; }
        [DisplayName("CASA (%)2")]
        [Category("C13")] 
        public string CASAPer2 { get; set; }

        [DisplayName("Priority sector advances (% of ANBC)")]
        [Category("B14")] 
        public string PrioritySectorAdvancesPer1 { get; set; }
        [DisplayName("Priority sector advances (% of ANBC)2")]
        [Category("C14")] 
        public string PrioritySectorAdvancesPer2 { get; set; }

        [DisplayName("Return on Assets (%)")]
        [Category("B15")] 
        public string ReturnOnAssetsPer1 { get; set; }
        [DisplayName("Return on Assets (%)2")]
        [Category("C15")] 
        public string ReturnOnAssetsPer2 { get; set; }

        [DisplayName("Return on Equity (%)")]
        [Category("B16")] 
        public string ReturnOnNetWorthPer1 { get; set; }
        [DisplayName("Return on Equity (%)2")]
        [Category("C16")] 
        public string ReturnOnNetWorthPer2 { get; set; }

        [DisplayName("Cost Of Deposits (%)")]
        [Category("B17")] 
        public string CostOfDepositsPer1 { get; set; }
        [DisplayName("Cost Of Deposits (%)2")]
        [Category("C17")] 
        public string CostOfDepositsPer2 { get; set; }

        [DisplayName("CRAR (%)")]
        [Category("B18")] 
        public string CRARPer1 { get; set; }
        [DisplayName("CRAR (%)2")]
        [Category("C18")] 
        public string CRARPer2 { get; set; }

        [DisplayName("Tier 1 (%)")]
        [Category("B19")] 
        public string Tier1Per1 { get; set; }
        [DisplayName("Tier 1 (%)2")]
        [Category("C19")] 
        public string Tier1Per2 { get; set; }

        [DisplayName("Common Equity Tier 1 (%)")]
        [Category("B20")]
        public string CommonEquityTierPer1 { get; set; }
        [DisplayName("Common Equity Tier 1 (%)2")]
        [Category("C20")]
        public string CommonEquityTierPer2 { get; set; }

        [DisplayName("Net NPA (%)")]
        [Category("B21")] 
        public string NetNPAPer1 { get; set; }
        [DisplayName("Net NPA (%)2")]
        [Category("C21")] 
        public string NetNPAPer2 { get; set; }

        [DisplayName("Growth in Deposits (%)")]
        [Category("B22")] 
        public string GrowthinDepositsPer1 { get; set; }
        [DisplayName("Growth in Deposits (%)2")]
        [Category("C22")] 
        public string GrowthinDepositsPer2 { get; set; }


        [DisplayName("Total No. of Branches")]
        [Category("B23")] 
        public string TotalNumBranches1 { get; set; }
        [DisplayName("Total No. of Branches2")]
        [Category("C23")] 
        public string TotalNumBranches2 { get; set; }

        [DisplayName("Gross NPA (%)")]
        [Category("B24")] 
        public string GrossNPAPer1 { get; set; }
        [DisplayName("Gross NPA (%)2")]
        [Category("C24")] 
        public string GrossNPAPer2 { get; set; }

        [DisplayName("Addition in NPAs/ Advances")]
        [Category("B25")] 
        public string AdditioninNPAsAdvancesPer1 { get; set; }
        [DisplayName("Addition in NPAs/ Advances2")]
        [Category("C25")] 
        public string AdditioninNPAsAdvancesPer2 { get; set; }

        [DisplayName("Diversity of Income")]
        [Category("B26")] 
        public string DiversityofIncomePer1 { get; set; }
        [DisplayName("Diversity of Income2")]
        [Category("C26")] 
        public string DiversityofIncomePer2 { get; set; }

        [DisplayName("Tangible NW/ Net NPA (x)")]
        [Category("B27")] 
        public string TangibleNWNetNPA1 { get; set; }
        [DisplayName("Tangible NW/ Net NPA (x)2")]
        [Category("C27")] 
        public string TangibleNWNetNPA2 { get; set; }

        [DisplayName("Total Cont. Liability/ Total Assets (%)")]
        [Category("B28")] 
        public string TotalContLiabilityTotalAssetsPer1 { get; set; }
        [DisplayName("Total Cont. Liability/ Total Assets (%)2")]
        [Category("C28")] 
        public string TotalContLiabilityTotalAssetsPer2 { get; set; }

        [DisplayName("Exposure to capital market/capital funds (%)")]
        [Category("B29")] 
        public string AdvancesToSensitiveSectorPer1 { get; set; }
        [DisplayName("Exposure to capital market/capital funds (%)2")]
        [Category("C29")]
        public string AdvancesToSensitiveSectorPer2 { get; set; }

        [DisplayName("Cost to Income (%)")]
        [Category("B30")] 
        public string CosttoIncomePer1 { get; set; }
        [DisplayName("Cost to Income (%)2")]
        [Category("C30")] 
        public string CosttoIncomePer2 { get; set; }

        [DisplayName("Credit Cost (%)")]
        [Category("B31")] 
        public string CreditCostPer1 { get; set; }
        [DisplayName("Credit Cost (%)2")]
        [Category("C31")] 
        public string CreditCostPer2 { get; set; }

        [DisplayName("PPOP/ Credit Cost (x)")]
        [Category("B32")] 
        public string PPOPCreditCost1 { get; set; }
        [DisplayName("PPOP/ Credit Cost (x)2")]
        [Category("C32")] 
        public string PPOPCreditCost2 { get; set; }

        //[DisplayName("ALM Gap in 6 months bucket")]
        //[Category("B33")] 
        //public string ALMGapin6monthsbucketPer1 { get; set; }
        //[DisplayName("ALM Gap in 6 months bucket2")]
        //[Category("C33")]
        //public string ALMGapin6monthsbucketPer2 { get; set; }

        [DisplayName("Liquidity Coverage Ratio (%)")]
        [Category("B33")]
        public string LiquidityCoverageRatioPer1 { get; set; }
        [DisplayName("Liquidity Coverage Ratio (%)2")]
        [Category("C33")] 
        public string LiquidityCoverageRatioPer2 { get; set; }

        [DisplayName("Top 20 Concentration (%)")]
        [Category("B34")] 
        public string Top20ConcentrationPer1 { get; set; }
        [DisplayName("Top 20 Concentration (%)2")]
        [Category("C34")] 
        public string Top20ConcentrationPer2 { get; set; }

        [DisplayName("Net Stable Funding Ratio (%)")]
        [Category("B35")] 
        public string NetStableFundingRatioPer1 { get; set; }
        [DisplayName("Net Stable Funding Ratio (%)2")]
        [Category("C35")] 
        public string NetStableFundingRatioPer2 { get; set; }

        [DisplayName("Gearing (%)")]
        [Category("B36")]
        public string GearingPer1 { get; set; }
        [DisplayName("Gearing (%)2")]
        [Category("C36")]
        public string GearingPer2 { get; set; }

        [DisplayName("Leverage (%)")]
        [Category("B37")]
        public string LeverageRatioPer1 { get; set; }
        [DisplayName("Leverage (%)2")]
        [Category("C37")]
        public string LeverageRatioPer2 { get; set; }

        [DisplayName("Provisioning Coverage Ratio (%)")]
        [Category("B38")]
        public string ProvisioningCoverageRatio1 { get; set; }

        [DisplayName("Provisioning Coverage Ratio (%)2")]
        [Category("C38")]
        public string ProvisioningCoverageRatio2 { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsStaging { get; set; }
        public bool IsFinal { get; set; }
    }
}
