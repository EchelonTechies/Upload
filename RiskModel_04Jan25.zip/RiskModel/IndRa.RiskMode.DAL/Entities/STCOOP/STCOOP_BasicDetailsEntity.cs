﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web;

namespace IndRa.RiskModel.DAL.Entities
{
    public class STCOOP_BasicDetailsEntity
    {
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        public HttpPostedFileBase ExcelFile { get; set; }
        public int UserId { get; set; }
        public string ButtonValue { get; set; }
        public int CompanyId { get; set; }
        [DisplayName("Financial Year")]
        public string FinYear { get; set; }
        public int reportCompanyId { get; set; }
        [DisplayName("Entity Name")]
        public string CompanyName { get; set; }
        [DisplayName("Company")]
        public string reportCompany { get; set; }
        public int LocationId { get; set; }
        [DisplayName("Location")]
        public string LocationName { get; set; }
        public string selectedLocation { get; set; }
        [DisplayName("Date of Balance Sheet")]
        public DateTime? DateOfInput { get; set; }
        [DisplayName("Financial Year Ending Date")]
        public string FinancialYearEndingDate { get; set; }
        [DisplayName("Input Currency")]
        public string CurrencyUnits { get; set; }
        public string ParentCompanyIsExist { get; set; }
        public int? ParentCompanyId { get; set; }
        [DisplayName("Parent Company")]
        public string ParentCompanyName { get; set; }
        public int? ParentRatingId { get; set; }
        [DisplayName("Parent Rating")]
        public string ParentRating { get; set; }
        [Category("B6")]
        [DisplayName("Sponsor Bank")]
        public string SponsorBank{ get; set; }
        [DisplayName("Parent Company Share Holding (%)")]
        public decimal? ParentCompanyShareHoldingPer { get; set; }
        [DisplayName("Admin Comments")]
        public string Comments { get; set; }
        [DisplayName("Final Rating As Per Rating Committe")]
        public string FinalRating { get; set; }

        [DisplayName("PD")]
        public string PD { get; set; }
        public string InputFilePath { get; set; }

        public bool? SubmitForApproval { get; set; }

        public DateTime? SubmitForApprovalDate { get; set; }

        public DateTime? ApprovedDate { get; set; }

        public DateTime? ReviewedDate { get; set; }

        public int CreatedBy { get; set; }
        [DisplayName("Created Date")]
        public DateTime CreatedDateTime { get; set; }
        [DisplayName("Created Date")]
        public DateTime reportCreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsFinal { get; set; }

        public STCOOP_KeyFinancialsEntity STCOOP_KeyFinancialsEntity { get; set; }
        public STCOOP_SubjectiveParametersEntity STCOOP_SubjectiveParametersEntity { get; set; }
        public List<STCOOP_OutputDetailsEntity> STCOOP_OutputDetailsEntity { get; set; }

    }
}
