﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class NHB_ProfitAndLossStatementss
    {

        public int StatementId { get; set; }
        public int DetailsId { get; set; }

        [DisplayName("Period Ending")]
        public string PeriodEndingDate { get; set; }
        public DateTime? PeriodEndingDate1_ProfitAndLoss { get; set; }
        public DateTime? PeriodEndingDate2_ProfitAndLoss { get; set; }
        public DateTime? PeriodEndingDate3_ProfitAndLoss { get; set; }
        public DateTime? PeriodEndingDate4_ProfitAndLoss { get; set; }

        [DisplayName("INCOME")]
        public string IncomeOutput { get; set; }
        public string IncomeOutput1 { get; set; }
        public string IncomeOutput2 { get; set; }
        public string IncomeOutput3 { get; set; }
        public string IncomeOutput4 { get; set; }

        [DisplayName("Interest Income")]
        public string InterestIncomeOutput { get; set; }
        public string InterestIncomeOutput1 { get; set; }
        public string InterestIncomeOutput2 { get; set; }
        public string InterestIncomeOutput3 { get; set; }
        public string InterestIncomeOutput4 { get; set; }

        [DisplayName("Interest on Housing Loans - Individuals")]
        public string InterestonHousingLoansIndividuals { get; set; }
        public string InterestonHousingLoansIndividuals1 { get; set; }
        public string InterestonHousingLoansIndividuals2 { get; set; }
        public string InterestonHousingLoansIndividuals3 { get; set; }
        public string InterestonHousingLoansIndividuals4 { get; set; }

        [DisplayName("Interest on Housing Loans - Corporate Bodies")]
        public string InterestonHousingLoansCorporateBodies { get; set; }
        public string InterestonHousingLoansCorporateBodies1 { get; set; }
        public string InterestonHousingLoansCorporateBodies2 { get; set; }
        public string InterestonHousingLoansCorporateBodies3 { get; set; }
        public string InterestonHousingLoansCorporateBodies4 { get; set; }

        [DisplayName("Other Interest Income")]
        public string OtherInterestIncome { get; set; }
        public string OtherInterestIncome1 { get; set; }
        public string OtherInterestIncome2 { get; set; }
        public string OtherInterestIncome3 { get; set; }
        public string OtherInterestIncome4 { get; set; }

        [DisplayName("Income from Investments - Short Term")]
        public string IncomeFromInvestmentsShortTerm { get; set; }
        public string IncomeFromInvestmentsShortTerm1 { get; set; }
        public string IncomeFromInvestmentsShortTerm2 { get; set; }
        public string IncomeFromInvestmentsShortTerm3 { get; set; }
        public string IncomeFromInvestmentsShortTerm4 { get; set; }

        [DisplayName("Income from Investments - Long Term")]
        public string IncomeFromInvestmentsLongTerm { get; set; }
        public string IncomeFromInvestmentsLongTerm1 { get; set; }
        public string IncomeFromInvestmentsLongTerm2 { get; set; }
        public string IncomeFromInvestmentsLongTerm3 { get; set; }
        public string IncomeFromInvestmentsLongTerm4 { get; set; }

        [DisplayName("Other Operating Income")]
        public string OtherOperatingIncomeOutput { get; set; }
        public string OtherOperatingIncomeOutput1 { get; set; }
        public string OtherOperatingIncomeOutput2 { get; set; }
        public string OtherOperatingIncomeOutput3 { get; set; }
        public string OtherOperatingIncomeOutput4 { get; set; }

        [DisplayName("Fees Received")]
        public string FeesReceived { get; set; }
        public string FeesReceived1 { get; set; }
        public string FeesReceived2 { get; set; }
        public string FeesReceived3 { get; set; }
        public string FeesReceived4 { get; set; }

        [DisplayName("Commisions, Exchange & Brokerage")]
        public string CommisionsAndExchangeAndBrokerage { get; set; }
        public string CommisionsAndExchangeAndBrokerage1 { get; set; }
        public string CommisionsAndExchangeAndBrokerage2 { get; set; }
        public string CommisionsAndExchangeAndBrokerage3 { get; set; }
        public string CommisionsAndExchangeAndBrokerage4 { get; set; }

        [DisplayName("Profit / Loss on sale of Investments")]
        public string ProfitLossSaleInvestments { get; set; }
        public string ProfitLossSaleInvestments1 { get; set; }
        public string ProfitLossSaleInvestments2 { get; set; }
        public string ProfitLossSaleInvestments3 { get; set; }
        public string ProfitLossSaleInvestments4 { get; set; }

        [DisplayName("Profit / Loss on sale of Assets")]
        public string ProfitLossSaleAssets { get; set; }
        public string ProfitLossSaleAssets1 { get; set; }
        public string ProfitLossSaleAssets2 { get; set; }
        public string ProfitLossSaleAssets3 { get; set; }
        public string ProfitLossSaleAssets4 { get; set; }

        [DisplayName("Profit / Loss on Exchange Transactions")]
        public string ProfitLossExchangeTransactions { get; set; }
        public string ProfitLossExchangeTransactions1 { get; set; }
        public string ProfitLossExchangeTransactions2 { get; set; }
        public string ProfitLossExchangeTransactions3 { get; set; }
        public string ProfitLossExchangeTransactions4 { get; set; }

        [DisplayName("Other Service Income")]
        public string OtherServiceIncome { get; set; }
        public string OtherServiceIncome1 { get; set; }
        public string OtherServiceIncome2 { get; set; }
        public string OtherServiceIncome3 { get; set; }
        public string OtherServiceIncome4 { get; set; }

        [DisplayName("Gain on Sale of securitised Assets")]
        public string GainOnSaleOfSecuritisedAssets { get; set; }
        public string GainOnSaleOfSecuritisedAssets1 { get; set; }
        public string GainOnSaleOfSecuritisedAssets2 { get; set; }
        public string GainOnSaleOfSecuritisedAssets3 { get; set; }
        public string GainOnSaleOfSecuritisedAssets4 { get; set; }

        [DisplayName("Other Non-operating Income")]
        public string OtherNonOperatingIncome { get; set; }
        public string OtherNonOperatingIncome1 { get; set; }
        public string OtherNonOperatingIncome2 { get; set; }
        public string OtherNonOperatingIncome3 { get; set; }
        public string OtherNonOperatingIncome4 { get; set; }

        [DisplayName("EXPENSE")]
        public string ExpenseOutput { get; set; }
        public string ExpenseOutput1 { get; set; }
        public string ExpenseOutput2 { get; set; }
        public string ExpenseOutput3 { get; set; }
        public string ExpenseOutput4 { get; set; }

        [DisplayName("Interest Expense")]
        public string InterestExpenseOutput { get; set; }
        public string InterestExpenseOutput1 { get; set; }
        public string InterestExpenseOutput2 { get; set; }
        public string InterestExpenseOutput3 { get; set; }
        public string InterestExpenseOutput4 { get; set; }

        [DisplayName("Interest on deposits")]
        public string InterestOnDeposits { get; set; }
        public string InterestOnDeposits1 { get; set; }
        public string InterestOnDeposits2 { get; set; }
        public string InterestOnDeposits3 { get; set; }
        public string InterestOnDeposits4 { get; set; }

        [DisplayName("Interest on borrowings")]
        public string InterestOnBorrowings { get; set; }
        public string InterestOnBorrowings1 { get; set; }
        public string InterestOnBorrowings2 { get; set; }
        public string InterestOnBorrowings3 { get; set; }
        public string InterestOnBorrowings4 { get; set; }

        [DisplayName("Interest paid")]
        public string InterestPaidOutput { get; set; }
        public string InterestPaidOutput1 { get; set; }
        public string InterestPaidOutput2 { get; set; }
        public string InterestPaidOutput3 { get; set; }
        public string InterestPaidOutput4 { get; set; }

        [DisplayName("Other Financial Charges")]
        public string OtherFinancialCharges { get; set; }
        public string OtherFinancialCharges1 { get; set; }
        public string OtherFinancialCharges2 { get; set; }
        public string OtherFinancialCharges3 { get; set; }
        public string OtherFinancialCharges4 { get; set; }

        [DisplayName("Personnel Expenses")]
        public string PersonnelExpenses { get; set; }
        public string PersonnelExpenses1 { get; set; }
        public string PersonnelExpenses2 { get; set; }
        public string PersonnelExpenses3 { get; set; }
        public string PersonnelExpenses4 { get; set; }

        [DisplayName("Operating Expenses Result")]
        public string OperatingExpensesOutput { get; set; }
        public string OperatingExpensesOutput1 { get; set; }
        public string OperatingExpensesOutput2 { get; set; }
        public string OperatingExpensesOutput3 { get; set; }
        public string OperatingExpensesOutput4 { get; set; }

        [DisplayName("Operating Expenses")]
        public string OperatingExpenses { get; set; }
        public string OperatingExpenses1 { get; set; }
        public string OperatingExpenses2 { get; set; }
        public string OperatingExpenses3 { get; set; }
        public string OperatingExpenses4 { get; set; }

        [DisplayName("Miscellaneous expenses written off")]
        public string MiscellaneousExpensesWrittenOff { get; set; }
        public string MiscellaneousExpensesWrittenOff1 { get; set; }
        public string MiscellaneousExpensesWrittenOff2 { get; set; }
        public string MiscellaneousExpensesWrittenOff3 { get; set; }
        public string MiscellaneousExpensesWrittenOff4 { get; set; }

        [DisplayName("Provision for impairment in value of assets")]
        public string ProvisionForImpairmentInValueOfAssets { get; set; }
        public string ProvisionForImpairmentInValueOfAssets1 { get; set; }
        public string ProvisionForImpairmentInValueOfAssets2 { get; set; }
        public string ProvisionForImpairmentInValueOfAssets3 { get; set; }
        public string ProvisionForImpairmentInValueOfAssets4 { get; set; }

        [DisplayName("Depreciation")]
        public string Depreciation { get; set; }
        public string Depreciation1 { get; set; }
        public string Depreciation2 { get; set; }
        public string Depreciation3 { get; set; }
        public string Depreciation4 { get; set; }

        [DisplayName("Loan Losses")]
        public string LoanLosses { get; set; }
        public string LoanLosses1 { get; set; }
        public string LoanLosses2 { get; set; }
        public string LoanLosses3 { get; set; }
        public string LoanLosses4 { get; set; }

        [DisplayName("Provision for loan losses")]
        public string ProvisionForLoanLosses { get; set; }
        public string ProvisionForLoanLosses1 { get; set; }
        public string ProvisionForLoanLosses2 { get; set; }
        public string ProvisionForLoanLosses3 { get; set; }
        public string ProvisionForLoanLosses4 { get; set; }

        [DisplayName("Provision for Interest on Income Tax Refund")]
        public string ProvisionForInterestOnIncomeTaxRefund { get; set; }
        public string ProvisionForInterestOnIncomeTaxRefund1 { get; set; }
        public string ProvisionForInterestOnIncomeTaxRefund2 { get; set; }
        public string ProvisionForInterestOnIncomeTaxRefund3 { get; set; }
        public string ProvisionForInterestOnIncomeTaxRefund4 { get; set; }

        [DisplayName("Provision for Bad Debts written back")]
        public string ProvisionForBadDebtsWrittenBack { get; set; }
        public string ProvisionForBadDebtsWrittenBack1 { get; set; }
        public string ProvisionForBadDebtsWrittenBack2 { get; set; }
        public string ProvisionForBadDebtsWrittenBack3 { get; set; }
        public string ProvisionForBadDebtsWrittenBack4 { get; set; }

        [DisplayName("Other Credit Assets written off")]
        public string OtherCreditAssetsWrittenOff { get; set; }
        public string OtherCreditAssetsWrittenOff1 { get; set; }
        public string OtherCreditAssetsWrittenOff2 { get; set; }
        public string OtherCreditAssetsWrittenOff3 { get; set; }
        public string OtherCreditAssetsWrittenOff4 { get; set; }

        [DisplayName("Other Adjustments")]
        public string OtherAdjustments { get; set; }
        public string OtherAdjustments1 { get; set; }
        public string OtherAdjustments2 { get; set; }
        public string OtherAdjustments3 { get; set; }
        public string OtherAdjustments4 { get; set; }

        [DisplayName("Profit Before Tax (PBT)")]
        public string ProfitBeforeTaxOutput { get; set; }
        public string ProfitBeforeTaxOutput1 { get; set; }
        public string ProfitBeforeTaxOutput2 { get; set; }
        public string ProfitBeforeTaxOutput3 { get; set; }
        public string ProfitBeforeTaxOutput4 { get; set; }

        [DisplayName("Tax Expense")]
        public string TaxExpenseOutput { get; set; }
        public string TaxExpenseOutput1 { get; set; }
        public string TaxExpenseOutput2 { get; set; }
        public string TaxExpenseOutput3 { get; set; }
        public string TaxExpenseOutput4 { get; set; }

        [DisplayName(" - Current Tax")]
        public string CurrentTax { get; set; }
        public string CurrentTax1 { get; set; }
        public string CurrentTax2 { get; set; }
        public string CurrentTax3 { get; set; }
        public string CurrentTax4 { get; set; }

        [DisplayName(" - Deferred Tax")]
        public string DeferredTax { get; set; }
        public string DeferredTax1 { get; set; }
        public string DeferredTax2 { get; set; }
        public string DeferredTax3 { get; set; }
        public string DeferredTax4 { get; set; }

        [DisplayName("Profit After Tax (PAT)")]
        public string ProfitAfterTaxOutput { get; set; }
        public string ProfitAfterTaxOutput1 { get; set; }
        public string ProfitAfterTaxOutput2 { get; set; }
        public string ProfitAfterTaxOutput3 { get; set; }
        public string ProfitAfterTaxOutput4 { get; set; }

        [DisplayName("Preference Dividend + Tax")]
        public string PreferenceDividend_Tax { get; set; }
        public string PreferenceDividend_Tax1 { get; set; }
        public string PreferenceDividend_Tax2 { get; set; }
        public string PreferenceDividend_Tax3 { get; set; }
        public string PreferenceDividend_Tax4 { get; set; }

        [DisplayName("Equity Dividend + Tax")]
        public string EquityDividend_Tax { get; set; }
        public string EquityDividend_Tax1 { get; set; }
        public string EquityDividend_Tax2 { get; set; }
        public string EquityDividend_Tax3 { get; set; }
        public string EquityDividend_Tax4 { get; set; }

        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public bool IsFinal { get; set; }
    }
}
