﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class ACHFS_SubjectiveParametersEntity
    {
        public int SubjectiveParametersId { get; set; }
        public int DetailsId { get; set; }
        public short LogId { get; set; }

        [DisplayName("Industry Risk Score")]
        [Category("D39")]
        public string IndustryRiskScore { get; set; }

        [DisplayName("Access to E-Kuber/ RTGS")]
        [Category("D40")]
        public string AccesstoEKuberRTGS { get; set; }

        [DisplayName("Management Quality")]
        [Category("D41")]
        public string ManagementQuality { get; set; }

        [DisplayName("Underwriting Standards")]
        [Category("D42")]
        public string UnderwritingStandards { get; set; }

         [DisplayName("Adverse news")]
        [Category("D43")]
        public string AdverseNews { get; set; }

        [Category("D44")]
        [DisplayName("Independence of the Board of Directors")]
        public string IndependenceBoardDirectors { get; set; }

        [DisplayName("Company spends on Corporate Social Responsibility as per regulatory requirement")]
        [Category("D45")]
        public string CompanySpendsCorporateSocialResponsibility { get; set; }

        [DisplayName("Audit Committee meetings held on time")]
        [Category("D46")]
        public string AuditCommitteeHeldOnTime { get; set; }

        [DisplayName("Audit Committee discussed all the calendar items in the meeting")]
        [Category("D47")]
        public string AuditCommitteeDiscuAllCalendarItems { get; set; }

        [DisplayName("No Change of Auditors before the term")]
        [Category("D48")]
        public string NoChangeAuditorsBeforeTerm { get; set; }
         
        [DisplayName("No Independent directors or Key  Management officials resigned before term")]
        [Category("D49")]
        public string NoIndKeyManResignBeforeTerm { get; set; }

        [DisplayName("Less than 1% of total transcations are  Related Party Transcations")]
        [Category("D50")]
        public string LessThanOnePerTotTran { get; set; }

        [DisplayName("Centralized database captures all data including branch level operations for all asset and liabilities")]
        [Category("D51")]
        public string CentDBCapturesAllData { get; set; }

        [DisplayName("NPA is System Generated")]
        [Category("D52")]
        public string NPASysGen { get; set; }

        [DisplayName("No Delay in  reporting and disclosure as per regulatory requirement")]
        [Category("D53")]
        public string NoDelayInReporting { get; set; }

        [DisplayName("Competent and Independent Management handles operation of company and promoter is not directly involved in day to day  operation")]
        [Category("D54")]
        public string CompAndIndManagement { get; set; }

        [DisplayName("No divergence between regulator assessment of company financials and Company Audited Financials")]
        [Category("D55")]
        public string NoDivBetRegAssess { get; set; }

        [DisplayName("SMA 2 under loan portfolio")]
        [Category("D56")]
        public string SMA1And2UnderLoanPort { get; set; }

        [DisplayName("Qualified Opinion by Auditor")]
        [Category("D57")]
        public string QualifiedOpinionByAuditor { get; set; }

        [DisplayName("Default with Lenders")]
        [Category("D58")]
        public string DefaultWithOtherLenders { get; set; }

        public DateTime? CreatedDateTime { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
    }
}
