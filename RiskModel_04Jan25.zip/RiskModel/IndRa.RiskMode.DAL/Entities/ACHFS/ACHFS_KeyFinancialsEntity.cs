﻿using System;
using System.ComponentModel;

namespace IndRa.RiskModel.DAL.Entities
{
    public class ACHFS_KeyFinancialsEntity
    {
        public int KeyFinancialsId { get; set; }
        public int DetailsId { get; set; }

        public short LogId { get; set; }

        [DisplayName("Currency")]
        [Category("B8")]
        public string Currency1 { get; set; }
        [DisplayName("Currency2")]
        [Category("C8")]
        public string Currency2 { get; set; }
        [DisplayName("Currency3")]
        [Category("D8")]
        public string Currency3 { get; set; }

        [DisplayName("Period of Year End")]
        [Category("B9")]
        public DateTime? PeriodEndingDate1 { get; set; }
        [DisplayName("Period of Year End2")]
        [Category("C9")]
        public DateTime? PeriodEndingDate2 { get; set; }
        [DisplayName("Period of Year End3")]
        [Category("D9")]
        public DateTime? PeriodEndingDate3 { get; set; }

        [DisplayName("No. of Months in the Period")]
        [Category("B10")]
        public int? NoofMonthsPeriod1 { get; set; }
        [DisplayName("No. of Months in the Period2")]
        [Category("C10")]
        public int? NoofMonthsPeriod2 { get; set; }
        [DisplayName("No. of Months in the Period3")]
        [Category("D10")]
        public int? NoofMonthsPeriod3 { get; set; }

        [DisplayName("Tangible Net Worth")]
        [Category("B11")]
        public string NetWorth1 { get; set; }
        [DisplayName("Tangible Net Worth2")]
        [Category("C11")]
        public string NetWorth2 { get; set; }
        [DisplayName("Tangible Net Worth3")]
        [Category("D11")]
        public string NetWorth3 { get; set; }

        [DisplayName("Total Assets")]
        [Category("B12")]
        public string TotalAssets1 { get; set; }
        [DisplayName("Total Assets2")]
        [Category("C12")]
        public string TotalAssets2 { get; set; }
        [DisplayName("Total Assets3")]
        [Category("D12")]
        public string TotalAssets3 { get; set; }

        [DisplayName("Total Memberships")]
        [Category("B13")]
        public string TotalMemberships1 { get; set; }
        [DisplayName("Total Memberships2")]
        [Category("C13")]
        public string TotalMemberships2 { get; set; }
        [DisplayName("Total Memberships3")]
        [Category("D13")]
        public string TotalMemberships3 { get; set; }

        [DisplayName("Total Underconstruction and Completed Houses")]
        [Category("B14")]
        public string TotalUnderconstructionCompletedHouses1 { get; set; }
        [DisplayName("Total Underconstruction and Completed Houses2")]
        [Category("C14")]
        public string TotalUnderconstructionCompletedHouses2 { get; set; }
        [DisplayName("Total Underconstruction and Completed Houses3")]
        [Category("D14")]
        public string TotalUnderconstructionCompletedHouses3 { get; set; }

        [DisplayName("Govt. Contribution to Total Share Capital")]
        [Category("B15")]
        public string GovtContributionTotalShareCapital1 { get; set; }
        [DisplayName("Govt. Contribution to Total Share Capital2")]
        [Category("C15")]
        public string GovtContributionTotalShareCapital2 { get; set; }
        [DisplayName("Govt. Contribution to Total Share Capital3")]
        [Category("D15")]
        public string GovtContributionTotalShareCapital3 { get; set; }

        [DisplayName("Total Advances")]
        [Category("B16")]
        public string TotalAdvances1 { get; set; }
        [DisplayName("Total Advances2")]
        [Category("C16")]
        public string TotalAdvances2 { get; set; }
        [DisplayName("Total Advances3")]
        [Category("D16")]
        public string TotalAdvances3 { get; set; }

        [DisplayName("Interest Income")]
        [ReadOnly(true)]
        [Category("B17")]
        public string InterestIncome1 { get; set; }
        [DisplayName("Interest Income2")]
        [Category("C17")]
        public string InterestIncome2 { get; set; }
        [DisplayName("Interest Income3")]
        [Category("D17")]
        public string InterestIncome3 { get; set; }

        [DisplayName("Non-Interest Income")]
        [ReadOnly(true)]
        [Category("B18")]
        public string NonInterestIncome1 { get; set; }
        [DisplayName("Non-Interest Income2")]
        [Category("C18")]
        public string NonInterestIncome2 { get; set; }
        [DisplayName("Non-Interest Income3")]
        [Category("D18")]
        public string NonInterestIncome3 { get; set; }

        [ReadOnly(true)]
        [Category("B19")]
        [DisplayName("Interest Expenses")]
        public string InterestExpenses1 { get; set; }
        [DisplayName("Interest Expenses2")]
        [Category("C19")]
        public string InterestExpenses2 { get; set; }
        [DisplayName("Interest Expenses3")]
        [Category("D19")]
        public string InterestExpenses3 { get; set; }

        [DisplayName("Employee, G&A and S&D Expenses Expenses")]
        [ReadOnly(true)]
        [Category("B20")]
        public string EmployeeGASDExpenses1 { get; set; }
        [DisplayName("Employee, G&A and S&D Expenses Expenses2")]
        [Category("C20")]
        public string EmployeeGASDExpenses2 { get; set; }
        [DisplayName("Employee, G&A and S&D Expenses Expenses3")]
        [Category("D20")]
        public string EmployeeGASDExpenses3 { get; set; }


        [DisplayName("PAT")]
        [ReadOnly(true)]
        [Category("B21")]
        public string PAT1 { get; set; }
        [DisplayName("PAT2")]
        [Category("C21")]
        public string PAT2 { get; set; }
        [DisplayName("PAT2")]
        [Category("D21")]
        public string PAT3 { get; set; }

        [DisplayName("Liquid Assets")]
        [ReadOnly(true)]
        [Category("B22")]
        public string LiquidAssets1 { get; set; }
        [DisplayName("Liquid Assets2")]
        [Category("C22")]
        public string LiquidAssets2 { get; set; }
        [DisplayName("Liquid Assets3")]
        [Category("D22")]
        public string LiquidAssets3 { get; set; }

        [DisplayName("Prov. For NPAs and Write-offs")]
        [ReadOnly(true)]
        [Category("B23")]
        public string ProvNPAWriteOffs1 { get; set; }
        [DisplayName("Prov. For NPAs and Write-offs2")]
        [Category("C23")]
        public string ProvNPAWriteOffs2 { get; set; }
        [DisplayName("Prov. For NPAs and Write-offs3")]
        [Category("D23")]
        public string ProvNPAWriteOffs3 { get; set; }

        [DisplayName("Diversity in Deposit Base")]
        [ReadOnly(true)]
        [Category("B24")]
        public string DiversitryDepositBasePer1 { get; set; }
        [DisplayName("Diversity in Deposit Base2")]
        [Category("C24")]
        public string DiversitryDepositBasePer2 { get; set; }
        [DisplayName("Diversity in Deposit Base3")]
        [Category("D24")]
        public string DiversitryDepositBasePer3 { get; set; }

        [DisplayName("Advances to Stressed Sector (%)")]
        [ReadOnly(true)]
        [Category("B25")]
        public string AdvancesStressedSectorPer1 { get; set; }
        [DisplayName("Advances to Stressed Sector (%)2")]
        [Category("C25")]
        public string AdvancesStressedSectorPer2 { get; set; }
        [DisplayName("Advances to Stressed Sector (%)3")]
        [Category("D25")]
        public string AdvancesStressedSectorPer3 { get; set; }

        [DisplayName("Cost Of Funds (%)")]
        [ReadOnly(true)]
        [Category("B26")]
        public string CostOfFundsPer1 { get; set; }
        [DisplayName("Cost Of Funds (%)2")]
        [Category("C26")]
        public string CostOfFundsPer2 { get; set; }
        [DisplayName("Cost Of Funds (%)3")]
        [Category("D26")]
        public string CostOfFundsPer3 { get; set; }

        [DisplayName("CRAR (%)")]
        [ReadOnly(true)]
        [Category("B27")]
        public string CRARPer1 { get; set; }
        [DisplayName("CRAR (%)2")]
        [Category("C27")]
        public string CRARPer2 { get; set; }
        [DisplayName("CRAR (%)3")]
        [Category("D27")]
        public string CRARPer3 { get; set; }

        [DisplayName("Tier 1 %")]
        [ReadOnly(true)]
        [Category("B28")]
        public string Tier1Per1 { get; set; }
        [DisplayName("Tier 1 %2")]
        [Category("C28")]
        public string Tier1Per2 { get; set; }
        [DisplayName("Tier 1 %3")]
        [Category("D28")]
        public string Tier1Per3 { get; set; }

        [DisplayName("Net NPA (%)")]
        [ReadOnly(true)]
        [Category("B29")]
        public string NetNPAPer1 { get; set; }
        [DisplayName("Net NPA (%)2")]
        [Category("C29")]
        public string NetNPAPer2 { get; set; }
        [DisplayName("Net NPA (%)3")]
        [Category("D29")]
        public string NetNPAPer3 { get; set; }

        [DisplayName("Addition in NPAs/ Advances")]
        [ReadOnly(true)]
        [Category("B30")]
        public string AdditioninNPAsAdvancesPer1 { get; set; }
        [DisplayName("Addition in NPAs/ Advances2")]
        [Category("C30")]
        public string AdditioninNPAsAdvancesPer2 { get; set; }
        [DisplayName("Addition in NPAs/ Advances3")]
        [Category("D30")]
        public string AdditioninNPAsAdvancesPer3 { get; set; }

        [DisplayName("Gross NPA (%)")]
        [ReadOnly(true)]
        [Category("B31")]
        public string GrossNPAPer1 { get; set; }
        [DisplayName("Gross NPA (%)2")]
        [Category("C31")]
        public string GrossNPAPer2 { get; set; }
        [DisplayName("Gross NPA (%)3")]
        [Category("D31")]
        public string GrossNPAPer3 { get; set; }

        [DisplayName("Contingent Liability")]
        [ReadOnly(true)]
        [Category("B32")]
        public string ContingentLiability1 { get; set; }
        [DisplayName("Contingent Liability2")]
        [Category("C32")]
        public string ContingentLiability2 { get; set; }
        [DisplayName("Contingent Liability3")]
        [Category("D32")]
        public string ContingentLiability3 { get; set; }

        [DisplayName("ALM Gap in 6 months bucket")]
        [ReadOnly(true)]
        [Category("B33")]
        public string ALMGapin6monthsbucketPer1 { get; set; }
        [DisplayName("ALM Gap in 6 months bucket2")]
        [Category("C33")]
        public string ALMGapin6monthsbucketPer2 { get; set; }
        [DisplayName("ALM Gap in 6 months bucket3")]
        [Category("D33")]
        public string ALMGapin6monthsbucketPer3 { get; set; }

        [DisplayName("Growth in Membership")]
        [ReadOnly(true)]
        [Category("B34")]
        public string GrowthMembershipPer1 { get; set; }
        [DisplayName("Growth in Membership2")]
        [Category("C34")]
        public string GrowthMembershipPer2 { get; set; }
        [DisplayName("Growth in Membership3")]
        [Category("D34")]
        public string GrowthMembershipPer3 { get; set; }

        [DisplayName("Business per employee")]
        [ReadOnly(true)]
        [Category("B35")]
        public string BusinessEmployee1 { get; set; }
        [DisplayName("Business per employee2")]
        [Category("C35")]
        public string BusinessEmployee2 { get; set; }
        [DisplayName("Business per employee3")]
        [Category("D35")]
        public string BusinessEmployee3 { get; set; }

        [DisplayName("Secured Advances / Total Advances (%)")]
        [ReadOnly(true)]
        [Category("B36")]
        public string SecuredAdvancesTotalAdvancesPer1 { get; set; }
        [DisplayName("Secured Advances / Total Advances (%)2")]
        [Category("C36")]
        public string SecuredAdvancesTotalAdvancesPer2 { get; set; }
        [DisplayName("Secured Advances / Total Advances (%)3")]
        [Category("D36")]
        public string SecuredAdvancesTotalAdvancesPer3 { get; set; }

        [DisplayName("State Economic Growth (GSDP)")]
        [ReadOnly(true)]
        [Category("B37")]
        public string StateEconomicGrowthPer1 { get; set; }
        [DisplayName("State Economic Growth (GSDP)2")]
        [Category("C37")]
        public string StateEconomicGrowthPer2 { get; set; }
        [DisplayName("State Economic Growth (GSDP)3")]
        [Category("D37")]
        public string StateEconomicGrowthPer3 { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDateTime { get; set; }
        public bool IsStaging { get; set; }
        public bool IsFinal { get; set; }
    }
}
