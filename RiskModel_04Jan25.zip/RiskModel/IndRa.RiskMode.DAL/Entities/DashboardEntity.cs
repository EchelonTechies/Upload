﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndRa.RiskModel.DAL.Entities
{
    public class DashboardEntity
    {
        public int DetailsId { get; set; }
        public int CompanyId { get; set; }
        public int? ModelId { get; set; }
        public string CompanyName { get; set; }
        public string ModelName { get; set; }
        public string DateOfInput { get; set; }
        public string ParentRating { get; set; }
        public string CurrencyUnits { get; set; }
        public string AnalystName { get; set; }
        public string createdDate { get; set; }
        public string FinalRating { get; set; }
        public string RatingAsPerModel { get; set; }

        public string Status { get; set; }
        public string FinancialYear { get; set; }

        public bool IsFinal { get; set; }
    }
    public class DashboardAnalystEntity
    {
        public int DetailsId { get; set; }
        public short LogId { get; set; }
        public int CompanyId { get; set; }
        public int ModelId { get; set; }
        public string CompanyName { get; set; }
        public string ModelName { get; set; }
        public string DateOfInput { get; set; }
        public string ParentRating { get; set; }
        public string CurrencyUnits { get; set; }
        public string AnalystName { get; set; }
        public string createdDate { get; set; }
        public string FinalRating { get; set; }
        public string RatingAsPerModel { get; set; }
        public string Status { get; set; }
        public string FinancialYear { get; set; }
        public string IsLogExist { get; set; }

        public string IsFinal { get; set; }
      
    }
}
